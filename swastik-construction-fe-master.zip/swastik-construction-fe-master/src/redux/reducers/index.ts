import { combineReducers } from 'redux';
import selectProjectSlice from '../features/selectProjectSlice';
import openPopoverSlice from '../features/openPopoverSlice';
import loaderSlice from '../features/loadingSlice';
import collapseExpandeSlice from '../features/collapseExpandedSlice';
import openModalSlice from '../features/openModalSlice';

const rootReducer = combineReducers({
  selectedProject: selectProjectSlice,
  openPopover: openPopoverSlice,
  loader: loaderSlice,
  collapseExpande: collapseExpandeSlice,
  openModal: openModalSlice,
});

export default rootReducer;
