import { createSlice } from '@reduxjs/toolkit';

const openModalSlice = createSlice({
  name: 'openModal',
  initialState: {
    open: false,
  },
  reducers: {
    setOpenModal: (state) => {
      state.open = true;
    },
    setCloseModal: (state) => {
      state.open = false;
    },
  },
});

export const { setOpenModal, setCloseModal } = openModalSlice.actions;

export default openModalSlice.reducer;
