import { createSlice } from '@reduxjs/toolkit';
import { MENU_ITEMS } from 'src/constants/menu-items';
const collapseExpandeSlice = createSlice({
  name: 'collapseExpande',
  initialState: {
    isExpanded: false,
    isSubMenuOpen: false,
    dropdownMenus: MENU_ITEMS,
  },
  reducers: {
    toggleExpanded: (state) => {
      state.isExpanded = !state.isExpanded;
    },
    setOpenSubMenu: (state: any, action: any) => {
      const id = action.payload;
      state.dropdownMenus = state?.dropdownMenus?.map((item: any) => {
        if (item.id == id && item.isExpanded !== true) {
          return { ...item, isExpanded: true };
        } else {
          return { ...item, isExpanded: false };
        }
      });
    },
  },
});

export const { toggleExpanded, setOpenSubMenu } = collapseExpandeSlice.actions;

export default collapseExpandeSlice.reducer;
