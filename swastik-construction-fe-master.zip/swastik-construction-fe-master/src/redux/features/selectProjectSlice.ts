import { createSlice } from '@reduxjs/toolkit';

export const selectProjectSlice = createSlice({
  name: 'selectedProject',
  initialState: {
    selectedValue: null,
  },
  reducers: {
    setSelectedValue: (state, action) => {
      state.selectedValue = action.payload;
    }, 
  },
});

export const { setSelectedValue } = selectProjectSlice.actions;

export default selectProjectSlice.reducer;
