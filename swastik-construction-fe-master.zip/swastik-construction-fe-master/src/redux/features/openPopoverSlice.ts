import { createSlice } from '@reduxjs/toolkit';

export const openPopoverSlice = createSlice({
  name: 'openPopover',
  initialState: {
    open: null,
  },
  reducers: {
    setOpenPopover: (state, action) => {
      state.open = action.payload;
    },
  },
});

export const { setOpenPopover } = openPopoverSlice.actions;

export default openPopoverSlice.reducer;
