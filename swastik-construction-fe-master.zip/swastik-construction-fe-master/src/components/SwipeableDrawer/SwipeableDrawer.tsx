import React, { useEffect, useState } from 'react';
import NotificationsOutlined from '@mui/icons-material/NotificationsOutlined';
import {
  Badge,
  List,
  ListItem,
  ListItemText,
  SwipeableDrawer,
} from '@mui/material';
import useGet from '../../hooks/useGet';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import {
  IconButtonContent,
  NotificationButton,
  NotificationHeader,
} from '../../common/styles/NotificationDrawer/styles';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { theme } from 'src/common/styles/theme';
import { materialRequestGetNotification, notification_pending_requests } from 'src/constants/api-routes';


const SwipeableDrawerCustom = () => {
  const router = useRouter()
  const { data: session } = useSession();
  const [openDrawer, setOpenDrawer] = useState(false);
  const { handleGetData, resData } = useGet();
  const { handleGetData: getMaterialNotification, resData: materialNotifiction } = useGet();
  let reversedArray = Array.isArray(resData) ? [...resData].reverse() : resData;
  const badgeContentCount = session?.user?.role_id === 2 ? (resData?.length + parseInt(materialNotifiction?.length)) : 0;
  const [invisible, setInvisible] = React.useState(false);


  // Get notification api
  useEffect(() => {
    getNotification();
    getReturnRequestNotification();
  }, []);

  useEffect(() => {
    if(badgeContentCount !== 0){
      setInvisible(false)
    }else{
      setInvisible(true)
    }
  }, [badgeContentCount])

  const handleClickNotification = () => {
    setOpenDrawer(true)
    getNotification();
    getReturnRequestNotification();
  }

  const getNotification = async () => {
    try {
      const details = await handleGetData(notification_pending_requests);
      return details;
    } catch (err) {
      return err;
    }
  };

  const getReturnRequestNotification = async () => {
    try {
      const details = await getMaterialNotification(`${materialRequestGetNotification}?returnRequest=true&status=pending`)
      return details;
    } catch (err) {
      return err;
    }
  };

  // function for clicking on the notification
  const handleNotificationClick = (notification: any) => {
    router.push(`/request-approval/${notification?.requestId}`)
    setOpenDrawer(false)
  };

  const handleNotificationReturnReqById = (id: number) => {
    router.push(`/request-approval/${id?.returnRequestId}`)
    setOpenDrawer(false)
  }


  return (
    <>
      <IconButtonContent onClick={() => handleClickNotification()}>
        <>
          <Badge color="error" overlap="circular" badgeContent=" " invisible={invisible} variant="dot">
            <NotificationsOutlined sx={{ color: theme.colors.Red}} />
          </Badge>
        </>
      </IconButtonContent>
      <SwipeableDrawer
        anchor={'right'}
        open={openDrawer}
        onClose={() => setOpenDrawer(false)}
        onOpen={() => setOpenDrawer(true)}
        sx={{ width: "25rem" }}
      >
        <List
          sx={{
            width: '100%',
            maxWidth: '27.6rem',
            bgcolor: 'background.paper',
            gap: '10px',
          }}
        > 
           <NotificationHeader>
              <Typography component="span" variant="h5" color="text.primary">
                Notifications
              </Typography> 
            </NotificationHeader>
          <hr></hr>

          {( [0,1,3]?.includes(session?.user?.role_id) && ((reversedArray?.length === 0) || (materialNotifiction?.length === 0))) && <>
            <div style={{ width: "27.5rem" }}>
            <NotificationButton>
              <Typography
              variant="subtitle1"
              >
                No Data Available
              </Typography> 
            </NotificationButton> 
            </div>
          </>}

          {((session?.user?.role_id === 2) && (reversedArray || materialNotifiction)) &&
            <>
              {!reversedArray?.length ?
                <NotificationButton>
                  <Typography
                  variant="subtitle1"
                  >
                      No Data Available
                  </Typography> 
                </NotificationButton> 
              : reversedArray?.map((item:any, index) => {
                return item?.requestId !== null ? (
                  <>
                    <NotificationButton key={index}
                      onClick={() => handleNotificationClick(item)}
                    >
                      <Paper elevation={4}>
                        <ListItem
                          alignItems="flex-start"
                          style={{
                            background:
                              (item?.is_accept == 1 && item?.status == 1) ||
                                (item?.is_accept == 0 && item?.status == 0) ||
                                (item?.is_accept == 1 && item?.status == 0)
                                ? 'white'
                                : '#e4adad59',
                          }}
                        >
                          <ListItemAvatar>
                            <Avatar alt={item?.project_name} src={item?.id} />
                          </ListItemAvatar>
                          <ListItemText
                            primary={item?.project_name}
                            secondary={
                              <React.Fragment>
                                <Typography
                                  sx={{ display: 'inline' }}
                                  component="span"
                                  variant="body2"
                                  color="text.primary"
                                >
                                   Material Requisition Approval Needed : 
                                </Typography>
                                <br/>
                                {` Request Id : ${item?.requestId}`}
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                      </Paper>
                    </NotificationButton>
                  </>
                ) : null;
              })}
              {materialNotifiction?.map((item: any, index: number) => {
                return (
                  <>
                    <NotificationButton key={index}
                      onClick={() => handleNotificationReturnReqById(item)}
                    >
                      <Paper elevation={4}>
                        <ListItem
                          alignItems="flex-start"
                          style={{
                            background:
                              (item?.is_accept == 1 && item?.status == 1) ||
                                (item?.is_accept == 0 && item?.status == 0) ||
                                (item?.is_accept == 1 && item?.status == 0)
                                ? 'white'
                                : '#e4adad59',
                          }}
                        >
                          <ListItemAvatar>
                            <Avatar alt={item?.project_name} src={item?.id} />
                          </ListItemAvatar>
                          <ListItemText
                            primary={item?.project_name}
                            secondary={
                              <React.Fragment>
                                <Typography
                                  sx={{ display: 'inline' }}
                                  component="span"
                                  variant="body2"
                                  color="text.primary"
                                >
                                  Material Return Requisition Approval Needed :
                                </Typography>
                                {` Request Id : ${item?.returnRequestId}`}
                              </React.Fragment>
                            }
                          />
                        </ListItem>
                      </Paper>
                    </NotificationButton>
                  </>)
              })}
            </> 
          }

        </List>
      </SwipeableDrawer>
    </>
  );
};
export default SwipeableDrawerCustom;