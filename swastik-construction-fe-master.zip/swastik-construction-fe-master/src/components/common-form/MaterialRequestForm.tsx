"use client";
import React, { useEffect, useReducer, useCallback } from "react";
import {
  Button,
  FormControl,
  InputLabel,
  FormHelperText,
  Grid,
  TextField,
  Typography,
  Autocomplete,
  CircularProgress,
} from "@mui/material";
import { Asterisk } from "../Modal/styles";
import { Textarea } from "../../constants";
import MaterialRequestTable from "../Table/RequestMaterialTable"; 
import usePost from "../../hooks/usePost";
import { useRouter } from "next/navigation";
import getRequestAPI from "../../services/getRequest";
import _ from "lodash";
import { useSelector } from "react-redux";
import { material_url } from "../../constants/api-routes";
import { toast } from "react-toastify";

interface materialRequestType {
  data?: any;
  url?: any;
  title?: string;
  catItems?: any;
  typeItems?: any;
  refreshData?: any;
}

interface State {
  isFormOpen: boolean;
  formData: any;
  dataArray: any[];
  editingId: number | null;
  materialData: any[];
  resMaterialAllData: any[];
  specificationArray: any[];
  subItems: any[];
  sizeItems: any[]; 
  editedValue: { quantity: string; remark: string };
  requestFormData: any;
  queryParams: any;
  formErrors: { [key: string ]: string | any };
  loading: boolean;
  page: number;
  hasMore: boolean;
  totalItems: number;
}

type Action =
  | { type: "SET_FORM_OPEN"; payload: boolean }
  | { type: "SET_FORM_DATA"; payload: any }
  | { type: "SET_DATA_ARRAY"; payload: any[] }
  | { type: "SET_EDITING_ID"; payload: number | null }
  | { type: "SET_MATERIAL_DATA"; payload: any[] }
  | { type: "SET_SPECIFICATION_ARRAY"; payload: any[] }
  | { type: "SET_SUB_ITEMS"; payload: any[] }
  | { type: "SET_SIZE_ITEMS"; payload: any[] } 
  | { type: "SET_EDITED_VALUE"; payload: { quantity: string; remark: string } }
  | { type: "SET_REQUEST_FORM_DATA"; payload: any }
  | { type: "SET_QUERY_PARAMS"; payload: any }
  | { type: "SET_FORM_ERRORS"; payload: { [key: string]: string | any } }
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_PAGE"; payload: number }
  | { type: "SET_HAS_MORE"; payload: boolean }
  | { type: "SET_TOTAL_ITEMS"; payload: number | any };

const initialState: State = {
  isFormOpen: false,
  formData: {},
  dataArray: [],
  editingId: null,
  materialData: [],
  resMaterialAllData: [],
  specificationArray: [],
  subItems: [],
  sizeItems: [],  
  editedValue: { quantity: "", remark: "" },
  requestFormData: {},
  queryParams: {},
  formErrors: {},
  loading: false,
  page: 1,
  hasMore: true,
  totalItems: 0, 
};

const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case "SET_FORM_OPEN":
      return { ...state, isFormOpen: action.payload };
    case "SET_FORM_DATA":
      return { ...state, formData: action.payload };
    case "SET_DATA_ARRAY":
      return { ...state, dataArray: action.payload };
    case "SET_EDITING_ID":
      return { ...state, editingId: action.payload }; 
    case "SET_MATERIAL_DATA":
      return { ...state, materialData: action.payload };
    case "SET_SPECIFICATION_ARRAY":
      return { ...state, specificationArray: action.payload };
    case "SET_SUB_ITEMS":
      return { ...state, subItems: action.payload };
    case "SET_SIZE_ITEMS":
      return { ...state, sizeItems: action.payload }; 
    case "SET_EDITED_VALUE":
      return { ...state, editedValue: action.payload };
    case "SET_REQUEST_FORM_DATA":
      return { ...state, requestFormData: action.payload };
    case "SET_QUERY_PARAMS":
      return { ...state, queryParams: action.payload };
    case "SET_FORM_ERRORS":
      return { ...state, formErrors: action.payload };
    case "SET_LOADING":
      return { ...state, loading: action.payload };
    case "SET_PAGE":
      return { ...state, page: action.payload };
    case "SET_HAS_MORE":
      return { ...state, hasMore: action.payload };
    case "SET_TOTAL_ITEMS":
      return { ...state, totalItems: action.payload };
    default:
      return state;
  }
};

const MaterialRequestForm = ({ data, url, title, catItems }: materialRequestType) => {
    const initialReqObj = {
      typeId: "1",
      categoryId: 0,
      categoryName: '', 
      machineryOrPrductName: '',
      specification: '',
      itemName: '',
      size: '',
      quantity: '',
      availableQty: '',
      unit: ''
    }
    const [state, dispatch] = useReducer(reducer, initialState);
    const router = useRouter();
    const { handlePostData } = usePost(); 
    const selectedProject = useSelector((state: any) => state?.selectedProject);

    const {
        isFormOpen,
        formData,
        dataArray,
        editingId,
        materialData, 
        specificationArray,
        subItems,
        sizeItems, 
        editedValue,
        requestFormData,
        queryParams,
        formErrors,
        loading,
    } = state;

    useEffect(() => {
        dispatch({ type: "SET_FORM_DATA", payload: data });
    }, [data]);

    const validateMaterial = useCallback(() => {
        const errors: { [key: string]: string } = {};
        if (!requestFormData?.machineryOrPrductId) {
        errors.machineryOrPrductId = "Material is required.";
        }
        if (!requestFormData?.categoryId) {
        errors.categoryId = "Category is required.";
        }
        if (!requestFormData?.quantity) {
        errors.quantity = "Quantity is required.";
        } else if (requestFormData?.quantity <= "0") {
        errors.quantity = "Quantity should be greater than 0.";
        }
        if (subItems?.length && !requestFormData?.itemName) {
        errors.itemName = "Type or grade is required.";
        }
        if (specificationArray?.length && !requestFormData?.specification) {
        errors.specification = "Specification is required.";
        }
        if (sizeItems?.length && !requestFormData?.size) {
        errors.size = "Size is required.";
        }
        dispatch({ type: "SET_FORM_ERRORS", payload: errors });
        return Object.keys(errors).length === 0;
    }, [requestFormData, subItems, specificationArray, sizeItems]);
 
    const handleChange = useCallback((e: any) => {
        const value = e.target.value;
        const key = e.target.name;
        const regex = /^[1-9]\d*$/;
        if (key === "quantity" && (value === "" || regex.test(value))) {
        dispatch({ type: "SET_EDITED_VALUE", payload: { ...editedValue, [key]: parseInt(value) } });
        } else {
        dispatch({ type: "SET_EDITED_VALUE", payload: { ...editedValue, [key]: value } });
        }
    }, [editedValue]);

    const handleEditMaterial = useCallback((id: any, value: any) => {
        dispatch({ type: 'SET_EDITED_VALUE', payload: value})
        dispatch({ type: "SET_EDITING_ID", payload: id })
    },[])

    const handleSave = useCallback(
        (id: any, row:any) => {
        const newDataArray = [...dataArray];
        newDataArray[id] = { ...dataArray[id],  machineryOrPrductId: row?.machineryOrPrductId,quantity: editedValue.quantity, remark: editedValue.remark,  itemName: row?.itemName, specification: row?.specification, size: row?.size }; 
        dispatch({ type: "SET_DATA_ARRAY", payload: newDataArray });
        dispatch({ type: "SET_EDITING_ID", payload: null });
    }, [dataArray, editedValue]);

    const getMaterialData = async(requestedParams:any) => {
        try {
          let searchParams = "";
          const params = Object.keys(requestedParams).reduce((acc: any, key) => {
              if (requestedParams[key] !== undefined &&  requestedParams[key] !== null ) {
                acc[key] = requestedParams[key];
              }
              return acc;
            }, {});
          Object.entries(params)?.map(([key, value]) => {
              searchParams += `${key}=${value}&`
          }) 
          dispatch({ type: "SET_LOADING", payload: true });  
          const response = await getRequestAPI(`${material_url}/?page=1&limit=50&${searchParams}`) 
          dispatch({ type: "SET_LOADING", payload: false }); 
          return response
      } catch (err){
          throw err;
      }       
    }
  
    const addMaterialForm = useCallback(() => {
        if (dataArray.some(item => item?.machineryOrPrductId === requestFormData?.machineryOrPrductId)) {
        toast.error("This item already exists", { position: "top-right", autoClose: 1000 });
         return;
        }
        if (validateMaterial()) {
        const newMaterial = {
            categoryId: requestFormData?.categoryId,
            machineryOrPrductId: requestFormData?.machineryOrPrductId,
            machineryOrPrductName: requestFormData?.machineryOrPrductName,
            subItem: requestFormData?.itemName,
            quantity: requestFormData?.quantity,
            unit: requestFormData?.unit,
            size: requestFormData?.size || requestFormData?.productName?.size,
            specification: requestFormData?.specification,
            categoryName: requestFormData?.categoryName,
            remark: requestFormData?.remark,
            typeId: requestFormData?.typeId,
        };         
        dispatch({ type: "SET_DATA_ARRAY", payload: [...dataArray, newMaterial] });
        toast.success("Successfully added to the list", { position: "top-right", autoClose: 1000 });
        dispatch({ type: "SET_REQUEST_FORM_DATA", payload: initialReqObj });
        dispatch({ type: "SET_FORM_OPEN", payload: false });
        }
    }, [dataArray, requestFormData, validateMaterial]);

    const handleSubmitMaterialRequest = useCallback(async () => { 
        await handlePostData(url, dataArray, title);
        router.back();
    }, [handlePostData, url, dataArray, title, router]);

    const handleFormSubmit = useCallback(
        (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        addMaterialForm();
        dataArray.forEach(item => {
            item.projectId = formData?.projectId;
            item.projectName = formData?.projectName;
        });
        handleSubmitMaterialRequest();
    }, [addMaterialForm, dataArray, formData, handleSubmitMaterialRequest]);
   
    const getMaterialByCategory = async (catId: any) => {
      try { 
          const material_unique_name = '/material/unique-name'
          const response = await getRequestAPI(`${material_unique_name}/?categoryId=${catId}`)   
          return response
      } catch (err){
          throw err;
      }        
    }

    useEffect(() => {
      if(!!catItems?.length) {
        const params = {q :requestFormData?.categoryId } 
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        })
        getMaterialByCategory(requestFormData?.categoryId).then((res: any) => { 
            dispatch({ type: "SET_MATERIAL_DATA", payload: res?.data });  
        })
      } 
    }, [requestFormData.categoryId])

    useEffect(() => {
      if(!!catItems?.length && requestFormData?.machineryOrPrductName != '') {
        const params = {...queryParams}
        params['productName'] = requestFormData?.machineryOrPrductName 
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        })
        getMaterialData(params).then((res: any) => {
            const items = _.uniqBy(res?.data?.items.filter((item: any) => item?.itemName != null), 'itemName');
            if(items?.length == 0) {
              dispatch({
                type: "SET_REQUEST_FORM_DATA",
                payload: { ...requestFormData, itemName: null }
              }) 
            } 
            dispatch({ type: "SET_SUB_ITEMS", payload: items }); 
        })
      } 
    }, [requestFormData?.machineryOrPrductName])

    useEffect(() => {
      if(!!catItems?.length && requestFormData?.machineryOrPrductName != '' && (requestFormData?.itemName != '' || requestFormData?.itemName == null)) {
        const params = {...queryParams}
        params['item'] = requestFormData?.itemName 
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        })
        getMaterialData(params).then((res: any) => { 
            const items = _.uniqBy(res?.data?.items.filter((item: any) => item?.specification != null), 'specification'); 
            if(items?.length == 0) { 
                dispatch({
                  type: "SET_REQUEST_FORM_DATA",
                  payload: { ...requestFormData, specification: null }
                }) 
            } 
            dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: items }); 
        })
      } 
    }, [requestFormData?.itemName])

    useEffect(() => {
        if(!!catItems?.length && requestFormData?.machineryOrPrductName != '' && (requestFormData?.itemName != '' ||  requestFormData?.itemName == null) && (requestFormData?.specification != '' || requestFormData?.specification == null)) {
          const params = {...queryParams}
          params['specification'] = requestFormData?.specification 
          dispatch({
            type: "SET_QUERY_PARAMS",
            payload: params
          })
          getMaterialData(params).then((res: any) => {
              const items:[] = _.uniqBy(res?.data?.items?.filter((item: any) => item?.size != null), 'size');    
              if(items?.length == 0) { 
                  dispatch({
                    type: "SET_REQUEST_FORM_DATA",
                    payload: { ...requestFormData, size: null }
                  }) 
              } 
              dispatch({ type: "SET_SIZE_ITEMS", payload: items }); 
          })
        } 
    }, [requestFormData?.specification])

    useEffect(() => {
      if(!!catItems?.length && requestFormData?.machineryOrPrductName != '' && requestFormData?.itemName != '' && requestFormData?.specification != '' && (requestFormData?.size != '' || requestFormData?.size == null)) {
        const params = {...queryParams}
        params['size'] = requestFormData?.size 
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        })
        getMaterialData(params).then((res: any) => { 
            dispatch({
              type: "SET_REQUEST_FORM_DATA",
              payload: { ...requestFormData,  
                machineryOrPrductId: res?.data?.items[0]?.id, 
                unit: res?.data?.items[0]?.unit }
            })  
        })
      } 
    }, [requestFormData?.size])

    const handleCategoryChange = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: {
          ...requestFormData,
          typeId: "1",
          categoryId: newValue?.id ?? 0,
          categoryName: newValue?.categoryName,  
          machineryOrPrductId: "",
          machineryOrPrductName: "",
          itemName: "",
          specification: "",
          size: "",
          quantity: "",
          unit: "",
        }}) 
      const params = {q: newValue?.id }
      dispatch({
        type: "SET_QUERY_PARAMS",
        payload: params
      }) 
      dispatch({ type: "SET_MATERIAL_DATA", payload: [] });  
      dispatch({ type: "SET_SUB_ITEMS", payload: [] });
      dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: [] });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] }); 
      const updatedErrors = { ...formErrors };
      delete updatedErrors.categoryId;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });  
    }

    const handleProductName = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: {
          ...requestFormData,
          machineryOrPrductId: newValue?.id,
          machineryOrPrductName: newValue?.productName,
          unit: newValue?.unit,
          itemName: "",
          specification: "",
          size: "",
          quantity: "",
        }}) 
      dispatch({ type: "SET_SUB_ITEMS", payload: [] });
      dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: [] });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] }); 
      const updatedErrors = { ...formErrors };
      delete updatedErrors.machineryOrPrductId;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors }); 
    }

    const handleItems = (e: any, newValue: any) => {  
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: { ...requestFormData, machineryOrPrductId: newValue?.id, unit: newValue?.unit, itemName: newValue?.itemName, specification: '', size: '', quantity: '' },
      });
      dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: [] });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] });
      const updatedErrors = { ...formErrors };
      delete updatedErrors.itemName; 
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });
    }

    const handleSpec = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: { ...requestFormData, machineryOrPrductId: newValue?.id, unit: newValue?.unit, specification: newValue?.specification, size: '', quantity: '' },
      });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] });
      const updatedErrors = { ...formErrors };
      delete updatedErrors.specification;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });
    }

    const handleSizeChange = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: { ...requestFormData, machineryOrPrductId: newValue?.id, unit: newValue?.unit, size: newValue?.size },
      });
      dispatch({ type: "SET_QUERY_PARAMS", payload: { ...queryParams, size: newValue?.size } });
      const updatedErrors = { ...formErrors };
      delete updatedErrors.size;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });
    }
 
  return (
    <form onSubmit={handleFormSubmit}>
      <>
        {!isFormOpen && (
          <>
            <Grid sx={{ padding: "20px" }} container spacing={2}>
              <Grid item lg={12} md={6} sm={6} xs={12}>
                <Typography
                  paragraph={true}
                  component={() => (
                    <div style={{ fontSize: "22px", display: "flex", justifyContent: "space-between", width: "70%" }}>
                      <span>Project: {selectedProject?.selectedValue?.name} </span>
                      <span>Location: {selectedProject?.selectedValue?.location} </span>
                    </div>
                  )}
                />
              </Grid>

              {dataArray.length !== 0 && (
                <Grid item lg={12} md={6} sm={6} xs={12}> 
                  <MaterialRequestTable
                    title={"Material Request"}
                    data={dataArray}
                    handleSave={handleSave}
                    editingId={editingId}
                    removeMaterial={(id: any) => dispatch({ type: "SET_DATA_ARRAY", payload: dataArray.filter((_, index) => index != id) })}
                    editMaterial={handleEditMaterial} 
                    handleChange={handleChange}
                    editedValue={editedValue}
                    isApproved={"pending"}
                  />
                </Grid>
              )}

              {formData?.projectId && (
                <Grid item alignItems={"end"} lg={12} md={6} sm={6} xs={12}>
                  <Button style={{ float: "right" }} variant="contained" type="button" onClick={() => dispatch({ type: "SET_FORM_OPEN", payload: !isFormOpen })}>
                    + Add Material
                  </Button>
                  <Button sx={{ float: "right", margin: "0px 10px" }} variant="contained" onClick={() => router.back()}>
                    Cancel
                  </Button>
                </Grid>
              )}
            </Grid>

            {dataArray.length !== 0 && (
              <Grid item lg={6} md={6} sm={6} xs={12}>
                <Button type="submit" variant="contained" style={{ margin: "20px", float: "right" }}>
                  Submit
                </Button>
              </Grid>
            )}
          </>
        )}

        {isFormOpen && (
          <Grid sx={{ padding: "20px" }} container spacing={2}>
            <Grid item lg={12} md={6} sm={6} xs={12}>
              <InputLabel htmlFor="my-input">
                Category <Asterisk>*</Asterisk>
              </InputLabel>
              <FormControl sx={{ width: "100%" }}>
                <Autocomplete
                    size='small'
                    disabled={!catItems?.length}
                    options={catItems}
                    getOptionLabel={(option) => {
                        return typeof option === 'object' ? option?.categoryName : option;
                    }}
                    value={requestFormData?.categoryName}
                    onChange={handleCategoryChange}
                    renderInput={(params) => {
                        return (<TextField {...params} />)
                    }}
                    fullWidth
                /> 
              </FormControl>
              {formErrors.categoryId && (
                <FormHelperText id="project-name-error" error>
                  {formErrors.categoryId}
                </FormHelperText>
              )}
            </Grid>

              <Grid item lg={12} md={6} sm={6} xs={12}>
                <InputLabel htmlFor="my-input">
                  Material <Asterisk>*</Asterisk>
                </InputLabel> 
                <FormControl sx={{ width: "100%" }}>
                    <Autocomplete
                        disabled={materialData.length == 0} 
                        size='small'
                        options={materialData}
                        getOptionLabel={(option) => typeof option == 'object' ? option?.productName : option}
                        value={requestFormData?.machineryOrPrductName}
                        ListboxProps={{  sx: { maxHeight: 150 } }}
                        onChange={handleProductName}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                            InputProps={{
                                    ...params.InputProps,
                                    endAdornment: (
                                        <>
                                            {loading && <CircularProgress color="info" size={30} />}
                                            {params.InputProps.endAdornment}
                                        </>
                                    ),
                                }}
                            />
                        )}
                        isOptionEqualToValue={(option, value) => option?.id === value?.id}
                        fullWidth
                    />
                </FormControl>
                {formErrors.machineryOrPrductId && (
                  <FormHelperText id="project-name-error" error>
                    {formErrors.machineryOrPrductId}
                  </FormHelperText>
                )}
              </Grid>

            {!!subItems?.length && (
              <Grid item lg={6} md={6} sm={6} xs={12}>
                <InputLabel htmlFor="my-input">Type / Grade</InputLabel>
                <FormControl sx={{ width: "100%" }}> 
                  <Autocomplete
                      size='small'
                      options={subItems}
                      getOptionLabel={(option) => typeof option == 'object' ? option?.itemName : option}
                      value={requestFormData?.itemName}
                      onChange={handleItems}
                      renderInput={(params) => {
                          return (<TextField {...params} />)
                      }}
                      fullWidth
                  />
                </FormControl>
                {formErrors.itemName && (
                  <FormHelperText id="error" error>
                    {formErrors.itemName}
                  </FormHelperText>
                )}
              </Grid>
            )}
 
            {!!specificationArray?.length && (
              <Grid item lg={6} md={6} sm={6} xs={12}>
                <InputLabel htmlFor="my-input">Specification</InputLabel>
                <FormControl sx={{ width: "100%" }}>
                  <Autocomplete
                      size='small' 
                      options={specificationArray}
                      getOptionLabel={(option) => typeof option == 'object' ? option?.specification : option} 
                      value={requestFormData?.specification}
                      onChange={handleSpec}
                      renderInput={(params) => {
                          return (<TextField {...params} />)
                      }}
                      fullWidth
                  /> 
                </FormControl>
                {formErrors.specification && (
                  <FormHelperText id="error" error>
                    {formErrors.specification}
                  </FormHelperText>
                )}
              </Grid>
            )}
 
            {!!sizeItems.length && (
              <Grid item lg={6} md={6} sm={6} xs={12}>
                <InputLabel htmlFor="my-input">Size</InputLabel>
                <FormControl sx={{ width: "100%" }}> 
                   <Autocomplete
                      size='small' 
                      options={sizeItems}
                      getOptionLabel={(option) => typeof option == 'object' ? option?.size : option}  
                      value={requestFormData?.size}
                      onChange={handleSizeChange}
                      renderInput={(params) => {
                          return (<TextField {...params} />)
                      }}
                      fullWidth
                  />
                </FormControl>
                {formErrors.size && (
                  <FormHelperText id="project-name-error" error>
                    {formErrors.size}
                  </FormHelperText>
                )}
              </Grid>
            )}

            <Grid item lg={6} md={6} sm={6} xs={12}>
              <InputLabel htmlFor="my-input">
                Quantity <Asterisk>*</Asterisk>
              </InputLabel>
              <FormControl sx={{ width: "100%" }}>
                <TextField
                  size="small"
                  type="text"
                  id="my-input"
                  autoComplete="off"
                  value={requestFormData?.quantity}
                  onChange={(e) => {
                    const value = e.target.value;
                    const regex = /^[1-9]\d*$/;
                    if (regex.test(value) || value === "") {
                      dispatch({
                        type: "SET_REQUEST_FORM_DATA",
                        payload: { ...requestFormData, quantity: value },
                      });
                      dispatch({ type: "SET_FORM_ERRORS", payload: { ...formErrors, quantity: undefined } });
                    }
                  }}
                  aria-describedby="my-helper-text"
                />
              </FormControl>
              {formErrors.quantity && (
                <FormHelperText id="project-name-error" error>
                  {formErrors?.quantity}
                </FormHelperText>
              )}
            </Grid>

            <Grid item lg={6} md={6} sm={6} xs={12}>
              <InputLabel htmlFor="my-input">Unit</InputLabel>
              <FormControl sx={{ width: "100%" }}>
                <TextField
                  size="small"
                  type="text"
                  id="my-input"
                  autoComplete='off'
                  disabled
                  defaultValue={requestFormData?.unit}
                  aria-describedby="my-helper-text"
                />
              </FormControl>
            </Grid>

            <Grid item lg={6} md={6} sm={6} xs={12}>
              <InputLabel htmlFor="my-input">Remark </InputLabel>
              <FormControl sx={{ width: "100%" }}>
                <Textarea 
                  sx={{resize: 'none'}}
                  type="text"
                  id="my-input"
                  value={requestFormData?.remark}
                  onChange={(e) => {
                    const value = e.target.value;
                    dispatch({
                      type: "SET_REQUEST_FORM_DATA",
                      payload: { ...requestFormData, remark: value },
                    });
                  }}
                  aria-describedby="my-helper-text"
                />
              </FormControl>
            </Grid>

            <Grid item lg={12} md={6} sm={6} xs={12}>
              <Button variant="contained" style={{ margin: "10px", float: "right" }} onClick={addMaterialForm}>
                Add
              </Button>
              <Button
                variant="contained"
                style={{ margin: "10px", float: "right" }}
                onClick={() => {
                  dispatch({ type: "SET_FORM_OPEN", payload: false }); 
                  dispatch({ type: "SET_REQUEST_FORM_DATA", payload: initialReqObj });
                }}
              >
                Cancel
              </Button>
            </Grid>
          </Grid>
        )}
      </>
    </form>
  );
};

export default MaterialRequestForm;
