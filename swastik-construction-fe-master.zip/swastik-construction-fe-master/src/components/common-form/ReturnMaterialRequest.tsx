"use client"
import React, { useCallback, useEffect, useRef, useState } from 'react'
import {
    Button,
    FormControl,
    InputLabel,
    FormHelperText,
    Grid,
    TextField,
    Typography,
    Autocomplete,
    CircularProgress,
} from '@mui/material';
import { Asterisk } from '../Modal/styles';
import { Textarea } from '../../constants';
import MaterialRequestTable from '../Table/RequestMaterialTable';
import usePost from '../../hooks/usePost';
import { useRouter } from 'next/navigation';
import getRequestAPI from '../../services/getRequest';
import _ from 'lodash';
import { useSelector } from 'react-redux';
import { return_request, site_inventory_url } from '../../constants/api-routes';
import {toast} from 'react-toastify';

interface returnMaterialRequestType {
    data?: any;
    title?: string;
    catItems?: any;
    projectItems?: any;
    typeItems?: any;
    refreshData?: any;
}

const ReturnMaterialRequest = ({ data, title }: returnMaterialRequestType) => { 
    const initialReqObj = {
        typeId: "1",
        categoryId: 0,
        categoryName: '',
        materialId: 0,
        machineryOrPrductName: '',
        specification: '',
        itemName: '',
        size: '',
        quantity: '',
        availableQty: '',
        unit: ''
    }
    const router = useRouter()
    const { handlePostData } = usePost()
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [categoryData, setCategoryData] = useState<any>([])
    const [formData, setFormData] = React.useState(data);
    const [dataArray, setDataArray] = useState<any>([])
    const [editingId, setEditingId] = useState(null);
    const [materialData, setMaterialData] = useState<any>([])
    const [specificationArray, setSpecificationArray] = useState<any>([]);
    const [sizeItems, setSizeItems] = useState<any>([])
    const [editedValue, setEditedValue] = useState({ quantity: '', remark: '' });
    const [requestFormData, setRequestFormData] = useState<any>(initialReqObj);
    const [queryParams, setQueryParams] = useState<any>({})
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const [itemNameArray, setItemNameArray] = useState<any>([])
    const [page, setPage] = useState(1)
    const [totalItems, setTotalItems] = useState(0)
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        if(selectedProject?.selectedValue?.name) {
            const params = {projectName: selectedProject?.selectedValue?.name}
            setQueryParams(params)
            getMaterialData(params).then((res: any) => {
                const uniqCat = _.uniqBy(res.data.items, 'categoryName')
                setCategoryData(uniqCat)
            })
        }  
    }, [selectedProject])

    useEffect(() => {
      if(!!categoryData.length) {
        const params = {...queryParams}
        params['q'] = requestFormData.categoryId
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            let resData = _.uniqBy(res.data.items, 'productName')
            setMaterialData(resData)
        })
      } 
    }, [requestFormData.categoryId])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '') {
        const params = {...queryParams}
        params['productName'] = requestFormData.machineryOrPrductName
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.itemName != null), 'itemName');
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    itemName: null,
                })
            }
            setItemNameArray(items)
        })
      } 
    }, [requestFormData.machineryOrPrductName])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' || requestFormData.itemName == null)) {
        const params = {...queryParams}
        params['itemName'] = requestFormData.itemName
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.productSpecification != null), 'productSpecification');   
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    specification: null
                })
            }
            setSpecificationArray(items)
        })
      } 
    }, [requestFormData.itemName])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' ||  requestFormData.itemName == null) && (requestFormData.specification != '' || requestFormData.specification == null)) {
        const params = {...queryParams}
        params['specification'] = requestFormData.specification
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => {
            const items:[] =_.uniqBy(res.data.items.filter((item: any) => item?.productSize != null), 'productSize');    
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    size: null
                })
            }
            setSizeItems(items)
        })
      } 
    }, [requestFormData.specification])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && requestFormData.itemName != '' && requestFormData.specification != '' && (requestFormData.size != '' || requestFormData.size == null)) {
        const params = {...queryParams}
        params['size'] = requestFormData.size
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            setRequestFormData({
                ...requestFormData,
                materialId: res?.data?.items[0]?.productId,
                availableQty: res?.data?.items[0]?.siteInventoryAvailableQuantity,
                unit: res?.data?.items[0]?.productUnit
            }) 
        })
      } 
    }, [requestFormData.size])
     
    useEffect(() => {
        setFormData(data)
    }, [data])
 
    const validateMaterial = () => {
        const errors: { [key: string]: string } = {};
        if (!requestFormData?.materialId) {
            errors.materialId = 'Material is required.';
        } else {
            delete errors.materialId;
        }
        if (!requestFormData?.categoryId) {
            errors.categoryId = 'Category is required.';
        } else {
            delete errors.categoryId;
        }
        if (!!itemNameArray.length) {
            if (!requestFormData?.itemName) {
                errors.itemName = 'Type or Grade is required.';
            } else {
                delete errors.itemName;
            }
        }
        if (!!specificationArray.length) {
            if (!requestFormData?.specification) {
                errors.specification = 'Specification is required.';
            } else {
                delete errors.specification;
            }
        }
        if (!!sizeItems.length) {
            if (!requestFormData?.size) {
                errors.size = 'Size is required.';
            } else {
                delete errors.size;
            }
        }
        if (!requestFormData?.quantity) {
            errors.quantity = 'Quantity is required.';
        } else {
            delete errors.quantity;
        }
        setFormErrors(errors)
        return Object.keys(errors).length === 0;
    }

    const removeMaterial = (id: any, mId: number) => {
        const newData = dataArray.filter((_: any, index: any) => index != id);
        setDataArray(newData);
    }

    const editMaterial = (id: any, value: any) => {
        setEditingId(id);
        setEditedValue(value);
    }

    const handleChange = (e: any, data?: any) => {
        const value = e.target.value;
        const regex = /^[1-9]\d*$/;
        const key = e.target.name;
        if (key === 'quantity') {
            if ((value === '' || regex.test(value)) && (data?.availableQty >= value)) {
                const newQuantity = parseInt(value);
                setEditedValue(prevState => ({
                    ...prevState,
                    [e.target.name]: newQuantity
                }));
            }
        } else {
            setEditedValue(prevState => ({
                ...prevState,
                [e.target.name]: value
            }));
        }
    }

    const handleSave = (id: any, row: any) => {
        let copyData = [...dataArray]
        copyData[id] = { ...dataArray[id], materialId: row?.materialId, ['quantity']: editedValue.quantity, ['remark']: editedValue.remark, itemName: row?.itemName, specification: row?.specification, size: row?.size }
        setDataArray(copyData)
        setEditingId(null)
    };

    const addMaterialForm = () => {
        const isValid = validateMaterial();
        const exists = dataArray.some(item => item?.materialId === requestFormData?.materialId);

        if (exists) {
            toast.error('This item is already exist', {
                autoClose: 1000,
            })
        } else if (isValid && !exists) {
            setDataArray((prevState: any) => [...prevState, {
                ['categoryId']: requestFormData?.categoryId,
                ['machineryOrPrductName']: requestFormData?.machineryOrPrductName,
                ['unit']: requestFormData?.unit,
                ['size']: requestFormData?.size?.productSize ?? requestFormData?.size,
                ['specification']: requestFormData?.specification?.productSpecification ?? requestFormData?.specification,
                ['categoryName']: requestFormData?.categoryName,
                ['remark']: requestFormData?.remark,
                ['typeId']: '1',
                ["materialId"]: requestFormData?.materialId,
                ["itemName"]: requestFormData?.itemName ?? requestFormData?.itemName,
                ["quantity"]: requestFormData?.quantity,
                ["availableQty"]: requestFormData?.availableQty
            }]);
            setRequestFormData(initialReqObj)
            setIsFormOpen(false)
            toast.success("Successfully added to the list", { autoClose: 1000 })
            setQueryParams({})
        }
    }
 
    const handleCancelMaterial = () => { 
        setRequestFormData(initialReqObj)  
        setIsFormOpen(false)
    }

    const handleSubmitMaterialRequest = async () => {
        const res = await handlePostData(return_request, dataArray, title);
        router.back()
        return res;
    }

    const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        addMaterialForm()
        for (let i = 0; i < dataArray?.length; i++) {
            dataArray[i].projectId = formData?.projectId;
        }
        handleSubmitMaterialRequest()
    }

    const getMaterialData = async (requestedParams: any) => {
        try {
            let searchParams = "";
            const params = Object.keys(requestedParams).reduce((acc: any, key) => {
                if (requestedParams[key] !== undefined &&  requestedParams[key] !== null ) {
                  acc[key] = requestedParams[key];
                }
                return acc;
              }, {});
            Object.entries(params)?.map(([key, value]) => {
                searchParams += `${key}=${value}&`
            })
            setLoading(true)
            const response = await getRequestAPI(`${site_inventory_url}/?page=${page}&limit=50&${searchParams}`)
            setTotalItems(response?.data?.metadata?.totalItems)
            setLoading(false)
            return response
        } catch (err){
            throw err;
        }        
    }

    const handleScroll = useCallback((event: React.SyntheticEvent) => {
        const listboxNode = event.currentTarget;
        if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight) {
            if (!loading){
                if ((materialData?.length <= totalItems)) {
                    setPage(page + 1)
                }
            }
        }
    }, [loading, page]);  
  
    const handleCategoryChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            categoryId: newValue?.categoryId ?? 0,
            categoryName: newValue?.categoryName,    
            machineryOrPrductName: '',
            itemName: '',
            specification: '',
            size: '',
            availableQty: '',
            quantity: '' 
        })
        const params = {projectName: selectedProject?.selectedValue?.name}
        setQueryParams(params)
        setMaterialData([])
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.categoryId;
        setFormErrors(updatedErrors);
    }

    const handleProductName = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            machineryOrPrductName: newValue?.productName,
            materialId: newValue?.productId,
            itemName: '',
            specification: '',
            size: '', 
            quantity: '' 
        }) 
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.materialId;
        setFormErrors(updatedErrors)
    }

    const handleItems = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            itemName: newValue?.itemName, 
            specification: '',
            size: '',  
            quantity: '' 
        })  
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.itemName;
        setFormErrors(updatedErrors)
    }

    const handleSpec = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            specification: newValue?.productSpecification, 
            size: '',  
            quantity: ''  
        }) 
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.specification;
        setFormErrors(updatedErrors)
    }

    const handleSizeChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            size: newValue?.productSize, 
        })
        const updatedErrors = { ...formErrors };
        delete updatedErrors.size;
        setFormErrors(updatedErrors)
    }
 
    return (
        <form onSubmit={handleFormSubmit}>
            <>
                {!isFormOpen && <>
                    <Grid sx={{ padding: '20px' }} container spacing={2}>
                        <Grid item lg={12} md={6} sm={6} xs={12}>
                            <Typography paragraph={true} component={() => {
                                return <>
                                    <div style={{
                                        fontSize: '22px',
                                        display: 'flex',
                                        justifyContent: ' space-between',
                                        width: '70%'
                                    }}>
                                        <span>Project: {selectedProject?.selectedValue?.name} </span> <span >Location:  {selectedProject?.selectedValue?.location} </span>
                                    </div>
                                </>
                            }}
                            />
                        </Grid>
                        {dataArray.length !== 0 && <Grid item lg={12} md={6} sm={6} xs={12}>
                            <MaterialRequestTable
                                title={"Return Request"}
                                requestType="Return Request"
                                data={dataArray}
                                handleSave={handleSave}
                                editingId={editingId}
                                removeMaterial={removeMaterial}
                                editMaterial={editMaterial}
                                handleChange={handleChange}
                                editedValue={editedValue}
                                isApproved={"pending"}
                            />
                        </Grid>}

                        {
                            formData?.projectId && <Grid item alignItems={'end'} lg={12} md={6} sm={6} xs={12}>
                                <Button style={{ float: 'right' }} variant='contained' type='button' onClick={() => setIsFormOpen(!isFormOpen)}> + Add Material </Button>
                                <Button sx={{ float: 'right', margin: '0px 10px' }} variant='contained' onClick={() => router.back()}>Cancel</Button>
                            </Grid>
                        }
                    </Grid>

                    {!!dataArray?.length && <Grid item lg={6} md={6} sm={6} xs={12}>
                        <Button
                            type="submit"
                            variant="contained"
                            style={{ margin: '20px', float: 'right' }}
                        >
                            Submit
                        </Button>
                    </Grid>}
                </>}

                <Grid sx={{ padding: '20px' }} container spacing={2}>
                    {
                        isFormOpen &&
                        <Grid container spacing={2}>
                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                <Typography paragraph={true} component={() => {
                                    return <>
                                        <div style={{
                                            fontSize: '30px',
                                            display: 'flex',
                                            justifyContent: 'space-between',
                                            width: '70%'
                                        }}>
                                            <span> Return Material Request</span>
                                        </div>
                                    </>
                                }}
                                />
                            </Grid>
                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Category <Asterisk>*</Asterisk></InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <Autocomplete
                                        size='small'
                                        disabled={!categoryData.length}
                                        options={categoryData}
                                        getOptionLabel={(option) => {
                                            return typeof option == 'object' ? option?.categoryName : option;
                                        }}
                                        value={requestFormData?.categoryName}
                                        onChange={handleCategoryChange}
                                        renderInput={(params) => {
                                            return (<TextField {...params} />)
                                        }}
                                        fullWidth
                                    />
                                </FormControl>
                                {formErrors.categoryId && (
                                    <FormHelperText id="project-name-error" error>
                                        {formErrors.categoryId}
                                    </FormHelperText>
                                )}
                            </Grid>

                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Material <Asterisk>*</Asterisk></InputLabel>
                                    <FormControl
                                        sx={{ width: '100%' }}
                                    >
                                        <Autocomplete
                                            disabled={materialData.length == 0} 
                                            size='small'
                                            options={materialData}
                                            getOptionLabel={(option) => typeof option == 'object' ? option?.productName : option}
                                            value={requestFormData?.machineryOrPrductName}
                                            ListboxProps={{ onScroll: handleScroll, sx: { maxHeight: 150 } }}
                                            onChange={handleProductName}
                                            renderInput={(params) => (
                                                <TextField
                                                    {...params}
                                                InputProps={{
                                                        ...params.InputProps,
                                                        endAdornment: (
                                                            <>
                                                                {loading && <CircularProgress color="info" size={30} />}
                                                                {params.InputProps.endAdornment}
                                                            </>
                                                        ),
                                                    }}
                                                />
                                            )}
                                            isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                            fullWidth
                                        />
                                        {formErrors.materialId && (
                                            <FormHelperText id="project-name-error" error>
                                                {formErrors.materialId}
                                            </FormHelperText>
                                        )}
                                    </FormControl>
                             </Grid>

                            {!!itemNameArray?.length && <>
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Type / Grade</InputLabel>
                                    <FormControl sx={{ width: '100%' }}>
                                        <Autocomplete
                                            size='small'
                                            options={itemNameArray}
                                            getOptionLabel={(option) => typeof option == 'object' ? option?.itemName : option}
                                            value={requestFormData?.itemName}
                                            onChange={handleItems}
                                            renderInput={(params) => {
                                                return (<TextField {...params} />)
                                            }}
                                            fullWidth
                                        />
                                    </FormControl>
                                    {formErrors.itemName && (
                                        <FormHelperText id="itemName-error" error>
                                            {formErrors?.itemName}
                                        </FormHelperText>
                                    )}
                                </Grid>
                            </>}

                            {!!specificationArray?.length && <>
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Specification</InputLabel>
                                    <FormControl
                                        sx={{ width: '100%' }}
                                    >
                                        <Autocomplete
                                            size='small' 
                                            options={specificationArray}
                                            getOptionLabel={(option) => option?.productSpecification ?? option}
                                            value={requestFormData?.specification}
                                            onChange={handleSpec}
                                            renderInput={(params) => {
                                                return (<TextField {...params} />)
                                            }}
                                            fullWidth
                                        />
                                    </FormControl>
                                    {formErrors.specification && (
                                        <FormHelperText id="specification-error" error>
                                            {formErrors?.specification}
                                        </FormHelperText>
                                    )}
                                </Grid>
                            </>}

                            {!!sizeItems.length && <>
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Size</InputLabel>
                                    <FormControl sx={{ width: '100%' }}>
                                        <Autocomplete
                                            size='small' 
                                            options={sizeItems}
                                            getOptionLabel={(option) => option?.productSize ?? option}
                                            value={requestFormData?.size}
                                            onChange={handleSizeChange}
                                            renderInput={(params) => {
                                                return (<TextField {...params} />)
                                            }}
                                            fullWidth
                                        />
                                    </FormControl>
                                    {formErrors.size && (
                                        <FormHelperText id="size-error" error>
                                            {formErrors?.size}
                                        </FormHelperText>
                                    )}
                                </Grid>
                            </>}

                            { !!requestFormData?.availableQty &&
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Available Qty</InputLabel>
                                    <FormControl
                                        sx={{ width: '100%' }}
                                    >
                                        <TextField
                                            size='small'
                                            type="text"
                                            id="my-input"
                                            autoComplete="off"
                                            disabled={true}
                                            value={requestFormData?.availableQty}
                                            aria-describedby="my-helper-text"
                                        />
                                    </FormControl>
                                </Grid>}

                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Quantity <Asterisk>*</Asterisk></InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <TextField
                                        autoComplete="off"
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        value={requestFormData?.quantity}
                                        onChange={(e) => {
                                            let value = e.target.value;
                                            const numericValue = Number(value);
                                            const regex = /^[1-9]\d*$/;
                                            regex.test(value)
                                            if (((regex.test(value)) || (value === '')) && requestFormData?.availableQty >= numericValue) {
                                                setRequestFormData({
                                                    ...requestFormData,
                                                    quantity: value,
                                                })
                                                const updatedErrors = { ...formErrors };
                                                delete updatedErrors.quantity;
                                                setFormErrors(updatedErrors)
                                            }
                                        }}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                                {formErrors.quantity && (
                                    <FormHelperText id="project-name-error" error>
                                        {formErrors?.quantity}
                                    </FormHelperText>
                                )}
                            </Grid>

                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Unit</InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    <TextField 
                                        autoComplete='off'
                                        size='small' 
                                        type="text"
                                        id="my-input"
                                        value={requestFormData?.unit}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                            </Grid>

                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Remark <Asterisk>*</Asterisk></InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    <Textarea
                                        sx={{resize: 'none'}}
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        value={requestFormData?.remark}
                                        onChange={(e) => {
                                            let value = e.target.value;
                                            setRequestFormData({
                                                ...requestFormData,
                                                remark: value,
                                            })
                                        }}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                            </Grid>

                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={addMaterialForm}>Add</Button>
                                <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={() => handleCancelMaterial()}>Cancel</Button>
                            </Grid>
                        </Grid>
                    }
                </Grid>
            </>
        </form>
    )
}

export default ReturnMaterialRequest