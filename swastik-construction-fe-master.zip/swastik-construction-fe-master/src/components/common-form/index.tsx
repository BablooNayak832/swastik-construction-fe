import * as React from 'react';
import {
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  FormHelperText,
  Grid,
  Checkbox,
  ListItemText,
  TextField,
  FormGroup,
  FormControlLabel,
  IconButton,
  InputAdornment, 
} from '@mui/material';
import { Asterisk, MainFormLayout } from '../Modal/styles';
import { MainConteiner } from '../../common/styles/common-form/styles';
import { useAllowedNavigation } from '../../context/context';
import { Textarea } from '../../constants';
import { useState } from 'react';
import CardContent from '@mui/material/CardContent';
import usePost from '../../hooks/usePost';  
import { Visibility, VisibilityOff } from '@mui/icons-material'; 
import { useSession } from 'next-auth/react'; 
import Chip from '@material-ui/core/Chip';
import { makeStyles } from '@material-ui/core/styles';
import moment from 'moment';
import Link from 'next/link';
import { handleValidateForm } from '../commonComponents/handleMessageToaster';
import {MenuProps} from 'src/constants/table-columns';
import Image from 'next/image';
 
const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    alignItems: 'center',
  },
  chip: {
    margin: theme.spacing(0.5),
  },
}));

type MainFormType = {
  data?: any;
  url?: string;
  title?: string;
  selectItem?: any;
  projectItems?: [] | any;
  userItems?: [] | any;
  refreshData: () => void;
  brandItems?: [] | any;
  typeItems?: [] | any;
  catItems?: [] | any;
  quantityFormPrefill?: any;
};

const MainForm = ({
  data,
  url,
  title,
  selectItem,
  refreshData,
  projectItems,
  catItems,
  brandItems,
  quantityFormPrefill,
}: MainFormType) => {

  const [formData, setFormData] = React.useState<any>(data);
  const [selectItems, setSelectItems] = React.useState(selectItem); 
  const { setOpenDialog, setRenderData } = useAllowedNavigation();
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});  
  const [showPassword, setShowPassword] = React.useState(false);
  const classes = useStyles();
  const [inputValue, setInputValue] = useState<any>({});
  const [tags, setTags] = useState<any>({ size: [], type: [], specification: [] }); 
  const { data: session } = useSession() 
  const { handlePostData } = usePost();

  //Validate forms
  const errors: { [key: string]: string } = {};
  const validateForm = () => {
    const isValid = handleValidateForm(formData, title, session?.user?.role_id)
    setFormErrors(isValid);
    return Object.keys(isValid).length === 0; // Returns true if no errors found
  };

  React.useEffect(() => {
    setSelectItems(selectItems);
  }, []);

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      try {
        const res = await handlePostData(url, formData, title);
        refreshData();
        setRenderData(true);
        setOpenDialog(false);
        return res;
      } catch (error) { }
      setRenderData(true);
    }
  };
  
  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault(); 
    if (title === 'Add Staff') {
      const isValid = validateForm();
      const newFormData = new FormData();
      newFormData.append('name', formData?.name)
      newFormData.append('mobileNumber', formData?.mobileNumber)
      newFormData.append('image', formData?.image)
      newFormData.append('projectId', formData?.projectId)

      if (isValid) {
        try {
          const res = await handlePostData(url, newFormData, title);
          refreshData();
          setRenderData(true);
          setOpenDialog(false);
          return res;
        } catch (error) { }
        setRenderData(true);
      }
    } else if(title === 'Add Material') {
      const formDataObj = new FormData();
      const isValid = validateForm();
      if (isValid) { 
        Object.entries(formData).map(([key, value]) => { 
          const valueArray = Array.isArray(value) ? value?.join(',') : value  ;
          if(valueArray !== undefined) { 
            
            formDataObj.append(key, valueArray)
          }
        })
        await handlePostData(url, formDataObj, title);
         refreshData();
         setRenderData(true);
         setOpenDialog(false);

      }
    } else if(title === 'Add User'){
      const payload = {   
            email: formData?.email ?? null,
            mobileNumber:	formData?.mobileNumber,
            name:	formData?.name,
            password:	formData?.password,
            projectId	:formData?.projectId,
            roleId:	formData?.roleId
         }
         const isValid = validateForm();
         if (isValid) {
           try {
             const res = await handlePostData(url, payload, title);
             refreshData();
             setRenderData(true);
             setOpenDialog(false);
             return res;
           } catch (error) { }
           setRenderData(true);
         }
    } else {
      handleSubmit(e);
    }
  };
 
  React.useEffect(() => {
    if (quantityFormPrefill?.id !== undefined) {
      setFormData({
        ...formData,
        storeId: quantityFormPrefill.id,
      });
    }
  }, [quantityFormPrefill?.id]);

  const handleClickShowPassword = () => setShowPassword((show) => !show)
 
  const handleInputChange = (event: any) => { 
    setInputValue({
      ...inputValue,
      [event.target.name]: event.target.value,
    })
  };

  const handleInputKeyDown = (event: any) => {
    if (event.key === 'Shift' && inputValue?.size?.trim() !== '') {
      setTags({
        ...tags,
        size: [...tags?.size, inputValue?.size?.trim()],
      })
      setInputValue({ size: '' });

      setFormData({
        ...formData,
        size: [...tags?.size, inputValue?.size?.trim()],
      })
    } else {
      if (formData?.size?.length === 0) {
        setFormData({
          ...formData,
          size: null,
        })
      }
    }
  };
 
  const handleChipDelete = (tagToDelete: any, type: string) => {
    if (type === 'size') {
      setTags({
        ...tags,
        size: tags?.size?.filter(tag => (tag !== tagToDelete)),
      })
      setFormData({
        ...formData,
        size: tags?.size?.filter(tag => (tag !== tagToDelete)),
      })
    }

    if (type === 'type') {
      setTags({
        ...tags,
        type: tags?.type?.filter(tag => tag !== tagToDelete),
      })
      setFormData({
        ...formData,
        type: tags?.type.filter(tag => tag !== tagToDelete),
      })
    }

    if (type === 'specification') {
      setTags({
        ...tags,
        specification: tags?.specification?.filter(tag => tag !== tagToDelete),
      })
      setFormData({
        ...formData,
        specification: tags?.specification.filter(tag => tag !== tagToDelete),
      })
    }
  };
 
  const handleFileUpload = (event: any) => {
    const file = event?.target?.files[0];
    const imageSizeInBytes: any = file?.size;
    const getImageSizeInKB: any = imageSizeInBytes / 1024;

    if (file && file?.type?.startsWith("image/")) {
      setFormData({
        ...formData,
        image: file,
        imagePreview: URL.createObjectURL(file)
      });
    }
    if (getImageSizeInKB >= 300) {
      setFormErrors({ ...errors, ["image"]: 'Please upload an image smaller than 300kb.' })
    } else {
      delete errors.image;
      setFormErrors(errors)
    }
  };
 
  return (
    <>
      <MainConteiner>
        <CardContent>
          <form onSubmit={handleFormSubmit}>
            <MainFormLayout>
              {title === 'Add Project' && (
                <>
                  <Grid container spacing={2}>
                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Project Name <Asterisk>*</Asterisk> </InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          id="outlined-basic"
                          placeholder="Project Name"
                          variant="outlined"
                          value={formData?.projectName}
                          onChange={(e) => {
                            const value = e.target.value;
                            if(value?.length <= 20){ 
                              setFormData({
                                ...formData,
                                projectName: value,
                                salesStatus: ((session?.user?.role_id === 0) || (session?.user?.role_id === 1)) ? "active" : "rejected"
                              });
                            }
                            if (value.trim() !== '') {
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.projectName;
                              setFormErrors(updatedErrors);
                            }
                          }}
                        />
                        {formErrors.projectName && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.projectName}
                          </FormHelperText>
                        )}
                      </FormControl>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">
                        Project ID <Asterisk>*</Asterisk>
                      </InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          id="outlined-basic"
                          placeholder="Unique ID"
                          value={formData?.siteId}
                          onChange={(e) => {
                            const value = e.target.value;
                            if(value?.length <= 12 ){
                              setFormData({
                                ...formData,
                                siteId: value,
                              }); 
                            }
                            if (value.trim() !== '') {
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.siteId;
                              setFormErrors(updatedErrors);
                            }
                          }}
                          aria-describedby="my-helper-text"
                        />
                        {formErrors.siteId && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.siteId}
                          </FormHelperText>
                        )}
                      </FormControl>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Location <Asterisk>*</Asterisk> </InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          id="outlined-basic"
                          placeholder='Location'
                          value={formData?.location}
                          onChange={(e) => {
                            const value = e.target.value;
                            setFormData({
                              ...formData,
                              location: value,
                            });
                            if (value.trim() !== '') {
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.location;
                              setFormErrors(updatedErrors);
                            }
                          }}
                          aria-describedby="my-helper-text"
                        />
                        {formErrors.location && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.location}
                          </FormHelperText>
                        )}
                      </FormControl>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input"> Latitude / Longitude <Asterisk>*</Asterisk> <Link style={{ textDecoration: 'none' }} href={'https://www.google.com/maps/@22.7378602,75.8882504,15z?entry=ttu'} target='_blank'><span style={{ fontSize: '12px' }}>Google map...</span> </Link></InputLabel>
                      <FormControl sx={{ width: '100% ' }}>
                        <div style={{ display: 'flex' }}>
                          <TextField
                            sx={{ paddingRight: '2px' }}
                            size='small'
                            id="outlined-basic"
                            placeholder='Latitude'
                            value={formData?.latitude}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData({
                                ...formData,
                                latitude: value
                              });
                              if (value.trim() !== '') {
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.latitude;
                                setFormErrors(updatedErrors);
                              }
                            }}
                            aria-describedby="my-helper-text"
                          />
                          <TextField
                            sx={{ paddingLeft: '2px' }}
                            size='small'
                            id="outlined-basic"
                            placeholder='Longitude'
                            value={formData?.longitude}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData({
                                ...formData,
                                longitude: value,
                              });
                              if (value.trim() !== '') {
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.longitude;
                                setFormErrors(updatedErrors);
                              }
                            }}
                            aria-describedby="my-helper-text"
                          />
                        </div>
                        {formErrors.location && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.location}
                          </FormHelperText>
                        )}
                      </FormControl>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">Start Date <Asterisk>*</Asterisk></InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                            <input 
                                style={{   
                                  width: 'auto',
                                  height: '30px',
                                  padding: '17px',
                                  fontSize: '15px'
                                }}
                                type="date" 
                                id="endDate" 
                                name="endDate"  
                                value={formData?.startDate} 
                                onChange={(newValue: any) => { 
                                  setFormData({
                                    ...formData,
                                    startDate: moment(newValue?.target?.value).format('YYYY-MM-DD'),
                                  });
                                }} 
                                /> 
                          </FormControl>
                    </Grid>

                    {
                     session?.user?.role_id !== 2 &&
                      <> 
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">End Date </InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                              <input 
                                style={{   
                                  width: 'auto',
                                  height: '30px',
                                  padding: '17px',
                                  fontSize: '15px'
                                }}
                                type="date" 
                                id="endDate" 
                                name="endDate"  
                                value={formData?.endDate} 
                                onChange={(newValue: any) => { 
                                  setFormData({
                                    ...formData,
                                    endDate: moment(newValue?.target?.value).format('YYYY-MM-DD'),
                                  });
                                }}
                                min={formData?.startDate}  
                                disabled={!formData.startDate}
                                /> 
                          </FormControl>
                        </Grid>              
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel>
                            Project Head <Asterisk>*</Asterisk>
                          </InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                            <Select
                              size='small'
                              labelId="demo-multiple-checkbox-label"
                              value={formData?.projectHead}
                              onChange={(event: any) => {
                                const { target: { value } } = event;
                                setFormData({
                                  ...formData,
                                  projectHead: value,
                                });
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.projectHead;
                                setFormErrors(updatedErrors);
                              }}
                              renderValue={(selected: any[]) => {
                                return selectItems?.filter((selectItem: any) => selectItem?.id == selected)?.map((item: any) => item?.name)?.join(', ');
                              }}
                              MenuProps={MenuProps}
                            >
                              { !selectItems?.filter(
                                (item: any) =>
                                  item?.role?.key === 'projectHead'
                              )?.length ? <MenuItem disabled={true}>No Data Available</MenuItem> : selectItems?.filter(
                                (item: any) =>
                                  item?.role?.key === 'projectHead'
                              )
                                ?.map((item: any) => {
                                  return (
                                    <MenuItem key={item.id} value={item.id}>
                                      <ListItemText primary={item.name} />
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                          </FormControl>
                          {formErrors.projectHead && (
                            <FormHelperText id="project-name-error" error>
                              {formErrors.projectHead}
                            </FormHelperText>
                          )}
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel>
                            Site Head
                          </InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                            <Select
                              size='small'
                              id="demo-multiple-checkbox"
                              multiple
                              value={formData?.siteHead}
                              onChange={(event: any) => {
                                const { target: { value } } = event;
                                setFormData({
                                  ...formData,
                                  siteHead: value,
                                });
                              }}
                              renderValue={(selected: any[]) => {
                                return selectItems?.filter((selectItem: any) => selected.includes(selectItem?.id))?.map((item: any) => item?.name)?.join(", ");
                              }}
                              MenuProps={MenuProps}
                            >
                              {!selectItems?.filter((item: any) => item?.role?.key === 'siteHead')?.length ? 
                              <MenuItem disabled={true}>No Data Available</MenuItem> :
                                selectItems?.filter(
                                (item: any) =>
                                  item?.role?.key === 'siteHead'
                                )?.map((item: any) => {
                                  return (
                                    <MenuItem key={item.id} value={item.id}>
                                      <Checkbox size='small'
                                        checked={formData?.siteHead?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item.name} />
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                          </FormControl>
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel>
                            Supervisor
                          </InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                            <Select
                              size='small'
                              labelId="demo-multiple-checkbox-label"
                              id="demo-multiple-checkbox"
                              multiple
                              value={formData?.supervisior}
                              onChange={(event: any) => {
                                const { target: { value } } = event;
                                setFormData({
                                  ...formData,
                                  supervisior: value,
                                });
                              }}
                              renderValue={(selected: any[]) => {
                                return selectItems?.filter((selectItem: any) => selected.includes(selectItem?.id))?.map((item: any) => item?.name)?.join(", ");
                              }}
                              MenuProps={MenuProps}
                            >
                              {!selectItems?.filter(
                                (item: any) =>
                                  item?.role?.key === 'supervisior'
                              )?.length ? <MenuItem disabled={true}>No Data Available</MenuItem> : 
                              selectItems?.filter(
                                (item: any) =>
                                  item?.role?.key === 'supervisior'
                              )
                                ?.map((item: any) => {
                                  return (
                                    <MenuItem key={item.id} value={item.id}>
                                      <Checkbox size='small'
                                        checked={formData?.supervisior?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item.name} />
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                          </FormControl>
                        </Grid>
                      </>
                    }

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Description</InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <Textarea
                          sx={{resize: 'none'}}
                          title="Description"
                          aria-label="minimum height"
                          minRows={3}
                          placeholder="Description..."
                          value={formData?.description}
                          onChange={(e) => {
                            const value = e.target.value;
                            setFormData({
                              ...formData,
                              description: value,
                            });
                            if (value.trim() !== '') {
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.description;
                              setFormErrors(updatedErrors);
                            }
                          }}
                        />
                      </FormControl>
                    </Grid>
                  </Grid>
                </>
              )}

              {title === 'Add Vendor' && (
                  <>
                    <Grid container spacing={2}>
                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input"> Name <Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <TextField
                            size='small'
                            id="outlined-basic"
                            placeholder="Name"
                            variant="outlined"
                            value={formData?.name}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData({
                                ...formData,
                                name: value,
                              });
                              if (value.trim() !== '') {
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.name;
                                setFormErrors(updatedErrors);
                              }
                            }}
                          />
                        </FormControl>
                        {formErrors.name && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.name}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Address <Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <TextField
                            size='small'
                            id="outlined-basic"
                            placeholder="Address"
                            variant="outlined"
                            value={formData?.address}
                            onChange={(e) => {
                              const value = e.target.value;
                              // if (value.trim() !== '') {
                              setFormData({
                                ...formData,
                                address: value,
                              });
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.projectName;
                              setFormErrors(updatedErrors);
                              // }
                            }}
                          />
                        </FormControl>
                        {formErrors?.address && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors?.address}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Contact <Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <TextField
                            size='small'
                            id="outlined-basic"
                            placeholder="Contact"
                            variant="outlined"
                            value={formData?.contact} 
                            onChange={(e) => {
                              const enteredValue = e.target.value;
                              const numericValue = Number(enteredValue); // Convert the value to a number
                              if (
                                !Number.isNaN(numericValue) &&
                                enteredValue.length <= 10
                              ) {
                                setFormData({
                                  ...formData,
                                  contact: enteredValue,
                                });
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.contact;
                                setFormErrors(updatedErrors);
                              }
                            }}
                          />
                        </FormControl>
                        {formErrors.contact && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.contact}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">GSTIN <Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <TextField
                            size='small'
                            id="outlined-basic"
                            placeholder="22AAAAA0000A1Z5"
                            variant="outlined"
                            value={formData?.GSTIN}
                            onChange={(e) => {
                              const value = e.target.value;
                              if (value?.length <= 15) {
                                setFormData({
                                  ...formData,
                                  GSTIN: value,
                                });
                                if (value.trim() !== '') {
                                  const updatedErrors = { ...formErrors };
                                  delete updatedErrors.GSTIN;
                                  setFormErrors(updatedErrors);
                                }
                              }
                            }}
                          />
                        </FormControl>
                        {formErrors.GSTIN && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.GSTIN}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Category</InputLabel>
                        <FormControl size="small" sx={{ width: '100%' }}>
                          <Select
                            id="demo-multiple-checkbox"
                            multiple
                            value={formData?.category}
                            onChange={(event: any) => {
                              const { target: { value } } = event;
                              setFormData({ ...formData, category: value })
                            }}
                            renderValue={(selected: any[]) => {
                              return catItems
                                ?.filter((selectItem: any) =>
                                  selected.includes(selectItem?.id)
                                )
                                ?.map((item: any) => item?.categoryName)
                                .join(',');
                            }}
                            MenuProps={MenuProps}
                          >
                            { !catItems?.length ? <MenuItem>No Data Available</MenuItem> :
                            catItems?.map((item: any) => {
                              return (
                                <MenuItem key={item?.id} value={item?.id}>
                                  <Checkbox size='small'
                                    checked={formData?.category?.indexOf(item.id) > -1}
                                  />
                                  <ListItemText primary={item?.categoryName} />
                                </MenuItem>
                              );
                            })}
                          </Select>
                          {formErrors.category && (
                            <FormHelperText id="project-name-error" error>
                              {formErrors.category}
                            </FormHelperText>
                          )}
                        </FormControl>
                      </Grid>
                    </Grid>
                  </>
              )}

              {title === 'Add User' && (
                <>
                  <Grid container spacing={2}>
                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Name <Asterisk>*</Asterisk></InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          placeholder='Name'
                          id="my-input"
                          value={formData?.name}
                          onChange={(e) => {
                            const value = e.target.value; 
                              setFormData({
                                ...formData,
                                name: value,
                              }); 
                            const updatedErrors = { ...formErrors };
                            delete updatedErrors.name;
                            setFormErrors(updatedErrors);
                          }}
                          aria-describedby="my-helper-text"
                        />
                      </FormControl>
                      {formErrors.name && (
                        <FormHelperText id="category-error" error>
                          {formErrors.name}
                        </FormHelperText>
                      )}
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Email  </InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          id="my-input"
                          type="email"
                          size='small'
                          placeholder='Email'
                          autoComplete="off"
                          defaultValue={data?.email}
                          value={formData?.email}
                          onChange={(e) => {
                            const value = e.target.value; 
                            setFormData({
                              ...formData,
                              email: value,
                            }); 
                            const updatedErrors = { ...formErrors };
                            delete updatedErrors.email;
                            setFormErrors(updatedErrors);
                          }}
                          aria-describedby="my-helper-text"
                        />
                      </FormControl>
                      {formErrors.email && (
                        <FormHelperText id="category-error" error>
                          {formErrors.email}
                        </FormHelperText>
                      )}
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Phone number <Asterisk>*</Asterisk></InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          id="my-input"
                          size='small' 
                          placeholder='Phone Number'
                          value={formData?.mobileNumber}
                          onChange={(e) => {
                            const enteredValue = e.target.value;
                            const numericValue = Number(enteredValue); // Convert the value to a number
                            if (
                              !Number.isNaN(numericValue) &&
                              enteredValue.length <= 10
                            ) {
                              setFormData({
                                ...formData,
                                mobileNumber: enteredValue,
                              });
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.mobileNumber;
                              setFormErrors(updatedErrors);
                            }
                          }}
                          aria-describedby="my-helper-text"
                        />
                      </FormControl>
                      {formErrors.mobileNumber && (
                        <FormHelperText id="category-error" error>
                          {formErrors.mobileNumber}
                        </FormHelperText>
                      )}
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel id="demo-simple-select-label">
                        Role <Asterisk>*</Asterisk>
                      </InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <Select
                          size='small'
                          labelId="demo-simple-select-filled-label"
                          id="demo-simple-select-filled"
                          value={formData?.roleId}
                          onChange={(e) => {
                            const value = e.target.value;
                            setFormData({
                              ...formData,
                              roleId: value,
                            });
                            const updatedErrors = { ...formErrors };
                            delete updatedErrors.roleId;
                            setFormErrors(updatedErrors);
                          }}
                          MenuProps={MenuProps}
                        > { 
                          !selectItem?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                          selectItem?.map(
                            (
                              rItem: any //declare any because in selectItem we are getting multiple types of data
                            ) => (
                              <MenuItem key={rItem.id} value={rItem.id}>
                                {rItem.roleName}
                              </MenuItem>
                            )
                          )}
                        </Select>
                      </FormControl>
                      {formErrors.roleId && (
                        <FormHelperText id="category-error" error>
                          {formErrors.roleId}
                        </FormHelperText>
                      )}
                    </Grid>

                  {( (formData?.roleId !== 1) && (formData?.roleId !== 3) && (formData?.roleId !== 6)) &&
                    <Grid item lg={12} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Project {((formData?.roleId === 4) || (formData?.roleId === 5)) && <Asterisk>*</Asterisk>}</InputLabel>
                      <FormControl
                        sx={{ width: '100%' }}
                      >
                        <Select
                          size='small'
                          labelId="demo-simple-select-filled-label"
                          id="demo-simple-select-filled"
                          value={formData?.projectId}
                          onChange={(e) => {
                            setFormData({
                              ...formData,
                              projectId: e.target.value,
                            });
                            const updatedErrors = { ...formErrors };
                            delete updatedErrors.projectId;
                            setFormErrors(updatedErrors);
                          }}
                          MenuProps={MenuProps}
                        >

                        {!projectItems?.length ? <MenuItem disabled>No Data Available</MenuItem> : 
                          projectItems?.map((item: any) => {
                            return (
                              <MenuItem
                                key={item?.id}
                                value={item?.id}
                              >
                                {item?.projectName}
                              </MenuItem>
                            );
                          })}
                        </Select>
                      </FormControl>
                      {formErrors.projectId && (
                        <FormHelperText id="material-error" error>
                          {formErrors.projectId}
                        </FormHelperText>
                      )}
                    </Grid>}

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Password <Asterisk>*</Asterisk></InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          placeholder="Enter Password"
                          id="my-input"
                          type={showPassword ? 'text' : 'password'}
                          value={formData?.password}
                          autoComplete="new-password"
                          onChange={(e) => {
                            const enteredValue = e.target.value;
                            if (
                              enteredValue.length <= 20
                            ) {
                              setFormData({
                                ...formData,
                                password: enteredValue,
                              });
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.password;
                              setFormErrors(updatedErrors);
                            }
                          }}
                          InputProps={{
                            endAdornment: <>
                              <IconButton onClick={handleClickShowPassword}>
                                {showPassword ? <VisibilityOff /> : <Visibility />}
                              </IconButton>
                            </>
                          }}
                          aria-describedby="my-helper-text"
                        />
                      </FormControl>
                      {formErrors.password && (
                        <FormHelperText id="category-error" error>
                          {formErrors.password}
                        </FormHelperText>
                      )}
                    </Grid>
                  </Grid>
                </>
              )}   

              {title === 'Add Material' && (
                <>
                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Category  <Asterisk>*</Asterisk></InputLabel>
                    <FormControl
                      sx={{ width: '100%' }}
                    >
                      <Select
                        size='small'
                        placeholder="Select category"
                        labelId="demo-simple-select-filled-label"
                        id="demo-simple-select-filled"
                        value={formData?.categoryId}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            categoryId: e.target.value,
                          });
                          const updatedErrors = { ...formErrors };
                          delete updatedErrors.categoryId;
                          setFormErrors(updatedErrors);
                        }}
                        MenuProps={MenuProps}
                      >
                        {!selectItem?.length ? <MenuItem disabled={true}>No Data Available</MenuItem> : 
                        selectItem?.map((item: any) => {
                          return (
                            <MenuItem
                              key={item?.id}
                              value={item?.id}
                            >
                              {item?.category}
                            </MenuItem>
                          );
                        })}
                      </Select>
                    </FormControl>
                    {formErrors.categoryId && (
                      <FormHelperText id="parent-category-error" error>
                        {formErrors.categoryId}
                      </FormHelperText>
                    )}
                  </Grid>

                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Material Name  <Asterisk>*</Asterisk></InputLabel>
                    <FormControl sx={{ width: '100%' }}>
                      <TextField
                        size='small'
                        type="text"
                        id="my-input"
                        placeholder="Enter material name"
                        value={formData?.productName}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            productName: e.target.value,
                          });
                          const updatedErrors = { ...formErrors };
                          delete updatedErrors.productName;
                          setFormErrors(updatedErrors);
                        }}
                        aria-describedby="my-helper-text"
                      />
                    </FormControl>
                    {formErrors.productName && (
                      <FormHelperText id="category-error" error>
                        {formErrors.productName}
                      </FormHelperText>
                    )}
                  </Grid>

                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Brand</InputLabel>
                    <FormControl sx={{ width: '100%' }}>
                      <Select
                        size='small'
                        id="demo-multiple-checkbox"
                        multiple
                        value={formData?.brandId}
                        onChange={(event: any) => {
                          const { target: { value } } = event; 
                          setFormData({
                            ...formData,
                            brandId: value,
                          });
                        }}
                        renderValue={(selected: any[]) => {
                          return brandItems?.filter((selectItem: any) => selected.includes(selectItem?.id))?.map((item: any) => item?.brandName)?.join(", ");
                        }}
                        MenuProps={MenuProps}
                      >
                        {!brandItems?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                        brandItems?.map((item: any) => {
                          return (
                            <MenuItem key={item.id} value={item.id}>
                              <Checkbox size='small'
                                checked={formData?.brandId?.indexOf(item.id) > -1}
                              />
                              <ListItemText primary={item.brandName} />
                            </MenuItem>
                          );
                        })}
                      </Select>
                    </FormControl>

                    {formErrors.brandId && (
                      <FormHelperText id="parent-category-error" error>
                        {formErrors.brandId}
                      </FormHelperText>
                    )}
                  </Grid>

                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Grade / Type</InputLabel>
                    <div className={classes.root}>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          variant="outlined"
                          name='type'
                          value={inputValue?.type}
                          placeholder="Write a Grade / Type here and enter shift"
                          InputProps={{
                            startAdornment: <InputAdornment position="start"> {tags?.type?.map((tag, index) => (
                              <Chip
                                key={index}
                                label={tag}
                                onDelete={() => handleChipDelete(tag, 'type')}
                                className={classes.chip}
                              />
                            ))}</InputAdornment>,
                          }}
                          onChange={handleInputChange}
                          onKeyDown={(event: any) => {
                            if (event.key === 'Shift' && inputValue?.type?.trim() !== '') {
                              setTags({
                                ...tags,
                                type: [...tags?.type, inputValue?.type?.trim()],
                              })
                              setInputValue({ type: '' });
                              setFormData({
                                ...formData,
                                type: [...tags.type, inputValue?.type?.trim()],
                              })
                            } else {
                              if (formData?.type?.length === 0) {
                                setFormData({
                                  ...formData,
                                  type: null,
                                })
                              }
                            }
                          }}
                        />
                      </FormControl>
                    </div>
                  </Grid>

                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Specification </InputLabel>
                    <FormControl
                      sx={{ width: '100%' }}
                    >
                      <TextField
                        size='small'
                        variant="outlined"
                        name='specification'
                        value={inputValue?.specification}
                        placeholder="Write a specification here and enter shift"
                        InputProps={{
                          startAdornment: <InputAdornment position="start"> {tags?.specification?.map((tag, index) => (
                            <Chip
                              key={index}
                              label={tag}
                              onDelete={() => handleChipDelete(tag, 'specification')}
                              className={classes.chip}
                            />
                          ))}</InputAdornment>,
                        }}
                        onChange={handleInputChange}
                        onKeyDown={(event: any) => {
                          if (event.key === 'Shift' && inputValue?.specification?.trim() !== '') {
                            setTags({
                              ...tags,
                              specification: [...tags?.specification, inputValue?.specification?.trim()],
                            })
                            setInputValue({ specification: '' });
                            setFormData({
                              ...formData,
                              specification: [...tags.specification, inputValue?.specification?.trim()],
                            })
                          } else {
                            if (formData?.specification?.length === 0) {
                              setFormData({
                                ...formData,
                                specification: null,
                              })
                            }
                          }
                        }}
                      />
                    </FormControl>
                  </Grid>

                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Size</InputLabel>
                    <div className={classes.root}>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          variant="outlined"
                          name='size'
                          value={inputValue?.size}
                          placeholder="Write a size here and enter shift"
                          InputProps={{
                            startAdornment: <InputAdornment position="start"> {tags?.size?.map((tag, index) => (
                              <Chip
                                key={index}
                                label={tag}
                                onDelete={() => handleChipDelete(tag, 'size')}
                                className={classes.chip}
                              />
                            ))}</InputAdornment>,
                          }}
                          onChange={handleInputChange}
                          onKeyDown={handleInputKeyDown}
                        />
                      </FormControl>
                    </div>
                  </Grid>

                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Unit</InputLabel>
                    <FormControl sx={{ width: '100%' }}>
                      <TextField
                        size='small'
                        type="text"
                        id="my-input"
                        placeholder="Enter Unit"
                        value={formData?.unit}
                        onChange={(e) => {
                          setFormData({
                            ...formData,
                            unit: e.target.value,
                          });
                          const updatedErrors = { ...formErrors };
                          delete updatedErrors.unit;
                          setFormErrors(updatedErrors);
                        }}
                        aria-describedby="my-helper-text"
                      />
                    </FormControl>
                    {formErrors.unit && (
                      <FormHelperText id="category-error" error>
                        {formErrors.unit}
                      </FormHelperText>
                    )}
                  </Grid>
                  
                  <Grid item lg={6} md={12} sm={12} xs={12}>
                  <InputLabel htmlFor="my-input">Upload Image</InputLabel>
                     <FormControl sx={{ width: '100%' }}>
                        <TextField 
                          type="file" 
                          size='small'
                          name="myImage"
                          inputProps={{
                            accept: "image/png, image/gif, image/jpeg"
                          }}  
                          onChange={(e) => { 
                            const file = e?.target?.files[0];  
                            if(!!file){
                            setFormData({
                              ...formData,
                              image: file,
                              imagePreview: URL.createObjectURL(file)
                            })
                            }
                          }}
                          />
                      {formData?.imagePreview && <Image alt='material-img' src={formData?.imagePreview} width={100} height={100} crossOrigin="anonymous" style={{margin:"10px"}}/>}
                      </FormControl>
                  </Grid>
                </>
              )}

              {title === 'Add Category' && (
                <>
                  <Grid container spacing={2}>
                    <Grid item lg={12} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Name *</InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          type="text"
                          id="my-input"
                          value={formData?.categoryName}
                          onChange={(e) => {
                            setFormData({
                              ...formData,
                              categoryName: e.target.value,
                            });
                            const updatedErrors = { ...formErrors };
                            delete updatedErrors.categoryName;
                            setFormErrors(updatedErrors);
                          }}
                          aria-describedby="my-helper-text"
                        />
                      </FormControl>
                        {formErrors.categoryName && (
                          <FormHelperText id="category-error" error>
                            {formErrors.categoryName}
                          </FormHelperText>
                        )}
                    </Grid>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input"> Type *</InputLabel>
                      <FormGroup>
                        {[{ id: '1', text: 'Material' }, { id: '2', text: 'Machinery' }].map(option => (
                          <div key={option.id}>
                            <FormControlLabel
                              label={option.text}
                              value={option.id}
                              control={
                                <Checkbox size='small' checked={formData?.type.includes(option.id)}
                                  onChange={(e) => {
                                    if (!formData?.type.includes(option.id)) {
                                      setFormData({
                                        ...formData,
                                        type: [...formData?.type, e.target.value],
                                      });
                                    } else {
                                      setFormData({
                                        ...formData,
                                        type: formData?.type.filter((type: any) => type !== e.target.value),
                                      });
                                    }
                                    const updatedErrors = { ...formErrors };
                                    delete updatedErrors.type;
                                    setFormErrors(updatedErrors);
                                  }} />
                              }
                            />
                          </div>
                        ))}
                      </FormGroup>
                      {formErrors.type && (
                          <FormHelperText id="category-error" error>
                            {formErrors.type}
                          </FormHelperText>
                        )}
                    </Grid>
                  </Grid>
                </>
              )}

              {title === 'Add Brand' && (
                <>
                  <Grid container spacing={2}>
                    <Grid item lg={12} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Name *</InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                        <TextField
                          size='small'
                          type="text"
                          id="my-input"
                          value={formData?.brandName}
                          onChange={(e) => {
                            setFormData({
                              ...formData,
                              brandName: e.target.value,
                            });
                            const updatedErrors = { ...formErrors };
                            delete updatedErrors.brandName;
                            setFormErrors(updatedErrors);
                          }}
                          aria-describedby="my-helper-text"
                        />
                      </FormControl>
                        {formErrors.brandName && (
                          <FormHelperText id="category-error" error>
                            {formErrors.brandName}
                          </FormHelperText>
                        )}
                    </Grid>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input">Category </InputLabel>
                      <FormControl sx={{ width: '100%' }}>
                              <Select
                                size='small'
                                id="demo-multiple-checkbox"
                                multiple
                                value={formData?.categoryID ?? []}
                                onChange={(event: any) => {
                                  const { target: { value } } = event;
                                  setFormData({
                                    ...formData,
                                    categoryID: value,
                                  });
                                }}
                                renderValue={(selected: any[]) => {
                                  return selectItem?.filter((sItem: any) => selected.includes(sItem?.id))?.map((item: any) => item?.categoryName)?.join(", ");
                                }}
                                MenuProps={MenuProps}
                              >
                                {!selectItem?.length ? 
                                <MenuItem disabled={true}>No Data Available</MenuItem> :
                                  selectItem?.map((item: any) => {
                                    return (
                                      <MenuItem key={item.id} value={item.id}>
                                        <Checkbox size='small'
                                          checked={formData?.categoryID?.indexOf(item.id) > -1}
                                        />
                                        <ListItemText primary={item.categoryName} />
                                      </MenuItem>
                                    );
                                  })}
                              </Select>
                      </FormControl>
                    </Grid>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                      <InputLabel htmlFor="my-input"> Type *</InputLabel>
                      <FormGroup>
                        {[{ id: '1', text: 'Material' }, { id: '2', text: 'Machinery' }].map(option => (
                          <div key={option.id}>
                            <FormControlLabel
                              label={option.text}
                              value={option.id}
                              control={
                                <Checkbox size='small' checked={formData?.type?.includes(option.id)}
                                  onChange={(e) => {
                                    if (!formData?.type?.includes(option.id)) {
                                      setFormData({
                                        ...formData,
                                        type: [...formData?.type, e.target.value],
                                      }); 
                                    } else {
                                      setFormData({
                                        ...formData,
                                        type: formData?.type.filter((type: any) => type !== e.target.value),
                                      });
                                    }
                                    const updatedErrors = { ...formErrors };
                                    delete updatedErrors.type;
                                    setFormErrors(updatedErrors);
                                  }} />
                              }
                            />
                          </div>
                        ))}
                        {formErrors.type && (
                          <FormHelperText id="category-error" error>
                            {formErrors.type}
                          </FormHelperText>
                        )}
                      </FormGroup>
                    </Grid>
                  </Grid>
                </>
              )}

              {title === 'Add Staff' && (
                  <>
                    <Grid container spacing={2}>
                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input"> Name <Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <TextField
                            size='small'
                            id="outlined-basic"
                            placeholder="Name"
                            variant="outlined"
                            value={formData?.name}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData({
                                ...formData,
                                name: value,
                              });
                              if (value.trim() !== '') {
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.name;
                                setFormErrors(updatedErrors);
                              }
                            }}
                          />
                        </FormControl>
                        {formErrors.name && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.name}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Mobile Number <Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <TextField
                            size='small'
                            id="outlined-basic"
                            placeholder="Contact"
                            variant="outlined"
                            value={formData?.mobileNumber}
                            onChange={(e) => {
                              const enteredValue = e.target.value;
                              const numericValue = Number(enteredValue); // Convert the value to a number
                              if (
                                !Number.isNaN(numericValue) &&
                                enteredValue.length <= 10
                              ) {
                                setFormData({
                                  ...formData,
                                  mobileNumber: enteredValue,
                                });
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.mobileNumber;
                                setFormErrors(updatedErrors);
                              }
                            }}
                          />
                        </FormControl>
                        {formErrors.mobileNumber && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.mobileNumber}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Project<Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <Select
                            size='small'
                            labelId="demo-multiple-checkbox-label"
                            value={formData?.projectId}
                            onChange={(event: any) => {
                              const { target: { value } } = event;
                              setFormData({
                                ...formData,
                                projectId: value,
                              });
                              const updatedErrors = { ...formErrors };
                              delete updatedErrors.projectId;
                              setFormErrors(updatedErrors);
                            }}
                            renderValue={(selected: any[]) => {
                              return selectItems?.filter((selectItem: any) => selectItem?.id == selected)?.map((item: any) => item?.projectName)?.join(', ');
                            }}
                            MenuProps={MenuProps}
                          >
                           {!selectItems?.length && <MenuItem>No Data Available</MenuItem>} 
                           {selectItems?.map((item: any) => {
                              return (
                                <MenuItem key={item.id} value={item.id}>
                                  <ListItemText primary={item.projectName} />
                                </MenuItem>
                              );
                            })}
                          </Select>
                        </FormControl>
                        {formErrors.projectId && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors.projectId}
                          </FormHelperText>
                        )}
                      </Grid>

                      <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Image<Asterisk>*</Asterisk> </InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                          <div className={classes.root}>
                            <input
                              accept="image/*"
                              className={classes.input}
                              id="contained-button-file"
                              type="file"
                              onChange={(e: any) => handleFileUpload(e)}
                            />
                            { formData?.imagePreview && 
                            <Image style={{padding: 10}} width={150} height={120} src={formData?.imagePreview} alt='staff'/>
                            }
                          </div>
                        </FormControl>
                        {formErrors?.image && (
                          <FormHelperText id="project-name-error" error>
                            {formErrors?.image}
                          </FormHelperText>
                        )}
                      </Grid>
                    </Grid>
                  </>
              )}

            </MainFormLayout>
            {title !== 'Material Request' && title !== 'Machinery Request' &&
              <Button
                type="submit"
                variant="contained"
                style={{ margin: '20px', float: 'right' }}
              >
                Save
              </Button>}
          </form>
        </CardContent>
      </MainConteiner>
    </>
  );
};

export default MainForm;
