'use client'
import React, { useEffect } from 'react';
import { useState } from "react";
import { Grid, IconButton, Input, List, ListItem, ListItemText, TextField } from "@mui/material";
import { Wrapper } from "../../app/styles";
import { ErrorMessage, RequestVerificationTable } from '../../../src/common/styles/Dashboard/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Button  } from '@mui/material';
import AddAPhotoOutlinedIcon from '@mui/icons-material/AddAPhotoOutlined';
import Paper from '@mui/material/Paper';
import { makeStyles } from '@material-ui/core/styles'; 
import moment from 'moment';  
import { useAllowedNavigation } from 'src/context/context';
import Image from 'next/image';

const useStyles = makeStyles((theme) => ({
    root: {
        '& > *': { 
            margin: theme.spacing(1),
        },
    },
    input: {
        display: 'none',
    },
}));


const RequestVerificationForm = ({ requestData, handleUpdateProps }: any) => {
     const {isResLoading} = useAllowedNavigation()
    const classes = useStyles();
    const [formData, setFormData] = useState(requestData) 
    const [updatedItems, setUpdatedItems] = useState(requestData?.items);
    const [uploadid, setUploadId] = useState('')
    const [error, setError] = useState({})
    const [isValidVerify, setIsValidVerify] = useState(false)
    const errors: { [key: string]: string } = {}; 
    let isValidField:any = false; 
    const filteredArray = updatedItems?.filter((fItem:any) => (fItem?.remainingToVerified !== 0 || (fItem?.receivedQuantity !== NaN)) && (fItem?.materialStatus !== true) );  

    useEffect(() => {
        const isAllValidField = !filteredArray?.filter(item => item?.isValidField === true)?.length;
        setIsValidVerify(isAllValidField)
    }, [updatedItems])

    useEffect(() => {
        setFormData(requestData)
    }, [requestData])

    useEffect(() => {
        const updatedItem = updatedItems?.map((item: any) => {
            const checkReceivedQty = !Object.keys(item)?.includes("receivedQuantity");
            const isQuantity = item?.receivedQuantity?.length < 0;
            if ((item.id === uploadid)) {
                return { ...item, errorMessage: error?.imageError };
            }
            if ((checkReceivedQty || isQuantity) && (item.remainingToVerified !== 0)) {
                return { ...item , isValidField: true };
            }
            if ((checkReceivedQty || isQuantity) && (item.remainingToVerified !== 0)) {
                return { ...item, receivedQtyError: 'Received Qty is required', isValidField: false };
            } else {
                return { ...item, receivedQtyError: '' };
            } 
        });
        setUpdatedItems(updatedItem);
    }, [error])

    const handleFileUpload = (event: any, id: any) => {
        const file = event.target.files[0];
        const formData = new FormData();
        formData.append('file', file);
        const imageSizeInBytes: number = file?.size;
        const imageSizeInKB: number = imageSizeInBytes / 1024;
        const imageUrl = file ?  URL.createObjectURL(file) : '';
        if (imageSizeInKB >= 300) {
            setError((value) => { return { ...error, ['imageError']: "Image size should be smaller than 300kb." } })
        } else {
            setError((value) => { return { ...error, ['imageError']: "" } })
        }
        const updatedItem = updatedItems?.map((item: any) => {
            if (item.id === uploadid) {
                return { ...item, materialImage: file, materialImageName: file?.name ,  imagePreview: imageUrl};
            }
            return item;
        });
        setUpdatedItems(updatedItem);
    };

    // Function to handle received quantity change for a specific item
    const handleReceivedQuantityChange = (itemId: any, receivedQuantity: any) => { 
        const negativeRegex = /^-.*$/;
            const updatedItem = updatedItems?.map((item: any) => { 
                const updatedQty = item?.remainingToVerified !== null ? item?.remainingToVerified : item?.quantity;
                if (item?.id === itemId) {
                    let blnc = receivedQuantity.length !== 0 ? (item?.quantity - parseInt(receivedQuantity) >= 0) ? updatedQty - parseInt(receivedQuantity) : "" : "";
                    if (receivedQuantity?.length === 0) { 
                        errors.receivedQtyError = "";
                        errors.imageReqError = "";
                        isValidField = true
                    } else {
                        if ((receivedQuantity == 0) || (negativeRegex.test(receivedQuantity))) {  
                            errors.receivedQtyError = "Recieved Qty should be greater than 0";
                            isValidField = false;
                        } else if(!receivedQuantity?.length){ 
                            errors.receivedQtyError = "";
                            isValidField = true;
                        }else if(receivedQuantity > updatedQty){
                            errors.receivedQtyError = "Qty should not be greater than requested quantity.";
                            isValidField = false
                        }else{
                            errors.receivedQtyError = "";
                            isValidField = true;
                        }
                    }
                  
                    if (receivedQuantity > '0' && ((!item?.materialImage) && (item?.materialImage === undefined)) ) {
                        errors.imageReqError = "Image is required.";
                    } else {
                        errors.imageReqError = "";
                    }  
                   
                    return {
                        ...item,
                        receivedQuantity: receivedQuantity,
                        balance: blnc,
                        receivedQtyError: errors?.receivedQtyError,
                        errorMessage: errors?.imageReqError,
                        isValidField: isValidField,
                    }; 
                }
                return item;
            });
            setUpdatedItems(updatedItem); 
    };
    
    const handleDamagedQuantityChange = (itemId: any, damagedQuantity: any) => {
        const updatedItem = updatedItems?.map((item: any) => {  
            if (item?.id === itemId) { 
                if (!damagedQuantity) {
                    errors.damagedQtyError = "Received Qty is required.";
                    isValidField = false
                } else if (damagedQuantity === "0") {
                    errors.damagedQtyError = ""
                    isValidField = true
                }

                if (damagedQuantity > "0" && !item?.materialImage ) {
                    errors.imageReqError = "Image is required.";
                    isValidField = false
                } else {
                    errors.imageReqError = "";
                    isValidField = true
                }  
                return {
                    ...item,
                    damagedQuantity: damagedQuantity, 
                    damagedQtyError: errors?.damagedQtyError,
                    errorMessage: errors?.imageReqError
                }; 
            }
            return item;
        });
        setUpdatedItems(updatedItem); 
    }  
    
    // Function to submit material verification
    const handleSubmit = (event: any) => {
        event.preventDefault();
        const verifyFormData = new FormData() 
        filteredArray?.filter(item => (item?.receivedQuantity !== 0) && (!!item?.receivedQuantity?.length))?.forEach((item: any, index: number) => { 
               if(!!Object.keys(item).includes('receivedQuantity')){ 
                   let damagedQuantity:any = 0;
                   let remark = !!item?.remark ? item?.remark : '';
                   if(item?.damagedQuantity){damagedQuantity = item.damagedQuantity}
                   verifyFormData.append(`Text[${index}][0][requestId]`, requestData?.reqId);
                   verifyFormData.append(`Text[${index}][1][receivedQuantity]`, parseInt(item?.receivedQuantity));
                   verifyFormData.append(`Text[${index}][2][verifiedRemark]`, remark);
                   verifyFormData.append(`Text[${index}][3][typeId]`, parseInt(requestData?.typeId));
                   verifyFormData.append(`Text[${index}][4][machineryOrPrductId]`, parseInt(item?.machineryOrProductId));
                   verifyFormData.append(`Text[${index}][5][projectId]`, parseInt(requestData?.projectId));
                   if(item?.damagedQuantity !== undefined ){ 
                       verifyFormData.append(`Text[${index}][6][damagedQuantity]`, damagedQuantity)
                   }   
               }
        }) 
        filteredArray?.map(((item: any) => {
            let image = '';
            if(item?.materialImage){ image = item.materialImage} 
            if(!!Object.keys(item).includes('receivedQuantity')){
                verifyFormData.append(`image`, image) 
            }
        }))
        const checkErrorMessage = filteredArray?.filter(item => !!Object.keys(item).includes('receivedQuantity') && !!item?.receivedQuantity?.length )
        const isErrorMessage = !filteredArray?.filter(item => (!!item?.errorMessage?.length))?.length;
        const isErrorQty = !filteredArray?.filter(item => (!!item?.receivedQtyError?.length))?.length;
        
        if (!!verifyFormData && !!checkErrorMessage?.length && isErrorMessage && isErrorQty) {  
            handleUpdateProps(verifyFormData)
        }
    }
    
    const handleChange = (e:any, row:any) => { 
        let enteredValue = e.target.value; 
        const validRegex = /^[0-9][0-9]*$/; 
        if(validRegex.test(enteredValue) || enteredValue == "") {  
            // Call your handler function here if the input is valid
            handleReceivedQuantityChange(row?.id,  enteredValue) 
        } else if(enteredValue?.length < 0 ) {  
           const updatedItem = updatedItems?.map((item: any) => {  
                if (item?.id === row?.id ) { 
                    return {
                        ...item,
                        isValidField: true, 
                    }; 
                }
                return item;
            })
            setUpdatedItems(updatedItem);  
        }
    }
    
    return (
        <>
            <Wrapper>
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={2}>
                        <Grid item lg={3} xs={12} md={12}>
                            <List>
                                <ListItem>
                                    <ListItemText primary={"Project Name"} secondary={formData?.projectName} />
                                </ListItem>
                            </List>
                        </Grid>
                        <Grid item lg={3} xs={12} md={12}>
                            <List>
                                <ListItem>
                                    <ListItemText primary={"Request No."} secondary={formData?.reqId} />
                                </ListItem>
                            </List>
                        </Grid>
                        <Grid item lg={3} xs={12} md={12}>
                            <List>
                                <ListItem>
                                    <ListItemText primary={"Requested Date"} secondary={moment(formData?.requestedDate).format('DD/MM/YYYY (hh:mm:ss)')} />
                                </ListItem>
                            </List>
                        </Grid> 
                        <Grid item lg={3} xs={12} md={12}>
                            <List>
                                <ListItem>
                                    <ListItemText primary={"Approved Date"} secondary={moment(formData?.dateApproved).format('DD/MM/YYYY (hh:mm:ss)')} />
                                </ListItem>
                            </List>
                        </Grid>
                        <Grid item lg={3} xs={3} md={3}>
                            <List >
                                <ListItem>
                                    <ListItemText primary={"Approved By"} secondary={formData?.approvedBy} />
                                </ListItem>
                            </List>
                        </Grid>
                        <Grid item lg={3} xs={3} md={3}>
                            <List>
                                <ListItem>
                                    <ListItemText primary={"Sender Name"} secondary={formData?.senderName} />
                                </ListItem>
                            </List>
                        </Grid>

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Paper sx={{ width: '100%' }}>
                                <RequestVerificationTable>
                                    <TableContainer sx={{ maxHeight: 350, border: '1px solid #3333' }}>
                                        <Table stickyHeader aria-label="sticky table">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell sx={{textAlign: 'center'}}>S No.</TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                       Material name
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                       Type / Grade 
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Specification
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Size 
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Requested Qty 
                                                    </TableCell >
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Remaining To Verify
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Received Qty
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Balance
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Remark
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Damaged Qty.
                                                    </TableCell>
                                                    <TableCell sx={{textAlign: 'center'}}>
                                                        Image
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody> 
                                                {updatedItems?.filter((fItem) => fItem?.materialStatus !== true)?.map((row: any, i: any) => {
                                                    const id = row?.id
                                                    return (
                                                        <TableRow hover role="checkbox" tabIndex={-1} key={id}>
                                                            <TableCell sx={{textAlign: 'center'}}>{i + 1}</TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.machineryOrPrductName}</TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.itemName ?? "_"}</TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.specification ?? "_"}</TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.size ?? "_"}</TableCell> 
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.quantity}</TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.remainingToVerified === null ? "Not Available" : row?.remainingToVerified} </TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>
                                                            <TextField
                                                                className={row?.isValidField ? "valid-field" : "invalid-field"} 
                                                                disabled={row?.remainingToVerified === 0 }
                                                                size="small"
                                                                sx={{ width: "100%", minWidth: "10rem" }}
                                                                placeholder="Quantity"
                                                                value={row?.receivedQty}
                                                                name="receivedQuantity"
                                                                autoComplete='off'
                                                                onChange={(e)=> handleChange(e, row)}
                                                                onKeyDown={(e) => {
                                                                    if (["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"].includes(e.key)) {
                                                                        return;
                                                                    } 
                                                                    if (!/^[0-9]$/.test(e.key)) {
                                                                        e.preventDefault();
                                                                    }
                                                                }}
                                                            />
                                                                <ErrorMessage>{(!!row?.receivedQtyError) && row?.receivedQtyError}</ErrorMessage>
                                                            </TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>{row?.balance}</TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}> 
                                                             <TextField size='small' sx={{ width: "100%", minWidth: "10rem" }}value={row?.verifiedRemark} onChange={(e: any) => { 
                                                                 const updatedItem = updatedItems?.map((item: any) => {
                                                                    if (item.id === id) {
                                                                        return { ...item, remark:  e.target.value };
                                                                    }
                                                                    return item;
                                                                });
                                                                setUpdatedItems(updatedItem); 
                                                             }} /> 
                                                            </TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>
                                                            <ListItemText> 
                                                            <TextField 
                                                                size='small'
                                                                type='number'
                                                                autoComplete='off'
                                                                disabled={row?.remainingToVerified === 0}
                                                                sx={{ width: "100%", minWidth: "10rem" }} 
                                                                value={row?.damagedQuantity} 
                                                                onChange={(e: any) => {  
                                                                    const enteredValue = e.target.value;
                                                                    // Validate to allow only positive numbers
                                                                    if (/^\d*$/.test(enteredValue)) {
                                                                        handleDamagedQuantityChange(row?.id, enteredValue);
                                                                    }
                                                                }}
                                                            />
                                                             </ListItemText>
                                                            </TableCell>
                                                            <TableCell sx={{textAlign: 'center'}}>
                                                                <div className={classes.root} style={{display: 'inline-grid', placeItems: 'center'}}>
                                                                     <input
                                                                        accept="image/png, image/gif, image/jpeg"
                                                                        className={classes.input}
                                                                        id="contained-button-file"
                                                                        type="file"
                                                                        onChange={(e: any) => handleFileUpload(e, id)}
                                                                    /> 
                                                                    <label key={i} title={row?.materialImageName} htmlFor="contained-button-file">
                                                                        <IconButton onClick={() => setUploadId(row?.id)} color="primary" component="span" aria-label="upload" size="small"  >
                                                                            <AddAPhotoOutlinedIcon />
                                                                        </IconButton>
                                                                    </label>
                                                                   {!!row?.imagePreview && <Image width={50} height={50} alt='image' src={row?.imagePreview} crossOrigin='anonymous'/>}
                                                                    {/* <InputLabel>{row?.materialImageName}</InputLabel> */}
                                                                    <ErrorMessage>{row?.errorMessage === undefined ? "" : row?.errorMessage}</ErrorMessage>
                                                                </div>
                                                            </TableCell>
                                                        </TableRow>
                                                    );
                                                })}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </RequestVerificationTable>
                            </Paper>
                        </Grid>

                        <Grid item lg={12} xs={12} md={12}>
                            <Button style={{ float: 'right', color: 'white' }} type='submit' variant='contained' disabled={isValidVerify || isResLoading}>Verify</Button>
                        </Grid>
                    </Grid>
                </form>
            </Wrapper>

        </>
    )
}

export default RequestVerificationForm
