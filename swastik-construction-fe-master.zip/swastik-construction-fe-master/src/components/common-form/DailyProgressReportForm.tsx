"use client"
import React, { useCallback, useEffect, useState } from 'react'
import {
    Button,
    FormControl,
    InputLabel,
    FormHelperText,
    Grid,
    TextField,
    Typography,
    Autocomplete,
    Table,
    TableContainer, 
    TableRow,
    TableCell,
    TableBody,
    CircularProgress,
    IconButton, 
} from '@mui/material';
import { Asterisk } from '../Modal/styles';
import { Textarea } from '../../constants'; 
import DailyUsedMaterialTable from '../Table/DailyUsedMaterialTable'
import useGet from '../../hooks/useGet';
import usePost from '../../hooks/usePost';
import { useRouter } from 'next/navigation';
import getRequestAPI from '../../services/getRequest';
import _ from 'lodash'; 
import { site_inventory_url, user_assigned_projects } from '../../constants/api-routes';
import {toast} from 'react-toastify';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import {formateDate} from '../../utils/formatDate';
import {stringCapitalization} from '../../utils/formatString';
import dayjs from 'dayjs';
import {useSession} from 'next-auth/react'; 
import { Delete } from '@mui/icons-material';
import AddIcon from '@mui/icons-material/Add';
import ConfirmationDialog from '../ui/ConfirmationDialog'

interface dailyProgressFormType {
    data?: any;
    title?: string;
    catItems?: any;
    projectItems?: any;
    typeItems?: any;
    refreshData?: any;
}

const DailyProgressForm = ({ title }: dailyProgressFormType) => { 
    const router = useRouter()
    const {data: session} = useSession()
    const { handlePostData, error, resData } = usePost()
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [categoryData, setCategoryData] = useState<any>([]) 
    const [dataArray, setDataArray] = useState<any>([])
    const [editingId, setEditingId] = useState(null);
    const [materialData, setMaterialData] = useState<any>([]) 
    const [specificationArray, setSpecificationArray] = useState<any>([]);
    const [sizeItems, setSizeItems] = useState<any>([]) 
    const [editedValue, setEditedValue] = useState({ quantity: '', remark:''  });
    const [requestFormData, setRequestFormData] = useState<any>({});
    const [queryParams, setQueryParams] = useState<any>({ })
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const [dprFormErrors, setDprFormErrors] = useState<{ [key: string]: string }>({});
    const [itemNameArray, setItemNameArray] = useState<any>([])
    const [dateOfConsumption,setDateOfConsumption] = useState<any>(dayjs()) 
    const [dprFormData, setDprFormData] = useState<any>({})
    const [projectArray, setProjectArray] = useState([])
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet()
    const [projectInfo, setProjectInfo] = useState(null) 
    const [loading, setLoading] = useState(false)
    const [totalItems, setTotalItems] = useState(0)
    const [page, setPage] = useState(1)
    const [contractors, setContractors] = useState<any>([
        { name: "", quantity: "", remark: "" },
     ]);
    const [openConfirm, setOpenConfirm] = useState(false);
    const [selectedFileIndex, setSelectedFileIndex] = useState(null);
    const [canSubmit, setCanSubmit] = useState(true)
 
    useEffect(() => {
        if(!!resData){
            router.back()
        }
    }, [error, resData]) 

    const validateMaterial = () => {
        const errors: { [key: string]: string } = {};
        if (!requestFormData?.materialId) {
            errors.materialId = 'Material is required.';
        } else {
            delete errors.materialId;
        }
        if (!requestFormData?.categoryId) {
            errors.categoryId = 'Category is required.';
        } else {
            delete errors.categoryId;
        }
        if(!!itemNameArray.length){
            if (!requestFormData?.itemName) {
                errors.itemName = 'Type or Grade is required.';
            } else {
                delete errors.itemName;
            }
        }
        if(!!specificationArray.length){
            if (!requestFormData?.specification) {
                errors.specification = 'Specification is required.';
            } else {
                delete errors.specification;
            }
        }
        if(!!sizeItems.length){
            if (!requestFormData?.size) {
                errors.size = 'Size is required.';
            } else {
                delete errors.size;
            }
        }
        if (!requestFormData?.quantity) {
            errors.quantity = 'Quantity is required.';
        } else {
            delete errors.quantity;
        }
        setFormErrors(errors)
        return Object.keys(errors).length === 0;
    } 
  
    useEffect(() => {
        if(projectInfo?.name) {
            const params = {projectName: projectInfo?.name}
            setQueryParams(params)
            getMaterialData(params).then((res: any) => {
                const uniqCat = _.uniqBy(res.data.items, 'categoryName')
                setCategoryData(uniqCat)
            })
        } 
    }, [projectInfo])

    useEffect(() => {
        if(!!categoryData.length) {
        const params = {...queryParams}
        params['q'] = requestFormData.categoryId
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            let resData = _.uniqBy(res.data.items, 'productName')
            setMaterialData(resData)
        })
        }
    }, [requestFormData.categoryId])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '') {
        const params = {...queryParams}
        params['productName'] = requestFormData.machineryOrPrductName
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.itemName != null), 'itemName');
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    itemName: null,
                })
            }
            setItemNameArray(items)
        })
        }
    }, [requestFormData.machineryOrPrductName])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' || requestFormData.itemName == null)) {
        const params = {...queryParams}
        params['itemName'] = requestFormData.itemName
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.productSpecification != null), 'productSpecification');   
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    specification: null
                })
            }
            setSpecificationArray(items)
        })
        }
    }, [requestFormData.itemName])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' ||  requestFormData.itemName == null) && (requestFormData.specification != '' || requestFormData.specification == null)) {
        const params = {...queryParams}
        params['specification'] = requestFormData.specification
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => {
            const items:[] = _.uniqBy(res.data.items.filter((item: any) => item?.productSize != null), 'productSize');    
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    size: null
                })
            }
            setSizeItems(items)
        })
        }
    }, [requestFormData.specification])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && requestFormData.itemName != '' && requestFormData.specification != '' && (requestFormData.size != '' || requestFormData.size == null)) {
        const params = {...queryParams}
        params['size'] = requestFormData.size
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            setRequestFormData({
                ...requestFormData,
                materialId: res?.data?.items[0]?.productId,
                availableQty: res?.data?.items[0]?.siteInventoryAvailableQuantity,
                unit: res?.data?.items[0]?.productUnit
            }) 
        })
        }
    }, [requestFormData.size])
         
    const removeMaterial = (idx: any, mId:any) => {  
        if(idx !== undefined){
            let copyData = [...dataArray]
            copyData = dataArray.filter((_: any, index: any) => index != idx);   
            setDataArray(copyData);  
        }
    }
  
    const editMaterial = (id: any, value: any) => {
        setEditingId(id);
        setEditedValue(value);
    }

    const handleChange = (e: any, data?:any) => { 
        const value = e.target.value;  
        const regex = /^[1-9]\d*$/;  
        const key = e.target.name;
        if(key === 'quantity'){
            if ((value === '' || regex.test(value)) && (data?.availableQty >= value )) {
                const newQuantity = parseInt(value ); 
                setEditedValue(prevState => ({
                    ...prevState,
                    [e.target.name]: newQuantity
                }));
            } 
        }else{
            setEditedValue(prevState => ({
                ...prevState,
                [e.target.name]: value
            }));
        } 
    }

    const handleSave = (id: any) => {
        let copyData = [...dataArray]
        copyData[id] = { ...dataArray[id], ['quantity']: editedValue.quantity, ['remark']: editedValue.remark }
        setDataArray(copyData)
        setEditingId(null) 
    };
 
    const addMaterialForm = () => {
        const isValid = validateMaterial();
        const exists = dataArray.some(item => item?.materialId === requestFormData?.materialId); 
        
        if(exists){
            toast.error('This item is already exist', { 
                    autoClose: 1000, 
                }) 
        } else if (isValid && !exists) {
            setDataArray((prevState: any) => [...prevState, {
                ['categoryId']: requestFormData?.categoryId,
                ['machineryOrPrductName']: requestFormData?.machineryOrPrductName,
                ['unit']: requestFormData?.unit,
                ['size']: requestFormData?.size?.productSize,
                ['specification']: requestFormData?.specification?.productSpecification,
                ['categoryName']: requestFormData?.categoryName,
                ['remark']: requestFormData?.remark,
                ['typeId']: requestFormData?.typeId,
                ["materialId"]: requestFormData?.materialId,
                ["itemName"]: requestFormData?.itemName,
                ["quantity"]: requestFormData?.quantity,
                ["availableQty"]: requestFormData?.availableQty
            }]); 
            setRequestFormData({})
            setIsFormOpen(false)
            toast.success("Successfully added to the list", { autoClose: 1000})
            setQueryParams({projectName: projectInfo?.name})
        } 
    } 
 
    const handleCancelMaterial = () => {
        setRequestFormData({})
        setIsFormOpen(false)
    }

    const createPayload = (data:any) => { 
        const payload = [];  
        const consumptionDate = formateDate(dateOfConsumption)
        for (const [type, values] of Object?.entries(data)) {   
          const formatedType = stringCapitalization(type)
          if(!!projectInfo?.id){
              for(const [key , value] of Object?.entries(values)){ 
               const formatedKey = stringCapitalization(key)
                let quantity = ((value?.quantity !== '') && (value?.quantity !== undefined)) ? value?.quantity : 0;
                let remark = ((!!value?.remark) && ((quantity !== 0) && (quantity !== undefined))) ? value.remark : '' 
                    if(quantity !== 0){
                        payload.push({
                          projectId: projectInfo?.id,
                          date: consumptionDate,
                          type: formatedType,
                          nameOrId: formatedKey,
                          consumptionOfQuantity: parseInt(quantity),
                          remark: remark 
                        });  
                }
              }
          }
        } 
        return payload;
    }; 
      
    function isObjectEmpty(obj: any) { 
        if (typeof obj !== 'object' || obj === null) {  // Check if the input is an object and not null
            return false;
        } 
        
        for (let key in obj) {   // Loop through all properties in the object
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                if (!isObjectEmpty(obj[key])) {
                    return false;
                }
            } else {
                return false;  // If a non-object or non-empty primitive is found, return false
            }
        } 
        return true; // If no non-empty properties found, return true
    }

    const validate = () => {
      const errors:any = {
            "labour": {
                "company": { },
                "contractor": { }
            },
            "machinery": {
                "tractor": { },
                "trolly": { },
                "tankerWithFighter": { },
                "jcb": { }
            }
        } 
        if(!projectInfo?.name){
            errors.project = "Project is required"
        }else{
            delete errors.project;
        }
        if (!dprFormData?.labour?.company?.quantity && !!dprFormData?.labour?.company?.remark) { 
            errors.labour.company.quantity = 'Quantity is required';
        } else{
            delete errors.labour.company.quantity;
        }
        if (!dprFormData?.labour?.contractor?.quantity && !!dprFormData?.labour?.contractor?.remark) { 
            errors.labour.contractor.quantity = 'Quantity is required';
        } else{
            delete errors.labour.contractor.quantity;
        }

        if (!dprFormData?.machinery?.tractor?.quantity && !!dprFormData?.machinery?.tractor?.remark) { 
            errors.machinery.tractor.quantity = 'Quantity is required';
        } else{
            delete errors.machinery.tractor.quantity;
        }
        if (!dprFormData?.machinery?.trolly?.quantity && !!dprFormData?.machinery?.trolly?.remark) { 
            errors.machinery.trolly.quantity = 'Quantity is required';
        } else{
            delete errors.machinery.trolly.quantity;
        }
        if (!dprFormData?.machinery?.tankerWithFighter?.quantity && !!dprFormData?.machinery?.tankerWithFighter?.remark) { 
            errors.machinery.tankerWithFighter.quantity = 'Quantity is required';
        } else{
            delete errors.machinery.tankerWithFighter.quantity;
        }
        if (!dprFormData?.machinery?.jcb?.quantity && !!dprFormData?.machinery?.jcb?.remark) { 
            errors.machinery.jcb.quantity = 'Quantity is required';
        } else{
            delete errors.machinery.jcb.quantity;
        }
        setDprFormErrors(errors);
        const isEmpty = isObjectEmpty(errors)         
        return isEmpty;
    } 
       
    const handleSubmitDailyReport = async () => {  
        let payload:any = await createPayload(dprFormData); 
        const consumptionDate = formateDate(dateOfConsumption) 
        if(!!projectInfo?.id) {
            for (const [index, element] of dataArray?.entries()) {
                payload.push({
                    projectId: projectInfo?.id,  
                    date: consumptionDate,
                    type: 'Material', 
                    nameOrId: element?.materialId,
                    consumptionOfQuantity: parseInt(element?.quantity),
                    remark: element?.remark  
                  })
              } 
            for(const ele of contractors){ 
                if(ele?.name !== ''){
                    payload.push({
                        projectId: projectInfo?.id,
                        date: consumptionDate,
                        type: "Contractor",
                        nameOrId: ele?.name,
                        consumptionOfQuantity: parseInt(ele?.quantity),
                        remark: ele?.remark
                    })
                }
            }
               
            const isValid = validate()
            if(isValid){
                if(payload?.length > 0){   
                const res = await handlePostData('/dpr', payload, title); 
                return res;
                }
            }
        }
    }

    useEffect(() => {
        validate()
    }, [dprFormData])
   
    const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        addMaterialForm()
        for (let i = 0; i < dataArray?.length; i++) {
            dataArray[i].projectId =  projectInfo?.id;  
        }
        handleSubmitDailyReport()
    } 

    const handleChangeValue = (event: React.ChangeEvent<HTMLInputElement>, type: string, nameOrId: string, key: string) => {
        let value = event.target.value; 
        if (key !== 'remark') { 
            if( value === '' || /^[1-9]\d*$/.test(value)){ 
                // Update state only if the value is positive or empty
                setDprFormData((prevData: any) => ({
                    ...prevData,
                    [type]: {
                        ...prevData[type],
                        [nameOrId]: {
                            ...prevData[type]?.[nameOrId],
                            [key]: value
                        }
                    }
                }));
                const updatedErrors = { ...dprFormErrors };
                delete updatedErrors?.[type]?.[nameOrId]?.[key];
                setFormErrors(updatedErrors);
            }
        } else {
            // For 'remark' key, just update the state without validation 
            if(event?.target?.value.length <= 150 ){
                setDprFormData((prevData: any) => ({
                    ...prevData,
                    [type]: {
                        ...prevData[type],
                        [nameOrId]: {
                            ...prevData[type]?.[nameOrId],
                            [key]: value
                        }
                    }
                }));
            }
        }
    }; 

    const getAssignedProjectData = async () => { 
        const assignProjectList = await handleGetProjectData(`${user_assigned_projects}?status=running`);
        return assignProjectList;
    }    

    useEffect(() => {
        let resArray:any=[]
        resProjectData?.length && resProjectData?.map((Item: any, idx: any) => {
            return Item?.assignProject?.map((project: any) => {
                resArray.push({ id: project?.projectId, name: project?.project?.projectName, location: project?.project?.location })
                setProjectArray(resArray) 
            })
        });
    },[resProjectData])

    useEffect(() => {
        getAssignedProjectData() 
    }, []) 

    const getMaterialData = async (requestedParams: any) => {
        try {
            let searchParams = "";
            const params = Object.keys(requestedParams).reduce((acc: any, key) => {
                if (requestedParams[key] !== undefined &&  requestedParams[key] !== null ) {
                  acc[key] = requestedParams[key];
                }
                return acc;
              }, {});
            Object.entries(params)?.map(([key, value]) => {
                searchParams += `${key}=${value}&`
            })
            setLoading(true)
            const response = await getRequestAPI(`${site_inventory_url}/?page=${page}&limit=50&${searchParams}`)
            setTotalItems(response?.data?.metadata?.totalItems)
            setLoading(false)
            return response
        } catch (err){
            throw err;
        }        
    }

    const handleCategoryChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            categoryId: newValue?.categoryId ?? 0,
            categoryName: newValue?.categoryName,    
            machineryOrPrductName: '',
            itemName: '',
            specification: '',
            size: '',
            availableQty: ''

        })
        const params = {projectName:  projectInfo?.name}
        setQueryParams(params)
        setMaterialData([])
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.categoryId;
        setFormErrors(updatedErrors);
    }

    const handleProductName = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            machineryOrPrductName: newValue?.productName,
            itemName: '',
            specification: '',
            size: '', 
        }) 
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.materialId;
        setFormErrors(updatedErrors)
    }

    const handleItems = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            itemName: newValue?.itemName, 
            specification: '',
            size: '',  
        })  
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.itemName;
        setFormErrors(updatedErrors)
    }

    const handleSpec = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            specification: newValue?.productSpecification, 
            size: '',  
        }) 
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.specification;
        setFormErrors(updatedErrors)
    }

    const handleSizeChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            size: newValue?.productSize, 
        })
        const updatedErrors = { ...formErrors };
        delete updatedErrors.size;
        setFormErrors(updatedErrors)
    }

    const handleScroll = useCallback((event: React.SyntheticEvent) => {
        const listboxNode = event.currentTarget;
        if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight) {
            if (!loading){
                if ((materialData?.length <= totalItems)) {
                    setPage(page + 1)
                }
            }
        }
    }, [loading, page]);  

    const addContractor = () => {
        setContractors([...contractors, { name: "", quantity: "", remark: "" }]);
    }

    const deleteContractor = () => { 
        const newContractors = contractors.filter((_:any, i:number) => i !== selectedFileIndex);
        setContractors(newContractors);
        setOpenConfirm(false)
    }

    const confirmRemoveContractor = (index:any) => {
        setSelectedFileIndex(index);
        setOpenConfirm(true);
    };

    const handleChangeContractor = (index: number, event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target; 
        const updatedContractors = [...contractors];
        if (name === 'quantity') { 
            if( value === '' || /^[1-9]\d*$/.test(value)){
                updatedContractors[index] = { ...updatedContractors[index], [name]: value }; 
            }
        } else {
           if(event?.target?.value.length <= 150 ){ 
            updatedContractors[index] = { ...updatedContractors[index], [name]: value }; 
           }
        }
        updatedContractors[index].errorContractorName = updatedContractors[index].name.trim() === "" && (updatedContractors[index].quantity.trim() !== ""  || updatedContractors[index].remark.trim() !== "");
        updatedContractors[index].errorQty = updatedContractors[index].quantity.trim() === "" && (updatedContractors[index].name.trim() !== "" || updatedContractors[index].remark.trim() !== "") ;
        setContractors(updatedContractors);
    };
  
    useEffect(() => { 
        const isContractValid = contractors?.some(item => 
            item?.errorContractorName === false && item?.errorQty === false
        );
      
        const isLabourValid = !!dprFormData?.labour?.length;  // Check if labour section has values
        const isMachineValid = !!dprFormData?.machine?.length; // Check if machine section has values
        const isMaterialValid = !!dprFormData?.material?.length; // Check if material section has values
        const isProjectSelected = dprFormErrors?.project === undefined;
        const hasNoErrors = isObjectEmpty(dprFormErrors); 
        const isFormValid = isProjectSelected && hasNoErrors && 
                            (isLabourValid || isContractValid || isMachineValid || isMaterialValid);
 
        setCanSubmit(!isFormValid); // Enable button when form is valid
    }, [dprFormErrors, contractors, dprFormData]);
    
    
    return (
        <form onSubmit={handleFormSubmit}>
            <>
                {!isFormOpen && <>
                    <Grid sx={{ padding: '20px' }} container spacing={2}> 
                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Typography>
                                Project Details
                            </Typography> 
                            <TableContainer>
                                <Table sx={{ minWidth: 650, border: '1px solid #3333', bgcolor: 'background.paper' }} aria-label="simple table">
                                    <TableBody>
                                        <TableRow>  
                                            <TableCell align="left" width={'50%'}>Project Name</TableCell>
                                            <TableCell align="left" width={'50%'}>  
                                                <Autocomplete
                                                    defaultValue={projectInfo?.name}
                                                    value={projectInfo?.name}
                                                    sx={{ width: '259px'}}
                                                    size='small' 
                                                    options={projectArray}
                                                    getOptionLabel={(option) => {  
                                                        return option?.name || option
                                                    }}
                                                    onChange={(e, newValue) => { 
                                                        setProjectInfo(newValue) 
                                                        setDprFormData({})
                                                        setDataArray([])
                                                        const updatedErrors = { ...dprFormErrors };
                                                        delete updatedErrors?.project;
                                                        setFormErrors(updatedErrors);
                                                    }} 
                                                    renderInput={(params) => <TextField {...params} variant="outlined" value={projectInfo?.name} placeholder="Please select a project" />}
                                                    isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                                    fullWidth
                                                /> 
                                                 {dprFormErrors?.project && (
                                                    <FormHelperText id="project-name-error" error>
                                                        {dprFormErrors?.project}
                                                    </FormHelperText>
                                                )}
                                            </TableCell>  
                                        </TableRow>
                                        <TableRow> 
                                            <TableCell align="left" width={'50px'}>Location</TableCell>
                                            <TableCell align="left" width={'50px'}>{ projectInfo?.location}</TableCell>  
                                        </TableRow> 
                                        <TableRow> 
                                            <TableCell align="left" width={'50px'}>Date</TableCell>
                                            <TableCell align="left" width={'50px'}> 
                                                { session?.user?.role_id === 2 ? <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                    <DemoContainer components={['DatePicker']}> 
                                                        <DatePicker  
                                                            maxDate={dayjs()}  
                                                            value={dateOfConsumption}
                                                            onChange={(date:any) => {                                     
                                                                setDateOfConsumption(date); 
                                                            }}   
                                                            slotProps={{ textField: { size: 'small' } }}
                                                            renderInput={(params:any) => <TextField {...params} value={dateOfConsumption}/>} 
                                                        />
                                                    </DemoContainer>
                                                </LocalizationProvider> 
                                                 : <Typography>{dayjs().format('DD/MM/YYYY')}</Typography>}
                                            </TableCell>  
                                        </TableRow> 
                                    </TableBody> 
                                </Table>
                            </TableContainer> 
                        </Grid> 

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Typography>
                                Labour
                            </Typography> 
                            <TableContainer>
                                <Table sx={{ minWidth: 650, border: '1px solid #3333', bgcolor: 'background.paper' }} aria-label="simple table">
                                    <TableBody>
                                        <TableRow> 
                                            <TableCell align="left" width={'50%'}>Company</TableCell>
                                            <TableCell align="left" width={'50%'}>  
                                                <FormControl>
                                                <TextField
                                                    name="company" 
                                                    value={dprFormData?.labour?.company?.quantity || ''}
                                                    onChange={(e) => handleChangeValue(e, 'labour', 'company', 'quantity')} 
                                                    placeholder="No. of company's labour"
                                                    size="small"
                                                    variant="outlined"
                                                />  
                                                {dprFormErrors?.labour?.company?.quantity && (
                                                    <FormHelperText id="project-name-error" error>
                                                        {dprFormErrors?.labour?.company?.quantity}
                                                    </FormHelperText>
                                                )}
                                                </FormControl> 
                                                <Textarea    
                                                    minRows={1} 
                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                    placeholder="Type remark here..." 
                                                    name='remark'  
                                                    value={dprFormData?.labour?.company?.remark || ''}
                                                    onChange={(e) => handleChangeValue(e, 'labour', 'company', 'remark')}  
                                                />
                                            </TableCell>  
                                        </TableRow>
                                        <TableRow>  
                                           <TableCell  sx={{ borderBottom: 'none'}}>
                                               Contractor 
                                           </TableCell>
                                           <TableCell sx={{textAlign: 'center', borderBottom: 'none'}}>
                                            <Button variant='contained' onClick={addContractor}>
                                                 <AddIcon /> 
                                            </Button>
                                           </TableCell> 
                                        </TableRow>
                                            {contractors?.map((contractor:any, index:number) => { 
                                                return (
                                                   <> 
                                                   <TableRow>  
                                                    <TableCell align="left" width={'50px'}>
                                                        <FormControl>
                                                            <TextField 
                                                                name="name" 
                                                                placeholder="Name of contractor" 
                                                                size='small'  
                                                                autoComplete='off'
                                                                onChange={(e)=> handleChangeContractor(index, e)}
                                                                value={contractor.name}
                                                                error={contractor?.errorContractorName}
                                                                helperText={contractor?.errorContractorName ? "Contractor is required" : ""}
                                                                variant="outlined" />
                                                               
                                                        </FormControl> 
                                                    </TableCell>
                                                    <TableCell align="left" width={'50px'}>
                                                        <div style={{display: 'flex'}}>
                                                            <FormControl>
                                                                <TextField 
                                                                    name="quantity" 
                                                                    autoComplete='off'
                                                                    placeholder="No. of Labour's" 
                                                                    size='small'  
                                                                    onChange={(e)=> handleChangeContractor(index, e)}
                                                                    value={contractor.quantity}
                                                                    error={contractor.errorQty}
                                                                    helperText={contractor.errorQty ? "Quantity is required" : ""}
                                                                    variant="outlined" />
                                                                   
                                                            </FormControl>  
                                                                <Textarea    
                                                                    minRows={1} 
                                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                                    placeholder="Type remark here..." 
                                                                    name='remark' 
                                                                    onChange={(e)=> handleChangeContractor(index, e)}
                                                                    value={contractor.remark} 
                                                                /> 
                                                               
                                                                {index !== 0 &&
                                                                <IconButton onClick={()=> confirmRemoveContractor(index)}>
                                                                    <Delete sx={{color: 'red'}}/> 
                                                                </IconButton> }
                                                        </div> 
                                                    </TableCell>  
                                                   </TableRow> 
                                                </>
                                                )
                                            })}
                                    </TableBody> 
                                </Table>
                            </TableContainer> 
                        </Grid> 

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Typography>
                               Machine
                            </Typography> 
                            <TableContainer>
                                <Table sx={{ minWidth: 650, border: '1px solid #3333', bgcolor: 'background.paper' }} aria-label="simple table">
                                    <TableBody>
                                        <TableRow> 
                                            <TableCell align="left" width={'50%'}>Tractor</TableCell>
                                            <TableCell align="left" width={'50%'}>  
                                                    <FormControl>
                                                        <TextField  
                                                            name="tractor" 
                                                            autoComplete='off'
                                                            value={dprFormData?.machinery?.tractor?.quantity || ''}
                                                            onChange={(e) => handleChangeValue(e, 'machinery', 'tractor', 'quantity')} 
                                                            placeholder='No. of tractor' 
                                                            size='small' 
                                                            variant="outlined" /> 
                                                            {dprFormErrors?.machinery?.tractor?.quantity && (
                                                                <FormHelperText id="error" error>
                                                                    {dprFormErrors?.machinery?.tractor?.quantity}
                                                                </FormHelperText>
                                                            )}
                                                    </FormControl>
                                                    <Textarea    
                                                    minRows={1} 
                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                    placeholder="Type remark here..."  
                                                    name='remark'
                                                    value={dprFormData?.machinery?.tractor?.remark}
                                                    onChange={(e) => handleChangeValue(e, 'machinery', 'tractor', 'remark')}  
                                                />
                                            </TableCell>  
                                        </TableRow>
                                        <TableRow> 
                                            <TableCell align="left" width={'50%'}>Trolly</TableCell>
                                            <TableCell align="left" width={'50%'}> 
                                                <FormControl>
                                                    <TextField  
                                                    name="trolly"
                                                    autoComplete='off'
                                                    value={dprFormData?.machinery?.trolly?.quantity || ''}
                                                    onChange={(e) => handleChangeValue(e, 'machinery', 'trolly', 'quantity')} 
                                                    placeholder='No. of trolly'
                                                    size='small'  
                                                    variant="outlined" />
                                                    {dprFormErrors?.machinery?.trolly?.quantity && (
                                                        <FormHelperText id="error" error>
                                                            {dprFormErrors?.machinery?.trolly?.quantity}
                                                        </FormHelperText>
                                                    )}
                                                </FormControl>

                                                <Textarea    
                                                    minRows={1} 
                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                    placeholder="Type remark here..."  
                                                    name='remark'
                                                    value={dprFormData?.machinery?.trolly?.remark}
                                                    onChange={(e) => handleChangeValue(e, 'machinery', 'trolly', 'remark')} 
                                                />
                                            </TableCell>  
                                        </TableRow>
                                        <TableRow> 
                                            <TableCell align="left" width={'50%'}>Tanker with fighter</TableCell>
                                            <TableCell align="left" width={'50%'}> 
                                                <FormControl>
                                                    <TextField   
                                                        autoComplete='off'
                                                        name="tankerWithFighter"
                                                        value={dprFormData?.machinery?.tankerWithFighter?.quantity || ''}
                                                        onChange={(e) => handleChangeValue(e, 'machinery', 'tankerWithFighter', 'quantity')} 
                                                        placeholder='No. of fighter' 
                                                        size='small'  
                                                        variant="outlined" />
                                                        {dprFormErrors?.machinery?.tankerWithFighter?.quantity && (
                                                        <FormHelperText id="error" error>
                                                            {dprFormErrors?.machinery?.tankerWithFighter?.quantity}
                                                        </FormHelperText>
                                                    )}
                                                </FormControl>

                                                <Textarea    
                                                    minRows={1} 
                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                    placeholder="Type remark here..."  
                                                    name='remark'
                                                    value={dprFormData?.machinery?.tankerWithFighter?.remark}
                                                    onChange={(e) => handleChangeValue(e, 'machinery', 'tankerWithFighter', 'remark')} 
                                                />
                                            </TableCell>  
                                        </TableRow>
                                        <TableRow> 
                                            <TableCell align="left" width={'50%'}>JCB</TableCell>
                                            <TableCell align="left" width={'50%'}> 
                                                <FormControl>
                                                    <TextField    
                                                    name="jcb"
                                                    autoComplete='off'
                                                    value={dprFormData?.machinery?.jcb?.quantity || ''}
                                                    onChange={(e) => handleChangeValue(e, 'machinery', 'jcb', 'quantity')} 
                                                    placeholder='No. of JCB' 
                                                    size='small'  
                                                    variant="outlined" />
                                                    {dprFormErrors?.machinery?.jcb?.quantity && (
                                                        <FormHelperText id="error" error>
                                                            {dprFormErrors?.machinery?.jcb?.quantity}
                                                        </FormHelperText>
                                                    )}
                                                </FormControl>

                                                <Textarea    
                                                    minRows={1} 
                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                    placeholder="Type remark here..."  
                                                    name='remark'
                                                    value={dprFormData?.machinery?.jcb?.remark}
                                                    onChange={(e) => handleChangeValue(e, 'machinery', 'jcb', 'remark')} 
                                                />
                                            </TableCell>  
                                        </TableRow>
                                    </TableBody> 
                                </Table>
                            </TableContainer> 
                        </Grid> 

                        {dataArray.length !== 0 && <Grid item lg={12} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Material</InputLabel>
                            <DailyUsedMaterialTable
                                data={dataArray}
                                handleSave={handleSave}
                                editingId={editingId}
                                removeMaterial={removeMaterial}
                                editMaterial={editMaterial}
                                handleChange={handleChange}
                                editedValue={editedValue}
                                isApproved={"pending"}
                            />
                        </Grid>}

                        <Grid item alignItems={'end'} lg={12} md={6} sm={6} xs={12}>
                            <Button style={{ float: 'right' }} variant='contained' type='button' onClick={() => setIsFormOpen(!isFormOpen)}> + Add Material </Button>
                            <Button sx={{ float: 'right', margin: '0px 10px' }} variant='contained' onClick={() => router.back()}>Cancel</Button>
                        </Grid>  
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={12}> 
                        <Button
                            type="submit"
                            variant="contained"
                            disabled={canSubmit}
                            style={{ margin: '0 20px', float: 'right' }}
                        >
                            Save
                        </Button>
                    </Grid>
                </>}

                <Grid sx={{ padding: '20px' }} container spacing={2}>
                    { isFormOpen &&
                        <Grid container spacing={2}>  
                        <Grid item lg={12} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Category <Asterisk>*</Asterisk></InputLabel>
                            <FormControl sx={{ width: '100%' }}>
                                <Autocomplete
                                    size='small'
                                    disabled={!categoryData.length}
                                    options={categoryData}
                                    getOptionLabel={(option) => {
                                        return typeof option == 'object' ? option?.categoryName : option;
                                    }}
                                    value={requestFormData?.categoryName}
                                    onChange={handleCategoryChange}
                                    renderInput={(params) => {
                                        return (<TextField {...params} />)
                                    }}
                                    fullWidth
                                />
                                {formErrors.categoryId && (
                                    <FormHelperText id="project-name-error" error>
                                        {formErrors.categoryId}
                                    </FormHelperText>
                                )}
                            </FormControl>
                        </Grid>

                        <Grid item lg={12} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Material <Asterisk>*</Asterisk></InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    <Autocomplete
                                        disabled={materialData.length == 0} 
                                        size='small'
                                        options={materialData}
                                        getOptionLabel={(option) => typeof option == 'object' ? option?.productName : option}
                                        value={requestFormData?.machineryOrPrductName}
                                        ListboxProps={{ onScroll: handleScroll, sx: { maxHeight: 150 } }}
                                        onChange={handleProductName}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                            InputProps={{
                                                    ...params.InputProps,
                                                    endAdornment: (
                                                        <>
                                                            {loading && <CircularProgress color="info" size={30} />}
                                                            {params.InputProps.endAdornment}
                                                        </>
                                                    ),
                                                }}
                                            />
                                        )}
                                        isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                        fullWidth
                                    />
                                    {formErrors.materialId && (
                                        <FormHelperText id="project-name-error" error>
                                            {formErrors.materialId}
                                        </FormHelperText>
                                    )}
                                </FormControl>
                            </Grid>

                        {!!itemNameArray?.length && <>
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Type / Grade</InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <Autocomplete
                                        size='small'
                                        options={itemNameArray}
                                        getOptionLabel={(option) => typeof option == 'object' ? option?.itemName : option}
                                        value={requestFormData?.itemName}
                                        onChange={handleItems}
                                        renderInput={(params) => {
                                            return (<TextField {...params} />)
                                        }}
                                        fullWidth
                                    />
                                </FormControl>
                                {formErrors.itemName && (
                                    <FormHelperText id="itemName-error" error>
                                        {formErrors?.itemName}
                                    </FormHelperText>
                                )}
                            </Grid>
                        </>}

                        {!!specificationArray?.length && <>
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Specification</InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    <Autocomplete
                                        size='small' 
                                        options={specificationArray}
                                        getOptionLabel={(option) => option?.productSpecification ?? option}
                                        value={requestFormData?.specification}
                                        onChange={handleSpec}
                                        renderInput={(params) => {
                                            return (<TextField {...params} />)
                                        }}
                                        fullWidth
                                    />
                                </FormControl>
                                {formErrors.specification && (
                                    <FormHelperText id="specification-error" error>
                                        {formErrors?.specification}
                                    </FormHelperText>
                                )}
                            </Grid>
                        </>}

                        {!!sizeItems.length && <>
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Size</InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <Autocomplete
                                        size='small' 
                                        options={sizeItems}
                                        getOptionLabel={(option) => option?.productSize ?? option}
                                        value={requestFormData?.size}
                                        onChange={handleSizeChange}
                                        renderInput={(params) => {
                                            return (<TextField {...params} />)
                                        }}
                                        fullWidth
                                    />
                                </FormControl>
                                {formErrors.size && (
                                    <FormHelperText id="size-error" error>
                                        {formErrors?.size}
                                    </FormHelperText>
                                )}
                            </Grid>
                        </>}

                        { !!requestFormData?.availableQty &&
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Available Qty</InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    <TextField
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        disabled={true}
                                        value={requestFormData?.availableQty}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                            </Grid>}

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Quantity <Asterisk>*</Asterisk></InputLabel>
                            <FormControl sx={{ width: '100%' }}>
                                <TextField
                                    size='small'
                                    type="text"
                                    id="my-input"
                                    value={requestFormData?.quantity}
                                    onChange={(e) => {
                                        let value = e.target.value;
                                        const numericValue = Number(value);
                                        const regex = /^[1-9]\d*$/;
                                        regex.test(value)
                                        if (((regex.test(value)) || (value === '')) && requestFormData?.availableQty >= numericValue) {
                                            setRequestFormData({
                                                ...requestFormData,
                                                quantity: value,
                                            })
                                            const updatedErrors = { ...formErrors };
                                            delete updatedErrors.quantity;
                                            setFormErrors(updatedErrors)
                                        }
                                    }}
                                    aria-describedby="my-helper-text"
                                />
                            </FormControl>
                            {formErrors.quantity && (
                                <FormHelperText id="project-name-error" error>
                                    {formErrors?.quantity}
                                </FormHelperText>
                            )}
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Unit</InputLabel>
                            <FormControl sx={{ width: '100%' }}>
                                <TextField
                                    size='small'
                                    type="text"
                                    id="my-input"
                                    value={requestFormData?.unit}
                                    aria-describedby="my-helper-text"
                                />
                            </FormControl>
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Remark <Asterisk>*</Asterisk></InputLabel>
                            <FormControl sx={{ width: '100%' }}>
                                <Textarea
                                    sx={{resize: 'none'}}
                                    size='small'
                                    type="text"
                                    id="my-input"
                                    value={requestFormData?.remark}
                                    onChange={(e) => {
                                        let value = e.target.value;
                                        setRequestFormData({
                                            ...requestFormData,
                                            remark: value,
                                        })
                                    }}
                                    aria-describedby="my-helper-text"
                                />
                            </FormControl>
                        </Grid>

                        <Grid item lg={12} md={6} sm={6} xs={12}>
                            <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={addMaterialForm}>Add</Button>
                            <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={() => handleCancelMaterial()}>Cancel</Button>
                        </Grid>
                        </Grid>
                    }
                </Grid>
                
                <ConfirmationDialog
                    open={openConfirm}
                    onClose={() => setOpenConfirm(false)}
                    title="Confirm Deletion"
                    message="Are you sure you want to delete this contractor?"
                    onConfirm={deleteContractor}
                    confirmText="Delete"
                    cancelText="Cancel"
                />
            </>
        </form>

    )
}

export default DailyProgressForm