import React from 'react';
import { MenuItem as MenuItemType } from '../../constants/menu-items';
import { MenuItemContainer, MenuItemLayout, SubmenuText } from '../../common/styles/MenuItem/styles';
import MenuItemsList from '../MenuItemsList';
import { useRouter } from 'next/navigation';
import { Dashbordtext } from '../../common/styles/MenuItem/styles';
import ExpandIcon from '../ExpandIcon/ExpandIcon';
import Link from 'next/link';
import { startLoading, stopLoading } from '../../redux/features/loadingSlice'
import { useDispatch } from 'react-redux';
import { setOpenSubMenu } from '../../redux/features/collapseExpandedSlice'

type MenuItemProps = {
  menuItem: MenuItemType;
  open?: boolean; 
  isSelected?: boolean;
  isSubMenuItem?: boolean;
};

export default function MenuItem({
  menuItem: { name, icon: Icon, url, depth, subItems, id, isExpanded },
  open: open, 
}: MenuItemProps) {
  const router = useRouter();
  const dispatch = useDispatch();
  let pageUrl = url === undefined ? "#" : url;
  const selected = router?.asPath === url;
  const isNested = subItems && subItems?.length > 0;

  const onClick = (mId: any) => {
    dispatch(startLoading());
    dispatch(setOpenSubMenu(mId))
  };

  return (
    <>
      {
        !!subItems?.length ?
          <>
            <MenuItemLayout className={selected ? '' : ''} depth={depth} onClick={() => onClick(id)}>
              <div className={`menu-item`}>
                <Icon />
                <SubmenuText open={open}>
                  {name}
                </SubmenuText>
              </div>

              {isNested ? (
                <ExpandIcon isExpanded={isExpanded} />
              ) : null}
            </MenuItemLayout>
          </> :
          <>
            <Link key={id}
              href={!!subItems?.length ? subItems?.[0].url : pageUrl}>
              <MenuItemContainer className={`${selected ? '' : ''}`} depth={depth}  >
                <div className={`menu-item`}>
                  <Icon />
                  <Dashbordtext open={open}>
                    {name}
                  </Dashbordtext>
                </div>

                {isNested ? (
                  <ExpandIcon isExpanded={isExpanded} />
                ) : null}
              </MenuItemContainer>
            </Link>
          </>
      }
      {isNested && isExpanded ? <MenuItemsList isSubMenuItem={isExpanded} options={subItems} open={open} /> : null}
    </>
  );
}
