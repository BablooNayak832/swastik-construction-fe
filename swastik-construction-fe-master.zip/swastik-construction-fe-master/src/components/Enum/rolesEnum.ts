export enum UserRoleEnum {
  SuperAdmin = 0,
  Admin = 1,
  ProjectHead = 2,
  PurchaseManager = 3,
  SiteManager = 4,
  SuperVisior = 5, // 'supervisior',
  SalesRepresentative = 6,
}

export enum userRole {
  SUPER_ADMIN = 'superAdmin',
  ADMIN = 'admin',
  ProjectHead = '',
  PurchaseManager = '',
  SiteManager = '',
  SuperVisior = '', // 'supervisior',
  SalesRepresentative = '',
}
