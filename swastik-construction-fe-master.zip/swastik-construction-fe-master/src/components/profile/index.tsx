import React, { useEffect, useState } from 'react';
import { 
    CoverPhoto,
    ImageText,
    Text,
    DetailsBox,
    DetailName,
    DetailRole,
    DetailWork,
    DetailEmail,
} from '../../common/styles/Profile/styles';
import { useSession } from 'next-auth/react';
import { Button, CircularProgress, FormControl, Grid, InputLabel, TextField } from '@mui/material';
import { Blankbox, Heading, HeadingBox } from '../../common/styles/Users/styles';
import { MainFormLayout, ProfilePageLayout } from '../Modal/styles'; 
import ResetPassword from '../../components/Auth/ResetPasswod/index'
import usePatch from 'src/hooks/usePatch';
import {toast} from 'react-toastify';
import useGet from 'src/hooks/useGet';
import {stringCapitalization} from 'src/utils/formatString'; 

const ProfilePage: React.FC = () => {
    const { data: session } = useSession()
    const [isClient, setIsClient] = useState(false);
    const [loginData, setLoginData] = useState<any>(null)
    const [userData, setUserData] = useState<any>({})
    const {handleUpdateData} = usePatch()
    const {resData, handleGetData} = useGet()

    const handleGetUserProfile = async() => {
      const res = await handleGetData(`/user/particular/${session?.user?.id}`)
      return res;
    }

    useEffect(() => {
        setIsClient(true); 
        handleGetUserProfile()
    }, []);

    useEffect(() => {
        setUserData(resData)
        setLoginData(resData)
    }, [resData])
 
    const getFirstLetter = (fullName: string): string => {
        if (fullName && fullName.trim().length > 0) {
            return fullName.charAt(0).toUpperCase(); // Get the first letter and capitalize it
        }
        return '';
    };

    const updateProfile =async() => {   
        const userPayload = {
            "updateUser": {
                "name": userData?.name ?? session?.user?.name,
                "mobileNumber": session?.user?.mobile ?? '',
                "id": session?.user?.id
            } 
        }
        const res = await handleUpdateData('/user', userPayload );
        toast("Successfully updated")
        return res;
    }

    return (
        <>
            {isClient ? (
                <div>
                    <CoverPhoto>
                        <img src={'/images/profile-image.jpg'} alt="noimage" />
                        <ImageText>
                            <Text>{session?.user ? getFirstLetter(session?.user?.name) : ''}</Text>
                        </ImageText>
                    </CoverPhoto>
                    <DetailsBox>
                        <>
                            <DetailName>{session?.user?.name}</DetailName>
                            <DetailRole>{session?.user?.role}</DetailRole>
                            <DetailWork>{session?.user?.mobile}</DetailWork>
                            <DetailEmail>{session?.user?.email}</DetailEmail>
                        </>
                    </DetailsBox>

                    <MainFormLayout>
                        <HeadingBox>
                            <Blankbox>
                                <Heading>Profile</Heading>
                            </Blankbox>
                            <Blankbox> 
                                    <ResetPassword updateData={{
                                        id: session?.user?.id,
                                        oldPassword: '',
                                        newPassword: ''
                                    }} /> 
                            </Blankbox>
                        </HeadingBox>
                        <ProfilePageLayout>
                            <form>
                                <Grid container spacing={2}>
                                    <Grid item lg={6} md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="my-input">Name</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                id="my-input"
                                                type='text'
                                                name='name'
                                                value={userData?.name}
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    setUserData({
                                                        ...userData,
                                                        name: value
                                                    });
                                                }}
                                                aria-describedby="my-helper-text"
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="my-input">Email</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                id="my-input"
                                                type='email' 
                                                value={loginData?.email}
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    setLoginData({
                                                        ...loginData,
                                                        email: value,
                                                    });
                                                }}
                                                aria-describedby="my-helper-text"
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="my-input">Mobile</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                id="my-input"
                                                type='text'
                                                value={loginData?.mobileNumber }
                                                onChange={(e) => {
                                                    const value = e.target.value;
                                                    setLoginData({
                                                        ...loginData,
                                                        mobileNumber: value,
                                                    });
                                                }}
                                                aria-describedby="my-helper-text"
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={12}>
                                        <InputLabel htmlFor="my-input">Role</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                id="my-input"
                                                type='text'
                                                value={stringCapitalization(loginData?.role?.key)}
                                                aria-describedby="my-helper-text"
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={12}>
                                        <Button variant='contained' onClick={updateProfile}>Save</Button>
                                    </Grid>
                                </Grid>
                            </form>
                        </ProfilePageLayout>
                    </MainFormLayout>
                </div>
            ) : (
                <CircularProgress color="success" />
            )}
        </>
    );
};
export default ProfilePage;