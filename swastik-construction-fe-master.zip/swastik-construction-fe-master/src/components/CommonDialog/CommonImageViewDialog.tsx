'use client';
import React, { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { DialogContent, DialogActions, IconButton, Tooltip } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import { useAllowedNavigation } from '../../context/context';
import ImageIcon from '@mui/icons-material/Image';
import { theme } from '../../../src/common/styles/theme';

type dialogType = {
    title?: string;
    children: any;
    onClick?: any;
    Icon?: any;
};

const CommonImageViewDialog = ({ title, children, onClick }: dialogType) => {

    const { openDialog, setOpenDialog } = useAllowedNavigation()
    const [headerTitle, setHeaderTitle] = useState<any>(null)
    const [childrenData, setChildrenData] = useState<any>(null)

    const handleClickOpen = () => {
        setHeaderTitle(title)
        setChildrenData(children)
        setOpenDialog(true);
        onClick();
    };

    const handleClose = () => {
        setHeaderTitle('')
        setChildrenData('')
        setOpenDialog(false);
    };

    return (
        <React.Fragment>

            <Tooltip title={`View`}>
                <IconButton aria-label="edit" size="small" color='success' onClick={handleClickOpen}>
                    <ImageIcon />
                </IconButton>
            </Tooltip>


            {openDialog && headerTitle && childrenData &&
                <Dialog
                    fullWidth
                    maxWidth='md'
                    open={openDialog}>
                    <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                        <Toolbar>
                            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                                {headerTitle}
                            </Typography>
                            <DialogActions>
                                <ClearIcon onClick={handleClose} />
                            </DialogActions>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>{childrenData} </DialogContent>
                </Dialog>
            }

        </React.Fragment>
    );
};
export default CommonImageViewDialog;
