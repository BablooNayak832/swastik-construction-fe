'use client';
import React from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { DialogContent, DialogActions, TableContainer, TableHead, TableRow, TableCell, TableBody, Table, Grid, List, ListItem, ListItemIcon, ListItemText, IconButton } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import moment from 'moment';
import { theme } from '../../../src/common/styles/theme';

type dialogType = {
    title?: string;
    children?: any;
    onClick?: any;
    data?: any;
    onClose?: any;
    open: boolean;
};

const SiteInventoryInfoDialog = ({ title, data, onClose, open }: dialogType) => {   
    return (
        <React.Fragment>
            {open &&
                <Dialog
                    fullWidth={true}
                    maxWidth={'md'}
                    open={open}
                >
                    <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                        <Toolbar>
                            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                                {title}
                            </Typography>
                            <DialogActions>
                                <ClearIcon onClick={() => onClose()} />
                            </DialogActions>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>
                        <Grid container item> 
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                                <ListItem secondaryAction={data?.projectName}>
                                    <ListItemText primary={ <strong>Project : </strong>} />
                                </ListItem> 
                            </Grid> 
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                               <ListItem secondaryAction={data?.category}>
                                    <ListItemText primary={<strong>Category : </strong>} />
                                </ListItem> 
                            </Grid>
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                                <ListItem secondaryAction={data?.productName}>
                                    <ListItemText primary={<strong>Material Name : </strong>} />
                                </ListItem>  
                            </Grid>
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                                <ListItem secondaryAction={data?.specification ?? "N/A"}>
                                    <ListItemText primary={<strong>Specification : </strong>} />
                                </ListItem> 
                            </Grid>
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                                 <ListItem secondaryAction={data?.size ?? "N/A"}>
                                    <ListItemText primary={<strong>Size : </strong>} />
                                </ListItem> 
                            </Grid>
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                                <ListItem secondaryAction={data?.itemName ?? "N/A"}>
                                    <ListItemText primary={<strong>Type / Grade : </strong>} />
                                </ListItem> 
                            </Grid>
                            <Grid lg={6} md={6} sm={6} xs={6}> 
                                 <ListItem secondaryAction={data?.unit}>
                                    <ListItemText primary={<strong>Unit : </strong>} />
                                </ListItem> 
                            </Grid>
                        </Grid>

                        <TableContainer>
                            <Table stickyHeader aria-label="sticky table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{fontWeight: 'bold'}} width={'15%'}> S No.</TableCell>
                                        <TableCell sx={{fontWeight: 'bold'}} width={'25%'} align='center'>Date / Time </TableCell>
                                        <TableCell sx={{fontWeight: 'bold'}} width={'25%'} align='center'>Received Quantity </TableCell>
                                        <TableCell sx={{fontWeight: 'bold'}} width={'25%'} align='center'>Deducted Quantity </TableCell> 
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {data?.logsData?.map((log: any, i: any) => {
                                        return (
                                            <TableRow hover role="checkbox" tabIndex={-1} key={i}>
                                                <TableCell key={i}>  {i + 1} </TableCell>
                                                <TableCell key={i} align='center'>{moment(log?.logsSiteInventoryCreatedAt).format("YYYY-MM-DD")} / {new Date(log?.logsSiteInventoryCreatedAt).toLocaleTimeString()}</TableCell>
                                                <TableCell key={i} align='center'> {!!log?.logsSiteInventoryReceivedQuantity ? log?.logsSiteInventoryReceivedQuantity : "_"}</TableCell> 
                                                <TableCell key={i} align='center'> {!!log?.logsSiteInventoryDeductQuantity ? log?.logsSiteInventoryDeductQuantity : '_'}</TableCell>
                                            </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </DialogContent>
                </Dialog>
            }

        </React.Fragment>
    );
};
export default SiteInventoryInfoDialog;
