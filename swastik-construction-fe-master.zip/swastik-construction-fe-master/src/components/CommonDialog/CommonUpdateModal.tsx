'use client';
import React, { useEffect, useState } from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { DialogContent, DialogActions } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import { useDispatch, useSelector } from 'react-redux';
import { setCloseModal } from 'src/redux/features/openModalSlice';
import { theme } from '../../../src/common/styles/theme';

type dialogType = {
    title?: string;
    children: any;
};

const CommonUpdateModal = ({ title, children }: dialogType) => {
    const [headerTitle, setHeaderTitle] = useState<any>(null)
    const [childrenData, setChildrenData] = useState<any>(null)
    const dispatch = useDispatch();
    const openModal = useSelector((state: any) => state?.openModal?.open)

    useEffect(() => {
        setChildrenData(children)
        setHeaderTitle(title)
    }, [children, title])

    const handleClose = () => {
        setHeaderTitle('')
        setChildrenData('')
        dispatch(setCloseModal());
    };

    return (
        <React.Fragment>
            {openModal && <Dialog
                fullWidth 
                maxWidth='lg'
                open={openModal}>
                <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                    <Toolbar>
                        <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                            {headerTitle}
                        </Typography>
                        <DialogActions>
                            <ClearIcon onClick={handleClose} />
                        </DialogActions>
                    </Toolbar>
                </AppBar>
                <DialogContent>{childrenData}</DialogContent>
            </Dialog>}
        </React.Fragment>
    );
};
export default CommonUpdateModal;