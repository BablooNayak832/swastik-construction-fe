'use client';
import React, { useState } from 'react';
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { DialogContent, DialogActions, IconButton } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import { useAllowedNavigation } from '../../context/context';
import EditIcon from '@mui/icons-material/Edit';
import { theme } from '../../../src/common/styles/theme';

type dialogType = {
    title?: string;
    children: any;
    onClick?: any;
};

const CommonEditDialog = ({ title, children, onClick }: dialogType) => {

    const { openDialog, setOpenDialog } = useAllowedNavigation()
    const [headerTitle, setHeaderTitle] = useState<any>(null)
    const [childrenData, setChildrenData] = useState<any>(null)

    const handleClickOpen = () => {
        setHeaderTitle(title)
        setChildrenData(children)
        setOpenDialog(true);
        onClick();
    };

    const handleClose = () => {
        setHeaderTitle('')
        setChildrenData('')
        setOpenDialog(false);
    };

    return (
        <React.Fragment>
            <IconButton aria-label="edit" size="small" onClick={handleClickOpen}>
                <EditIcon color='action'/>
            </IconButton>

            {openDialog && headerTitle && childrenData &&
                <Dialog
                    fullWidth
                    maxWidth='md'
                    open={openDialog}>
                    <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                        <Toolbar>
                            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                                {headerTitle}
                            </Typography>
                            <DialogActions>
                                <ClearIcon onClick={handleClose} />
                            </DialogActions>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>{childrenData} </DialogContent>
                </Dialog>
            }

        </React.Fragment>
    );
};
export default CommonEditDialog;
