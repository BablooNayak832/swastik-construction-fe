import { Visibility, VisibilityOff } from "@mui/icons-material";
import { AppBar, Button, Dialog, DialogActions, DialogContent, FormControl, FormHelperText, Grid, IconButton, Input, InputAdornment, InputLabel, TextField, Toolbar, Typography } from "@mui/material";
import React, { useState } from "react";
import usePatch from "../../../hooks/usePatch";
import { user_update_password } from "../../../constants/api-routes";
import {theme} from "../../../common/styles/theme";
import ClearIcon from '@mui/icons-material/Clear';

const ResetPassword = ({ updateData }: any) => {
    const [updateUserdata, setUpdateUserdata] = useState(updateData)
    const { handleUpdateData } = usePatch()
    const [showCurrentPassword, setShowCurrentPassword] = React.useState(false);
    const [showNewPassword, setShowNewPassword] = React.useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = React.useState(false)
    const [openDialog, setOpenDialog] = React.useState(false)
    const [errors, setErrors] = useState<any>({});

    const validateForm = () => {
        const newErrors:any = {};
        if (!updateUserdata?.oldPassword) {
        newErrors.oldPassword = 'Current password is required';
        }
        if (!updateUserdata?.newPassword) {
        newErrors.newPassword = 'New password is required';
        } 
        // else if (updateUserdata?.newPassword.length < 8) {
        // newErrors.newPassword = 'Password must be at least 8 characters long';
        // }
        if (updateUserdata?.newPassword !== updateUserdata?.confirmPassword) {
        newErrors.confirmPassword = 'Passwords must match';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };
 
    const handleSubmit = (e: any) => {
        e.preventDefault() 
         const payload = {
            "id": updateUserdata?.id,
            "oldPassword": updateUserdata?.oldPassword,
            "newPassword": updateUserdata?.newPassword,
            "confirmPassword" : updateUserdata?.confirmPassword
        } 
        if (validateForm()) {
            const result = handleUpdateData(user_update_password, payload).then((response) => response).catch((err) => err);
            setOpenDialog(false)
            setUpdateUserdata({})
            return result;
        }
    }

    const handleMouseDownPassword = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
    };

    return (
        <>
        <React.Fragment>
            <Button variant="contained" onClick={()=> setOpenDialog(!openDialog)}>
                 Reset password
            </Button>
            {openDialog && <Dialog
                fullWidth
                maxWidth='md'
                open={openDialog}>
                <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                <Toolbar>
                    <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                       Reset password
                    </Typography>
                    <DialogActions>
                      <ClearIcon onClick={() => setOpenDialog(!openDialog)} />
                    </DialogActions>
                </Toolbar>
                </AppBar>
                <DialogContent>              
                <form onSubmit={handleSubmit}>
                    <Grid container spacing={2}>
                        <Grid item lg={12} md={6} sm={6} xs={12}>
                            <FormControl sx={{ m: 1, width: '100%' }} variant="standard">
                                <InputLabel htmlFor="standard-adornment-password">Current Password</InputLabel>
                                <Input
                                    id="standard-adornment-password"
                                    type={showCurrentPassword ? 'text' : 'password'}
                                    value={updateUserdata.oldPassword} 
                                    placeholder='Enter your current password'
                                    onChange={(e: any) => {
                                        setUpdateUserdata({
                                            ...updateUserdata,
                                            oldPassword: e.target.value,
                                        });
                                        const updatedErrors = { ...errors };
                                        delete updatedErrors.oldPassword;
                                        setErrors(updatedErrors);
                                    }}
                                    endAdornment={
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label="toggle password visibility"
                                                onClick={() => setShowCurrentPassword((show) => !show)}
                                                onMouseDown={handleMouseDownPassword}
                                            >
                                                {showCurrentPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    }
                                />
                            {errors.oldPassword &&  
                             <FormHelperText id="project-name-error" error>
                               {errors.oldPassword}
                             </FormHelperText>}
                            </FormControl>

                        </Grid>

                        <Grid item lg={12} md={6} sm={6} xs={12}>
                            <FormControl sx={{ m: 1, width: '100%' }} variant="standard">
                                <InputLabel htmlFor="standard-adornment-password">New Password Password</InputLabel>
                                <Input
                                    id="standard-adornment-password" 
                                    type={showNewPassword ? 'text' : 'password'}
                                    value={updateUserdata.newPassword}
                                    placeholder='Enter your current password'
                                    onChange={(e: any) => {
                                        setUpdateUserdata({
                                            ...updateUserdata,
                                            newPassword: e.target.value,
                                        });
                                        const updatedErrors = { ...errors };
                                        delete updatedErrors.newPassword;
                                        setErrors(updatedErrors);
                                    }}
                                    endAdornment={
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label="toggle password visibility"
                                                onClick={() => setShowNewPassword((show) => !show)}
                                                onMouseDown={handleMouseDownPassword}
                                            >
                                                {showNewPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    }
                                />
                            {errors.newPassword &&
                             <FormHelperText id="project-name-error" error>
                               {errors.newPassword}
                             </FormHelperText>}
                            </FormControl>
                        </Grid>

                        <Grid item lg={12} md={6} sm={6} xs={12}>
                            <FormControl sx={{ m: 1, width: '100%' }} variant="standard">
                                <InputLabel htmlFor="standard-adornment-password">Confirm Password</InputLabel>
                                <Input 
                                    id="standard-adornment-password"
                                    type={showConfirmPassword ? 'text' : 'password'}
                                    value={updateUserdata.confirmPassword}
                                    placeholder='Enter your current password'
                                    onChange={(e: any) => {
                                        setUpdateUserdata({
                                            ...updateUserdata,
                                            confirmPassword: e.target.value,
                                        });
                                        const updatedErrors = { ...errors };
                                        delete updatedErrors.confirmPassword;
                                        setErrors(updatedErrors);
                                    }}
                                    endAdornment={
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label="toggle password visibility"
                                                onClick={() => setShowConfirmPassword((show) => !show)}
                                                onMouseDown={handleMouseDownPassword}
                                            >
                                                {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    }
                                />
                            {errors.confirmPassword &&  
                            <FormHelperText id="project-name-error" error>
                                {errors.confirmPassword}
                            </FormHelperText>}
                            </FormControl>
                        </Grid>
                    </Grid>
                    <Button variant="contained" type="submit">Reset</Button>
                </form>
                </DialogContent>
            </Dialog>}
            </React.Fragment>

        </>
    );
}

export default ResetPassword;
