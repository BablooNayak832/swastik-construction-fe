/* eslint-disable prettier/prettier */
'use client'; 
import React, { useEffect, useState } from 'react';
import {
  Wrapper,
  Container,
  Header,
  LoginCard, 
  LTEtext,
  Paragraph,
  Form,
  Input,
  ButtonBox, 
  LogoTitleText,
  LogoSubTitletext,
  LogoContainerLayout,
} from '../../../common/styles/Auth/Login/styles'; 
import { usePathname, useRouter } from 'next/navigation';
import SnackbarToast from '../../SnackbarToast/SnackbarToast';
import { Button, FormHelperText, Grid, IconButton } from '@mui/material';
import { useSession, signIn } from 'next-auth/react';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import VisibilityIcon from '@mui/icons-material/Visibility';
import {toast} from 'react-toastify';
import Image from 'next/image';

interface UserFormData{
  username: string;
  password: string;
}

const Login = () => {
  const pathname = usePathname()
  const router = useRouter(); 
  const [loginData, setLoginData] = React.useState({
    username: '',
    password: '',
  });
  const [isShowPassword, setIsShowPassword] = React.useState(false);
  const [openSuccess, setOpenSuccess] = React.useState(false);
  const [openError, setOpenError] = React.useState(false);
  const [snackbarMessage, setSnackbarMessage] = React.useState('');
  const [errors, setErrors] = useState<UserFormData>({
    username: '',
    password: '',
  });
  const { status, data: session } = useSession();
  const [userFcmToken, setUserFcmToken ] = useState<any>('')

  const handleShowPassword = () => {
    setIsShowPassword(!isShowPassword);
  };

  // Function to validate the form
  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!loginData.username.trim()) {
      newErrors.username = 'Email or mobile number is required.';
    } else {
      delete newErrors.username;
    }
    if (!loginData.password.trim()) {
      newErrors.password = 'Password is required.';
    } else {
      delete newErrors.password;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const fcmLocalToken = typeof window !== 'undefined' ? localStorage.getItem('fcmToken') : ''; 

  useEffect(() => {
    setUserFcmToken(fcmLocalToken)
  },[fcmLocalToken])

  useEffect(() => { 
    if(!!session?.user && pathname === '/auth/signin'){
      router.replace('/')
    }  
  }, [session, router]);

  const handleSubmit = async (e: any) => { 
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      let res = await signIn('credentials', {
        redirect: false,
        username: loginData.username.trim(),
        password: loginData.password.trim(),
        firebaseToken: userFcmToken,
        callbackUrl: "/", 
      });
      console.log("res ---->>>", res); 
      
      if (res?.status === 401) {
        setOpenError(true);
        setSnackbarMessage('Unauthorized User');
      }
      if (res?.error === "CAN_NOT_LOGIN_THIS_USER") {
        setOpenError(true);
        setSnackbarMessage("Can't login this user.");
      }
      if (res?.error === "MOBILE_NUMBER_NOT_REGISTERED_OR_EMAIL_NOT_REGISTERED") {
        setOpenError(true);
        setSnackbarMessage('This email or mobile number is not registered');
      }
      if (res?.error === null && res?.status === 200) { 
        router.replace('/')
        toast.success("Login successful!")
      }
    }
  };  
  console.warn("userFcmToken", userFcmToken);

  if (status === 'unauthenticated') {
    return (
      <>
        <Grid container spacing={0}>
          <Grid item xs={6}> 
            <Wrapper>
              <Container>
                <Header> 
                  <LTEtext>Swastik Construction</LTEtext>
                </Header>

                <LoginCard>
                  <Paragraph>Sign in to start your session</Paragraph>
                  <Form method="POST" onSubmit={handleSubmit}>
                    <div
                      style={{
                        width: '100%',
                        position: 'relative',
                        paddingBottom: '10px',
                      }}
                    >
                      <Input
                        placeholder="Enter your email or mobile number."
                        value={loginData.username}
                        onChange={(e) => {
                          setLoginData({
                            ...loginData,
                            username: e.target.value,
                          });
                          const updateError = {...errors}
                          delete updateError?.username;
                          setErrors(updateError);
                        }}
                      />
                      <FormHelperText
                        style={{
                          position: 'absolute',
                          bottom: '-10px', 
                        }}
                      >
                        {errors.username}
                      </FormHelperText>
                    </div>
                    <div
                      style={{
                        width: '100%',
                        position: 'relative',
                        paddingBottom: '10px',
                      }}
                    >
                      <Input
                        type={isShowPassword ? 'text' : 'password'}
                        placeholder="Password"
                        value={loginData.password}
                        onChange={(e) => { 
                          setLoginData({
                            ...loginData,
                            password: e.target.value,
                          });
                          const updateError = {...errors}
                          delete updateError?.password;
                          setErrors(updateError);
                        }}
                      />
                      <IconButton
                        aria-label="visibility-icon"
                        style={{
                          position: 'absolute',
                          top: '11px',
                          right: '0px',
                        }}
                        onClick={handleShowPassword}
                      >
                        {isShowPassword ? (
                          <VisibilityIcon />
                        ) : (
                          <VisibilityOffIcon />
                        )}
                      </IconButton>
                      <FormHelperText
                        style={{
                          position: 'absolute',
                          bottom: '-10px', 
                        }}
                      >
                        {errors.password}
                      </FormHelperText>
                    </div>
                    <ButtonBox>
                      <Button type='submit' variant='contained'>Sign in</Button> 
                    </ButtonBox>
                  </Form>
                </LoginCard>
              </Container>
            </Wrapper> 
            <SnackbarToast
              openSuccess={openSuccess}
              openError={openError}
              setOpenSuccess={setOpenSuccess}
              setOpenError={setOpenError}
              snackbarMessage={snackbarMessage}
            />
          </Grid>
          <Grid item xs={6}>
            <div style={{ height: '100vh', width: '100%', placeContent: 'center' , justifyItems: 'center'}}>
            <div style={{textAlign:"center"}}>
              <Image alt='login-image' width={100} height={100} style={{ width: '25%', height: 'auto' , alignItems: 'center' }} src="/images/swastik_icon.png"/>
              <LogoContainerLayout> 
                    <LogoTitleText>Swastik Habitates (I) Pvt. Ltd. </LogoTitleText>
                    <LogoSubTitletext>CONTRACTOR & DEVELOPER</LogoSubTitletext>
              </LogoContainerLayout> 
            </div>
            </div>
          </Grid>
        </Grid>
      </>
    );
  }
};

export default Login;
