import React, { useState } from 'react'
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import { useDispatch, useSelector } from 'react-redux';
import { setOpenPopover } from 'src/redux/features/openPopoverSlice';
import { Textarea } from '../../constants';
import { Button, ButtonGroup, FormControl, FormHelperText, Grid, IconButton, InputLabel } from '@mui/material';


interface popoverType {
    openPopup: boolean,
    updateRowData: any,
    handleApproveProject: any
}

const PopoverComponent = ({ updateRowData, handleApproveProject, openPopup }: popoverType) => {
    const openPopover = useSelector((state: any) => state?.openPopover);
    const dispatch = useDispatch();
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const open = Boolean(openPopover.open);
    const popupId = open ? 'simple-popover' : undefined;
    const errors: { [key: string]: string } = {};

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        dispatch(setOpenPopover(event.currentTarget))
    };

    const handleClose = () => {
        dispatch(setOpenPopover(null))
    };

    const [formData, setFormData] = useState({
        remark: '',
        salesStatus: ''
    })

    const handleApprove = (status: string) => {
        const payload = {
            project: {
                id: updateRowData?.id,
                remark: formData.remark,
                salesStatus: status
            }
        }

        if (status !== 'rejected') {
            handleApproveProject(payload)
            dispatch(setOpenPopover(null))
            setFormData({ remark: '', salesStatus: '' })

        } else {
            const isValid = validateFields()
                if (isValid) { 
                if (!!formData.remark) {
                    handleApproveProject(payload)
                    dispatch(setOpenPopover(null))
                    setFormData({ remark: '', salesStatus: '' })
                }
            }
        }
    }
   
    const validateFields = () => {
        if(!formData?.remark){
            errors.remark = 'Please filled in the remarks field.'
        }else{
            delete errors.remark
        }
        setFormErrors(errors); 
       return Object.keys(errors).length === 0; // Returns true if no errors found
     }; 

    return (
        <>
            {/* <IconButton
                color="primary"
                size="small"
                aria-label="edit"
            // onClick={handleClick}
            >
                <SettingsOutlinedIcon />
            </IconButton> */}
            {openPopup && <Popover
                id={popupId}
                open={openPopup}
                anchorEl={openPopover.open}
                onClose={handleClose}
                anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'left',
                }}
            > 
                <div style={{ width: "400px", height: "200px", background: "#73857b47", padding: '10px' }}>
                    {/* <Typography sx={{ p: 2 }}> Do you want to {updateRowData.salesStatus === "rejected" ? 'approve' : "reject"} this project ?</Typography> */}
                    <Typography sx={{ p: 2 }}> Do you want to {updateRowData.salesStatus === "Pending" ? 'Approve / Reject' : updateRowData.salesStatus === "Rejected" ? 'approve' : 'reject'} this project ?</Typography>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Remark</InputLabel>
                        <FormControl
                            sx={{ width: '100%' }}
                        >
                            <Textarea
                                sx={{resize: 'none'}}
                                size='small'
                                type="text"
                                id="my-input"
                                value={formData.remark}
                                onChange={(e) => {
                                    const value = e.target.value;
                                    setFormData({
                                        ...formData,
                                        remark: e.target.value,
                                    });
                                    const updatedErrors = { ...formErrors };
                                    delete updatedErrors.remark;
                                    setFormErrors(updatedErrors);
                                }}
                                aria-describedby="my-helper-text"
                            />
                        </FormControl>
                          {formErrors.remark && (
                           <FormHelperText id="name-error" error>
                              {formErrors.remark}
                            </FormHelperText>
                           )} 
                    </Grid>
             
                   { updateRowData.salesStatus === "Pending" ? 
                     <ButtonGroup sx={{ padding: '10px 20px', float: 'right' }} variant="outlined" aria-label="Basic button group">
                        <Button variant='outlined' size='small' onClick={() => handleApprove("rejected")}>Reject</Button>
                        <Button variant='contained' size='small' onClick={() => handleApprove('active')}>Approve</Button>
                    </ButtonGroup> :
                    <ButtonGroup sx={{ padding: '10px 20px', float: 'right' }} variant="outlined" aria-label="Basic button group">
                        <Button variant='outlined' size='small' onClick={() => dispatch(setOpenPopover(null))}>No</Button>
                        <Button variant='contained' size='small' onClick={() => handleApprove(updateRowData.salesStatus === "Rejected" ? 'active' : "rejected")}>Yes</Button>
                    </ButtonGroup> 
                   } 
                </div>
            </Popover>}
        </>
    )
}

export default PopoverComponent