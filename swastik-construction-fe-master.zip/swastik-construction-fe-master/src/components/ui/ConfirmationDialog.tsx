import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from "@mui/material";
import React from "react";

interface propType{
    open: boolean;
    onClose: () => void;
    title: string;
    message: string;
    onConfirm: () => void;
    confirmText: string;
    cancelText: string;
}
const ConfirmationDialog = ({ open, onClose, title, message, onConfirm, confirmText = "Confirm", cancelText = "Cancel" }: propType) => {
    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>{title}</DialogTitle>
            <DialogContent>{message}</DialogContent>
            <DialogActions>
                <Button variant="outlined" size="small" onClick={onClose}>
                    {cancelText}
                </Button>
                <Button variant="contained" size="small" onClick={onConfirm}>
                    {confirmText}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

export default ConfirmationDialog;
