import Avatar from "@mui/material/Avatar/Avatar";
import AvatarGroup from "@mui/material/AvatarGroup";
import React from "react";
import TooltipMaterial from '@mui/material/Tooltip';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { List } from "@mui/material";

const CommonAvatarGroup = ({ itemGroup, columnId, valueType }: any) => {
    return (
        <>
            {columnId === 'assignproject' &&
                <AvatarGroup total={itemGroup?.length} max={3}>
                    {!itemGroup?.length ? (<span>Not Assigned</span>) : (valueType === 'object' && Array.isArray(itemGroup)
                        && columnId === 'assignproject' && itemGroup?.map((i) => {
                            return (
                                <TooltipMaterial
                                    describeChild
                                    key={i?.id}
                                    disableFocusListener
                                    title={i?.admin?.email}
                                >
                                    <Avatar
                                        key={i?.admin?.id}
                                        src=''
                                        alt={i?.admin?.name}
                                    />
                                </TooltipMaterial>
                            );
                        }))}
                </AvatarGroup>
            }

            {(itemGroup?.length && valueType === 'object') ? Array.isArray(itemGroup)
                && columnId === 'subcategory' && itemGroup?.map((i) => {
                    const style = {
                        width: '100%',
                    };
                    return (
                        <>
                            <div sx={{ display: 'block' }}>
                                <List sx={style} >
                                    <ListItem>
                                        <ListItemText primary={i?.category} />
                                    </ListItem>
                                </List>
                            </div>
                        </>
                    );
                }) : null}

            {columnId === 'assignProject' &&
                <AvatarGroup total={itemGroup?.length} max={3}>
                    {itemGroup?.length && valueType === 'object' && Array.isArray(itemGroup) &&
                        columnId === 'assignProject' && itemGroup?.map((i) => {
                            return (
                                <TooltipMaterial
                                    describeChild
                                    key={i?.id}
                                    disableFocusListener
                                    title={i?.projectName}
                                >
                                    <Avatar
                                        key={i?.id}
                                        src='/'
                                        alt={i?.projectName}
                                    />
                                </TooltipMaterial>
                            );
                        })
                    }
                </AvatarGroup>
            }
        </>);
}

export default CommonAvatarGroup;