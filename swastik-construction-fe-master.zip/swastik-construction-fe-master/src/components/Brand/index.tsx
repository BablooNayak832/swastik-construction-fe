'use client'
import React, { useEffect, useState } from "react";
import TableMain from '../Table/Table'
import { TablePagination } from "@mui/material";
import { Heading, HeadingBox } from "../../common/styles/Users/styles";
import { Blankbox } from "../../components/Table/styles";
import CommonDialog from "../../components/CommonDialog/CommonDialog";
import MainForm from "../../components/common-form";
import useGet from "../../hooks/useGet";
import { Wrapper } from "../../app/styles";
import usePatch from "../../hooks/usePatch";
import { useAllowedNavigation } from "../../context/context";
import useDelete from "../../hooks/useDelete";
import useDownloadExcel from "../../hooks/downloadExcel";
import { brandExcel, brand_url, category_url } from "../../constants/api-routes";
import { useSession } from "next-auth/react";
import axios from "axios";
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import { Button } from "@mui/material";
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { DialogContent, DialogActions } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import usePost from "src/hooks/usePost";
import UploadDialog from "../UploadDialog";
import { toast } from "react-toastify";

const brandColumns: any = [
    { id: 'sNo', label: 'S No.', minWidth: 70 },
    { id: 'brandName', label: 'Name', minWidth: 70 },
    { id: 'type', label: 'Type', minwidth: 100 },
    { id: 'category', label: 'Category', minwidth: 100 }
]

function createBrandData(
    id: number,
    sNo: number,
    brandName: string,
    typeId: any[],
    type: string,
    category: string | undefined | null,
    categories: any[]
): any {
    return {
        id,
        sNo,
        brandName,
        typeId,
        type,
        category,
        categories
    }
}

const BrandPage = () => {
    const { resData, handleGetData, isLoading } = useGet()
    const { resData: getCategoryData, handleGetData: handleGetCategory } = useGet()
    const { handleDeleteData } = useDelete()
    const { handleUpdateData } = usePatch()
    const { setOpen, setRenderData } = useAllowedNavigation()
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const { data: session } = useSession()
    const [openUploadMaterialDialog, setOpenUploadMaterialDialog] = useState(false);
    const [file, setFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);
    const { handlePostData } = usePost();

    useEffect(() => {
        getBrands()
        getCategory()
    }, [])

    useEffect(() => {
        getBrands()
    }, [queryParams])

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    const brandData = resData?.map((i: any, index: number) => {
        const cType = i?.type && i?.type?.map((i: any) => i === 1 ? "Material" : "Machinery").join(", ");
        const categories = i?.categories && i?.categories?.map((i: any) => i.categoryName).join(", ");
        return createBrandData(i?.id, index + 1, i.brandName, i?.type, cType, categories, i?.categories?.map(i => i?.id));
    });

    const getBrands = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
        const category = await handleGetData(`${brand_url}?${searchParams}`);
        setPage(0)
        return category;
    }

    const getCategory = async () => {
        const category = await handleGetCategory(`${category_url}`);
        return category;
    }

    const searchTableData = async (value: any) => {
        setQueryParams((prevValue: any) => {
            return { ...queryParams, ['q']: value }
        })
        setPage(0)
    }

    const filterBrand = async (param: any) => {
        setQueryParams((prevValue: any) => {
            return { ...queryParams, ['typeId']: param.value }
        })
        setPage(0)
    }

    const filterMenuOption = [
        { id: 1, menuText: 'Material', fun: () => filterBrand({ key: 'typeId', value: 1 }) },
        { id: 2, menuText: 'Machinery', fun: () => filterBrand({ key: 'typeId', value: 2 }) },
    ]

    const handleUpdateBrand = async (
        e: { preventDefault: () => void },
        payload: any
    ) => {
        e.preventDefault();
        const res = await handleUpdateData(brand_url, payload)
            .then((data) => {
                setRenderData(true);
            })
            .catch((error) => {
                alert(`Invalid Credentials, Try Again ${error.message}`);
            });
        setOpen(false);
        getBrands();
        return res;
    };

    const removeBrand = async (mId: any) => {
        const { id, brandName } = mId;
        const details = await handleDeleteData(`${brand_url}/${brandName}`);
        getBrands()
        return details;
    };

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        const res = handleDownloadData(`${brand_url}?type=xls${searchParams}`, "Brand")
        return res;
    }

    const resetFilter = async () => {
        setQueryParams({})
        setPage(0)
        await getBrands()
    }

    //  const token = localStorage.getItem("token");
    const handleUpload = async () => {
        if (!file) {
            toast.warning("Please select a file.");
            return;
        }

        const formData = new FormData();
        formData.append("excelFile", file);
        await handlePostData(brandExcel, formData)
        await getBrands()
        setOpenUploadMaterialDialog(false)
        setFile(null);
    };

    const handleDownload = async () => {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Dummy Data');

        // Define columns
        worksheet.columns = [
            { header: 'Head', key: 'productName', width: 20 }
        ];

        // Add dummy row
        worksheet.addRow({
            productName: 'CONCRETE'
        });

        // Generate file and download
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        saveAs(blob, 'dummy_brand_format.xlsx');
    };

    const handleFileChange = (event) => {
        setFile(event.target.files?.[0] || null);
    };

    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Brand</Heading>
                    </Blankbox>
                    <Blankbox>
                        <Button variant='contained' onClick={() => setOpenUploadMaterialDialog(true)} >Upload Brand</Button>
                        <Button variant='contained' sx={{ margin: '0px 2px' }} onClick={handleDownload}>
                            Export Brand Template
                        </Button>
                        {session?.user?.role_id === 1 &&  
                        <CommonDialog title="Add Brand">
                            <MainForm
                                data={{
                                    brandName: '',
                                    type: [],
                                }}
                                url={brand_url}
                                title={'Add Brand'}
                                selectItem={getCategoryData}
                                refreshData={getBrands}
                            />
                        </CommonDialog>
                          }
                    </Blankbox> 
                </HeadingBox>
                <TableMain
                    title='Brand'
                    isLoading={isLoading}
                    url={brand_url}
                    handleExcelExport={handleExcelExport}
                    columns={brandColumns}
                    rows={brandData}
                    page={page}
                    rowsPerPage={rowsPerPage}
                    handleChangePage={handleChangePage}
                    handleChangeRowsPerPage={handleChangeRowsPerPage}
                    refreshTableData={getBrands}
                    handleRemoveRow={removeBrand}
                    handleUpdateProps={handleUpdateBrand}
                    handleAvailableQuantity={() => 'handleAvailableQuantity'}
                    searchTableData={searchTableData}
                    filterMenuOption={filterMenuOption}
                    resetFilter={resetFilter}
                    catItems={getCategoryData}
                />
                <TablePagination
                    rowsPerPageOptions={[5, 10, 15, 25, 50]}
                    component="div"
                    count={brandData?.length}
                    rowsPerPage={rowsPerPage}
                    page={page}
                    onPageChange={handleChangePage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                />

                <UploadDialog
                    open={openUploadMaterialDialog}
                    loading={loading}
                    file={file}
                    setOpen={setOpenUploadMaterialDialog}
                    setFile={setFile}
                    handleUpload={handleUpload}
                    title="Upload Brand Excel"
                />
            </Wrapper>
        </>
    )
}

export default BrandPage;