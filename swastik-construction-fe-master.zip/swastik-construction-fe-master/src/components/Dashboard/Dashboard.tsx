'use client';
import React, { useState, useEffect } from 'react';
import Card from '@mui/material/Card'; 
import Grid from '@mui/material/Grid';
import { Box, Paper } from '@mui/material';
import useGet from '../../hooks/useGet';
import MainPieChart from '../Highcharts/PieChart';
import { useSession } from 'next-auth/react'; 
import { poDashboardColumn, projectListDashboardColumn } from '../../constants/table-columns'
import { UserRoleEnum } from '../Enum/rolesEnum';
import { material_url, projects_url, user_get_count, project_count, purchase_order_url } from 'src/constants/api-routes';
import ProjectListTable from '../Table/ProjectListTable';
import { useSelector } from 'react-redux';
import _ from 'lodash';
import CountCardComponent from '../../view/dashboard/CountCard'

interface HomeProps {
  open?: boolean;
}

const Dashboard: React.FC<HomeProps> = () => {
  const { data: session } = useSession();
  const { resData: materialData, handleGetData: GetAllMaterial } = useGet();
  const { resData: CountData, handleGetData: GetAllCounts } = useGet<any>();
  const { resData: Projects, handleGetData: getAllProject } = useGet(); 
  const { resData: partialPoResData, handleGetData: GetPartialPO } = useGet();
  const { resData: deliveredPoResData, handleGetData: GetDeliveredPO } = useGet(); 
  const { resData: totalCount, handleGetData: getTotalCounts } = useGet();
  const selectedProject = useSelector((state: any) => state?.selectedProject);
  let selectedProjectId = selectedProject?.selectedValue?.id === undefined ? '' : `${selectedProject?.selectedValue?.id}`;
  const [ purchaseOrderList, setPurchaseOrderList] = useState([])
  const [ partialPurchaseOrderList, setPartialPurchaseOrder] = useState([])
  
  useEffect(() => {
    getTotalCount()
  },[selectedProjectId])
 
  useEffect(() => {
    // Fetch projects for the initial page
    GetAllCountss();
    handleAllMaterial(); 
    handleGetProjects();
    handleGetPartialPO() 
    handleGetDelivered() 
  }, []);
  
  const getTotalCount = async() => {
    const res = await getTotalCounts(`${project_count}?projectId=${selectedProjectId}`)
    return res;
  }

  const GetAllCountss = async () => {
    try {
      const details = await GetAllCounts(user_get_count);
      return details;
    } catch (err) {
      return err;
    }
  };

  const handleAllMaterial = async () => {
    try {
      const details = await GetAllMaterial(material_url);
      return details;
    } catch (err) {
      return err;
    }
  };

  const handleGetProjects = async () => { 
      const details = await getAllProject(`${projects_url}/?page=1&limit=100&sales=active`);
      return details; 
  };

  const handleGetPartialPO = async () => { 
    const details = await GetPartialPO(`${purchase_order_url}/?page=1&limit=100&searchTerm=partialDelivered`);
    return details; 
 };

  const handleGetDelivered = async() => {
    const details = await GetDeliveredPO(`${purchase_order_url}/?page=1&limit=100&searchTerm=delivered`);
    return details; 
  }

  useEffect(() => {
     let sNo:number, projectName:string, poNo, poStatus, array = [];
     partialPoResData?.orderData?.items?.map((item: any,idx: any) => { 
      item?.items?.map((purchase: any,index: number) => {     
          sNo = idx + 1;
          projectName = purchase?.projectDetails?.projectName ?? "_";
          poNo = item?.purchaseOrderNo ?? "_";
          poStatus = item?.status ?? "_";  
        })    
        // return array;
        array.push({sNo: sNo, projectName: projectName, poNo: poNo, poStatus: poStatus}) 
      }); 
      setPartialPurchaseOrder(array)
  }, [partialPoResData?.orderData?.items])
    
  useEffect(() => {
    let sNo, projectName, poNo, poStatus, array = [];
    deliveredPoResData?.orderData?.items?.map((item: any,idx: any) => { 
      item?.items?.map((purchase: any,index: number) => {     
          sNo = idx + 1;
          projectName = purchase?.projectDetails?.projectName ?? "_";
          poNo = item?.purchaseOrderNo ?? "_";
          poStatus = item?.status ?? "_";  
        })     
        array.push({sNo: sNo, projectName: projectName, poNo: poNo, poStatus: poStatus}) 
      });
      setPurchaseOrderList(array)
  },[deliveredPoResData?.orderData?.items])

  return (
    <>   
      <CountCardComponent 
        CountData={CountData} 
        UserRoleEnum={UserRoleEnum} 
        materialData={materialData} 
        Projects={Projects} 
        totalCount={totalCount}/>

      {session?.user?.role_id !== 3 && <Grid sx={{ display: 'flex', gap: '10px' }}>
        <Grid sx={{ width: '100%', padding: '10px 0', }}>
          <Paper elevation={24}>
            <Card>
              {/* <ProjectLineChart /> */}
            </Card>
          </Paper>
        </Grid>
      </Grid>}

      {session?.user?.role_id !== 3 &&  
        <Box sx={{ width: '100%', padding: '10px 0'}}>
          <Grid container spacing={2}>
            <Grid item lg={6} xs={12} md={6}>
              <Paper>
                <Card>
                  <MainPieChart />
                </Card>
              </Paper>
            </Grid>
            <Grid item lg={6} xs={12} md={6}>
            <Paper>
                <Card> 
                  <ProjectListTable columns={projectListDashboardColumn} data={Projects} heading="Project List"/>
                </Card>
              </Paper>
            </Grid>
          </Grid>
        </Box>
      }

      { session?.user?.role_id === 3 && 
       <Box sx={{ width: '100%', padding: '10px 0'}}>
          <Grid container spacing={2}>
            <Grid item lg={6} xs={12} md={6}> 
                  <ProjectListTable columns={poDashboardColumn} data={partialPurchaseOrderList} heading="PO Partial Delivered"/>
            </Grid>
            <Grid item lg={6} xs={12} md={6}>
                  <ProjectListTable columns={poDashboardColumn} data={purchaseOrderList} heading="PO Delivered"/>
            </Grid>
          </Grid>
       </Box>
       }
    </>
  );
};

export default Dashboard;
