import React, { useEffect, useState } from 'react'
import Chart from '../Highcharts';

function ProjectLineChart() {

    return (
        <div>
            <Chart />
        </div>
    )
}

export default ProjectLineChart