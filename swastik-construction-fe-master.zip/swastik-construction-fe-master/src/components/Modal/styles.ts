import styled from 'styled-components';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import FormHelperText from '@mui/material/FormHelperText';
import { theme } from 'src/common/styles/theme';

export const AddButton = styled(Button)`
  margin-top: 5px;
`;
export const StyledBox = styled(Box)`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 400px;
  background-color: white;
  box-shadow: 24px;
  padding: 4;
  display: flex;
  justify-content: center;
  border-radius: 10px;
  padding: 15px;
`;

export const Text = styled(TextField)`
  width: 250px;
  padding: 3px 0px 5px 0px;
`;

export const AddRole = styled.div``;
export const RollHeading = styled.p`
  font-size: 25px;
  font-weight: 600;
  text-align: center;
`;
export const SubHeading = styled.p`
  text-align: center;
  padding: 10px 0px 13px 0px;
`;
export const Form = styled.form`
  gap: 15px 5px;
  display: flex;
  flex-direction: column;
  .MuiFormControl-root {
    position: relative;

    .MuiFormHelperText-root {
      position: absolute;
      bottom: -15px;
    }
  }
`;

export const Helpertext = styled(FormHelperText)`
  color: red;
  margin-bottom: -2px;
`;

export const ProfilePageLayout = styled.div`
  background-color: white;
  padding: 25px;
`;

export const Asterisk = styled.span`
  color: ${theme.colors.Red};
`;

export const MainFormLayout = styled.div`
  gap: 10px 15px;
  display: flex;
  flex-direction: column;

  .MuiInputBase-colorPrimary.Mui-focused {
    .MuiOutlinedInput-notchedOutline {
      border: 1px solid red !important;
    }
  }
  .MuiInputBase-colorPrimary.MuiInputBase-formControl.Mui-focused:after {
    border-bottom: 2px solid red;
  }

  label.Mui-focused {
    color: red !important;
  }
  .css-1h51icj-MuiAutocomplete-root .MuiOutlinedInput-root {
    border-radius: 12px !important;
  }
`;
