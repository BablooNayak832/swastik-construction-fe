import React from 'react'
import Dialog from '@mui/material/Dialog';
import { DialogContent, DialogActions, AppBar, Toolbar, Typography, Button, ButtonGroup } from '@mui/material';
import {theme} from 'src/common/styles/theme'; 
import usePatch from 'src/hooks/usePatch';
import {vendor_url} from 'src/constants/api-routes';

const VerifyVendor = ({ rowData,openVerifyByAdmin, setOpenVerifyByAdmin, fetchData}:any) => {
  const {handleUpdateData} = usePatch()

  const handleVerifyVendor = async(verify:string) => { 
    const payload = { 
      prevContact: rowData?.contact,
      contact: rowData.contact,
      verifiedByAdmin: verify === "yes" ? true : false
    }
    await handleUpdateData(vendor_url, payload)
    fetchData()
    setOpenVerifyByAdmin(false)
  }

  return (
    <>
    <Dialog
        fullWidth
        maxWidth='md'
        open={openVerifyByAdmin}>
        <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
          <Toolbar>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              Approve Vendor
            </Typography>
            <DialogActions>
              <Button variant='contained' onClick={() => setOpenVerifyByAdmin(false)}>X</Button> 
            </DialogActions>
          </Toolbar>
        </AppBar>
        <DialogContent> 
        <Typography sx={{ p: 2 }}> Do you want to {rowData?.verifiedByAdmin === false ? 'approve' : "reject"} this vendor ?</Typography>
        <ButtonGroup sx={{ padding: '10px 20px', float: 'right' }} variant="outlined" aria-label="Basic button group">
            <Button variant='outlined' size='small' onClick={() => handleVerifyVendor("no")}>No</Button>
            <Button variant='contained' size='small' onClick={() => handleVerifyVendor("yes")}>Yes</Button>
        </ButtonGroup>
        </DialogContent>
      </Dialog>
    </>
  )
}

export default VerifyVendor