'use client';

import React, { useEffect } from 'react';
import {
  Blankbox, 
  Heading,
  HeadingBox,
  TableBox,
} from '../../common/styles/Users/styles';
import { useAllowedNavigation } from '../../context/context';
import CommonDialog from '../CommonDialog/CommonDialog';
import MainForm from '../common-form/index';
import dynamic from 'next/dynamic';
import { usercolumns } from '../../constants/table-columns';
const TableMain = dynamic(() => import('../../components/Table/Table'), {
  ssr: false,
});
import { UserData, createData } from '../../Interfaces/Userinterface';
import useGet from '../../hooks/useGet';
import { projects_url, user_url, get_roles_url } from '../../constants/api-routes';
import usePatch from '../../hooks/usePatch';
import useDelete from '../../hooks/useDelete'; 
import { Wrapper } from '../../app/styles';
import {useSession} from 'next-auth/react'; 

interface UserType {
  resetFilter: any;
  propsData: any
  refreshTableData: any;
  isLoading: boolean;
  filterActiveUser?: any; 
  searchTableData?: any;
  handleExcelExport?: any;
  totalItems?:number;
  handleChangePage?:any;
  handleChangeRowsPerPage?:any;
  page?:number;
  rowsPerPage?:number;
}

const User = ({resetFilter,
   propsData, 
   refreshTableData, 
   isLoading, 
   filterActiveUser, 
   searchTableData, 
   handleExcelExport, 
   totalItems, 
   handleChangePage,
   handleChangeRowsPerPage,
   page, 
   rowsPerPage }: UserType) => {

  const {data: session} = useSession() 
  const { setOpen } = useAllowedNavigation();
  const { resData: roleDataRes, handleGetData: getRoleData } = useGet();
  const { resData: projectData, handleGetData: getProjectData } = useGet();
  const { handleUpdateData } = usePatch();
  const { handleDeleteData } = useDelete(); 

  function createData(
    id?: number,
    sNo: number,
    name?: string,
    email?: string,
    mobileNumber?: number,
    userStatus?: boolean,
    role?: string,
    roleId?: number,
    action?: number | React.FC | undefined,
    createdBy?: string,
    assignedProject?: [] | any, 
  ): createData {
    return {
      id,
      sNo,
      name,
      email,
      mobileNumber,
      userStatus,
      role,
      roleId,
      createdBy,
      assignedProject,
      action, 
    };
  }  

  const userdata = propsData?.items?.map((item: UserData, index: number) => {
    const projectNames = item?.assignProject?.map(
      (project: { project: any }) => project.project
    ); 
    return createData(
      item?.id,
      (page - 1) * rowsPerPage + index + 1, 
      item?.name,
      item?.email,
      item?.mobileNumber,
      item?.status,
      item?.role?.roleName,
      item?.role?.id,
      item?.role?.id,
      item?.createdByName?.name,
      projectNames, // Assign concatenated project names to the 'assignProject' field 
    );
  });

  useEffect(() => {
    if([0,1].includes(session?.user?.role_id) ){
      refreshTableData();
    }
  }, []);


  // get roles for add user
  const getAllRoles = async () => {
    const res = await getRoleData(get_roles_url)
    return res;
  };

  // Fetch roles when the component mounts
  React.useEffect(() => {
    if([0, 1].includes(session?.user?.role_id)){
      getAllRoles();
    }
  }, []);

  // function for update user
  const handleUpdateProps = async (
    e: { preventDefault: () => void },
    payload: any
  ) => {
    e.preventDefault();
    const res = await handleUpdateData(user_url, payload)
    setOpen(false);
    refreshTableData();
    return res;
  };

  //function for delete user
  const handleRemoveRow = async (Id) => {
    const { id } = Id;
    const details = await handleDeleteData(`${user_url}/${id}`);
    refreshTableData();
    return details; 
  };

  const handleProjectData = async () => {
    const res = getProjectData(`${projects_url}?page=1&limit=100&sales=active&status=running`)
    return res;
  }
   
  useEffect(() => {
    handleProjectData()
  }, [])

  const filterMenuOption = [ 
    { id: 1, menuText: 'Active User', fun: () => filterActiveUser({ key: 'status', value: 1 }) },
    { id: 2, menuText: 'Inactive User', fun: () => filterActiveUser({ key: 'status', value: 0 }) },
    {
      id: 3,
      menuText: 'Role',
      subItem: [
        (session?.user?.role_id === 0 ? { id: 0.3, menuText: 'Admin', fun: () => filterActiveUser({ key: 'role', value: 1 }) } : {}), 
        { id: 3.1, menuText: 'Project Head', fun: () => filterActiveUser({ key: 'role', value: 2 }) },
        { id: 3.2, menuText: 'Purchase Head', fun: () => filterActiveUser({ key: 'role', value: 3 }) },
        { id: 3.3, menuText: 'Site Head', fun: () => filterActiveUser({ key: 'role', value: 4 }) },
        { id: 3.4, menuText: 'Supervisor', fun: () => filterActiveUser({ key: 'role', value: 5 }) },
        { id: 3.5, menuText: 'Sale Representative', fun: () => filterActiveUser({ key: 'role', value: 6 }) },
      ]
    },
  ] 
  
  return (
    <>
      <Wrapper> 
          <HeadingBox>
            <Blankbox>
              <Heading>Users</Heading>
            </Blankbox>
            <Blankbox>
            { (session?.user?.role_id == 1 || session?.user?.role_id == 0) && <CommonDialog title="Add User">
                <MainForm
                  data={{
                    name: '',
                    email: null,
                    mobileNumber: '',
                    password: '',
                    roleId: '',
                    projectId: null,
                    assignedProject: []
                  }}
                  url={user_url}
                  title={'Add User'}
                  userItems={userdata}
                  projectItems={projectData?.items}
                  selectItem={roleDataRes}
                  refreshData={refreshTableData}
                />
              </CommonDialog>}
            </Blankbox>
          </HeadingBox>

          <TableBox>
            <TableMain
              handleExcelExport={handleExcelExport}
              filterMenuOption={filterMenuOption}
              title={'User'}
              isLoading={isLoading}
              columns={usercolumns}
              rows={userdata}
              page={page}
              rowsPerPage={rowsPerPage}
              resetFilter={resetFilter}
              projectItems={projectData?.items}
              handleChangePage={handleChangePage}
              handleChangeRowsPerPage={handleChangeRowsPerPage}
              refreshTableData={refreshTableData}
              handleRemoveRow={handleRemoveRow}
              handleUpdateProps={handleUpdateProps}
              searchTableData={searchTableData}
              totalItems={totalItems}
            />
          </TableBox> 
      </Wrapper>
    </>
  );
};

export default User;
