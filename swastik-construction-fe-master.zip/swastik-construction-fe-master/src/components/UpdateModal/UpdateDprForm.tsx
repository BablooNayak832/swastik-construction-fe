"use client"
import React, { useEffect, useRef, useState } from 'react'
import {
    Button, 
    InputLabel, 
    Grid,
    TextField,
    Typography, 
    Table,
    TableContainer, 
    TableRow,
    TableCell,
    TableBody,
    FormControl,
    Autocomplete,
    FormHelperText,
    CircularProgress,
    IconButton, 
} from '@mui/material'; 
import { Textarea } from '../../constants'; 
import DailyUsedMaterialTable from '../Table/DailyUsedMaterialTable'
import { useRouter } from 'next/navigation'; 
import _ from 'lodash'; 
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker'; 
import { stringCapitalization } from '../../utils/formatString';
import usePatch from 'src/hooks/usePatch';
import dayjs from 'dayjs';
import { useSession } from 'next-auth/react';
import useDelete from 'src/hooks/useDelete';
import {formateDate} from 'src/utils/formatDate';
import {Asterisk} from '../Modal/styles';
import {site_inventory_url} from 'src/constants/api-routes'; 
import {toast} from 'react-toastify';
import getRequestAPI from 'src/services/getRequest';
import {Delete} from '@mui/icons-material';
import AddIcon from '@mui/icons-material/Add';
import ConfirmationDialog from '../ui/ConfirmationDialog'

interface dailyProgressFormType { 
    data?: any;
    title?: string;
    catItems?: any;
    projectItems?: any;
    typeItems?: any;
    refreshData?: any;
    recordedDate?: any;
}

type DataItem = {
    categoryId?: string;
    machineryOrPrductName?: string;
    unit?: string;
    size?: string;
    specification?: string;
    categoryName?: string;
    remark?: string;
    typeId?: string;
    materialId?: string;
    itemName?: string;
    quantity?: number;
    availableQty?: number;
    projectId?: string;
  };
  

const DailyProgressForm = ({data, title, recordedDate }: dailyProgressFormType) => {  
    const router = useRouter() 
    const {data: session} = useSession()
    const [dataArray, setDataArray] = useState<any>([])
    const [editingId, setEditingId] = useState(null); 
    const [editedValue, setEditedValue] = useState({ quantity: '' , remark:'' });  
    const [dateOfConsumption,setDateOfConsumption] = useState<string>(dayjs(recordedDate) ?? dayjs())  
    const { handleUpdateData, error, resData } = usePatch()
    const { handleDeleteData } = useDelete()
    const { handleDeleteData: hendleDeleteContractor } = useDelete()
    const [isFormOpen,setIsFormOpen]= useState(false)
    const [categoryData, setCategoryData] = useState<any>([]) 
    const [requestFormData, setRequestFormData] = useState<any>({});  
    const [queryParams, setQueryParams] = useState<any>({})
    const [specificationArray, setSpecificationArray] = useState<any>([]);
    const [materialData, setMaterialData] = useState<any>([])
    const [sizeItems, setSizeItems] = useState<any>([])
    const [itemNameArray, setItemNameArray] = useState<any>([])
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({}); 
    const [projectInfo, setProjectInfo] = useState({}) 
    const [dprFormErrors, setDprFormErrors] = useState<{ [key: string]: string }>({});
    const [dprUpdateForm, setDprUpdateForm] = useState<any>({
        Labour: {
            Company: { id: null, projectId: '', consumptionOfQuantity: 0, remark: '' },
            Contractor: {id: null, projectId: '', consumptionOfQuantity: 0, remark: '' }
        }, 
        Machinery: {
            'Tractor': {id: null, projectId: '', consumptionOfQuantity: 0, remark: ''},
            'Trolly': {id: null, projectId:'', consumptionOfQuantity: 0, remark: ''},
            'Tanker With Fighter': {id: null, projectId: '', consumptionOfQuantity: 0, remark: ''},
            'Jcb': {id: null, projectId: '', consumptionOfQuantity: 0, remark: ''}
        }
    });
    const [loading, setLoading] = useState(false)
    const [totalItems, setTotalItems] = useState(0)
    const [page, setPage] = useState(1)
    const [contractors, setContractors] = useState<any>([]);
    const [openConfirm, setOpenConfirm] = useState(false);
    const [selectedFileIndex, setSelectedFileIndex] = useState({});
    const [canSubmit, setCanSubmit] = useState(true)
     
 
    useEffect(() => {
       const createDataArray = data?.Material?.map((item) => {
        setProjectInfo({ id: item?.projectId, name: item?.project?.projectName, location: item?.project?.location})
          return {
            "id": item?.id,
            "categoryId": item?.materialDetails?.categoryId,
            "machineryOrPrductName": item?.materialDetails?.productName,
            "unit": item?.materialDetails?.unit ,//"cum",
            "size":  item?.materialDetails?.size,
            "categoryName": item?.materialDetails?.category?.categoryName,
            "remark": item?.remark,
            "typeId": "1",
            "materialId": item?.materialDetails?.id,
            "itemName": item?.materialDetails?.itemName,
            "quantity": item?.consumptionOfQuantity, 
            "projectId": item?.projectId,
            "availableQty": item?.materialDetails?.siteInventory?.availableQuantity
        }
        })
        setDataArray(createDataArray)
    }, [data?.Material])

    useEffect(() => {
        const updatedLabour = { ...dprUpdateForm?.Labour };
        const updatedMachine = { ...dprUpdateForm?.Machinery };  
        data?.Labour?.forEach(item => {  
          if (item.type === 'Labour' && updatedLabour[item.nameOrId]) {
            setProjectInfo({ id: item?.projectId, name: item?.project?.projectName, location: item?.project?.location})
            updatedLabour[item.nameOrId].id = item.id;
            updatedLabour[item.nameOrId].consumptionOfQuantity = item.consumptionOfQuantity;
            updatedLabour[item.nameOrId].remark = item.remark;
            updatedLabour[item.nameOrId].projectId = item.projectId;
          }
        }); 
        data?.Machinery?.forEach(item => {  
            if (item.type === 'Machinery' && updatedMachine[item?.nameOrId]) { 
            setProjectInfo({ id: item?.projectId, name: item?.project?.projectName, location: item?.project?.location})
            updatedMachine[item?.nameOrId].id = item?.id;
            updatedMachine[item?.nameOrId].consumptionOfQuantity = item?.consumptionOfQuantity;
            updatedMachine[item?.nameOrId].remark = item?.remark;
            updatedMachine[item?.nameOrId].projectId = item?.projectId;
            }
          });
          setDprUpdateForm({...dprUpdateForm, Labour: updatedLabour, Machinery: updatedMachine}); 
          setContractors(data?.Contractor ?? []) 
      }, [data?.Labour, data?.Machinery, data?.Contractor]);

    useEffect(() => { 
        if(!!resData?.length){ 
            router.replace('/dpr-management')
        }
    }, [error, resData]) 

    const removeMaterial = async (index: any, id: any ) => {
        const newData = dataArray?.filter((item: any, index: any) => item?.id !== id);
        setDataArray(newData);
        await handleDeleteData(`/dpr/${id}`);
    }

    const editMaterial = (id: any, value: any) => {
        setEditingId(id);
        setEditedValue(value);
    }

    const handleChange = (e: any, data?:any) => { 
        const value = e.target.value;  
        const regex = /^[1-9]\d*$/;  
        const key = e.target.name; 
        if(key === 'quantity'){
            if ((value === '' || regex.test(value)) && (data?.availableQty >= value )) { 
                const newQuantity = parseInt(value); 
                setEditedValue(prevState => ({
                    ...prevState,
                    [e.target.name]: newQuantity
                }));
            } 
        }else{
            setEditedValue(prevState => ({
                ...prevState,
                [e.target.name]: value
            }));
        } 
    }

    const handleSave = (id: any) => {
        let copyData = [...dataArray]
        copyData[id] = { ...dataArray[id], ['quantity']: editedValue.quantity , ['remark']: editedValue.remark }
        setDataArray(copyData)
        setEditingId(null) 
    };
 
    const createPayload = (data:any) => {
        const payload:any = [];   
        for (const [type, values] of Object?.entries(data)) { 
           const formatedType = stringCapitalization(type)
           for(const [key , value] of Object?.entries(values)){
            let quantity = value?.consumptionOfQuantity !== '' ? value?.consumptionOfQuantity : 0;
            let remark = ((!!value?.remark) && (quantity !== 0 )) ? value.remark : ''
            let checkValue = ((quantity !== 0 && value?.id !== null) || (quantity !== 0 && value?.id === null)) ;
            if( checkValue ){
                payload.push({
                  id: value?.id,
                  projectId: projectInfo?.id,
                  date: dateOfConsumption !== '' ? formateDate(dateOfConsumption) : recordedDate, 
                  type: formatedType.trim(),
                  nameOrId: key.trim(),
                  consumptionOfQuantity: parseInt(quantity),
                  remark: remark
                });
            }
           }
        }   
        return payload;
    }; 
    
    const handleSubmitDprUpdate = async () => {  
        let payload:any = await createPayload(dprUpdateForm);  
        if((!!dataArray?.length) && (dataArray !== undefined)){
            for (const [index, element] of dataArray?.entries()) { 
                payload.push({
                    id: element?.id,
                    projectId: projectInfo?.id,
                    date: dateOfConsumption !== '' ? formateDate(dateOfConsumption) : recordedDate , 
                    type: 'Material',
                    nameOrId: element?.materialId,
                    consumptionOfQuantity: parseInt(element?.quantity),
                    remark: !!element?.remark ? element?.remark : ""
                  })
            } 
        }
        for(const ele of contractors){ 
            if(ele?.nameOrId !== ''){
                payload.push({
                    id: ele?.id,
                    projectId: projectInfo?.id,
                    date: dateOfConsumption !== '' ? formateDate(dateOfConsumption) : recordedDate ,
                    type: "Contractor",
                    nameOrId: ele?.nameOrId,
                    consumptionOfQuantity: parseInt(ele?.consumptionOfQuantity),
                    remark: ele?.remark
                })
            }
        }
        const isValid = validate() 
        if(isValid){
            if(payload?.length > 0) { 
                const res = await handleUpdateData('/dpr', payload, title);
                return res;
            }
        }
    }

    const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault() 
        for (let i = 0; i < dataArray?.length; i++) {
            dataArray[i].projectId = projectInfo?.id;
        }
        handleSubmitDprUpdate()
    } 
  
    const handleChangeValue = (event:any, type:string, nameOrId:any) => { 
        const value = event.target.value;
        const name = event.target.name;
        const regex = /^[0-9]\d*$/;  
        // Check if the value is a positive integer
        if(name !== 'remark'){
            if ( value === '' || regex.test(value)) {  
                setDprUpdateForm((prevData:any) => ({
                    ...prevData,
                    [`${type}`]: {
                    ...prevData[`${type}`],
                    [`${nameOrId}`]: {
                        ...prevData[`${type}`]?.[`${nameOrId}`],
                        ['consumptionOfQuantity']: event?.target?.value, 
                    }
                }
                }))
                const updatedErrors = { ...dprFormErrors };
                delete updatedErrors?.[type]?.[nameOrId]?.consumptionOfQuantity // ['consumptionOfQuantity'];
                setFormErrors(updatedErrors); 
            } 
        }else{         
            if(event?.target?.value.length <= 150 ){
                setDprUpdateForm((prevData:any) => ({
                    ...prevData,
                    [`${type}`]: {
                      ...prevData[`${type}`],
                      [`${nameOrId}`]: {
                        ...prevData[`${type}`]?.[`${nameOrId}`], 
                        ['remark']: event?.target?.value, 
                      }
                    }
                  }))
            }     
        }
    };

    const handleCancelMaterial = () => {
        setRequestFormData({})
        setIsFormOpen(false)
    }

    const addMaterialForm = () => {
        const isValid = validateMaterial();
        const exists = dataArray?.some(item => item?.materialId === requestFormData?.materialId); 
        
        if(exists){
            toast.error('This item is already exist', { 
                    autoClose: 1000, 
             }) 
        } else if (isValid && !exists) {   
            if(Object.keys(requestFormData)?.length !== 0 ){  
                    setDataArray((prevItems: DataItem[] = []) => [
                        ...prevItems,
                        {
                          categoryId: requestFormData?.categoryId,
                          machineryOrPrductName: requestFormData?.machineryOrPrductName,
                          unit: requestFormData?.unit,
                          size: requestFormData?.size?.productSize,
                          specification: requestFormData?.specification?.productSpecification,
                          categoryName: requestFormData?.categoryName,
                          remark: requestFormData?.remark,
                          typeId: requestFormData?.typeId,
                          materialId: requestFormData?.materialId,
                          itemName: requestFormData?.itemName,
                          quantity: requestFormData?.quantity,
                          availableQty: requestFormData?.availableQty,
                          projectId: projectInfo?.id,
                        },
                      ]);
            }  
            setRequestFormData({})
            setIsFormOpen(false)
            toast.success("Successfully added to the list", { autoClose: 1000})
            setQueryParams({})
        } 
    }

    function isObjectEmpty(obj: any) { 
        if (typeof obj !== 'object' || obj === null) {  // Check if the input is an object and not null
            return false;
        } 
        
        for (let key in obj) {   // Loop through all properties in the object
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                if (!isObjectEmpty(obj[key])) {
                    return false;
                }
            } else {
                return false;  // If a non-object or non-empty primitive is found, return false
            }
        } 
        return true; // If no non-empty properties found, return true
    }

    const validate = () => {
        const errors:any = {
              "labour": {
                  "company": { },
                  "contractor": { }
              },
              "machinery": {
                  "tractor": { },
                  "trolly": { },
                  "tankerWithFighter": { },
                  "jcb": { }
              }
          } 
       
          if ((!dprUpdateForm?.Labour?.Company?.consumptionOfQuantity || (dprUpdateForm?.Labour?.Company?.consumptionOfQuantity == 0)) && !!dprUpdateForm?.Labour?.Company?.remark) { 
              errors.labour.company.quantity = 'Quantity is required';
          } else{
              delete errors.labour.company.quantity;
          }
          if ((!dprUpdateForm?.Labour?.Contractor?.consumptionOfQuantity || (dprUpdateForm?.Labour?.Contractor?.consumptionOfQuantity == 0)) && !!dprUpdateForm?.Labour?.Contractor?.remark) { 
              errors.labour.contractor.quantity = 'Quantity is required';
          } else{
              delete errors.labour.contractor.quantity;
          }
  
          if ((!dprUpdateForm?.Machinery?.Tractor?.consumptionOfQuantity || (dprUpdateForm?.Machinery?.Tractor?.consumptionOfQuantity == 0)) && !!dprUpdateForm?.Machinery?.Tractor?.remark) { 
              errors.machinery.tractor.quantity = 'Quantity is required';
          } else{
              delete errors.machinery.tractor.quantity;
          }
          if ((!dprUpdateForm?.Machinery?.Trolly?.consumptionOfQuantity || (dprUpdateForm?.Machinery?.Trolly?.consumptionOfQuantity == 0)) && !!dprUpdateForm?.Machinery?.Trolly?.remark) { 
              errors.machinery.trolly.quantity = 'Quantity is required';
          } else{
              delete errors.machinery.trolly.quantity;
          } 
            if ((!dprUpdateForm?.Machinery?.[`Tanker With Fighter`]?.consumptionOfQuantity || (dprUpdateForm?.Machinery?.[`Tanker With Fighter`]?.consumptionOfQuantity == 0)) && !!dprUpdateForm?.Machinery?.[`Tanker With Fighter`]?.remark) { 
                errors.machinery.tankerWithFighter.quantity = 'Quantity is required';
            } else{
                delete errors.machinery.tankerWithFighter.quantity;
            }
          if ((!dprUpdateForm?.Machinery?.Jcb?.consumptionOfQuantity || (dprUpdateForm?.Machinery?.Jcb?.consumptionOfQuantity == 0)) && !!dprUpdateForm?.Machinery?.Jcb?.remark) { 
              errors.machinery.jcb.quantity = 'Quantity is required';
          } else{
              delete errors.machinery.jcb.quantity;
          }
          setDprFormErrors(errors);
          const isEmpty = isObjectEmpty(errors)   
          return isEmpty;
    }

    const validateMaterial = () => {
        const errors: { [key: string]: string } = {};
        if (!requestFormData?.materialId) {
            errors.materialId = 'Material is required.';
        } else {
            delete errors.materialId;
        }
        if (!requestFormData?.categoryId) {
            errors.categoryId = 'Category is required.';
        } else {
            delete errors.categoryId;
        }
        if(!!itemNameArray.length){
            if (!requestFormData?.itemName) {
                errors.itemName = 'Type or Grade is required.';
            } else {
                delete errors.itemName;
            }
        }
        if(!!specificationArray.length){
            if (!requestFormData?.specification) {
                errors.specification = 'Specification is required.';
            } else {
                delete errors.specification;
            }
        }
        if(!!sizeItems.length){
            if (!requestFormData?.size) {
                errors.size = 'Size is required.';
            } else {
                delete errors.size;
            }
        }
        if (!requestFormData?.quantity) {
            errors.quantity = 'Quantity is required.';
        } else {
            delete errors.quantity;
        }
        setFormErrors(errors)
        return Object.keys(errors).length === 0;
    } 

    useEffect(() => {
        validate()
    }, [dprUpdateForm])

    useEffect(() => {
    if(projectInfo?.name) {
        const params = {projectName: projectInfo?.name}
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            const uniqCat = _.uniqBy(res.data.items, 'categoryName')
            setCategoryData(uniqCat)
        })
    } 
    }, [projectInfo])
    
    useEffect(() => {
        if(!!categoryData.length) {
        const params = {...queryParams}
        params['q'] = requestFormData.categoryId
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            let resData = _.uniqBy(res.data.items, 'productName')
            setMaterialData(resData)
        })
        }
    }, [requestFormData.categoryId])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '') {
        const params = {...queryParams}
        params['productName'] = requestFormData.machineryOrPrductName
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.itemName != null), 'itemName');
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    itemName: null,
                })
            }
            setItemNameArray(items)
        })
        }
    }, [requestFormData.machineryOrPrductName])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' || requestFormData.itemName == null)) {
        const params = {...queryParams}
        params['itemName'] = requestFormData.itemName
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.productSpecification != null), 'productSpecification');   
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    specification: null
                })
            }
            setSpecificationArray(items)
        })
        }
    }, [requestFormData.itemName])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' ||  requestFormData.itemName == null) && (requestFormData.specification != '' || requestFormData.specification == null)) {
        const params = {...queryParams}
        params['specification'] = requestFormData.specification
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => {
            const items:[] = _.uniqBy(res.data.items.filter((item: any) => item?.productSize != null), 'productSize');    
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    size: null
                })
            }
            setSizeItems(items)
        })
        }
    }, [requestFormData.specification])

    useEffect(() => {
        if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && requestFormData.itemName != '' && requestFormData.specification != '' && (requestFormData.size != '' || requestFormData.size == null)) {
        const params = {...queryParams}
        params['size'] = requestFormData.size
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            setRequestFormData({
                ...requestFormData,
                materialId: res?.data?.items[0]?.productId,
                availableQty: res?.data?.items[0]?.siteInventoryAvailableQuantity,
                unit: res?.data?.items[0]?.productUnit
            }) 
        })
        }
    }, [requestFormData.size])

    const getMaterialData = async (requestedParams: any) => {
        try {
            let searchParams = "";
            const params = Object.keys(requestedParams).reduce((acc: any, key) => {
                if (requestedParams[key] !== undefined &&  requestedParams[key] !== null ) {
                  acc[key] = requestedParams[key];
                }
                return acc;
              }, {});
            Object.entries(params)?.map(([key, value]) => {
                searchParams += `${key}=${value}&`
            })
            setLoading(true)
            const response = await getRequestAPI(`${site_inventory_url}/?page=${page}&limit=50&${searchParams}`)
            setTotalItems(response?.data?.metadata?.totalItems)
            setLoading(false)
            return response
        } catch (err){
            throw err;
        }        
    }

    const handleCategoryChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            categoryId: newValue?.categoryId ?? 0,
            categoryName: newValue?.categoryName,    
            machineryOrPrductName: '',
            itemName: '',
            specification: '',
            size: '',
            availableQty: ''

        })
        const params = {projectName:  projectInfo?.name}
        setQueryParams(params)
        setMaterialData([])
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.categoryId;
        setFormErrors(updatedErrors);
    }

    const handleProductName = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            machineryOrPrductName: newValue?.productName,
            itemName: '',
            specification: '',
            size: '', 
        }) 
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.materialId;
        setFormErrors(updatedErrors)
    }

    const handleItems = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            itemName: newValue?.itemName, 
            specification: '',
            size: '',  
        })  
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.itemName;
        setFormErrors(updatedErrors)
    }

    const handleSpec = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            specification: newValue?.productSpecification, 
            size: '',  
        }) 
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.specification;
        setFormErrors(updatedErrors)
    }

    const handleSizeChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            size: newValue?.productSize, 
        })
        const updatedErrors = { ...formErrors };
        delete updatedErrors.size;
        setFormErrors(updatedErrors)
    }

    const handleScroll = (event: React.SyntheticEvent) => {
        const listboxNode = event.currentTarget;
        if (listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight) {
            if (!loading){
                if ((materialData?.length <= totalItems)) {
                    setPage(page + 1)
                }
            }
        }
    }

    const addContractor = () => { 
        setContractors([...contractors, { nameOrId: "", consumptionOfQuantity: "", remark: "" }]);
    }
    
    const deleteContractor = () => { 
        const newContractors = contractors.filter((_:any, i:number) => i !== selectedFileIndex?.idx);
        setContractors(newContractors);
        setOpenConfirm(false)
        if(selectedFileIndex?.contractorId !== undefined){
            hendleDeleteContractor(`/dpr/${selectedFileIndex?.contractorId}`)
        }
    }
    
    const confirmRemoveContractor = (index:any, conId: any) => {
        setSelectedFileIndex({ contractorId:conId, idx:index});
        setOpenConfirm(true);
    };

    const handleChangeContractor = (index: number, event: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = event.target;
        const updatedContractors = [...contractors];         
        if (name === 'consumptionOfQuantity') { 
            if( value === '' || /^[1-9]\d*$/.test(value)){
                updatedContractors[index] = { ...updatedContractors[index], [name]: value };
            } 
        } else {
            if(event?.target?.value.length <= 150 ){
                updatedContractors[index] = { ...updatedContractors[index], [name]: value };
             }
        } 
        
        updatedContractors[index].errorContractorName = updatedContractors[index]?.nameOrId === "" && (updatedContractors[index]?.consumptionOfQuantity !== "" || updatedContractors[index]?.remark !== "");
        updatedContractors[index].errorQty = updatedContractors[index]?.consumptionOfQuantity === "" && (updatedContractors[index]?.nameOrId !== "" || updatedContractors[index]?.remark !== "");
        setContractors(updatedContractors);
    };
    
    useEffect(() => {  
        const isContractValid = contractors?.some(item => 
            (item?.errorContractorName === false) && (item?.errorQty === false)
        ); 
        const isLabourValid = !!dprUpdateForm?.Labour?.length;  // Check if labour section has values
        const isMachineValid = !!dprUpdateForm?.Machinery?.length; // Check if machine section has values
        const isMaterialValid = !!dataArray?.length; // Check if material section has values
        const hasNoErrors = isObjectEmpty(dprFormErrors); 
        const isFormValid =  hasNoErrors && 
                            ((isLabourValid || isContractValid) || isMachineValid || isMaterialValid);

        setCanSubmit(!isFormValid); // Enable button when form is valid
    }, [dprFormErrors, contractors, dataArray, dprUpdateForm]);  
    
    return (
        <form onSubmit={handleFormSubmit}>
            <>
                { 
                 <>
                   {!isFormOpen && <Grid sx={{ padding: '20px' }} container spacing={2}> 
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Typography>
                                    Project Details
                                </Typography> 
                                <TableContainer>
                                    <Table sx={{ minWidth: 650, border: '1px solid #3333', bgcolor: 'background.paper' }} aria-label="simple table">
                                        <TableBody>
                                            <TableRow> 
                                                <TableCell align="left" width={'50%'}>Project Name</TableCell>
                                                <TableCell align="left" width={'50%'}> 
                                                    <Typography>
                                                        {projectInfo?.name} 
                                                    </Typography>
                                                    </TableCell>  
                                            </TableRow>
                                            <TableRow> 
                                                <TableCell align="left" width={'50px'}>Location</TableCell>
                                                <TableCell align="left" width={'50px'}>{projectInfo?.location}</TableCell>  
                                            </TableRow> 
                                            <TableRow> 
                                                <TableCell align="left" width={'50px'}>Date</TableCell>
                                                <TableCell align="left" width={'50px'}>  
                                                     { session?.user?.role_id === 2 ? <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                          <DemoContainer components={['DatePicker']}>
                                                            <DatePicker 
                                                              maxDate={dayjs()} 
                                                              sx={{ overflow: 'hidden' }}
                                                              value={dateOfConsumption}
                                                              onChange={(date) => {
                                                                const formatedDate = formateDate(date); 
                                                                setDateOfConsumption(formatedDate)
                                                              }}
                                                              slotProps={{ textField: { size: 'small' } }}
                                                              renderInput={(params:any) => <TextField {...params} value={dateOfConsumption ? formateDate(dateOfConsumption) : ''} />}
                                                            />
                                                          </DemoContainer> 
                                                        </LocalizationProvider> 
                                                        : <Typography>{dayjs(recordedDate).format('DD/MM/YYYY')}</Typography>
                                                        } 
                                                </TableCell>  
                                            </TableRow> 
                                        </TableBody> 
                                    </Table>
                                </TableContainer> 
                            </Grid> 
                    
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Typography>
                                    Labour
                                </Typography> 
                                <TableContainer>
                                    <Table sx={{ minWidth: 650, border: '1px solid #3333', bgcolor: 'background.paper' }} aria-label="simple table">
                                        <TableBody> 
                                            <TableRow> 
                                                <TableCell align="left" width={'50%'}>Company</TableCell>
                                                <TableCell align="left" width={'50%'}>  
                                                  <FormControl>
                                                    <TextField 
                                                        autoComplete='off'
                                                        name="Company"
                                                        defaultValue={dprUpdateForm?.Labour?.Company?.consumptionOfQuantity} 
                                                        value={dprUpdateForm?.Labour?.Company?.consumptionOfQuantity} 
                                                        onChange={(e) => handleChangeValue(e, 'Labour', 'Company')}  
                                                        placeholder="No. of company's labour" 
                                                        size='small' 
                                                        variant="outlined"/>
                                                        {dprFormErrors?.labour?.company?.quantity && (
                                                        <FormHelperText id="error" error>
                                                        {dprFormErrors?.labour?.company?.quantity}
                                                        </FormHelperText>
                                                        )}
                                                    </FormControl>
                                                    <Textarea    
                                                        minRows={1} 
                                                        sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                        placeholder="Type remark here..."  
                                                        name='remark'   
                                                        defaultValue={dprUpdateForm?.Labour?.Company?.remark} 
                                                        value={dprUpdateForm?.Labour?.Company?.remark} 
                                                        onChange={(e) => handleChangeValue(e, 'Labour', 'Company')}  
                                                    />
                                                </TableCell>  
                                            </TableRow> 
                                            <TableRow>  
                                           <TableCell sx={{ borderBottom: 'none'}}>
                                               Contractor 
                                           </TableCell>
                                           <TableCell sx={{textAlign: 'center', borderBottom: 'none'}}>
                                            <Button variant='contained' onClick={addContractor}>
                                                 <AddIcon /> 
                                            </Button>
                                           </TableCell> 
                                        </TableRow>
                                            {contractors?.map((contractor:any, index:number) => {
                                                return (
                                                   <> 
                                                   <TableRow>  
                                                    <TableCell align="left" width={'50px'}>
                                                        <FormControl>
                                                            <TextField 
                                                                autoComplete='off'
                                                                name="nameOrId" 
                                                                placeholder="Name of contractor" 
                                                                size='small'  
                                                                onChange={(e)=> handleChangeContractor(index, e)}
                                                                value={contractor?.nameOrId}
                                                                error={contractor?.errorContractorName}
                                                                helperText={contractor?.errorContractorName ? "Contractor is required" : ""}
                                                                variant="outlined" />
                                                               
                                                        </FormControl> 
                                                    </TableCell>
                                                    <TableCell align="left" width={'50px'}>
                                                        <div style={{display: 'flex'}}>
                                                            <FormControl>
                                                                <TextField 
                                                                    autoComplete='off'
                                                                    name="consumptionOfQuantity" 
                                                                    placeholder="No. of Labours" 
                                                                    size='small'  
                                                                    onChange={(e)=> handleChangeContractor(index, e)}
                                                                    value={contractor?.consumptionOfQuantity}
                                                                    error={contractor.errorQty}
                                                                    helperText={contractor.errorQty ? "Quantity is required" : ""}
                                                                    variant="outlined" />

                                                            </FormControl>  
                                                                <Textarea    
                                                                    minRows={1} 
                                                                    sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                                    placeholder="Type remark here..." 
                                                                    name='remark' 
                                                                    onChange={(e)=> handleChangeContractor(index, e)}
                                                                    value={contractor?.remark} 
                                                                />  
                                                                 
                                                                <IconButton onClick={()=> confirmRemoveContractor(index, contractor?.id)}>
                                                                    <Delete sx={{color: 'red'}}/> 
                                                                </IconButton> 
                                                        </div> 
                                                    </TableCell>  
                                                   </TableRow> 
                                                </>
                                                )
                                            })} 
                                        </TableBody> 
                                    </Table>
                                </TableContainer> 
                            </Grid>

                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Typography>
                                  Machine
                                </Typography> 
                                <TableContainer>
                                    <Table sx={{ minWidth: 650, border: '1px solid #3333', bgcolor: 'background.paper' }} aria-label="simple table">
                                        <TableBody> 
                                                    <TableRow> 
                                                        <TableCell align="left" width={'50%'}>Tractor</TableCell>
                                                        <TableCell align="left" width={'50%'}>  
                                                            <FormControl>
                                                             <TextField 
                                                                autoComplete='off'
                                                                name={'Tractor'}  
                                                                defaultValue={dprUpdateForm?.Machinery?.Tractor?.consumptionOfQuantity} 
                                                                value={dprUpdateForm?.Machinery?.Tractor?.consumptionOfQuantity} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Tractor')}  
                                                                placeholder="No. of company's labour" 
                                                                size='small' 
                                                                variant="outlined" />
                                                                {dprFormErrors?.machinery?.tractor?.quantity && (
                                                                <FormHelperText id="error" error>
                                                                {dprFormErrors?.machinery?.tractor?.quantity}
                                                                </FormHelperText>
                                                                )}
                                                            </FormControl>

                                                            <Textarea    
                                                                minRows={1} 
                                                                sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                                placeholder="Type remark here..." 
                                                                defaultValue={dprUpdateForm?.Machinery?.Tractor?.remark} 
                                                                value={dprUpdateForm?.Machinery?.Tractor?.remark} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Tractor')}  
                                                                name='remark'  
                                                            />
                                                        </TableCell>  
                                                </TableRow> 
                                                <TableRow> 
                                                        <TableCell align="left" width={'50%'}>Trolly</TableCell>
                                                        <TableCell align="left" width={'50%'}> 
                                                           <FormControl>
                                                            <TextField 
                                                                autoComplete='off'
                                                                name={'Trolly'}  
                                                                defaultValue={dprUpdateForm?.Machinery?.Trolly?.consumptionOfQuantity} 
                                                                value={dprUpdateForm?.Machinery?.Trolly?.consumptionOfQuantity} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Trolly')}  
                                                                placeholder="No. of company's labour" 
                                                                size='small' 
                                                                variant="outlined" />
                                                                {dprFormErrors?.machinery?.trolly?.quantity && (
                                                                <FormHelperText id="error" error>
                                                                {dprFormErrors?.machinery?.trolly?.quantity}
                                                                </FormHelperText>
                                                                )}
                                                            </FormControl>

                                                            <Textarea    
                                                                minRows={1} 
                                                                sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                                placeholder="Type remark here..." 
                                                                defaultValue={dprUpdateForm?.Machinery?.Trolly?.remark} 
                                                                value={dprUpdateForm?.Machinery?.Trolly?.remark} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Trolly')}  
                                                                name='remark'  
                                                            />
                                                        </TableCell>  
                                                </TableRow> 
                                                <TableRow> 
                                                        <TableCell align="left" width={'50%'}>Tanker with fighter</TableCell>
                                                        <TableCell align="left" width={'50%'}>  
                                                          <FormControl>
                                                            <TextField 
                                                                autoComplete='off'
                                                                name={'Tanker With Fighter'}  
                                                                defaultValue={dprUpdateForm?.Machinery?.[`Tanker With Fighter`]?.consumptionOfQuantity} 
                                                                value={dprUpdateForm?.Machinery?.['Tanker With Fighter']?.consumptionOfQuantity} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Tanker With Fighter')} 
                                                                placeholder="No. of company's labour" 
                                                                size='small' 
                                                                variant="outlined" />
                                                                {dprFormErrors?.machinery?.tankerWithFighter?.quantity && (
                                                                <FormHelperText id="error" error>
                                                                {dprFormErrors?.machinery?.tankerWithFighter?.quantity}
                                                                </FormHelperText>
                                                                )}
                                                            </FormControl>

                                                            <Textarea    
                                                                minRows={1} 
                                                                sx={{width:'49%', mx:'10px', resize: 'none'}}
                                                                placeholder="Type remark here..." 
                                                                defaultValue={dprUpdateForm?.Machinery?.['Tanker With Fighter']?.remark} 
                                                                value={dprUpdateForm?.Machinery?.['Tanker With Fighter']?.remark} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Tanker With Fighter')} 
                                                                name='remark'  
                                                            />
                                                        </TableCell>  
                                                </TableRow> 
                                                <TableRow> 
                                                        <TableCell align="left" width={'50%'}>Jcb</TableCell>
                                                        <TableCell align="left" width={'50%'}>  
                                                            <FormControl>
                                                            <TextField 
                                                                autoComplete='off'
                                                                name={'Jcb'}  
                                                                defaultValue={dprUpdateForm?.Machinery?.[`Jcb`]?.consumptionOfQuantity} 
                                                                value={dprUpdateForm?.Machinery?.['Jcb']?.consumptionOfQuantity} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Jcb')}  
                                                                placeholder="No. of company's labour" 
                                                                size='small' 
                                                                variant="outlined" />
                                                                {dprFormErrors?.machinery?.jcb?.quantity && (
                                                                <FormHelperText id="error" error>
                                                                {dprFormErrors?.machinery?.jcb?.quantity}
                                                                </FormHelperText>
                                                                )}
                                                            </FormControl>

                                                            <Textarea    
                                                                minRows={1} 
                                                                sx={{width:'49%', mx:'10px', resize: 'none'}} 
                                                                placeholder="Type remark here..." 
                                                                defaultValue={dprUpdateForm?.Machinery?.['Jcb']?.remark} 
                                                                value={dprUpdateForm?.Machinery?.['Jcb']?.remark} 
                                                                onChange={(e) => handleChangeValue(e, 'Machinery', 'Jcb')} 
                                                                name='remark'  
                                                            />
                                                        </TableCell>  
                                                </TableRow>                                         
                                        </TableBody> 
                                    </Table>
                                </TableContainer> 
                            </Grid> 
                         
                         <Grid item lg={12} md={12} sm={12} xs={12}> 
                            <Button style={{float: 'right'}} variant='contained' onClick={() => setIsFormOpen(!isFormOpen)}> + Add Material</Button>
                         </Grid>
                         {!isFormOpen && 
                            (!!dataArray?.length && <Grid item lg={12} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Material</InputLabel>
                                <DailyUsedMaterialTable
                                    data={dataArray}
                                    handleSave={handleSave}
                                    editingId={editingId}
                                    removeMaterial={removeMaterial}
                                    editMaterial={editMaterial}
                                    handleChange={handleChange}
                                    editedValue={editedValue}
                                    isApproved={"pending"}
                                />
                            </Grid>)  
                         }
                    </Grid>}

                   {!isFormOpen && <Grid item lg={6} md={6} sm={6} xs={12}>  
                        <Button 
                            disabled={canSubmit}
                            type="submit"
                            variant="contained"
                            style={{ margin: '20px', float: 'right', color: 'white' }}
                        >
                            Save  
                        </Button>
                    </Grid>}
                 </>
                }  
                <Grid sx={{ padding: '20px' }} container spacing={2}>
                    {
                        isFormOpen &&
                         <Grid container spacing={2}>

                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Category <Asterisk>*</Asterisk></InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <Autocomplete
                                        size='small'
                                        disabled={!categoryData.length}
                                        options={categoryData}
                                        getOptionLabel={(option) => {
                                            return typeof option == 'object' ? option?.categoryName : option;
                                        }}
                                        value={requestFormData?.categoryName}
                                        onChange={handleCategoryChange}
                                        renderInput={(params) => {
                                            return (<TextField {...params} />)
                                        }}
                                        fullWidth
                                    />
                                    {formErrors.categoryId && (
                                        <FormHelperText id="project-name-error" error>
                                            {formErrors.categoryId}
                                        </FormHelperText>
                                    )}
                                </FormControl>
                            </Grid>
    
                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Material <Asterisk>*</Asterisk></InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    <Autocomplete
                                        disabled={materialData.length == 0} 
                                        size='small'
                                        options={materialData}
                                        getOptionLabel={(option) => typeof option == 'object' ? option?.productName : option}
                                        value={requestFormData?.machineryOrPrductName}
                                        ListboxProps={{ onScroll: handleScroll, sx: { maxHeight: 150 } }}
                                        onChange={handleProductName}
                                        renderInput={(params) => (
                                            <TextField
                                                {...params}
                                            InputProps={{
                                                    ...params.InputProps,
                                                    endAdornment: (
                                                        <>
                                                            {loading && <CircularProgress color="info" size={30} />}
                                                            {params.InputProps.endAdornment}
                                                        </>
                                                    ),
                                                }}
                                            />
                                        )}
                                        isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                        fullWidth
                                    />
                                    {formErrors.materialId && (
                                        <FormHelperText id="project-name-error" error>
                                            {formErrors.materialId}
                                        </FormHelperText>
                                    )}
                                </FormControl>
                            </Grid>
    
                            {!!itemNameArray?.length && <>
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Type / Grade</InputLabel>
                                    <FormControl sx={{ width: '100%' }}>
                                        <Autocomplete
                                            size='small'
                                            options={itemNameArray}
                                            getOptionLabel={(option) => typeof option == 'object' ? option?.itemName : option}
                                            value={requestFormData?.itemName}
                                            onChange={handleItems}
                                            renderInput={(params) => {
                                                return (<TextField {...params} />)
                                            }}
                                            fullWidth
                                        />
                                    </FormControl>
                                    {formErrors.itemName && (
                                        <FormHelperText id="itemName-error" error>
                                            {formErrors?.itemName}
                                        </FormHelperText>
                                    )}
                                </Grid>
                            </>}
    
                            {!!specificationArray?.length && <>
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Specification</InputLabel>
                                    <FormControl
                                        sx={{ width: '100%' }}
                                    >
                                        <Autocomplete
                                            size='small' 
                                            options={specificationArray}
                                            getOptionLabel={(option) => option?.productSpecification ?? option}
                                            value={requestFormData?.specification}
                                            onChange={handleSpec}
                                            renderInput={(params) => {
                                                return (<TextField {...params} />)
                                            }}
                                            fullWidth
                                        />
                                    </FormControl>
                                    {formErrors.specification && (
                                        <FormHelperText id="specification-error" error>
                                            {formErrors?.specification}
                                        </FormHelperText>
                                    )}
                                </Grid>
                            </>}
    
                            {!!sizeItems.length && <>
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Size</InputLabel>
                                    <FormControl sx={{ width: '100%' }}>
                                        <Autocomplete
                                            size='small' 
                                            options={sizeItems}
                                            getOptionLabel={(option) => option?.productSize ?? option}
                                            value={requestFormData?.size}
                                            onChange={handleSizeChange}
                                            renderInput={(params) => {
                                                return (<TextField {...params} />)
                                            }}
                                            fullWidth
                                        />
                                    </FormControl>
                                    {formErrors.size && (
                                        <FormHelperText id="size-error" error>
                                            {formErrors?.size}
                                        </FormHelperText>
                                    )}
                                </Grid>
                            </>}
    
                            { !!requestFormData?.availableQty &&
                                <Grid item lg={6} md={6} sm={6} xs={12}>
                                    <InputLabel htmlFor="my-input">Available Qty</InputLabel>
                                    <FormControl
                                        sx={{ width: '100%' }}
                                    >
                                        <TextField
                                            size='small'
                                            type="text"
                                            id="my-input"
                                            disabled={true}
                                            value={requestFormData?.availableQty}
                                            aria-describedby="my-helper-text"
                                        />
                                    </FormControl>
                                </Grid>}
    
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Quantity <Asterisk>*</Asterisk></InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <TextField
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        value={requestFormData?.quantity}
                                        onChange={(e) => {
                                            let value = e.target.value;
                                            const numericValue = Number(value);
                                            const regex = /^[1-9]\d*$/;
                                            regex.test(value)
                                            if (((regex.test(value)) || (value === '')) && requestFormData?.availableQty >= numericValue) {
                                                setRequestFormData({
                                                    ...requestFormData,
                                                    quantity: value,
                                                })
                                                const updatedErrors = { ...formErrors };
                                                delete updatedErrors.quantity;
                                                setFormErrors(updatedErrors)
                                            }
                                        }}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                                {formErrors.quantity && (
                                    <FormHelperText id="project-name-error" error>
                                        {formErrors?.quantity}
                                    </FormHelperText>
                                )}
                            </Grid>
    
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Unit</InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <TextField
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        value={requestFormData?.unit}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                            </Grid>
    
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                                <InputLabel htmlFor="my-input">Remark <Asterisk>*</Asterisk></InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <Textarea
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        sx={{resize: 'none'}}
                                        value={requestFormData?.remark}
                                        onChange={(e) => {
                                            let value = e.target.value;
                                            setRequestFormData({
                                                ...requestFormData,
                                                remark: value,
                                            })
                                        }}
                                        aria-describedby="my-helper-text"
                                    />
                                </FormControl>
                            </Grid>
    
                            <Grid item lg={12} md={6} sm={6} xs={12}>
                                <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={addMaterialForm}>Add</Button>
                                <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={() => handleCancelMaterial()}>Cancel</Button>
                            </Grid>
                         </Grid>
                    }
                </Grid>
            </>
            <ConfirmationDialog
                    open={openConfirm}
                    onClose={() => setOpenConfirm(false)}
                    title="Confirm Deletion"
                    message="Are you sure you want to delete this contractor?"
                    onConfirm={deleteContractor}
                    confirmText="Delete"
                    cancelText="Cancel"
                />
        </form>

    )
}

export default DailyProgressForm