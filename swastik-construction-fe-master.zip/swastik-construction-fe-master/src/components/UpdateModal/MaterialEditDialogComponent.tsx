import * as React from 'react';
import {
    Box, Button, FormControl, Grid, InputLabel, MenuItem, Modal, Select, Typography, TextField
  } from '@mui/material';
  import _ from 'lodash';

export const MaterialEditDialogComponent = ({ resData, openEdit, handleCloseEditModal, editedMaterial, handleInputChange, handleSelectChange, handleSaveChanges }: any) => {
    const [ subItems ,setSubItems ] = React.useState<any>([])
    const [ specificationArray ,setSpecificationArray ] = React.useState<any>([])
    const [ sizeItems ,setSizeItems ] = React.useState<any>([])
 
    React.useEffect(() => {  
        if (!!resData?.items?.length) {
            const specification = _.uniqBy(_.filter(resData?.items, p =>(( p?.specification !== '') &&  (p?.specification !== null))), 'specification');
            const size = _.uniqBy(_.filter(resData?.items, p => ((p.size !== '') && (p.size !== null))), 'size');
            const itemName = _.uniqBy(_.filter(resData?.items, p => ((p.itemName !== '') && (p?.itemName !== null))), 'itemName')
            setSubItems(itemName) 
            setSpecificationArray(specification)
            setSizeItems(size) 
        }   
    }, [resData]) 
 
    return (
    <>
      <div>
        <Modal
          open={openEdit}
          onClose={handleCloseEditModal}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <Box sx={style}>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              Edit Material
            </Typography>
            <Typography id="modal-modal-title" variant="body1" component="h1">
              Material Name:  {editedMaterial.machineryOrPrductName || ''}
            </Typography>
            <Grid container sx={{py:2}} spacing={2}> 
            { !!editedMaterial?.item?.length && <Grid item xs={12} lg={6} md={6}>
                <FormControl fullWidth>
                  <InputLabel>Type / Grade</InputLabel>
                  <Select
                    defaultValue={editedMaterial?.item}
                    size='small'
                    name="item"
                    label="Type / Grade"
                    value={ editedMaterial?.item || ''}
                    onChange={handleSelectChange}
                  >
                     <MenuItem value="clear">Clear</MenuItem>
                   { subItems?.map((option) => {
                        return <MenuItem value={option?.itemName}>
                                 <em>{option?.itemName}</em>
                               </MenuItem>
                    })}
                  </Select>
                </FormControl>
              </Grid>}
             { !!editedMaterial?.specification?.length && <Grid item xs={12} lg={6} md={6}> 
                <FormControl fullWidth>
                  <InputLabel>Specification</InputLabel>
                  <Select
                    defaultValue={editedMaterial?.specification}
                    size='small'
                    label="Specification"
                    name="specification"
                    value={editedMaterial.specification || '' }
                    onChange={handleSelectChange}
                  >
                    <MenuItem value="clear">Clear</MenuItem>
                   { specificationArray?.map((option) => {
                        return <MenuItem value={option?.specification ?? option?.productSpecification}>
                                 <em>{option?.specification ?? option?.productSpecification}</em>
                               </MenuItem>
                     })}  
                  </Select>
                </FormControl>
              </Grid>}
             { !!editedMaterial?.size?.length && <Grid item xs={12} lg={6} md={6}> 
                 <FormControl fullWidth>
                  <InputLabel>Size</InputLabel>
                  <Select
                    defaultValue={editedMaterial.size}
                    size='small'
                    label="Size"
                    name="size"
                    value={editedMaterial.size || editedMaterial.size || ''}
                    onChange={handleSelectChange}
                  >
                    <MenuItem value="clear">Clear</MenuItem>
                   { sizeItems?.map((option) => {
                        return <MenuItem value={option?.size ?? option?.productSize}>
                                 <em>{option?.size ?? option?.productSize}</em>
                               </MenuItem>
                     })}  
                  </Select>
                </FormControl>
              </Grid>}
              <Grid item xs={12} lg={6} md={6}>
                <TextField
                  fullWidth
                  size='small'
                  label="Unit"
                  name="unit"
                  value={editedMaterial.unit || ''}
                  onChange={(e) => handleInputChange(e, editedMaterial)}
                />
              </Grid>
              { !!editedMaterial.siteAvailableQuantity && <Grid item xs={12} lg={6} md={6}>
                <TextField
                  size='small'
                  fullWidth
                  disabled={true}
                  label="Available Quantity"
                  name="siteAvailableQuantity"
                  value={editedMaterial?.siteAvailableQuantity || ''}
                  onChange={(e) => handleInputChange(e, editedMaterial)}
                />
              </Grid>}
              <Grid item xs={12} lg={6} md={6}>
                <TextField
                  fullWidth
                  size="small"
                  label="Quantity"
                  name="quantity"
                  value={editedMaterial.quantity || ''}
                  onChange={(e) => handleInputChange(e, editedMaterial)}
                />
              </Grid>
              <Grid item xs={12} lg={6} md={6}>
                <TextField
                  fullWidth
                  size="small"
                  label="Remark"
                  name="remark"
                  value={editedMaterial.remark || ''}
                  onChange={(e) => handleInputChange(e, editedMaterial)}
                />
              </Grid>
            </Grid>
            <Box sx={{ mt: 2 }}>
              <Button type='button' variant="contained" color="primary" onClick={handleSaveChanges}>
                Save
              </Button>
              <Button variant="outlined" onClick={handleCloseEditModal} sx={{ ml: 2 }}>
                Cancel
              </Button>
            </Box>
          </Box>
        </Modal>
      </div>
    </>
  )
}

const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 500,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
