import React, { useState, useMemo } from 'react';
import {
  Select,
  MenuItem,
  ListSubheader,
  TextField,
  InputAdornment,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { MenuProps } from '../../constants/table-columns'

const containsText = (text, searchText) =>
  text.toLowerCase().indexOf(searchText.toLowerCase()) > -1;

interface selectType {
  allOptions?: any;
}
const SelectSearch = ({ allOptions }: selectType) => {
  const [selectedOption, setSelectedOption] = useState([]);

  const [searchText, setSearchText] = useState('');
  const displayedOptions = useMemo(
    () =>
      allOptions.filter((option) => {
        return containsText(option?.category, searchText);
      }),
    [searchText]
  );

  return (
    <>
      <Select
        multiple
        MenuProps={MenuProps}
        labelId="search-select-label"
        id="search-select"
        value={selectedOption}
        label="Options"
        onChange={(e) => {
          setSelectedOption({
            ...selectedOption,
            [e.target.name]: e.target.value,
          });
        }}
        onClose={() => setSearchText('')}
        renderValue={() => selectedOption}
      >
        <ListSubheader>
          <TextField
            size="small"
            autoFocus
            placeholder="Type to search..."
            fullWidth
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon />
                </InputAdornment>
              ),
            }}
            onChange={(e) => setSearchText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key !== 'Escape') {
                e.stopPropagation();
              }
            }}
          />
        </ListSubheader>
        {displayedOptions.map((option, i) => {
          return (
            <MenuItem key={i} value={option.id}>
              {option.category}
            </MenuItem>
          );
        })}
      </Select>
    </>
  );
};

export default SelectSearch;
