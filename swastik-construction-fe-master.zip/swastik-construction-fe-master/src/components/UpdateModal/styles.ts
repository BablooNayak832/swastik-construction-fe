import styled from 'styled-components';
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { theme } from 'src/common/styles/theme';

export const AddButton = styled(Button)``;
export const StyledBox = styled(Box)`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 700px;
  background-color: white;
  box-shadow: 24px;
  padding: 4;
  display: flex;
  justify-content: center;
  border-radius: 10px;
  padding: 15px;
  .css-sghohy-MuiButtonBase-root-MuiButton-root {
    background-color: ${theme.colors.Red};
  }
  .MuiInputBase-colorPrimary.Mui-focused {
    .MuiOutlinedInput-notchedOutline {
      border: 1px solid red !important;
    }
  }
  .css-1jy569b-MuiFormLabel-root-MuiInputLabel-root.Mui-focused {
    color: ${theme.colors.Red};
  }
`;

export const Text = styled(TextField)`
  width: 250px;
  padding: 3px 0px 10px 0px;
`;

export const AddRole = styled.div`
  label.MuiFormControlLabel-root.MuiFormControlLabel-labelPlacementStart.css-1f2kvjf-MuiFormControlLabel-root {
    justify-content: flex-end;
    gap: 19px;
    margin: auto;
  }
`;
export const RollHeading = styled.p`
  font-size: 25px;
  font-weight: 600;
  text-align: center;
`;
export const SubHeading = styled.p`
  text-align: center;
  font-size: 20px;
  font-weight: 500;
  padding: 10px 0px 13px 0px;
`;
export const Form = styled.div`
  gap: 15px 5px;
  display: flex;
  flex-direction: column;
`;
