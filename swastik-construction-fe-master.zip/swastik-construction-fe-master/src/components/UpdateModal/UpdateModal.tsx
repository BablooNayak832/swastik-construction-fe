import React, { useEffect, useState } from 'react';
import {
  AddRole,
  Form,
  AddButton,
} from './styles';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import { baseImgUrl, get_roles_url } from '../../constants/api-routes';
import { AppBar, Dialog, DialogContent, FormControlLabel, FormGroup, FormHelperText, IconButton, Link, TextField, Toolbar, Typography } from '@mui/material';
import { currentPath } from '../../Interfaces/UpdateInterface';
import useGet from '../../hooks/useGet';
import ListItemText from '@mui/material/ListItemText';
import { SelectChangeEvent } from '@mui/material/Select';
import Checkbox from '@mui/material/Checkbox';
import { UpdateModalLayout } from '../../common/styles/common-form/styles';
import { MainFormLayout } from '../Modal/styles';
import ClearIcon from '@mui/icons-material/Clear';
import { DialogActions, Grid } from '@mui/material';
import moment from 'moment'; 
import { Textarea } from '../../constants';
import ListItemComponent from '../ListItem/page'; 
import _ from 'lodash';
import { theme } from '../../common/styles/theme';  
import RequestUpdate from '../../view/material-request-update/RequestUpdate'; 
import ReturnRequestUpdate from '../../view/material-request-update/ReturnRequestUpdate'
import {useSession} from 'next-auth/react';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import NoImage from '../../../public/images/no-image-png-2.png';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: { sx: {
    maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP, 
    width: 250,  
    boxShadow: '1px 2px 10px #0c0c0c47 !important',
    '.MuiMenu-list': {
      paddingTop: 0,
      paddingBottom: 0,
    }
 }}
};


interface updateModaleType {
  open?: boolean;
  setOpen: ((value: any) => void) | undefined;
  url?: string;
  updateData?: any;
  refreshTableData?: any;
  handleUpdateProps?: any;
  selectItems?: any;
  projectItems?:any;
  title?: string;
  catItems?: any; 
  items?: any;
}

const UpdateModal = ({
  open,
  setOpen,
  catItems,
  updateData,
  projectItems,
  handleUpdateProps,
  selectItems,
  title,
  refreshTableData,
  items
}: updateModaleType) => {  
  const [updateUserdata, setUpdateUserdata] = React.useState<any>({});
  const { resData: roleData, handleGetData: getRoles } = useGet();
  const [dataArray, setDataArray] = useState<any[]>(updateData?.items);
  const [updateDataImg, setUpdateDataImg] = useState<any>({})
  const [updateFormErrors, setUpdateFormErrors] = useState<{ [key: string]: string }>({}); 
  const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({}); 
  const errors: { [key: string]: string } = {};
  const {data: session} = useSession()
  const [showPassword, setShowPassword] = React.useState(false);

  useEffect(() => {
    setDataArray(updateData?.items)
  }, [updateData?.items])

  useEffect(() => {
    if (title === 'Category' || title === 'Material' || title === 'Machinery' || title === 'User' || title === 'Brand') {
      setUpdateUserdata(updateData)
    }
  }, [updateData])


  React.useEffect(() => {
    if (title === 'Project' || title === 'Project Assigned') {
      setUpdateUserdata({
        ...updateData,
        supervisior: updateData?.supervisior?.map((value: any) => value.userId),
        siteManagers: updateData?.siteManagers?.map((value: any) => value.userId),
        projectManagers: updateData?.projectManagers?.map((value: any) => value.userId),
        purchaseManager: updateData?.purchaseManager?.map((value: any) => value.userId)
      });
    }

    if(title === "User"){
      setUpdateUserdata({
        ...updateData,
        assignedProject: updateData?.assignedProject?.map((value:any) => value?.id)
      })
    }

    if (title === 'Vendor') {
      setUpdateUserdata({
        ...updateData,
        categories: updateData?.categories?.map((value: any) => value),
      })
    }
    if(title === 'Category') {
      setUpdateUserdata({
        ...updateData,
        categoryName: updateData?.categoryName, 
      })
     } 
       if(title === 'Brand') {
      setUpdateUserdata({
        ...updateData,
        categories: updateData?.categories, 
      })
     } 

    if (title == 'Staff') {
      convertImageUrlToFile(updateData?.image)
    }
  }, [updateData]);

  // Function to fetch and convert the image to a File object
  const convertImageUrlToFile = async (url?: any) => {
    if (!!url) {
      const parts = url?.split('/');
      const filename = parts[parts?.length - 1];
      try {
        const response = await fetch(url);
        const blob = await response.blob();
        // Create a File object
        const file = new File([blob], filename, {
          lastModified: 1707887289134, // Set the last modified timestamp
          lastModifiedDate: new Date(1707887289134), // Set the last modified date
          type: "image/png" // Set the MIME type
        });
        setUpdateDataImg(file)
      } catch (error) {
        return error;
      }
    }
  }

  
  const validateForm = (title) => { 
    var reMobile = /^[0]?[6789]\d{9}$/; 
    const reEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    switch (title) {
      case 'Project': 
       if (!updateUserdata?.projectName){
        errors.projectName = 'Project name is required.';
       } else {
        delete errors.projectName;
       }
       break;
      case 'User':
        if (!updateUserdata?.name) {
           errors.name = 'Name is required.';
        }  else {
            delete errors.name;
        } 
        if(!!updateUserdata?.email){
          if(!reEmail.test(updateUserdata?.email)){
             errors.email = 'Enter a valid email address.';
          }else{
            delete errors.email;
          }
        }
        if (!updateUserdata?.mobileNumber) {  
           errors.mobileNumber = 'Mobile Number is required.';
        } else if (!reMobile.test(updateUserdata?.mobileNumber)) {
          errors.mobileNumber = 'Number is not a valid mobile number.';
         }else {
          delete errors.mobileNumber;
        }
        break;
      case 'Category':
          if (!updateUserdata?.categoryName) {
              errors.categoryName = 'Name is required.';
          } else {
              delete errors.categoryName;
          }
          if (!updateUserdata?.typeId?.length) {
              errors.typeId = 'Type is required.';
          } else {
              delete errors.typeId;
          }
          break;
      case 'Brand':
        if (!updateUserdata?.brandName) {
            errors.brandName = 'Brand name is required.';
        } else {
            delete errors.brandName;
        }
        if (!updateUserdata?.typeId?.length) {
            errors.typeId = 'Type is required.';
        } else {
            delete errors.typeId;
        }
        break;
      case 'Vendor':
        if (!updateUserdata?.name){
            errors.name = 'Vendor name is required.';
        } else {
            delete errors.name;
        } 
        if (!updateUserdata?.address){
          errors.address = 'Address is required.';
        } else {
          delete errors.address;
        } 
        if (!updateUserdata?.contact){
          errors.contact = 'Contact number is required.';
        }else if (!reMobile.test(updateUserdata?.contact)) {
          errors.contact = 'Number is not a valid contact number.';
         } else {
          delete errors.contact;
        } 
        if (!updateUserdata?.GSTIN){
          errors.GSTIN = 'GSTIN number is required.';
        } else {
          delete errors.GSTIN;
        } 
        break; 
       } 
     setFormErrors(errors); 
     return Object.keys(errors).length === 0; // Returns true if no errors found
  }; 
 
  const handleUpdate = (event: any, checkId: any, id: any) => { 
    if (!Object.keys(updateFormErrors)?.length) {
      switch (checkId) {
        case currentPath.Project: {
          const payload = {
            project: {
              id: updateData?.id,
              projectName: !!updateUserdata?.projectName ? updateUserdata?.projectName : updateData?.projectName,
              location: updateData?.location,
              startDate: updateUserdata?.startDate ? updateUserdata?.startDate : updateData?.startDate,
              endDate: updateUserdata?.endDate,
              status: updateUserdata?.status,
              description: updateUserdata?.description,
            },
            assignProject: {
              projectId: updateData?.id,
              projectManager: updateUserdata?.projectManagers,
              supervisior: updateUserdata?.supervisior,
              purchaseManager: updateUserdata?.purchaseManager,
              siteManager: updateUserdata?.siteManagers,
            }
          } 
          const isValid = validateForm('Project')
          if(isValid){
            handleUpdateProps(event, payload);
            setOpen(!open)
            setUpdateUserdata({})
          }
         }
          break;
        case currentPath.Category: {
          const payload = {
            // id: updateData.id,
            previousName: updateData?.categoryName,
            categoryName: updateUserdata?.categoryName?.length
              ? updateUserdata?.categoryName
              : updateData?.categoryName,
            type: updateUserdata?.typeId?.length
              ? updateUserdata?.typeId
              : updateData?.typeId,
          }
          const isValid = validateForm('Category')
          if(isValid){
            handleUpdateProps(event, payload);
            setOpen(!open)
            setUpdateUserdata({})
          }
        }
          break;
        case currentPath.User: { 
            const payload = {
              updateUser: {
                  id:updateData?.id,
                  name: updateUserdata?.name,
                  status: updateUserdata?.status,
                  email: updateUserdata?.email,
                  roleId: updateUserdata?.roleId,
                  mobileNumber: updateUserdata?.mobileNumber,
                  password: updateUserdata?.password?.length ? updateUserdata?.password : updateData?.password
              },
              assignProject: {
                  projectId: updateUserdata?.assignedProject
              }
            } 
          const isValid = validateForm('User') 
          if(isValid){
            handleUpdateProps(event, payload);
            setOpen(!open)
            setUpdateUserdata({})
          }
        }
          break;
        case currentPath.Brand: {
          const payload = {
            previousName: updateData?.brandName,
            brandName: updateUserdata?.brandName,
            type: updateUserdata?.typeId,
            categoryID: updateUserdata?.categories?.length
            ? updateUserdata?.categories
            : updateData?.categories
          }  
          const isValid = validateForm('Brand')
          if(isValid){ 
            handleUpdateProps(event, payload);
            setOpen(!open)
            setUpdateUserdata({})
          } 
        }
          break;
        case currentPath.Staff: {
          const formData = new FormData();
          formData.append('id', updateData?.id);
          formData.append('name', updateUserdata?.name || updateData?.name);
          formData.append('image', updateUserdata?.image || updateDataImg);
          formData.append('projectId', updateUserdata?.projectId || updateData?.projectId);
          if(!!updateUserdata?.mobileNumber){
            formData.append('mobileNumber', updateUserdata?.mobileNumber) //|| updateData?.mobileNumber); 
          }
          handleUpdateProps(event, formData);
          setOpen(!open)
          setUpdateUserdata({})
        }
          break;
        case currentPath.Type: {
          const formData = new FormData();
          formData.append('id', updateData.id);
          formData.append('name', updateUserdata.name);
          formData.append('image', updateUserdata.image);
          handleUpdateProps(event, formData);
          setOpen(!open)
          setUpdateUserdata({})
        }
          break;
        case currentPath.Product: {
          const productPayload = {
            id: updateData.id,
            productName: updateUserdata?.productName?.length
              ? updateUserdata?.productName
              : updateData?.productName,
            categoryId: updateUserdata?.categoryId
              ? updateUserdata?.categoryId
              : updateData?.categoryId,
            size: updateUserdata?.size
              ? updateUserdata?.size
              : updateData?.size,
            unit: updateUserdata?.unit
              ? updateUserdata?.unit
              : updateData?.unit
          }
          handleUpdateProps(event, productPayload);
          setOpen(!open)
          setUpdateUserdata({})
        }
          break; 
        case currentPath.Request: {
          for (let i = 0; i < dataArray?.length; i++) {
            dataArray[i].projectId = updateData.projectId;
          }
          handleUpdateProps(event, dataArray);
          setOpen(!open)
          setUpdateUserdata({})
        }
          break;
        case currentPath.ReturnRequest: {
          let payload: any = [];
          for (let i = 0; i < dataArray?.length; i++) {
            dataArray[i].projectId = updateData.projectId;
          }
          dataArray?.map((data: any) => {
            payload.push({
              id: data?.id,
              projectId: data?.projectId,
              materialId: data?.materialId,
              quantity: data?.quantity,
              remark: data?.remark,
            })
          })
          handleUpdateProps(event, payload);
          setOpen(!open)
          setUpdateUserdata({})
        }
          break;
        case currentPath.Vendor: {
          const payload = {
            name: updateUserdata?.name?.length
              ? updateUserdata?.name
              : updateData?.name,
            address: updateUserdata?.address?.length
              ? updateUserdata?.address
              : updateData?.address,
            prevContact: updateData?.contact,
            contact: updateUserdata?.contact?.length
              ? updateUserdata?.contact
              : updateData?.contact,
            GSTIN: updateUserdata?.GSTIN?.length
              ? updateUserdata?.GSTIN
              : updateData?.GSTIN,
            category: updateUserdata?.categories?.length
              ? updateUserdata?.categories
              : updateData?.categories
          }  
          const isValid = validateForm('Vendor')
          if(isValid) { 
            handleUpdateProps(event, payload);
            setOpen(!open) 
            setUpdateUserdata({})
          } 
        }
          break;
      } 
    }  
  };
   
  const getUserRoles = async () => {
    const res = await getRoles(get_roles_url)
      .then((data) => {
        return data;
      })
      .catch((error) => {
        return error;
      });
    return res;
  };

  useEffect(() => {
    if( [0, 1].includes(session?.user?.role_id)){
      getUserRoles();
    }
  }, []); 
  

  return (
    <UpdateModalLayout>
      {!!open && (
        <>
          <Dialog
            fullWidth
            maxWidth={ ["Material Request"].includes(title) ? 'lg' : "md"}
            open={open}
            onClose={() => {
              setOpen(!open)
              setFormErrors({})
            }}>
            <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
              <Toolbar>
                <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                  Update {title}
                </Typography>
                <DialogActions>
                  <ClearIcon onClick={() => {
                       setOpen(!open) 
                       setFormErrors({})
                  }} />
                </DialogActions>
              </Toolbar>
            </AppBar>
            <DialogContent>
              <AddRole>
                <MainFormLayout>
                  {title === 'User' && (
                    <Form>
                      <Grid container spacing={2}>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Name
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <TextField
                              size="small"
                              id="outlined-basic"
                              placeholder="Name"
                              variant="outlined"
                              type="text"
                              name="name"
                              defaultValue={updateUserdata?.name}
                              onChange={(e) => {
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  name: e.target.value,
                                });
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.name;
                                setFormErrors(updatedErrors);
                              }}
                              />
                          </FormControl>
                              {formErrors.name && (
                                <FormHelperText id="brand-error" error>
                                  {formErrors.name}
                                </FormHelperText>
                              )}
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}> 
                          <InputLabel id="demo-simple-select-label">
                            Email
                          </InputLabel> 
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <TextField
                              size="small"
                              id="outlined-basic"
                              variant="outlined"
                              type="email"
                              autoComplete="off"
                              name="email"
                              value={updateUserdata?.email}
                              disabled={!!updateData?.email}
                              onChange={(e) => {
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  email: e.target.value,
                                });
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.email;
                                setFormErrors(updatedErrors);
                              }} 
                            />
                          </FormControl>
                          {formErrors.email && (
                               <FormHelperText id="brand-error" error>
                                 {formErrors.email}
                               </FormHelperText>
                               )}
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Password
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <TextField
                              size="small"
                              id="outlined-basic"
                              placeholder="Password"
                              autoComplete="new-password"
                              variant="outlined"
                              type={showPassword ? 'text' : 'password'}
                               InputProps={{
                                endAdornment: <>
                                  <IconButton onClick={() => setShowPassword((show) => !show)}>
                                    {showPassword ? <VisibilityOff /> : <Visibility />}
                                  </IconButton>
                                </>
                              }}
                              name="password"
                              defaultValue={updateUserdata?.password}
                              onChange={(e) => {
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  password: e.target.value,
                                });
                              }}
                            />
                          </FormControl>
                        </Grid> 

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Mobile Number
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}> 
                                 <TextField
                                    id="my-input"
                                    size='small' 
                                    placeholder='Phone Number'
                                    value={updateUserdata?.mobileNumber}
                                    onChange={(e) => {
                                      const enteredValue = e.target.value;
                                      const numericValue = Number(enteredValue); // Convert the value to a number
                                      if (
                                        !Number.isNaN(numericValue) &&
                                        enteredValue.length <= 10
                                      ) {
                                        setUpdateUserdata({
                                          ...updateUserdata,
                                          mobileNumber: enteredValue,
                                        });
                                        const updatedErrors = { ...formErrors };
                                        delete updatedErrors.mobileNumber;
                                        setFormErrors(updatedErrors);
                                      } 
                                    }}
                                    aria-describedby="my-helper-text"
                                 />
                          </FormControl>
                              {formErrors.mobileNumber && (
                               <FormHelperText id="brand-error" error>
                                 {formErrors.mobileNumber}
                               </FormHelperText>
                               )}
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Role
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                              value={updateUserdata?.roleId}
                              onChange={(event: SelectChangeEvent<object>) => {
                                const { target: { value } } = event;
                                setUpdateUserdata({ ...updateUserdata, roleId: value, assignedProject:[] })
                              }}
                              renderValue={(selected: any[]) => {
                                return roleData?.filter(i => i?.id === selected)?.map(item => item?.roleName)?.join(', ') || selected;

                              }}
                              MenuProps={MenuProps}
                              defaultValue={updateUserdata?.role}
                            >
                              {roleData?.map((item: any) => {
                                return (
                                  <MenuItem key={item?.id} value={item?.id}>
                                    <ListItemText primary={item?.roleName} />
                                  </MenuItem>
                                );
                              })}
                            </Select>
                          </FormControl>
                        </Grid>  

                        {(( (updateData?.roleId !== 1)
                           && (updateData?.roleId == 2 ) 
                           && (updateData?.roleId !== 3) 
                           && (updateData?.roleId !== 6)) ||
                            ((updateUserdata?.roleId == 2) || (updateUserdata?.roleId == 4) || (updateUserdata?.roleId == 5))) && 
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel id="demo-simple-select-label">
                              Assigned Projects
                            </InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                            <Select 
                                id="demo-multiple-checkbox"
                                multiple
                                value={updateUserdata?.assignedProject}
                                onChange={(event: SelectChangeEvent<object>) => {
                                  const { target: { value } } = event;  
                                  setUpdateUserdata({ ...updateUserdata, assignedProject: value })
                                }}
                                renderValue={(selected: any[]) => {
                                  return projectItems?.filter(item => selected?.includes(item?.id))?.map(item => item?.projectName)?.join(','); 
                                }}
                                MenuProps={MenuProps}
                              > 
                              {projectItems?.length === 0 &&
                               <MenuItem>No Data Available</MenuItem>
                              } 
                                { projectItems?.map((item: any) => { 
                                    return (
                                      <MenuItem key={item?.id} value={item?.id}>
                                        <Checkbox size='small'
                                          checked={updateUserdata?.assignedProject?.indexOf(item.id) > -1}
                                        />
                                        <ListItemText sx={{padding: 0}} primary={item?.projectName} />
                                      </MenuItem>
                                    );
                                  })}
                              </Select> 
                            </FormControl>
                        </Grid>}

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <AddButton
                            variant="contained"
                            sx={{ marginTop: '22px' }} 
                            onClick={(e) => handleUpdate(e, 'user', updateData?.id)}
                          >
                            Update User
                          </AddButton>
                        </Grid>
                      </Grid>
                    </Form>
                  )} 
                  
                  {((title === 'Project') || (title === 'Project Assigned')) && (
                    <Form>
                      <Grid container spacing={2}>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">Project Name</InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <TextField
                              size="small"
                              id="outlined-basic"
                              placeholder='Project Name'
                              // label="Project Name"
                              onChange={(e) => {
                                setUpdateUserdata({...updateUserdata,
                                  projectName: e.target.value
                                })
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.projectName;
                                setFormErrors(updatedErrors); 
                              }}
                              variant="outlined"
                              type="text"
                              name="projectName"
                              defaultValue={updateData?.projectName}
                              value={updateUserdata?.projectName}
                            />
                          </FormControl>
                          {formErrors.projectName && (
                           <FormHelperText id="name-error" error>
                              {formErrors.projectName}
                            </FormHelperText>
                          )}
                        </Grid>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">Project Id</InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <TextField
                              size="small"
                              id="outlined-basic"
                              variant="outlined"
                              type="text"
                              name="siteId"
                              value={updateData?.projectId ?? updateData?.siteId }
                            />
                          </FormControl>

                        </Grid>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">Location</InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <TextField
                              size="small"
                              id="outlined-basic"
                              variant="outlined"
                              type="text"
                              name="location"
                              defaultValue={updateData?.location}
                              disabled={session?.user?.role_id === 2}
                              value={updateUserdata?.location}
                              onChange={(e) => {      
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  location: e.target.value,
                                });
                              }}
                            />
                          </FormControl>
                        </Grid> 
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">Latitude / Longitude <Link style={{ textDecoration: 'none' }} href={'https://www.google.com/maps/@22.7378602,75.8882504,15z?entry=ttu'} target='_blank'><span style={{ fontSize: '12px' }}>Google map...</span> </Link></InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                          <div style={{ display: 'flex' }}>
                            <TextField
                              size="small"
                              sx={{ paddingRight: '2px' }}
                              id="outlined-basic"
                              variant="outlined" 
                              disabled={session?.user?.role_id === 2}
                              name="latitude"
                              defaultValue={updateData?.latitude} 
                              value={updateUserdata?.latitude  } 
                              onChange={(e) => {      
                                const value = e.target.value; 
                                const regex =  /^[+-]?(\d*\.\d+|\d+\.?\d*)$/;  
                                if ((value !== 'e') && ((value === '') || (regex.test(value)))) {
                                    setUpdateUserdata({
                                      ...updateUserdata,
                                      latitude: value,
                                    });
                                  }
                              }}
                            />
                            <TextField
                              sx={{ paddingRight: '2px' }}
                              size="small"
                              id="outlined-basic"
                              variant="outlined"
                              disabled={session?.user?.role_id === 2}
                              name="longitude"
                              defaultValue={updateData?.longitude}
                              value={updateUserdata?.longitude}
                              onChange={(e) => {
                                const value = e.target.value; 
                                const regex =  /^[+-]?(\d*\.\d+|\d+\.?\d*)$/;  
                                if ((value !== 'e') && ((value === '') || (regex.test(value)))) {
                                  setUpdateUserdata({
                                    ...updateUserdata,
                                    longitude: e.target.value,
                                  });
                                }
                              }}
                            />
                          </div>
                          </FormControl>
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel>
                            Status
                          </InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                            <Select
                              size='small'
                              labelId="demo-simple-select-label"
                              id="demo-simple-select"
                              value={updateUserdata?.status}
                              defaultValue={updateData?.status}
                              onChange={(e) => {
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  status: e.target.value,
                                });
                              }}
                              renderValue={(selected) => {
                                return selected;
                              }}
                              MenuProps={MenuProps}
                            >
                              {[{ id: 1, value: 'onhold', text: "On hold" }, { id: 2, value: "running", text: "Resume" }]?.map((sItem: any, i: any) => {
                                return (
                                  <MenuItem key={i?.id} value={sItem?.value}>
                                    {sItem?.text}
                                  </MenuItem>
                                );
                              })}
                            </Select>
                          </FormControl>
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Start Date
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                          <input 
                            style={{   
                              width: 'auto',
                              height: '30px',
                              padding: '17px',
                              fontSize: '15px'
                            }}
                            type="date" 
                            id="startDate" 
                            name="startDate"  
                            value={updateUserdata?.startDate}
                            onChange={(newValue: any) => {
                              setUpdateUserdata({
                                ...updateUserdata,
                                startDate: moment(newValue?.target?.value).format('YYYY-MM-DD')
                              });
                            }} 
                            /> 
                          </FormControl>
                        </Grid>

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            End Date
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                          <input 
                            style={{   
                              width: 'auto',
                              height: '30px',
                              padding: '17px',
                              fontSize: '15px'
                            }}
                            type="date" 
                            id="endDate" 
                            name="endDate" 
                            defaultValue={updateUserdata?.endDate}
                            value={updateUserdata?.endDate} 
                            onChange={(newValue: any) => { 
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  endDate: moment(newValue?.target?.value).format('YYYY-MM-DD')
                                }); 
                            }}
                            min={updateUserdata?.startDate}  
                            // min={formData?.startDate}  
                            disabled={!updateUserdata.startDate}
                            /> 
                          </FormControl>
                        </Grid>

                       { session?.user?.role_id !== 2 && <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Project Head
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                              labelId="demo-multiple-checkbox-label"
                              id="demo-multiple-checkbox"
                              multiple
                              value={updateUserdata?.projectManagers}
                              onChange={(event: SelectChangeEvent<object>) => {
                                const { target: { value } } = event;
                                setUpdateUserdata({ ...updateUserdata, projectManagers: value })
                              }}
                              renderValue={(selected: any[]) => {
                                return selectItems?.filter((selectItem:any) =>
                                  selected.includes(selectItem?.id)
                                )
                                ?.map((item:any) => item?.name)
                                .join(', ');
                                // return selectItems?.filter((selectItem: any) => selectItem?.id == selected)?.map((item: any) => item?.name)?.join(', ');;
                              }}
                              MenuProps={MenuProps}
                              defaultValue={updateUserdata?.projectManagers}
                            >
                            {!selectItems?.filter((item: any) => item?.role?.key === 'projectHead')?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                              selectItems?.filter((item: any) => item?.role?.key === 'projectHead')?.map((item: any) => {
                                  return (
                                    <MenuItem key={item?.id} value={item.id}>
                                      <Checkbox size='small'
                                        checked={updateUserdata?.projectManagers?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item?.name} />
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                          </FormControl>
                        </Grid>}

                       { session?.user?.role_id !== 2 && <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel id="demo-simple-select-label">
                            Site Head
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                              id="demo-multiple-checkbox"
                              multiple
                              value={updateUserdata?.siteManagers}
                              onChange={(event: SelectChangeEvent<object>) => {
                                const { target: { value } } = event;
                                setUpdateUserdata({ ...updateUserdata, siteManagers: value })
                              }}
                              renderValue={(selected: any[]) => {
                                return selectItems
                                  ?.filter((selectItem) =>
                                    selected.includes(selectItem?.id)
                                  )
                                  ?.map((item) => item?.name)
                                  .join(',');
                              }}
                              MenuProps={MenuProps}
                            >
                              {!selectItems?.filter((item: any) => item?.role?.key === 'siteHead')?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                              selectItems?.filter((item: any) => item?.role?.key === 'siteHead')?.map((item: any) => {
                                  return (
                                    <MenuItem key={item?.id} value={item?.id}>
                                      <Checkbox size='small'
                                        checked={updateUserdata?.siteManagers?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item?.name} />
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                          </FormControl>
                        </Grid>}

                       {session?.user?.role_id !== 2 &&  <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel>
                            Supervisors
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                              labelId="demo-multiple-checkbox-label"
                              id="demo-multiple-checkbox"
                              multiple
                              value={updateUserdata?.supervisior}
                              onChange={(event: any) => {
                                const { target: { value } } = event;
                                setUpdateUserdata({ ...updateUserdata, supervisior: value })
                              }}
                              renderValue={(selected: any[]) => {
                                return selectItems
                                  ?.filter((selectItem) =>
                                    selected.includes(selectItem?.id)
                                  )
                                  ?.map((item) => item?.name)
                                  .join(',');
                              }}
                              MenuProps={MenuProps}
                            >
                              {!selectItems?.filter((item: any) => item?.role?.key === 'supervisior')?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                              selectItems?.filter((item: any) => item?.role?.key === 'supervisior')?.map((item: any) => {
                                  return (
                                    <MenuItem key={item?.id} value={item?.id}>
                                      <Checkbox size='small'
                                        checked={updateUserdata?.supervisior?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item?.name} />
                                    </MenuItem>
                                  );
                                })}
                            </Select>
                          </FormControl>
                        </Grid>}

                        <Grid item lg={6} md={6} sm={6} xs={12}>
                          <InputLabel>
                            Description
                          </InputLabel>
                          <FormControl size="small" sx={{ width: '100%' }}>
                            <Textarea
                              title="Description"
                              aria-label="minimum height"
                              minRows={3}
                              sx={{resize: 'none'}}
                              placeholder="Description..."
                              defaultValue={updateData?.description}
                              value={updateUserdata?.description}
                              onChange={(e) => {
                                const value = e.target.value;
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  description: value,
                                });
                              }}
                            />
                          </FormControl>
                        </Grid>

                        <Grid item lg={12} md={12} sm={6} xs={12}>
                          <AddButton
                            variant="contained"
                            onClick={(e) => handleUpdate(e, 'project')}
                          >
                            Update Project
                          </AddButton>
                        </Grid>
                      </Grid>
                    </Form>
                  )}

                  {title === 'Category' && (
                    <Form>
                      <Grid container spacing={2}>
                        <Grid item lg={12} md={6} sm={6} xs={12}>
                          <InputLabel htmlFor="my-input">Name</InputLabel>
                          <FormControl sx={{ width: '100%' }}>
                            <TextField
                              size='small'
                              type="text"
                              id="my-input"
                              defaultValue={updateData?.categoryName}
                              value={updateUserdata?.categoryName}
                              onChange={(e) => {
                                setUpdateUserdata({
                                  ...updateUserdata,
                                  categoryName: e.target.value,
                                });
                                const updatedErrors = { ...formErrors };
                                delete updatedErrors.categoryName;
                                setFormErrors(updatedErrors);
                              }}
                              aria-describedby="my-helper-text"
                              />
                          </FormControl>
                              {formErrors.categoryName && (
                                <FormHelperText id="name-error" error>
                                  {formErrors.categoryName}
                                </FormHelperText>
                              )}
                        </Grid>
                      </Grid>
                      <Grid item lg={12} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input"> Type *</InputLabel>
                        <FormGroup>
                          {[{ id: 1, text: 'Material' }, { id: 2, text: 'Machinery' }].map(option => {
                            return (
                              <div key={option.id}>
                                <FormControlLabel
                                  label={option.text}
                                  value={option.id}
                                  defaultValue={updateUserdata?.typeId}
                                  control={
                                    <Checkbox size='small'
                                      checked={updateUserdata?.typeId?.includes(option.id)}
                                      onChange={(e) => {
                                        const type = parseInt(e.target.value);
                                        if (!updateUserdata?.typeId?.includes(option?.id)) {
                                          setUpdateUserdata((prevData: any) => ({
                                            ...prevData,
                                            typeId: prevData?.typeId ? [...prevData?.typeId, type] : [type],
                                          }));
                                        } else {
                                          setUpdateUserdata((prevData: any) => ({
                                            ...prevData,
                                            typeId: prevData?.typeId?.filter((fType: any) => fType !== type),
                                          }))
                                        }
                                        const updatedErrors = { ...formErrors };
                                        delete updatedErrors.typeId;
                                        setFormErrors(updatedErrors);
                                      }} />
                                    }
                                    />
                              </div>
                            )
                          })}
                        </FormGroup>
                          {formErrors.typeId && (
                           <FormHelperText id="name-error" error>
                             {formErrors.typeId}
                           </FormHelperText>
                         )}
                      </Grid>
                      <Grid item lg={12} md={12} sm={6} xs={12}>
                        <AddButton
                          variant="contained"
                          onClick={(e) => handleUpdate(e, 'category')}
                        >
                          Update Category
                        </AddButton>
                      </Grid>
                    </Form>
                  )}

                  {title === 'Material Request' && (
                    <>
                    <RequestUpdate 
                     setOpen={setOpen}
                     updateData={updateData}
                     handleUpdateProps={handleUpdateProps} 
                     catItems={catItems}
                     refreshTableData={refreshTableData}/> 
                    </>
                  )}

                  {title === "Vendor" && (
                    <>
                      <Form>
                        <Grid container spacing={2}>
                          <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Name</InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                              <TextField
                                size="small"
                                id="outlined-basic" 
                                variant="outlined"
                                type="text"
                                value={updateUserdata?.name}
                                defaultValue={updateData?.name}
                                onChange={(e) => {
                                  setUpdateUserdata({
                                    ...updateUserdata,
                                    name: e.target.value,
                                  });
                                  const updatedErrors = { ...formErrors };
                                  delete updatedErrors.name;
                                  setFormErrors(updatedErrors);
                                }}
                                />
                            </FormControl>
                                {formErrors.name && (
                                  <FormHelperText id="name-error" error>
                                    {formErrors.name}
                                  </FormHelperText>
                                )}
                          </Grid>

                          <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Address</InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                              <TextField
                                size="small"
                                id="outlined-basic" 
                                variant="outlined"
                                type="text"
                                value={updateUserdata?.address}
                                defaultValue={updateData?.address}
                                onChange={(e) => {
                                  setUpdateUserdata({
                                    ...updateUserdata,
                                    address: e.target.value,
                                  });
                                  const updatedErrors = { ...formErrors };
                                  delete updatedErrors.address;
                                  setFormErrors(updatedErrors);
                                }}
                                />
                            </FormControl>
                                {formErrors.address && (
                                 <FormHelperText id="address-error" error>
                                   {formErrors.address}
                                  </FormHelperText>
                                )}
                          </Grid>

                          <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Contact</InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                              <TextField
                                size="small"
                                id="outlined-basic" 
                                variant="outlined"
                                type="text"
                                value={updateUserdata?.contact}
                                defaultValue={updateData?.contact}
                                onChange={(e) => {
                                  const enteredValue = e.target.value;
                                  const numericValue = Number(enteredValue); // Convert the value to a number
                                  if (
                                    !Number.isNaN(numericValue) &&
                                    enteredValue.length <= 10
                                  ) {
                                    setUpdateUserdata({
                                      ...updateUserdata,
                                      contact: enteredValue,
                                    });
                                    const updatedErrors = { ...formErrors };
                                    delete updatedErrors.contact;
                                    setFormErrors(updatedErrors);
                                  }
                                }}
                                />
                            </FormControl>
                                {formErrors.contact && (
                                 <FormHelperText id="contact-error" error>
                                   {formErrors.contact}
                                 </FormHelperText>
                               )}
                          </Grid>

                          <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">GSTIN</InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                              <TextField
                                size="small"
                                id="outlined-basic"
                                variant="outlined"
                                type="text"
                                value={updateUserdata?.GSTIN}
                                defaultValue={updateData?.GSTIN}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  if (value?.length <= 15) {
                                    setUpdateUserdata({
                                      ...updateUserdata,
                                      GSTIN: value,
                                    });
                                  }
                                  const updatedErrors = { ...formErrors };
                                  delete updatedErrors.GSTIN;
                                  setFormErrors(updatedErrors);
                                }}
                                />
                            </FormControl>
                                {formErrors.GSTIN && (
                                  <FormHelperText id="name-error" error>
                                    {formErrors.GSTIN}
                                  </FormHelperText>
                                )}
                          </Grid>
                          <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Category</InputLabel> 
                            <FormControl size="small" sx={{ width: '100%' }}>
                              <Select
                                id="demo-multiple-checkbox"
                                multiple
                                value={updateUserdata?.categories}
                                onChange={(event: SelectChangeEvent<object>) => {
                                  const { target: { value } } = event;
                                  setUpdateUserdata({ ...updateUserdata, categories: value })
                                }}
                                renderValue={(selected: any) => {
                                  return catItems
                                    ?.filter((selectItem) =>
                                      selected.includes(selectItem?.id)
                                    )
                                    ?.map((item) => item?.categoryName)
                                    .join(',');
                                }}
                                MenuProps={MenuProps}
                              >
                                {!catItems?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                                catItems?.map((item: any) => {
                                  return (
                                    <MenuItem key={item?.id} value={item?.id}>
                                      <Checkbox size='small'
                                        checked={updateUserdata?.categories?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item?.categoryName} />
                                    </MenuItem>
                                  );
                                })}
                              </Select>
                            </FormControl>
                          </Grid>

                          <Grid item lg={12} md={6} sm={6} xs={12}>
                            <AddButton
                              style={{ float: 'right' }}
                              variant="contained"
                              onClick={(e) => handleUpdate(e, 'vendor', updateData?.id)}
                            >
                              Update Vendor
                            </AddButton>
                          </Grid>
                        </Grid>
                      </Form>
                    </>
                  )}
 
                  {title === "Brand" && (
                      <>
                        <Form>
                          <Grid container spacing={2}>
                            <Grid item lg={12} md={6} sm={6} xs={12}>
                              <InputLabel htmlFor="my-input">Name</InputLabel>
                              <FormControl size="small" sx={{ width: '100%' }}>
                                <TextField
                                  size="small"
                                  id="outlined-basic"
                                  variant="outlined"
                                  type="text"  
                                  defaultValue={updateData?.brandName}
                                  onChange={(e) => {
                                    setUpdateUserdata({
                                      ...updateUserdata,
                                      brandName: e.target.value,
                                    });
                                    const updatedErrors = { ...formErrors };
                                    delete updatedErrors.brandName;
                                    setFormErrors(updatedErrors);
                                  }}
                                />
                              </FormControl>
                                 {formErrors.brandName && (
                                    <FormHelperText id="brand-error" error>
                                      {formErrors.brandName}
                                    </FormHelperText>
                                  )}
                            </Grid>

                            <Grid item lg={12} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Category</InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                              <Select
                                id="demo-multiple-checkbox"
                                multiple
                                value={updateUserdata?.categories ?? []}
                                onChange={(event: SelectChangeEvent<object>) => {
                                  const { target: { value } } = event;
                                  setUpdateUserdata({ ...updateUserdata, categories: value })
                                }}
                                renderValue={(selected: any) => {
                                  return catItems
                                    ?.filter((selectItem) =>
                                      selected.includes(selectItem?.id)
                                    )
                                    ?.map((item) => item?.categoryName)
                                    .join(',');
                                }}
                                MenuProps={MenuProps}
                              >  
                                {!catItems?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                                catItems?.map((item: any) => {
                                  return (
                                    <MenuItem key={item?.id} value={item?.id}>
                                      <Checkbox size='small'
                                        checked={updateUserdata?.categories?.indexOf(item.id) > -1}
                                      />
                                      <ListItemText primary={item?.categoryName} />
                                    </MenuItem>
                                  );
                                })}
                              </Select>
                            </FormControl>
                            </Grid>
                            
                            <Grid item lg={12} md={6} sm={6} xs={12}>
                              <InputLabel htmlFor="my-input"> Type *</InputLabel>
                              <FormGroup>
                                {[{ id: 1, text: 'Material' }, { id: 2, text: 'Machinery' }].map(option => {
                                  return (
                                    <div key={option.id}>
                                      <FormControlLabel
                                        label={option.text}
                                        value={option.id}
                                        defaultValue={updateUserdata?.typeId}
                                        control={
                                          <Checkbox size='small'
                                            checked={updateUserdata?.typeId?.includes(option.id)}
                                            onChange={(e) => {
                                              const type = parseInt(e.target.value); 
                                                if (!updateUserdata?.typeId?.includes(option?.id)) {
                                                  setUpdateUserdata((prevData: any) => ({
                                                      ...prevData,
                                                      typeId: prevData?.typeId ? [...prevData?.typeId, type] : [type],
                                                    }));
                                                } else {  
                                                  setUpdateUserdata((prevData: any) => ({
                                                    ...prevData,
                                                    typeId: prevData?.typeId?.filter((fType: any) => fType !== type),
                                                  }))
                                                } 
                                              const updatedErrors = { ...formErrors };
                                              delete updatedErrors.typeId;
                                              setFormErrors(updatedErrors);
                                            }} />
                                        }
                                      /> 
                                    </div>
                                  )
                                })}
                              </FormGroup>
                              {formErrors.typeId && (
                                  <FormHelperText id="brand-error" error>
                                      {formErrors.typeId}
                                   </FormHelperText>
                              )}
                            </Grid>

                            <Grid item lg={12} md={6} sm={6} xs={12}>
                              <AddButton
                                style={{ float: 'right' }}
                                variant="contained"
                                onClick={(e) => handleUpdate(e, 'brand', updateData?.id)}
                              >
                                Update Brand
                              </AddButton>
                            </Grid>
                          </Grid>
                        </Form>
                      </>
                  )}

                  {title === "Return Request" && (
                      <>
                       <ReturnRequestUpdate
                        setOpen={setOpen}
                        updateData={updateData}
                        handleUpdateProps={handleUpdateProps} 
                        catItems={catItems}
                        refreshTableData={refreshTableData}/> 
                      </> 
                  )}

                  {title === 'Staff' && (
                      <>
                        <Form>
                          <Grid container spacing={2}>
                            <Grid item lg={6} md={6} sm={6} xs={12}>
                              <InputLabel htmlFor="my-input">Name</InputLabel>
                              <FormControl size="small" sx={{ width: '100%' }}>
                                <TextField
                                  size="small"
                                  id="outlined-basic"
                                  // label="Unique Id"
                                  variant="outlined"
                                  type="text"
                                  name="siteId"
                                  defaultValue={updateData?.name}
                                  onChange={(e) => {
                                    setUpdateUserdata({
                                      ...updateUserdata,
                                      name: e.target.value,
                                    });
                                  }}
                                />
                              </FormControl>
                            </Grid>

                            <Grid item lg={6} md={6} sm={6} xs={12}>
                              <InputLabel htmlFor="my-input">Mobile Number</InputLabel>
                              <FormControl size="small" sx={{ width: '100%' }}>
                                <TextField
                                  size="small"
                                  id="outlined-basic"
                                  // label="Unique Id"
                                  variant="outlined"
                                  placeholder='Mobile Number'
                                  name="mobileNumber"
                                  value={updateUserdata?.mobileNumber}
                                  defaultValue={updateData?.mobileNumber}
                                  onChange={(e) => {
                                    const enteredValue = e.target.value;
                                    const numericValue = Number(enteredValue); // Convert the value to a number  
                                    if (
                                      !Number.isNaN(numericValue) &&
                                      enteredValue.length <= 10
                                    ) {
                                      setUpdateUserdata({
                                        ...updateUserdata,
                                        mobileNumber: enteredValue,
                                      })
                                    }

                                  }}
                                />
                              </FormControl>
                            </Grid>

                            <Grid item lg={6} md={6} sm={6} xs={12}>
                              <InputLabel htmlFor="my-input">Project</InputLabel>
                              <FormControl size="small" sx={{ width: '100%' }}>
                                <Select
                                  labelId="demo-simple-select-label"
                                  id="demo-simple-select"
                                  defaultValue={updateData?.projectId}
                                  value={updateUserdata?.projectId}
                                  onChange={(e) => {
                                    setUpdateUserdata({
                                      ...updateUserdata,
                                      projectId: e.target.value
                                    });
                                  }}
                                  renderValue={(selected) => {
                                    return selectItems?.filter((select: any) => select?.id == selected)?.map((item) => item?.projectName)?.join(', ');
                                  }}
                                  MenuProps={MenuProps}
                                >
                                  {!selectItems?.length ? <MenuItem disabled>No Data Available</MenuItem> :
                                  selectItems?.map((item) => (
                                    <MenuItem key={item?.id} value={item?.id}>
                                      {item?.projectName}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </FormControl>
                            </Grid>

                            <Grid item lg={6} md={6} sm={6} xs={12}>
                              <InputLabel htmlFor="my-input">Image</InputLabel>
                              <FormControl size="small" sx={{ width: '100%' }}>
                                <div>
                                  <input
                                    accept="image/*"
                                    id="contained-button-file"
                                    type="file"
                                    onChange={(e: any) => {
                                      const file = e?.target?.files[0];
                                      // setFormErrors(errors);
                                      // if (file && file?.type?.startsWith("image/")) {
                                      //   setUpdateUserdata({
                                      //     ...updateUserdata,
                                      //     image: file,
                                      //   });
                                      // }

                                      const imageSizeInBytes: any = file?.size;
                                      const getImageSizeInKB: any = imageSizeInBytes / 1024;

                                      if (file && file?.type?.startsWith("image/")) {
                                        setUpdateUserdata({
                                          ...updateUserdata,
                                          image: file,
                                           imagePreview: URL.createObjectURL(file)
                                        });
                                      }
                                      if (getImageSizeInKB >= 300) {
                                        setUpdateFormErrors({ ...errors, ["image"]: 'Please upload an image smaller than 300kb.' })
                                      } else {
                                        delete errors.image;
                                        setUpdateFormErrors(errors)
                                      }
                                    }}
                                  />
                                  <label title={updateData?.image} htmlFor="contained-button-file" />
                                </div>
                                <Link href={updateUserdata?.image ?? `${baseImgUrl}${updateData?.image}`} target="_blank">
                                <img
                                  style={{ paddingTop: '5px' }}
                                  src={ updateUserdata?.image ?? `${baseImgUrl}${updateData?.image}`}
                                  alt="noimage"
                                  crossOrigin="anonymous"
                                  height={100}
                                  width={100} 
                                />
                                </Link>
                              </FormControl>
                              {updateFormErrors?.image && (
                                <FormHelperText id="project-name-error" error>
                                  {updateFormErrors?.image}
                                </FormHelperText>
                              )}
                            </Grid>

                            <Grid item lg={12} md={6} sm={6} xs={12}>
                              <AddButton
                                style={{ float: 'right' }}
                                variant="contained"
                                onClick={(e) => handleUpdate(e, 'staff', updateData?.id)}
                              >
                                Update Staff
                              </AddButton>
                            </Grid>
                          </Grid>
                        </Form>
                      </>
                  )}
                </MainFormLayout>
              </AddRole>
            </DialogContent>
          </Dialog>
        </>
      )}
    </UpdateModalLayout>
  );
};

export default UpdateModal;
