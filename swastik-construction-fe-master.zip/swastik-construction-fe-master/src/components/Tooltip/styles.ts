import styled from 'styled-components';
import ErrorIcon from '@mui/icons-material/Error';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import DeleteIcon from '@mui/icons-material/Delete';
import Menu from '@mui/material/Menu';

export const Container = styled(Box)`
  text-align: center;
  align-items: center;
  display: flex;
`;

export const TooltipBox = styled(Tooltip)``;

export const Binicon = styled(DeleteIcon)`
  color: red;
`;
export const Tooltipmenu = styled(Menu)``;
export const Tooltipwarningicon = styled(ErrorIcon)`
  color: #faad14;
  font-size: 14px;
`;

export const Conformation = styled.p`
  font-size: 14px;
  margin: 10px 20px;
`;

export const Message = styled.p`
  font-weight: 600;
  font-size: 14px;
`;

export const Okbutton = styled(Button)`
  font-size: 14px;
  height: 24px;
  padding: 0px 7px;
  width: 5px;
`;
export const Cancelbutton = styled(Button)`
  font-size: 14px;
  height: 24px;
  padding: 0px 7px;
`;

export const WarningBox = styled.div`
  align-items: center;
  display: flex;
  gap: 8px;
  padding: 5px;
`;

export const ConformationBox = styled.div`
  display: flex;
  align-items: center;
  justify-content: end;
  padding: 15px 15px 8px 0px;
  gap: 10px;
`;
