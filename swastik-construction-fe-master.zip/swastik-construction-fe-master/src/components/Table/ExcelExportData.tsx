import { Button, Tooltip } from '@mui/material';
import React from 'react';
import XLSX from 'sheetjs-style';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';

const ExcelExportData = ({ excelData, title, handleExcelExport }: any) => {
  const fileName = `${title} Report` //'Excel Export';

  const modifyDataForExport = (data: any) => {
    // Function to convert keys to title case
    const convertToTitleCase = (str: any) => {
      let words = str.replace(/([a-z])([A-Z])/g, '$1 $2');
      // Capitalize each word
      words = words.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1));
      return words.join(' ');
    };
    // Remove 'id' and 'action' columns
    const modifiedData = data.map(item => {
      const newItem: any = {};
      Object.keys(item).forEach(key => {
        if (key !== 'id' && key !== 'action' && key !== 'purchaseManager' && key !== 'assignproject' && key !== 'typeId') {
          newItem[convertToTitleCase(key)] = item[key];
        }
      });
      return newItem;
    });
    return modifiedData;
  };

  const exportToExcel = async () => {
    // handleExcelExport()
    const modifiedData = modifyDataForExport(excelData);
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(modifiedData);
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, `${fileName}.xlsx`);
  };

  return (
    <>
      <Tooltip title="Export excel">
        <Button onClick={() => exportToExcel()}>
          Download Excel
          <FileDownloadOutlinedIcon fontSize='small' />
        </Button>
      </Tooltip>
    </>
  );
};

export default ExcelExportData;
