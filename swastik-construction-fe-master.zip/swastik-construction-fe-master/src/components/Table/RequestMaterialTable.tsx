import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { FormControl, IconButton, Input, InputAdornment, InputLabel, MenuItem, Select, TextField, Tooltip, Typography } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import { RequestMaterialTable } from '../../common/styles/RequestMaterialTable/style'
import {
  Tooltipwarningicon, Message, Conformation, Okbutton, Cancelbutton, Tooltipmenu, WarningBox, ConformationBox,
} from '../../components/Tooltip/styles';
import useGet from 'src/hooks/useGet';
import _ from 'lodash';  
import {material_url, site_inventory_url} from 'src/constants/api-routes';
import {Textarea} from 'src/constants';
import getRequestAPI from 'src/services/getRequest';
import {ClearIcon} from '@mui/x-date-pickers';

interface MaterialRequestTableType {
  requestType?:string,
  title?: any,
  data?: any,
  removeMaterial?: any,
  editMaterial?: any,
  editingId?: any,
  handleSave?: any,
  handleChange?: any,
  editedValue?: any,
  isApproved?: any,
  isView?: any,
  fetchData?:any,
}

const MaterialRequestTable = ({ 
  requestType,
  title, data, removeMaterial, editMaterial, editingId, handleSave, handleChange, editedValue, isApproved, isView, fetchData
}: MaterialRequestTableType) => {  
    const [materialData, setMaterialData] = React.useState<any>({})
    const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
    // const [openEditModal, setOpenEditModal] = React.useState<boolean>(false);
    const [editedMaterial, setEditedMaterial] = React.useState<any>({});
    const { resData ,handleGetData } = useGet()
    const { resData: resSiteInventory ,handleGetData : handleGetSiteInventory} = useGet() 
    const [ queryParams, setQueryParams ] = React.useState<any>({})   
    const [ subItems ,setSubItems ] = React.useState<any>([])
    const [ specificationArray ,setSpecificationArray ] = React.useState<any>([])
    const [ sizeItems ,setSizeItems ] = React.useState<any>([])  
    const open = Boolean(anchorEl);  

    const handleClickDelete = (event: React.MouseEvent<HTMLElement>, mId) => {
        let index = event.currentTarget.id;
        setAnchorEl(event.currentTarget);
        setMaterialData({index: index, materialId: mId })
    };
    
    const handleOpenEditModal = (i, row: any) => {    
            editMaterial(i, row)
            setEditedMaterial({
                "id": row.id,
                "reqId": row?.reqId, 
                "machineryOrPrductId": row.machineryOrPrductId,
                "machineryOrPrductName": row.machineryOrPrductName,
                "item": row.itemName,
                "specification": row.specification,
                "size":  row.size,
                "unit": row.unit,
                "quantity": row.quantity,
                "remark": row.remark,
                "typeId": row.typeId,
                "categoryId": row.categoryId,
                "siteAvailableQuantity": row?.siteAvailableQuantity,
                "projectId": row.projectId,
            }); 
            setQueryParams({...queryParams, 
                q: row?.categoryId, 
                productName: row?.machineryOrPrductName, 
                specification: row?.specification ?? "",
                item: row?.itemName ?? "",
                size: row?.size ?? ""
            })
            // setOpenEditModal(true);
    } 

    const materialFetchData = async() => {
        let searchParams = "";
        Object.entries(queryParams).forEach(([key, value]) => {
          searchParams += `&${key}=${value}`
        }) 
        const res = await handleGetData(`${material_url}/?page=1&limit=100&${searchParams}`) 
        return res;
    }

    const siteInventoryFetchData = async() => {
      let searchParams = "";
      Object.entries(queryParams).forEach(([key, value]) => {
        if(key === "item"){
          key = 'itemName'
        }
        searchParams += `&${key}=${value}`
      })  
      const res = await handleGetSiteInventory(`${site_inventory_url}/?page=1&limit=1000${searchParams}`) 
      return res;
    } 

    const handleClose = () => {
        setAnchorEl(null);
        setQueryParams({})
    };
 
    const handleSaveChanges = async(i, row) => { 
       if(title !== "Return Request"){  
        const obj = { 
          item: editedMaterial.item ?? '',
          specification: editedMaterial.specification ?? '',
          size: editedMaterial.size ?? '', 
          q: queryParams?.q,
          productName: queryParams?.productName
        }
        let searchParams = "";
        Object.entries(obj).forEach(([key, value]) => { 
          searchParams += `${key}=${value}&`
        }) 
        const result = await getRequestAPI(`${material_url}?page=1&limit=100&${searchParams}`) 
        if(result?.status === 200){
          const materialId = result.data?.items[0]?.id  
          const paylaodObj = {
                "id": editedMaterial?.id,
                "machineryOrPrductId":  materialId ,
                "machineryOrPrductName": editedMaterial?.machineryOrPrductName,
                "itemName": editedMaterial?.item ?? '',
                "specification": editedMaterial?.specification ?? '',
                "size": editedMaterial?.size ?? '',
                "unit": editedMaterial?.unit,
                "quantity": editedMaterial?.quantity,
                "remark": editedMaterial?.remark,
                "typeId": editedMaterial?.typeId,
                "categoryId": editedMaterial?.categoryId
          } 
          handleSave(i, paylaodObj)
          setQueryParams({})
          setEditedMaterial({})
        } 
        }else{
          const obj = { 
            item: editedMaterial.item ?? '',
            specification: editedMaterial.specification ?? '',
            size: editedMaterial.size ?? '', 
            q: queryParams?.q,
            productName: queryParams?.productName
          }
          let searchParams = "";
          Object.entries(obj).forEach(([key, value]) => { 
            searchParams += `${key}=${value}&`
          }) 
          const result = await getRequestAPI(`${site_inventory_url}?page=1&${searchParams}`) 
          if(result?.status === 200){
            const materialId = result.data?.items[0]?.siteInventoryMaterialId  
            const paylaodObj = {
              "id":editedMaterial?.id,
              "projectId": editedMaterial?.projectId,
              "materialId":materialId,
              "quantity": editedMaterial?.quantity,
              "remark": editedMaterial?.remark 
            }
            handleSave(i, paylaodObj)
            setQueryParams({})
            setEditedMaterial({})
          } 
        }
    }

    const endAdornment = (key:string) => {
        return editedMaterial?.[key] ? (
                <InputAdornment position="end"> 
                    <IconButton
                        size="small"
                        sx={{m:1}}
                        onClick={() => {
                            setEditedMaterial({ ...editedMaterial, [key]: '' });
                            setQueryParams({ ...queryParams, [key]:  '' });
                        }}
                    >
                        <ClearIcon fontSize='small'/>
                    </IconButton>
                </InputAdornment>
            ) : null
    }

    // const handleSelectChange = (e) => {
    //     let { name, value } = e.target; 
    //     setEditedMaterial({ ...editedMaterial, [name!]: value });
    //     if(value !== 'clear'){ 
    //       setQueryParams({...queryParams, [name!] : value })
    //     }else{
    //       setQueryParams({...queryParams, [name!] : '' })
    //     }
    // }

    React.useEffect(() => {
        if(requestType !== "Return Request"){
            materialFetchData()
        }else{
            siteInventoryFetchData()
        }
    }, [queryParams]) 
    
    React.useEffect(() => {  
    if (!!resData?.items?.length) {
        const specification = _.uniqBy(_.filter(resData?.items, p =>(( p?.specification !== '') &&  (p?.specification !== null))), 'specification');
        const size = _.uniqBy(_.filter(resData?.items, p => ((p.size !== '') && (p.size !== null))), 'size');
            const itemName = _.uniqBy(_.filter(resData?.items, p => ((p.itemName !== '') && (p?.itemName !== null))), 'itemName') 
            setSubItems(itemName) 
            setSpecificationArray(specification)
            setSizeItems(size) 
        }  
    }, [resData]) 

    React.useEffect(() => {
      if (!!resSiteInventory?.items?.length) {
        const specification = _.uniqBy(_.filter(resSiteInventory?.items, p =>(( p?.productSpecification !== '') &&  (p?.productSpecification !== null))), 'productSpecification');
        const size = _.uniqBy(_.filter(resSiteInventory?.items, p => ((p.productSize !== '') && (p.productSize !== null))), 'productSize');
        const itemName = _.uniqBy(_.filter(resSiteInventory?.items, p => ((p.itemName !== '') && (p?.itemName !== null))), 'itemName')    
        setSubItems(itemName) 
        setSpecificationArray(specification)
        setSizeItems(size) 
        }  
    }, [resSiteInventory]) 
     
  return (
    <> 
    <Typography variant='h6' component={"div"}>{title} Items</Typography>
      <RequestMaterialTable>
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell sx={{fontWeight: 'bold'}} width={'70px'}>S No.</TableCell>
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Name</TableCell>
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Type / Grade </TableCell>
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Specification</TableCell>
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Size</TableCell>
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Unit</TableCell>
                { requestType === "Return Request" && <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Available Qty.</TableCell>}
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}> {requestType === "Return Request" ? "Return Qty." : "Requested Qty."}</TableCell>
                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Remark</TableCell>
                {(isApproved === 'pending' && !isView?.includes("true")) &&
                  <TableCell sx={{fontWeight: 'bold'}} align="left" width={'70px'}>Action</TableCell>}
              </TableRow>
            </TableHead>
            <TableBody sx={{height: '100px', overflow: 'scroll'}}>
              {data && data?.map((row: any, i: number) => {
                return (
                  <TableRow key={`${row?.name-i}`} >
                    <TableCell>{i + 1}</TableCell>
                    <TableCell align="left">{row?.machineryOrPrductName}</TableCell>
  
                    <TableCell align="left">   
                      {
                        editingId === i ? (
                          <FormControl fullWidth sx={{width: 180 }}> 
                            <Select
                              defaultValue={editedMaterial?.item || row?.itemName || row?.subItem || ""} 
                              size='small'
                              name="item" 
                              disabled={!subItems?.length}
                              value={ editedMaterial?.item || row?.itemName || row?.subItem || ""} 
                              onChange={(e) => { 
                                let { value } = e.target; 
                                setEditedMaterial({ ...editedMaterial, item: value, specification: '', size: '' });
                                if(value !== 'clear'){ 
                                  setQueryParams({...queryParams, item : value })
                                }else{
                                  setQueryParams({...queryParams, item : '' })
                                }  
                              }} 
                              endAdornment={endAdornment('item')}
                            >  
                              { subItems?.map((option) => {
                                  return <MenuItem value={option?.itemName}>
                                            <em>{option?.itemName}</em>
                                          </MenuItem>
                              })}
                            </Select>
                          </FormControl>
                        ) :  
                        <>
                        {!!row?.subItem ? row?.subItem : !!row?.itemName ? row?.itemName : "_"} 
                        </>
                      }
                    </TableCell>

                    <TableCell align="left">
                      {
                        editingId === i ? (
                          <FormControl fullWidth sx={{width: 180 }}>  
                            <Select
                              defaultValue={editedMaterial?.specification || row?.specification || "" } 
                              size='small'
                              name="specification" 
                              disabled={!specificationArray?.length}
                              value={ editedMaterial?.specification || row?.specification || ""}
                              onChange={(e) => {  
                                let { value } = e.target; 
                                setEditedMaterial({ ...editedMaterial, specification: value, size: '' });
                                if(value !== 'clear'){ 
                                  setQueryParams({...queryParams, specification : value })
                                }else{
                                  setQueryParams({...queryParams, specification : '' })
                                } 
                              }} 
                              endAdornment={ endAdornment("specification") }
                            > 
                             { specificationArray?.map((option, i) => {
                              return <MenuItem key={i} value={option?.specification ?? option?.productSpecification }>
                                      <em>{option?.specification ?? option?.productSpecification }</em>
                                     </MenuItem>
                              })}
                            </Select>
                          </FormControl>
                        ) : 
                        <>
                         {!!row?.specification ? row?.specification  : "_"}
                        </>
                      }
                    </TableCell>
 
                    <TableCell align="left">
                      {editingId === i ? (
                          <FormControl fullWidth sx={{width: 180 }}> 
                            <Select
                              defaultValue={editedMaterial?.size || row?.size || "" } 
                              size='small'
                              name="size" 
                              disabled={!sizeItems?.length}
                              value={ editedMaterial?.size || row?.size || "" }
                              onChange={(e) => { 
                                let { value } = e.target; 
                                setEditedMaterial({ ...editedMaterial, size: value });
                                if(value !== 'clear'){ 
                                  setQueryParams({...queryParams, size : value })
                                }else{
                                  setQueryParams({...queryParams, size : '' })
                                } 
                              }}  
                              endAdornment={endAdornment("size")}
                            > 
                              { sizeItems?.map((option) => {
                                  return <MenuItem value={option?.size ?? option?.productSize }>
                                            <em>{option?.size ?? option?.productSize}</em>
                                          </MenuItem>
                              })}
                            </Select>
                          </FormControl>
                      ) : <>
                          {!!row?.size ? row?.size : "_"}
                          </>
                      } 
                    </TableCell>

                    <TableCell align="left" >{row?.unit}</TableCell>
                    {requestType === "Return Request" && <TableCell align="left" >{row?.siteAvailableQuantity ?? row?.availableQty}</TableCell>}
                    <TableCell align="left">
                      {editingId === i ? ( 
                        <TextField
                          size='small'
                          type='number' 
                          name='quantity'
                          sx={{ width: '100%', minWidth:'100px'}} 
                          value={editedValue?.quantity}
                          defaultValue={row?.quantity} 
                          onChange={(e) => handleChange(e, editedValue)}
                         />
                      ) : (
                        row?.quantity
                      )}
                    </TableCell>

                    <TableCell align="left">
                      {editingId === i ? (
                         <Textarea  
                            maxRows={3}
                            name='remark' 
                            sx={{ width: '100%', minWidth:'100px', resize: 'none'}} 
                            value={editedValue?.remark}
                            defaultValue={row?.remark} 
                            onChange={(e) => handleChange(e)}
                          /> 
                      ) : (
                        row?.remark
                      )}
                    </TableCell>

                    { (isApproved === 'pending' && !isView?.includes("true")) &&
                      <TableCell align="left" style={{
                        opacity: (isView?.includes("true")) ? '0.4' : '1',
                        pointerEvents: (isView?.includes("true")) ? 'none' : null,
                      }}>
                        <div style={{display:'flex'}}>
                          {editingId !== i ? (<>
                            {<Tooltip title={"Edit"}>
                              <IconButton disabled={isApproved !== 'pending'}> 
                                 <EditIcon onClick={() => handleOpenEditModal( i ,row)} color='success' /> 
                              </IconButton>
                            </Tooltip>}
                          </>
                          ) : (
                            <> 
                              <Tooltip title={"Save"}> 
                                <IconButton disabled={Number.isNaN(editedValue.quantity)}>
                                   <SaveIcon disabled={Number.isNaN(editedValue.quantity)} onClick={() => handleSaveChanges(i, row)} color='success' />
                                  {/* <SaveIcon onClick={() => handleSave(i, row)} color='success' /> */}
                                </IconButton>
                              </Tooltip>
                            </>
                          )} 
                          {//title !== 'Return Request' && 
                          <Tooltip title={"Delete"}>
                            <IconButton disabled={ isApproved !== 'pending'}>
                              <DeleteIcon id={i} onClick={(event:any) => handleClickDelete(event,row?.id)} color='error' />
                            </IconButton>
                          </Tooltip>}
                        </div>
                      </TableCell>}
                  </TableRow>)
              }
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {/* This Popup is use for Delete Material  */}
        <Tooltipmenu
          anchorEl={anchorEl}
          id="account-menu"
          open={open}
          onClose={handleClose}
          onClick={handleClose}
        >
          <WarningBox>
            <Tooltipwarningicon />
            <Message>Delete the Material</Message>
          </WarningBox>
          <Conformation>Are you sure to delete the material? </Conformation>
          <ConformationBox>
            <Cancelbutton variant="outlined">Cancel</Cancelbutton>
            <Okbutton variant="contained"
              onClick={() => {
                removeMaterial(materialData.index, materialData.materialId)
              }}>
              Ok
            </Okbutton>
          </ConformationBox>
        </Tooltipmenu> 
      </RequestMaterialTable>
    </>
  );
};

export default MaterialRequestTable; 