import React, {useEffect, useState} from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper, 
  Typography
} from '@mui/material';
import _ from 'lodash'; 
import dayjs, { Dayjs } from 'dayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import {formateDate} from 'src/utils/formatDate';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import { DateRangePicker } from '@mui/x-date-pickers-pro';
import { createTheme, ThemeProvider } from "@mui/material/styles";

const theme = createTheme({
  palette: {
    primary: {
      main: "#FF5B5B", // Red color for primary elements
    },
  },
  components: {
    MuiTextField: {
      styleOverrides: {
        root: {
          "& label": {
            color: "#FF5B5B", // Red color for labels
          },
          "& .MuiInputBase-input": {
            color: "#FF5B5B", // Red color for input text
          },
          "& .MuiOutlinedInput-root": {
            "& fieldset": {
              borderColor: "#FF5B5B", // Red border color
            },
            "&:hover fieldset": {
              borderColor: "#FF5B5B",
            },
            "&.Mui-focused fieldset": {
              borderColor: "#FF5B5B",
            },
          },
        },
      },
    },
  },
});
 
const getWeekDates = (startOfWeek: Dayjs): Dayjs[] => {
  const weekDates:any = [];
   for (let i = 0; i < 7; i++) { 
     weekDates.push(startOfWeek.add(i, 'day'));
   }
  return weekDates;
 };

function getDatesInCurrentMonth(date:any) { 
  const dates = [];
  const today = date?.$d; //new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-indexed (0 = January, 1 = February, ...) 
  // Get the last date of the current month
  const lastDate = new Date(year, month + 1, 0).getDate(); 
  // Populate the array with dates
  for (let day = 1; day <= lastDate; day++) {
      dates.push(new Date(year, month, day));
  }  
  return dates;
}
 
function getAllMonthOfYear(month:any){ 
  const months = []; 
  for (let i = 0; i < 12; i++) {
    const allMonth = new Date(month?.$y, i).toLocaleString('default', { month: 'long' });
    months.push(allMonth);
  } 
  return months;
}

 interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}
 
function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ py: 3 }}>{children}</Box>}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function ProgressReport({data, handleFilter, filterByMonth, filterByYear}:any) { 
  const [value, setValue] = React.useState<Dayjs | null>(dayjs());
  const [yearValue, setYearValue] = React.useState<Dayjs | null>(dayjs());
  const [tabValue, setTabValue] = React.useState(0);
  const weekStart = value ? value.startOf('week') : dayjs().startOf('week');
  const weekDates = getWeekDates(weekStart);
  const allDateOfMonth = getDatesInCurrentMonth(value);
  const monthOfYear = getAllMonthOfYear(yearValue) 
  const [ propsData, setPropsData ] = useState<any>({})  
  const [dateRange ,setDateRange] = useState<any>({startDate: dayjs().startOf('week'), endDate: dayjs().endOf('week')}) 
  const [weekDateRange, setWeekDateRange] = useState<any>([])

  function getDatesBetweenRange(startDate:any, endDate:any) {
    const dates = [];
    let currentDate = new Date(startDate); 
    while (currentDate <= new Date(endDate)) {
      dates.push(new Date(currentDate)); // Add the current date
      currentDate.setDate(currentDate.getDate() + 1); // Move to the next day
    }  
    setWeekDateRange(dates) 
  }
 
  const convertedDates = weekDates?.map((dateString:any) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() 
  });

  const convertedDatesRange = weekDateRange?.map((dateString:any) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() 
  });
 
  const convertedDatesOfMonth = allDateOfMonth?.map((dateString:any) => {
    const date = new Date(dateString);
    return date.toLocaleDateString() 
  })

  useEffect(() => {
    setPropsData(data)
  },[data])
 
  const renderSection = (title:any, rows:any) => {    
    let groupedData:any, transformedData:any;
    const groupReceivedMaterialData = (data:any) => {
        return data.reduce((acc, curr) => { 
            const date = new Date(curr?.createdDate).toLocaleDateString()  // dayjs(curr.createdDate).format('YYYY/MM/DD'); //new Date(curr?.createdDate)?.toISOString()?.split('T')[0];  
            if (!acc[date]) {
                acc[date] = [];
            }
            acc[date].push(curr); 
            return acc;
        },{});
    };

    const transformData = (data:any) => {
      const transformed:any = {}; 
      Object?.keys(data)?.forEach(date => {
        data[date]?.forEach(item => {
          const key = item?.verify_material_material_id; //`${item.materialDetails_name}-${item.materialDetails_Specification}`; 
          if (!transformed[key]) {
            transformed[key] = { ...item, quantities: {} };
          }
          transformed[key].quantities[date] = item?.total;
        });
      }); 
      return transformed;
    };
    
    if(title === 'Received Stock'){
      groupedData = groupReceivedMaterialData(rows)   
      transformedData = transformData(groupedData); 
    }  
    
    return( 
       <>
          <TableRow sx={{ backgroundColor: '#fff', color: '#fff', fontWeight: 'bold' }}>
            <TableCell colSpan={ tabValue === 0 ? 11 : 35 } sx={{ color: '#333' , fontSize: '15px', fontWeight: 'bold'}}>{title}</TableCell>
          </TableRow>  
          { (title === 'Received Stock') && 
                   !!Object?.keys(transformedData)?.length && Object?.keys(transformedData)?.map(key => {
                    const item = transformedData[key];
                    const totalQty = Object.values(item?.quantities).reduce((sum, qty) => sum + parseInt(qty), 0); 
                    return (
                      <TableRow key={key}>
                        <TableCell>{`${item?.materialDetails_name} ${item?.materialDetails_item_name ? '-' + item?.materialDetails_item_name : ''} ${item?.materialDetails_Specification} ${item.materialDetails_size ? '-' + item?.materialDetails_size : ''} (${item?.materialDetails_unit})`}</TableCell>
                          {tabValue === 0 && 
                              convertedDates?.map(d => {                                  
                                return(
                                  <TableCell key={d}> 
                                    {item?.quantities[d] || '-'} 
                                  </TableCell>
                                )
                          })} 
                          {tabValue === 1 && 
                              convertedDatesOfMonth?.map(d => {                                  
                                return(
                                  <TableCell key={d}> 
                                    {item?.quantities[d] || '-'}  
                                  </TableCell>
                                )
                          })} 
                          {tabValue === 2 && monthOfYear?.map(month => { 
                            const getDate = new Date(Object.keys(item?.quantities).join(''));  
                            const monthString = monthOfYear[getDate.getMonth()]   
                            return (
                              <TableCell> 
                                {monthString === month ? item?.quantities[Object.keys(item?.quantities).join('')] : '-'}
                              </TableCell>
                            )
                          })} 
                           {tabValue === 3 && 
                              convertedDatesRange?.map(d => {                                  
                                return(
                                  <TableCell key={d}> 
                                    {item?.quantities[d] || '-'} 
                                  </TableCell>
                                )
                          })} 
                        <TableCell>{'-'}</TableCell>
                        <TableCell>{totalQty}</TableCell>
                      </TableRow>
                    );
                  }) 
          } 
       
           { rows?.length ?  
              rows?.map((item:any, index:any) => { 
                if (title !== 'Received Stock') { 
                  const itemName = !!item?.materialDetails?.subItem ? `-${item?.materialDetails?.subItem}` : !!item?.materialDetails?.itemName ? `-${item?.materialDetails?.itemName}` : "" ;
                  const specification = item?.materialDetails?.specification !== undefined ? `-${item?.materialDetails?.specification}` : "";
                  const size = item?.materialDetails?.size !== undefined ? `-${item?.materialDetails?.size}` : "";
                  const unit = item?.materialDetails?.unit;
                  const materialFullName= `${item?.materialDetails?.productName} ${itemName}${specification}${size}(${unit})`
                  const name = item?.materialDetails?.productName !== undefined ? materialFullName : item?.nameOrId;
          
                  const qtyByMonth =  item?.dailyQuantities?.reduce((acc, curr) => {
                    const currMonth = new Date(curr?.date).toLocaleString('default', { month: 'long' })   
                    acc[currMonth] = (acc[currMonth] || 0) + curr?.qty; // Sum quantities for the same date
                    return acc;
                  }, {});
              
                  // Create a mapping of quantities by date
                  const qtyByDate = item?.dailyQuantities?.reduce((acc, curr) => { 
                      const currDate = new Date(curr?.date).toLocaleDateString() 
                      acc[currDate] = (acc[currDate] || 0) + curr?.qty; // Sum quantities for the same date
                      return acc;
                  }, {}); 
      
                  const remarkByDate = item?.dailyQuantities?.reduce((acc, curr) => { 
                  const currDate = new Date(curr?.date).toLocaleDateString() 
                  acc[currDate] = curr.remark; //(acc[currDate] || 0) + curr.qty; // Sum quantities for the same date
                  return acc;
              }, {})
      
                  // Create a result array with matched quantities
                  const result = convertedDates.map(date => {  
                      return { date, qty: qtyByDate[date] || '-', remark : remarkByDate[date] || '-' }; // Default to 0 if no match
                  });
                  
                  const resultOfMonth = convertedDatesOfMonth.map(date => {
                    return {date, qty: qtyByDate[date] || '-' }
                  })
      
                  const resultOfYear = monthOfYear.map(month => { 
                    return {month, qty: qtyByMonth[month] || '-' }
                  }) 

                  const resultOfDateRange = convertedDatesRange?.map(date => {  
                    return { date, qty: qtyByDate[date] || '-', remark : remarkByDate[date] || '-' }; // Default to 0 if no match
                   }); 
                  
                  return( 
                    <> 
                    <TableRow key={item?.id} sx={{backgroundColor: '#fff'}}>
                        <TableCell sx={{ color: '#333', borderBottom: '1px solid #5555551a' }}>  {name}</TableCell>  
                        { tabValue === 0 &&  result?.map((value:any, i:any) => { 
                          return (
                            <TableCell sx={{ color: '#333' , fontSize: '12px',   borderBottom: '1px solid #5555551a' }}> 
                                {value?.qty} 
                            </TableCell> 
                          )
                        })} 
                        {
                          tabValue === 1 &&  
                          resultOfMonth?.map((value:any, i:any) => { 
                            return (
                              <TableCell sx={{ color: '#333' , fontSize: '12px',  borderBottom: '1px solid #5555551a' }}> 
                                {value?.qty} 
                              </TableCell> 
                            )
                          })
                        } 
                        {
                          tabValue === 2 &&  
                          resultOfYear?.map((value:any, i:any) => { 
                            return (
                              <TableCell sx={{ color: '#333' , fontSize: '12px',  borderBottom: '1px solid #5555551a' }}> 
                                {value?.qty}  
                              </TableCell> 
                            )
                          })
                        }

                        { tabValue === 3 && resultOfDateRange?.map((value:any, i:any) => { 
                          return (
                            <TableCell sx={{ color: '#333', fontSize: '12px',borderBottom: '1px solid #5555551a' }}> 
                                {value?.qty} 
                            </TableCell> 
                          )
                        })} 
                        <TableCell sx={{ color: '#333' , fontSize: '12px',  borderBottom: '1px solid #5555551a' }}> 
                          { title === "Material" ? item.availableQty : "_"}
                        </TableCell> 
                    
                        <TableCell sx={{ color: '#333' , fontSize: '12px',  borderBottom: '1px solid #5555551a' }}> 
                          { item.totalQty}
                        </TableCell>  
                      </TableRow>   
                    </>
                  ) 
                }
              })
              : 
              <>
                  <TableRow>
                    <TableCell colSpan={ tabValue === 0 ? 10 : 34 }>
                    <Typography sx={{ px:'10px', textAlign: 'center'}} variant='subtitle1'>
                        No Data Available
                    </Typography>
                    </TableCell> 
                  </TableRow>
              </>
           }    
           
       </>
  )}; 
 
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  function getStartOfWeek(date) {
    const currentDate = new Date(date);
    const dayOfWeek = currentDate.getDay(); // 0 (Sunday) to 6 (Saturday)
    const startOfWeek = new Date(currentDate); 
    startOfWeek.setDate(currentDate.getDate() - dayOfWeek);
    // Reset the time to 00:00:00 for consistency
    startOfWeek.setHours(0, 0, 0, 0); 
    return startOfWeek;
  }

  function getEndOfWeek(date) {
    const startOfWeek = getStartOfWeek(date);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999); // Set time to the end of the day
    return endOfWeek;
  }

   const currentDate = new Date();
   const startOfWeek = getStartOfWeek(new Date());
   const endOfWeek = getEndOfWeek(new Date());
   const curentMonth = currentDate.getMonth() + 1;
   const curentYear = currentDate.getFullYear()
 
  useEffect(() => {
    if(tabValue === 0){ 
      const weekStart = value ? startOfWeek : dayjs().startOf('week');
      const weekEnd = value ? endOfWeek : dayjs().endOf('week'); 
      setValue(dayjs())
      handleFilter(formateDate(weekStart), formateDate(weekEnd))
    }
    if(tabValue === 1){ 
      setValue(dayjs())
      filterByMonth(curentMonth)  
    }
    if(tabValue === 2){
      filterByYear(curentYear) 
    } 
    if(tabValue === 3){
      const weekStart = dateRange?.startDate ? startOfWeek : dayjs().startOf('week');
      const weekEnd = dateRange ? endOfWeek : dayjs().endOf('week'); 
      setDateRange({startDate: weekStart, endDate: weekEnd})
      handleFilter(formateDate(weekStart), formateDate(weekEnd)) 
      getDatesBetweenRange(dateRange?.startDate ,dateRange?.endDate)
    }
  },[tabValue])

  useEffect(() => {
    getDatesBetweenRange(dateRange.startDate, dateRange?.endDate) 
  }, [dateRange])  
  
  return (
    <>  
    <ThemeProvider theme={theme}> 
    <Box sx={{ width: '100%' }}> 
     <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
      <Tabs 
          sx={{
              "& .MuiTabs-indicator": {
              backgroundColor: "#fe2f15", // Customize indicator color
              },
              "& .MuiTab-root": {
              color: "gray", // Default tab text color
              },
              "& .Mui-selected": {
              color: "#fe2f15", // Highlighted tab text color
              },
          }} 
         value={tabValue}  onChange={handleChange} aria-label="basic tabs example">
        <Tab label="Weekly" {...a11yProps(0)} />
        <Tab label="Monthly" {...a11yProps(1)} /> 
        <Tab label="Yearly" {...a11yProps(2)} /> 
        <Tab label="Custom" {...a11yProps(3)} />
      </Tabs>
    </Box>
     {/* filter by week */}
    <CustomTabPanel value={tabValue} index={0}>
      <div style={{display:'flex', alignItems: 'center'}}> 
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DemoContainer components={['DatePicker']}> 
              <DatePicker 
                sx={{  overflow: 'hidden'}}
                slotProps={{ textField: { size: 'small' } }}
                onChange={(newValue:any) => {                   
                  const weekStart = newValue ? newValue.startOf('week') : dayjs().startOf('week');
                  const weekEnd = newValue ? newValue.endOf('week') : dayjs().endOf('week');  
                  setValue(newValue) 
                  handleFilter(formateDate(weekStart), formateDate(weekEnd))
              }}  
              />
          </DemoContainer>
        </LocalizationProvider>  
      </div>
    </CustomTabPanel>
   
    {/* filter based on month */}
    <CustomTabPanel value={tabValue} index={1}>
      <div style={{display:'flex', alignItems: 'center'}}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DatePicker 
            slotProps={{ textField: { size: 'small' } }}
            views={['month', 'year']}
            value={value}
            onChange={(newValue) => { 
              setValue(newValue); 
              filterByMonth(newValue?.format('MM')) 
            }} 
          />
        </LocalizationProvider> 
      </div>
    </CustomTabPanel>

    {/* filter based on year */}
    <CustomTabPanel value={tabValue} index={2}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker 
          slotProps={{ textField: { size: 'small' } }}
          views={['year']}
          value={value}
          onChange={(newValue) => {  
            setYearValue(newValue);              
            filterByYear(newValue?.format('YYYY')) 
          }} 
        />
      </LocalizationProvider>
    </CustomTabPanel> 

    {/* filter based on date rang */}
    <CustomTabPanel value={tabValue} index={3}>
      <div style={{display:'flex', alignItems: 'center'}}>  
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <DemoContainer components={['DateRangePicker']}>
            <DateRangePicker 
                onChange={(newValue : any) => { 
                    const weekStart = newValue?.[0]?.$d;  
                    const weekEnd = newValue?.[1]?.$d;  
                    setDateRange({startDate: weekStart, endDate: weekEnd});
                    handleFilter(formateDate(weekStart), formateDate(weekEnd)) 
                }}
                slotProps={{ textField: { size: 'small' } }} 
                localeText={{ start: 'Start Date', end: 'End Date' }} />
          </DemoContainer>
        </LocalizationProvider>  
      </div>
     </CustomTabPanel>
    </Box>
    </ThemeProvider>

    <TableContainer sx={{overflowX: 'scroll', height: 'auto'}} component={Paper}>
      <Table>

        <TableHead sx={{ backgroundColor: '#e3dddd', position: 'sticky', top: 0}}>
          <TableRow>
            <TableCell sx={{ fontWeight: 'bold', color: '#333', borderBottom: '1px solid #5555551a' }}>Description</TableCell> 
              {tabValue === 0 && weekDates?.map((date:any, index) => { 
                 return (
                  <>
                    <TableCell sx={{ fontWeight: 'bold', color: '#333', borderBottom: '1px solid #5555551a' }}>{date?.format('DD MMM')}</TableCell>
                  </>
                 ) 
              })}  

              { tabValue === 1 && allDateOfMonth?.map((value:any, i:any) => { 
                const date = new Date(value);
                const options = {  month: 'short', day: '2-digit',};
                const formattedDate = date.toLocaleString('en-US', options).replace(',', '');
                      return (
                        <TableCell sx={{fontWeight: 'bold', color: '#333', width: '20px', borderBottom: '1px solid #5555551a' }}>  
                            {formattedDate} 
                        </TableCell> 
                      )
              })}

              {tabValue === 2 && monthOfYear?.map((month) => {
                return (
                  <TableCell sx={{fontWeight: 'bold', color: '#333', width: '20px', borderBottom: '1px solid #5555551a' }}>  
                      {month} 
                  </TableCell> 
                )
              })} 

              {tabValue === 3 && weekDateRange?.map((date:any, index:number) => { 
                const newDate = new Date(date);  
                const options = { day: '2-digit', month: 'short' };
                const formattedDate = newDate.toLocaleDateString('en-US', options);
                return <TableCell key={index} sx={{ fontWeight: 'bold', color: '#333', borderBottom: '1px solid #5555551a' }}>{formattedDate}</TableCell>   
              })}  
            <TableCell sx={{fontWeight: 'bold', color: '#333', borderBottom: '1px solid #5555551a' }}>Available qty</TableCell>
            <TableCell sx={{fontWeight: 'bold', color: '#333', borderBottom: '1px solid #5555551a' }}>Total qty</TableCell> 
          </TableRow>  
        </TableHead>

        <TableBody>
            {((!propsData?.Labour?.length) && (!propsData?.Machinery?.length) && (!propsData?.Material?.length) && (!propsData?.receivedMaterial)) ? <>
              <TableRow>
                <TableCell colSpan={ tabValue === 0 ? 10 : 34 }>
                <Typography sx={{ px:'10px', textAlign: 'center'}} variant='subtitle1'>
                   No Data Available
                </Typography>
                </TableCell> 
              </TableRow>
            </> : 
              <>  
                {renderSection('Labour', propsData?.Labour)}
                {renderSection('Contractor', propsData?.Contractor)}
                {renderSection('Machinery', propsData?.Machinery)}
                {renderSection('Material', propsData?.Material)} 
                {renderSection('Received Stock', propsData?.receivedMaterial)} 
              </>  
          } 
        </TableBody>
        
      </Table>
    </TableContainer>
    </>
  );
}  