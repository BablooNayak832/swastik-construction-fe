import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer'; 
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper'; 
import TableHead from '@mui/material/TableHead'; 
import useGet from '../../hooks/useGet';
import {useSelector} from 'react-redux';
import _ from 'lodash'; 
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import {formateDate} from '../../utils/formatDate';
import {Button, FormControl, InputLabel, ListItemText, MenuItem, Select, TextField, Typography} from '@mui/material';
import {DPRDateFilterLayout, FilterButtonBox} from '../../common/styles/Dashboard/styles';
import {useRouter} from 'next/navigation';
import useDownloadExcel from "../../hooks/downloadExcel";
import {projects_url} from '../../constants/api-routes';
import {MenuProps} from 'src/constants/table-columns';
import {useSession} from 'next-auth/react';
import dayjs from 'dayjs';

const data = [
  { 
    section: 'Labour', 
    rows: []
  },
  { 
    section: 'Contractor', 
    rows: []
  },
  { 
    section: 'Machinery', 
    rows: []
  },
  { 
    section: 'Material', 
    rows: []
  } 
]

const DailyProgressReportTable = () => { 
      const router = useRouter()
      let projectArray:any = []
      const currentDate:any = new Date()
      const previousDate = currentDate.setDate(currentDate.getDate() - 1) 
      const convertToLocalDate = formateDate(new Date(previousDate).toLocaleDateString())
      const { data: session }:any = useSession()
      const {resData, handleGetData}:any = useGet()
      const selectedProject = useSelector((state: any) => state?.selectedProject);
      const [selectedDate, setSelectedDate] = React.useState(dayjs().subtract(1, 'day'));
      const [filterConsumeQty, setFilterConsumeQty] = React.useState<any>({
        date: convertToLocalDate
      })
      const [dprData, setDprData] = React.useState(data);
      const { handleDownloadData } = useDownloadExcel() 
      const [selectedFilterProject, setSelectedFilterProject] = React.useState<any>('')
      const [selectedProjectItems, setSelectedProjectItems] = React.useState<any>(null)
      const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet() 
      const [projectId , setProjectId] = React.useState(null)
      const project = projectId !== null ? projectId : selectedProject?.selectedValue?.id; 
      // get dpr data based on specifi date 
      const getDPRData = async () => {
        let searchParam = '';
        Object.entries(filterConsumeQty).forEach(([key, value]) => {
          searchParam += `${key}=${value}&`;
        }); 
        const url = `/dpr?projectId=${project}&${searchParam}`;
        await handleGetData(url);
      };
     
      const defaultDateGet = () => { 
        const defaultDate = dayjs().subtract(1, 'day');
        setSelectedDate(defaultDate); 
        setFilterConsumeQty(() => {
           return { ['date'] : convertToLocalDate } 
         }) 
      }
  
      const getProjectData = async () => {
        const res = await handleGetProjectData(`${projects_url}?/page=1&limit=1000`);
        return res;
      }

      const handleDownloadExcel = () => {
        let searchParams = "";
        Object.entries(filterConsumeQty)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `dpr/?type=xls${searchParams}`
        const res = handleDownloadData(url, "DPR")
        return res;
      }

      const filterByProject = (param:any) => { 
        setProjectId(param) 
      }

      resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
        return projectArray.push({ id: Item?.id, name: Item?.projectName })
      });

      React.useEffect(() => {  
        getProjectData() 
      }, [])
 
      React.useEffect(() => {
        defaultDateGet()
      },[selectedProject?.selectedValue?.id])

      React.useEffect(() => { 
        getDPRData(); 
      }, [filterConsumeQty, selectedProject?.selectedValue?.id, projectId]); 
      
      React.useEffect(() => {  
        if (resData) { 
          const groupedLabour = _.groupBy(resData?.Labour, 'nameOrId');
          const groupedContractor = _.groupBy(resData?.Contractor, 'nameOrId');
          const groupedMachine = _.groupBy(resData?.Machinery, 'nameOrId');
          const groupedMaterial = _.groupBy(resData?.Material, 'nameOrId');
      
          const resultOfLabour = _.map(groupedLabour, (items, key) => { 
             return({
              description: key,
              consumptionOfQuantity: _.sumBy(items, 'consumptionOfQuantity'), 
              remark: _.join(items?.map(item => item?.remark) , ',')
            })
          });

          const resultOfContractor = _.map(groupedContractor, (items, key) => { 
            return({
             description: key,
             consumptionOfQuantity: _.sumBy(items, 'consumptionOfQuantity'), 
             remark: _.join(items?.map(item => item?.remark) , ',')
           })
         });
    
          const resultOfMachine = _.map(groupedMachine, (items, key) => ({
            description: key,
            consumptionOfQuantity: _.sumBy(items, 'consumptionOfQuantity'),
            remark: _.join(items?.map(item => item?.remark) , ',')
          }));
    
          const resultOfMaterial = _.map(groupedMaterial, (items) => {
            const materialDetails = _.map(items, (item) => _.get(item, 'materialDetails'));
            const availableQuantities = _.map(items, (item) => _.get(item, 'materialDetails.siteInventory.availableQuantity'));
            const materialName = _.map(materialDetails, (item) => {
              let specification = item?.specification ? `-${item.specification}` : '';
              let itemName = item?.itemName ? `-${item.itemName}` : '';
              let size = item?.size ? `-${item.size}` : '';
              return `${item?.productName}${itemName}${specification}${size}`;
            });
            const uniqMaterial = _.uniq(materialName);
            const result = _.join(uniqMaterial, ','); 
    
            return {
              description: result,
              consumptionOfQuantity: _.sumBy(items, 'consumptionOfQuantity'),
              availableQuantity: _.sum(availableQuantities),
              remark: _.join(items?.map(item => item?.remark) , ',')
            };
          }); 
 
          setDprData((prevRows) =>
            prevRows.map((section:any) =>
              section.section === 'Labour'
                ? { ...section, rows: resultOfLabour }
                :  section.section === 'Contractor'
                ? { ...section, rows: resultOfContractor } 
                : section.section === 'Machinery'
                ? { ...section, rows: resultOfMachine }
                : section.section === 'Material'
                ? { ...section, rows: resultOfMaterial } 
                : section
            )
          );
        }  
      }, [resData])
  
      React.useEffect(() => { 
        setSelectedFilterProject(projectArray[0]?.id)
        setSelectedProjectItems(projectArray) 
        defaultDateGet()
      }, [resProjectData?.items])
      
      const renderTable = (rows:any) => { 
        return (
          <>
          { !!rows?.length ? rows?.map((row:any, index:number) => {
              return (
                <TableRow key={index}>
                  <TableCell>{index+1}</TableCell>
                  <TableCell>{row?.description}</TableCell>
                  <TableCell>{row?.unit}</TableCell>
                  <TableCell>{!!row?.consumptionOfQuantity ? row?.consumptionOfQuantity : '_'}</TableCell>
                  <TableCell>{!!row?.availableQuantity ? row?.availableQuantity: "_"}</TableCell> 
                  <TableCell width={'25%'}>{!!row?.remark ? row?.remark: "_"}</TableCell> 
                </TableRow>
              )
            }) : 
            <TableRow>
              <TableCell sx={{textAlign: 'center'}} colSpan={6}>No Data Available</TableCell>
            </TableRow>
            }
          </>
        )
       } 

  return (
    <>
    <DPRDateFilterLayout> 
    { ( [0, 1]?.includes(session?.user?.role_id)) && <> 
    <FilterButtonBox>
      <FormControl sx={{width:"200px",borderRadius: '12px',height:"42px",border:"1px solid #66666636"}}>
      <InputLabel  id="demo-simple-select-label">
        Select Project 
      </InputLabel>
        <Select  
          id="demo-simple-select"
          label="Select Project"
          sx={{ 
            '.MuiOutlinedInput-notchedOutline':{
             border: 'none !important',
            },
            '.MuiSelect-outlined':{
              lineHeight: '10px',
              color: 'grey', 
              },
            '.MuiSelect-icon':{
              top:'8px'
            }
          }} 
          value={selectedFilterProject}    
          onChange={(event: any) => { 
            const { target: { value }} = event;  
            setSelectedFilterProject( value )
            filterByProject(value)    
          }}  
          renderValue={(selected: any[]) => { 
          return selectedProjectItems?.filter(item => selected == item?.id)?.map(item => item?.name)?.join(','); 
          }}
          MenuProps={MenuProps}
          > 
          { selectedProjectItems?.map((item: any) => { 
          return (
            <MenuItem key={item?.id} value={item?.id}> 
              <ListItemText primary={item?.name} />
            </MenuItem>
          );
          })}
        </Select>  
      </FormControl> 
    </FilterButtonBox>
      </> }

     <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer sx={{ float: 'right', height: '55px', boxSizing: 'border-box' }} components={['DatePicker']}>
        <DatePicker 
          sx={{ overflow: 'hidden' }}
          value={selectedDate}
          onChange={(date) => {
            const formatedDate = formateDate(date);
            setFilterConsumeQty((preValue:any) => {
              return { ...preValue, ['date']: formatedDate };
            });
            setSelectedDate(date);
          }}
          slotProps={{ textField: { size: 'small' } }}
          renderInput={(params:any) => <TextField {...params} value={selectedDate ? formateDate(selectedDate) : ''} />}
        />
      </DemoContainer>
      <Button variant="contained" sx={{ mx: '2px' }} onClick={() => defaultDateGet()} size="small">
        Reset
      </Button>
    </LocalizationProvider> 

      <Button disabled={dprData?.every(item=> item.rows?.length === 0)} variant='contained' style={{mx: '2px', color: 'white'}} onClick={() => handleDownloadExcel()} size='small'>Download Excel</Button> 
      { [2, 4, 5].includes(session?.user?.role_id) && 
      <Button disabled={dprData?.every(item=> item.rows?.length === 0)} variant='contained' style={{margin: '2px 0', color: 'white'}} onClick={() => router.replace(`/dpr-management/update-dpr/${filterConsumeQty?.date}`)} size='small'>Update DPR</Button>  
      }
      {[2, 4, 5].includes(session?.user?.role_id) && 
       <Button  
          variant="contained"
          onClick={() => router.push(`/dpr-management/report-dpr`)}  
          style={{margin: '2px 0', color: 'white'}} 
          size='small'>
          + DPR
      </Button>}
    </DPRDateFilterLayout>
    
    <TableContainer component={Paper}> 
      <Table sx={{ minWidth: 500 }} aria-label="custom pagination table">
        <TableHead>
          <TableRow>
            <TableCell>S No</TableCell>
            <TableCell>Description</TableCell>
            <TableCell>Unit</TableCell> 
            <TableCell>Consumed Qty</TableCell>
            <TableCell>Available Qty</TableCell>   
            <TableCell>Remark</TableCell>   
          </TableRow>
        </TableHead>
        <TableBody>  
          {dprData?.every(item=> item.rows?.length === 0) ?
            <TableCell sx={{textAlign: 'center'}} colSpan={6}>
              <Typography sx={{alignContent:'center'}} variant='body1'>
                No Data Available
              </Typography>
            </TableCell> 
          :
          (dprData?.map((section) => {  
           return( 
            <>
              <TableRow key={section?.section}>
                <TableCell colSpan={12} style={{ fontWeight: 'bold' }}>{section?.section}</TableCell>
              </TableRow>  
              {renderTable(section?.rows)} 
            </>
            )
          }))}
        </TableBody> 
      </Table> 
    </TableContainer>
    </>
  );
}

export default DailyProgressReportTable;
 