'use client';
import React, { ChangeEvent, useEffect, useState } from 'react';
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow, 
  TableCell,
  IconButton,
  FormControlLabel,
  Menu,
  Switch,
  Tooltip, 
  Select,
  MenuItem, 
  ListItemText,
  InputLabel,
  FormControl,
  Badge,
  AppBar,
  Toolbar,
  Dialog,
  Typography,
  DialogActions,
  DialogContent, 
} from '@mui/material';
import TablePagination from '@mui/material/TablePagination';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import UpdateModal from '../UpdateModal/UpdateModal';
import CircularProgress from '@mui/material/CircularProgress';
import editIcon from '../../../assets/img/editIcon.png';
import PopoverComponent from '../../components/Popover/index'
import {
  ContainerMain,
  SearchFilterLayout,
  Searchicon,
  MainBox,
  TableCategoryImageBox,
  StaffImageBox,
  FilterButtonBox,
  FilterTextBox,
  FilterTextLayout,
  AttendanceContainer,
} from '../../common/styles/Dashboard/styles';
import CustomTooltip from '../Tooltip/Tooltip';
import { TableColumn } from '../../Interfaces/Tableinterface';
import {
  Cell,
  Permission,
  PermissonBox,
  EyeIcon,
  Blankbox,
} from '../../components/Table/styles';
import CommonAvatarGroup from '../avatar-group/AvatarGroup';
import { headers, MenuProps } from '../../constants/table-columns';
import { useAllowedNavigation } from '../../context/context';
import { usePathname, useRouter } from 'next/navigation';
import {
  Button,
} from '@mui/material';
import Image from 'next/image';
import Visibility from '@mui/icons-material/Visibility';
import LinearProgress from '@mui/joy/LinearProgress'; 
import ListItemComponent from '../ListItem/page';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { TreeView } from '@mui/x-tree-view/TreeView';
import RequestVerificationForm from '../common-form/RequestVerification'
import { TreeItem } from '@mui/x-tree-view/TreeItem';
import { useSession } from 'next-auth/react';
import { useDispatch, useSelector } from 'react-redux';
import { setOpenPopover } from 'src/redux/features/openPopoverSlice';
import { setOpenModal } from 'src/redux/features/openModalSlice';
import CommonUpdateModal from '../CommonDialog/CommonUpdateModal';
import AttendanceFilter from '../AttendanceManagement/FilterAttendance/index';
import ImageIcon from '@mui/icons-material/Image';
import CommonImageViewDialog from '../CommonDialog/CommonImageViewDialog';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import SiteInventoryInfoDialog from '../CommonDialog/SiteInventoryInfoDialog'
import VerifyVendor from '../VendorManagement/VerifyVendor' 
import BillIcons from '../../../assets/svg/BillIcon'; 
import MinMaxDateRangePicker from '../../components/Highcharts/dateSelector'; 
import {DatePickerLineBox} from 'src/common/styles/HighChartsLayout/styles';
import AutocompleteComponent from '../AutoComplete';
import TuneIcon from '@mui/icons-material/Tune';
import {theme} from 'src/common/styles/theme';
import ClearIcon from '@mui/icons-material/Clear';
import { formatString } from '../../utils/formatString'; 
import Link from 'next/link';
import {baseImgUrl} from 'src/constants/api-routes';

type TableType = {
  isVisible?: boolean;
  isLoading?: boolean;
  columns: TableColumn[]; // Replace 'any' with a specific type for columns
  rows: any; //use any because row is getting different from parent component
  rowsPerPage?: number;
  page?: number;
  handleChangePage?: (
    event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => void;
  handleChangeRowsPerPage?: (event: ChangeEvent<HTMLInputElement>) => void;
  refreshTableData: (data: any) => void; //use any because row is getting different from parent component
  handleOpenDialogBox?: (id: number) => void;
  handleUpdateProps?: (
    e: React.MouseEvent<HTMLButtonElement>,
    payload: any
  ) => void;
  handleRemoveRow?: (data: any) => void; //use any because data is getting different from parent component
  url?: string;
  title?: string;
  editData?: any; //use any because data is getting different from parent component
  selectItems?: any; //use any because data is getting different from parent component 
  filterMenuOption?: any[];
  handleAvailableQuantity?: any;
  searchTableData?: any;
  handleApproveProject?: any
  handleExcelExport?: any;
  catItems?: any;
  roleItems?: any[];
  projectItems?: any[];
  getUserByRole?: any[];
  filterOnAttendance?: (data: any, type: any) => void;
  applyFilter?: any;
  items?: any[];
  filterOnProject?:any;
  resetFilter?:() => void;
  filterByCategory?: any;
  filterByProject?:any;
  selectedDateRange?:any;
  categorySelected?:any;
  setCategorySelected?:any;
  selectedFilterProject?:any; 
  setSelectedFilterProject?:any;
  totalItems?:any; 
};

const TableMain = ({
  isVisible,
  isLoading,
  columns,
  rows,
  rowsPerPage,
  page,
  handleChangePage,
  handleChangeRowsPerPage,
  refreshTableData,
  handleOpenDialogBox,
  handleUpdateProps,
  handleRemoveRow,
  url,
  catItems,
  selectItems,
  filterMenuOption,
  title,
  searchTableData,
  handleApproveProject,
  handleExcelExport,
  projectItems,
  filterOnAttendance,
  getUserByRole,
  applyFilter,
  items,
  filterOnProject,
  resetFilter,
  filterByCategory,
  filterByProject,
  selectedDateRange,
  categorySelected,
  setCategorySelected,
  selectedFilterProject, 
  setSelectedFilterProject,
  totalItems, 
}: TableType) => {  
  
  const { data: session }:any = useSession()
  const router = useRouter()
  const pathname = usePathname();
  const [searchInput, setSearchInput] = useState<string>('');
  const [filteredResults, setFilteredResults] = useState<any>([]);
  const [columnsData, setColumnsData] = useState<any>(columns); 
  const { setOpenEndModal } = useAllowedNavigation();
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [updateRowData, setUpdateRowDAta] = useState<any>();
  const [openUpdateModal, setOpenUpdateModal] = useState<boolean>(false);
  const [openInfoModal, setOpenInfoModal] = useState<boolean>(false);
  const [showAttendance, setShowAttendance] = React.useState<boolean>(false);
  const [ openVerifyByAdmin , setOpenVerifyByAdmin ] = useState<boolean>(false) 
  const dispatch = useDispatch();
  const openPopover = useSelector((state: any) => state?.openPopover);
  const openPopup = Boolean(openPopover.open);
  const openModal = useSelector((state: any) => state?.openModal?.open)
  const [isFilterSelected, setFilterSelected] = useState<boolean>(false)
  const [openViewProjectDetails, setOpenViewProjectDetails] = useState<boolean>(false)
  const [openInventoryDialog, setOpenInventoryDialog] = useState(false)
 
  const open = Boolean( anchorEl );

  const handleSetRowData = ( row: any ) => {
    setUpdateRowDAta( row );
  };

  const handleClick = ( event: React.MouseEvent<HTMLElement> ) => {
    setAnchorEl( event.currentTarget );  
  };
  
  const handleClose = () => {
    setAnchorEl( null );
  };

  const tableSearch = ( searchValue: any ) => {
    setSearchInput( searchValue.target.value );
    searchTableData( searchValue.target.value )
  };

  useEffect(() => {
    if ((title !== 'Attendance') && (title !== 'Central Inventory') ) {
      setColumnsData([...columns, ...headers]);
    } 
  }, [columns]);

  useEffect(() => {
    setFilteredResults(rows); 
  }, [rows]);

  useEffect(() => {
    setFilteredResults(rows);
    // refreshTableData(filteredResults);   
  }, []);
 
  const handleShowUser = (data: any) => {
    router.push(`/user/${data?.id}`)
  };
 
  const selectFilter = (item:any) => { 
    if(Object.keys(item).includes('fun')){
      item?.fun()
      setFilterSelected(!!item?.id)
    } 
  }

  const filterMenu = (menuData: any) => {
    return menuData?.map((item: any, index:number) => {  
      return !!Object.keys(item)?.length && ( 
        <div key={index}>
           <FilterTextLayout> 
              <TreeItem className='parent-item' key={item?.id} nodeId={item?.id?.toString()} label={item?.menuText} onClick={() => selectFilter(item)}>
                {item?.subItem && item?.subItem?.map((subMenuItem: any) => (
                  <TreeItem className='SubItem' key={subMenuItem?.id} nodeId={subMenuItem?.id?.toString()} label={subMenuItem?.menuText} onClick={subMenuItem?.fun} />
                ))}
            </TreeItem>  
          </FilterTextLayout>
        </div>
      )});
  };
  
  const handleOpenDialog = (row: any) => {
    dispatch(setOpenModal());
    handleSetRowData(row);
  } 
  const checkPagination = totalItems !== undefined ? filteredResults : filteredResults?.slice( page * rowsPerPage, page * rowsPerPage + rowsPerPage );
 
  return (
    <MainBox>
      <ContainerMain>
        {
          <> 
            <SearchFilterLayout>
              {!isVisible &&
                <SearchFilterLayout>
                    <Button variant='contained' style={{whiteSpace: 'nowrap'}} onClick={() => handleExcelExport()}>
                      Download Excel
                    </Button> 
                    { title === "Project" &&
                    
                    <div style={{display: 'block', margin:' 0 12px'}}>
                          <DatePickerLineBox> 
                            <MinMaxDateRangePicker selectedDateRange={selectedDateRange} handleFilter={(e) =>  filterOnProject(e)} />
                          </DatePickerLineBox>  
                    </div> 
                     }
                </SearchFilterLayout>
              }
              {( (title === "Request Verification") && [0, 1, 3]?.includes(session?.user?.role_id)) 
                && <div style={{margin: "10px"}}> <AutocompleteComponent /></div>}
            
              <FilterButtonBox>  
                { (((title == "Staff" ) || (title === "Material Request") || ( title === 'Site Inventory') || (title === 'Purchase Management') )
                  && [0, 1, 3]?.includes(session?.user?.role_id))  && <> 
                  <FormControl sx={{width:"20rem",borderRadius: '12px',height:"40px", border:"1px solid #66666636"}}>
                    <InputLabel sx={{top: '-3px'}} id="demo-simple-select-label">
                      Select Project 
                    </InputLabel>
                    <Select  
                      id="demo-simple-select"
                      label="Select Project"
                      sx={{
                        '.MuiOutlinedInput-notchedOutline': {
                         border: 'none !important',  
                         },
                         padding: '0px 20px 0px 8px'
                      }} 
                      value={selectedFilterProject}    
                      onChange={(event: any) => { 
                        const { target: { value } } = event;  
                        setSelectedFilterProject( value )
                        filterByProject(value)    
                      }}  
                      renderValue={(selected: any[]) => { 
                          return projectItems?.filter(item => selected == item?.id)?.map(item => item?.name)?.join(','); 
                      }}
                      MenuProps={MenuProps}
                      > 
                      { projectItems?.map((item: any) => { 
                      return (
                        <MenuItem key={item?.id} value={item?.id}> 
                          <ListItemText primary={item?.name} />
                        </MenuItem>
                      );
                      })}
                    </Select>  
                  </FormControl> 
                  </> }
                
                {/* filter by category for material request*/}
                 { (title == "Material") && <>  
                  <FormControl sx={{width:"20rem",borderRadius: '10px'}}>
                  <InputLabel sx={{top: '-4px'}} id="demo-simple-select-label">
                     Select Category
                  </InputLabel>
                  <Select  
                    id="demo-simple-select"
                    label="Select Category" 
                    value={categorySelected}  
                    sx={{ 
                       padding: '0px 20px 0px 8px'
                    }} 
                    onChange={(event: any) => {
                      const { target: { value } } = event; 
                      setCategorySelected(value) 
                      filterByCategory(value) 
                    }} 
                    renderValue={(selected: any[]) => { 
                      return selectItems?.filter((item:any) => selected == item?.id)?.map(item => item?.category)?.join(','); 
                    }}
                    MenuProps={MenuProps}
                  >  
                     { selectItems?.map((item: any) => { 
                        return (
                          <MenuItem key={item?.id} value={item?.id}> 
                            <ListItemText primary={item?.category} />
                          </MenuItem>
                        );
                      })}
                    </Select>  
                  </FormControl> 
                  </> }

                 {/* filter by category for central inventory */}
                  { title === "Central Inventory" && <>
                    <FormControl sx={{width:"20rem",borderRadius: '10px'}}>
                      <InputLabel  sx={{top: '-4px'}} id="demo-simple-select-label">
                        Select Category
                      </InputLabel>
                      <Select  
                        id="demo-simple-select"
                        label="Select Category"
                        size='small' 
                        value={categorySelected}  
                        sx={{ 
                          padding: '0px 20px 0px 8px'
                        }} 
                        onChange={(event: any) => {
                          const { target: { value } } = event; 
                          setCategorySelected(value) 
                          filterByCategory(value) 
                        }} 
                        renderValue={(selected: any[]) => { 
                          return selectItems?.filter((item:any) => selected == item?.id)?.map((item:any) => item?.categoryName)?.join(','); 
                        }}
                        MenuProps={MenuProps}
                      >   
                        { selectItems?.map((item: any) => { 
                            return (
                              <MenuItem key={item?.id} value={item?.id}> 
                                <ListItemText primary={item?.categoryName} />
                              </MenuItem>
                            );
                          })}
                      </Select>  
                    </FormControl> 
                  </> 
                  }
            
                {/* filter for attendance  */}
                { title === 'Attendance' &&
                  <>
                    { !showAttendance &&
                      <Button
                        variant="contained"
                        onClick={ () => setShowAttendance( !showAttendance ) }
                      >
                        <FilterTextBox>
                          Filter
                        </FilterTextBox>
                      </Button>
                    }
                  </> }

                <TextField
                  id="outlined-start-adornment"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Searchicon />
                      </InputAdornment>
                    ),
                  } }
                  placeholder='Search'
                  value={ searchInput }
                  name="search"
                  onChange={ ( e ) => tableSearch( e ) }
                />
                 { !!filterMenuOption?.length && 
                 <IconButton id="demo-customized-button" color='info' onClick={ handleClick }>
                 <Badge color="info" variant="dot" invisible={!isFilterSelected}> 
                     <TuneIcon />  
                 </Badge> 
                </IconButton>
                 } 

                { title !== 'Attendance' && <Button variant='contained' onClick={() => {
                  setSearchInput('')
                  resetFilter() 
                  // refreshTableData()  
                  setFilterSelected(false)  
                }}>Reset</Button>} 
              </FilterButtonBox>
 
              <Menu
                sx={ { borderRadius: "2%" } }
                anchorEl={ anchorEl }
                open={ open }
                onClose={ handleClose }
                id="demo-customized-menu"
                MenuListProps={ {
                  'aria-labelledby': 'demo-customized-button',
                } }
              >
                <TreeView 
                  aria-label="menu"
                  defaultCollapseIcon={ <ExpandMoreIcon /> }
                  defaultExpandIcon={ <ChevronRightIcon /> }
                >
                  { filterMenu( filterMenuOption ) }
                </TreeView>
              </Menu>
            </SearchFilterLayout>

            {/* Filter for staff attendance list */ }
            <div style={ { display: "flex", marginBottom: '12px' } }>
              { showAttendance ? (
                <AttendanceFilter
                  selectedDateRange={selectedDateRange}
                  getUserByRole={ getUserByRole }
                  applyFilter={ applyFilter }
                  filterOnAttendance={ filterOnAttendance }
                  projectItems={ projectItems } />
              ) : null }
              {
                showAttendance &&
                <AttendanceContainer>
                  <Button
                    sx={ { margin: 'auto 6px' } }
                    variant='outlined'
                    onClick={ ( e ) => { 
                      setShowAttendance( !showAttendance )
                      filterOnAttendance( e, 'remove' )
                      resetFilter()
                    } }>
                    Clear
                  </Button>
                  <Button variant='contained' onClick={ applyFilter }>Apply</Button>
                </AttendanceContainer>
              }
            </div>

            <TableContainer sx={ { maxHeight: 440 } }>
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow hover role="checkbox" tabIndex={ -1 }>
                    { columnsData?.map( ( column ) => (
                      <Cell
                        key={ column.id }
                        variant="head"
                        align={ 'center' }
                        style={ {
                          background: '#F3F6F9',
                          border: 'none',
                          // color: '#B5B5C3',
                          minWidth: column.minWidth,
                          fontSize: '15px',
                          fontWeight: 'bold',
                          fontFamily: '"Poppins", sans-serif'
                        } }
                      >
                        { column.label }
                      </Cell>
                    ) ) }
                  </TableRow>
                </TableHead>
                
                <TableBody>
                  { checkPagination?.length === 0 ? (
                    <> 
                      <TableRow>
                       {<TableCell align="center" colSpan={ columnsData?.length }>
                        <h1>Data Not Found...</h1> 
                        </TableCell>}
                      </TableRow>  
                    </>
                  ) : !isLoading ? (
                    <>
                      <TableRow>
                        <TableCell align="center" colSpan={ columnsData?.length }>
                          <CircularProgress />
                        </TableCell>
                      </TableRow>
                    </>
                  ) : ( checkPagination?.map( ( row, i ) => {
                        return (
                          <TableRow
                            hover
                            role="checkbox"
                            tabIndex={ 1 }
                            key={ row.id }
                          >
                            { columnsData?.map( ( column ) => {
                              const value = row[ column?.id ];
                              const formattedValue = typeof value === "string" ?  formatString(value) : value;   
                              return column?.id !== 'action' ? (
                                <>
                                  <TableCell style={ {
                                    border: 'none',
                                    color: '#000000',
                                    alignItems:'center' ,//column?.align,
                                    textAlign: 'center',//column?.textAlign,
                                    minWidth: column?.minWidth,
                                    width: column?.width ,
                                    fontSize: '14px',
                                    fontWeight: '100',
                                    fontFamily: '"Poppins", sans-serif',
                                  } }
                                    align='left'
                                    key={ column?.id }>
                                    { row[ column?.id ] === null ? (
                                      'Not Specified'
                                    ) : column?.id === 'approvedOrReject' ? (
                                      <>  
                                          <Button 
                                            variant='contained'
                                            color="primary" 
                                            size='small' 
                                            className='approved-reject'
                                            disabled={(row?.status === "Completed") || ([0,3].includes(session?.user?.role_id)) }
                                            onClick={ ( event: React.MouseEvent<HTMLButtonElement> ) => {
                                              handleSetRowData( row )
                                              dispatch( setOpenPopover( event.currentTarget ) )
                                            } }>
                                           { row?.salesStatus === "Rejected" ? 'Approve' : row?.salesStatus === "Approved" ? "Reject" : row?.salesStatus === "Pending" ? "Approve / Reject" : "" }
                                          </Button>  
                                      </>
                                    ) : column?.id === 'verifiedByAdmin' ? <>  
                                          <Button 
                                          size='small' 
                                          variant='contained'
                                          disabled={row?.verifiedByAdmin || [0,3].includes(session?.user?.role_id)} 
                                          className='approved-reject'
                                          onClick={ ( event: React.MouseEvent<HTMLButtonElement> ) => {
                                            handleSetRowData( row )
                                            setOpenVerifyByAdmin(true) 
                                          }}> 
                                            {row?.verifiedByAdmin === true ? "Approved" : "Approve"}
                                          </Button> 
                                    </> : column?.label === 'Permission' ? (
                                      <>
                                        <TableCell >
                                          <Permission>
                                            <PermissonBox
                                              onClick={ () =>
                                                handleOpenDialogBox( row?.id )
                                              }
                                            >
                                              <EyeIcon />
                                              <Blankbox>Permission</Blankbox>
                                            </PermissonBox>
                                          </Permission>
                                        </TableCell>
                                      </>
                                    ) : column.label === 'Images' ? (
                                      <>
                                        <TableCategoryImageBox>
                                          { !!row?.img.length && row?.img?.map( ( item ) => (
                                           <Link href={`${baseImgUrl}${item}`} target='_blank'>
                                           <img
                                              src={ `${baseImgUrl}${item}` }
                                              alt="noimage"
                                              crossOrigin="anonymous" 
                                            />
                                           </Link> 
                                          ) ) }
                                        </TableCategoryImageBox>
                                      </>
                                    ) : column?.label === 'img' ? (
                                      <>
                                        <TableCategoryImageBox>
                                          { row?.img?.map( ( item ) => (
                                             <Link href={`${baseImgUrl}${item}`} target='_blank'>
                                               <img
                                                 width={20}
                                                 height={20}
                                                 src={`${baseImgUrl}${item}`}
                                                 alt="noimage"
                                                 crossOrigin="anonymous" 
                                               /> 
                                             </Link>
                                          ) ) }
                                        </TableCategoryImageBox>
                                      </>
                                    ) : column?.label === 'Image' ? (
                                      <> 
                                        <TableCategoryImageBox>
                                          { !!row?.image ? 
                                           <Link href={`${baseImgUrl}${row?.image}`} target='_blank'>
                                             <img  
                                             src={ `${baseImgUrl}${row?.image}` }
                                             alt="noimage"
                                             crossOrigin="anonymous"  
                                           /> 
                                           </Link>
                                          : <ImageIcon /> } 
                                        </TableCategoryImageBox>
                                      </>
                                    ) : typeof value === 'object' &&
                                      Array.isArray( value ) ? (
                                      <> 
                                        <CommonAvatarGroup
                                          itemGroup={ value }
                                          columnId={ column.id }
                                          valueType={ typeof value }
                                        />
                                      </>
                                    ) : typeof value === 'undefined' ? null : column?.id === 'userStatus' ? <>
                                      <Tooltip title={ `${ !row?.userStatus ? 'Enable' : 'Disable' }` }>
                                        <FormControlLabel
                                          value="start"
                                          control={
                                            <>
                                              <Switch
                                                color="success"
                                                disabled={session?.user?.role_id === 2}
                                                defaultChecked={ row?.userStatus }
                                                value={ row?.userStatus }
                                                checked={ row.userStatus }
                                                onChange={ ( e: any ) => {
                                                  let copyArr = [ ...filteredResults ]
                                                  copyArr[ i ] = { ...row, userStatus: e.target.checked }
                                                  setFilteredResults( copyArr )
                                                  const payload: any = {
                                                    updateUser: {
                                                      id: row?.id,
                                                      status: e.target.checked,
                                                    }
                                                  }
                                                  handleUpdateProps( e, payload );
                                                } }
                                                inputProps={ { 'aria-label': 'ant design' } }
                                              />
                                            </>
                                          }
                                          labelPlacement="start"
                                        />
                                      </Tooltip>
                                    </> : column.label === 'Progress' ? <>
                                      <LinearProgress
                                        determinate
                                        value={ 50 }
                                      />
                                    </>
                                      : (
                                        <> 
                                          { formattedValue } 
                                          { column.id === 'user' ? <> { !!row?.image ? <>
                                            {
                                              <>
                                                <CommonImageViewDialog onClick={() => {
                                                  setOpenEndModal(true) 
                                                  }} title="Image">
                                                  <StaffImageBox>
                                                    { !!row?.image ?
                                                     <Link href={`${baseImgUrl}${row?.image}`} target='_blank'>
                                                       <img
                                                         src={ `${baseImgUrl}${row?.image}` }
                                                         alt="noimage"
                                                         crossOrigin="anonymous" 
                                                       /> 
                                                     </Link>
                                                      : <ImageIcon /> }
                                                  </StaffImageBox>
                                                </CommonImageViewDialog>
                                              </>
                                            }
                                          </>
                                            : null }</> : <></> }
                                        </>
                                      )
                                    }
                                  </TableCell>
                                </>
                              ) : (
                                <>
                                  <TableCell align="center" style={ {
                                    border: 'none',
                                    color: 'rgba(0, 0, 0, 0.26)',
                                    minWidth: '150px',
                                    fontSize: '14px',
                                    fontWeight: '600',
                                    fontFamily: '"Poppins", sans-serif',
                                    width: '250px'
                                  } } >
                                    { ((title === "Request Verification") && [4, 5]?.includes(session?.user?.role_id)) &&
                                      <>  
                                          <Tooltip title="Verify">
                                            <Button 
                                             style={{margin: '0px 10px'}}
                                             variant="contained" 
                                             key={ i }
                                             color="primary" 
                                             size="small"
                                             aria-label="edit"
                                             disabled={((row?.approveStatus === 'delivered') || ( row?.approveStatus === 'rejected') || ( row?.approveStatus === 'pending' ) || ( row?.approveStatus === 'approved' ) ) }
                                              onClick={ () => handleOpenDialog( row ) }> 
                                              {(row?.approveStatus === 'delivered' ) && 'Verified'} 
                                              {(row?.approveStatus === 'partialDelivered' ) && 'Verify'}  
                                              { ( row?.approveStatus === 'pending' ) && "Verify"}
                                              {( row?.approveStatus === 'approved' )  && 'Verify'}
                                              {( row?.approveStatus === 'ordered' )  && 'Verify'}
                                              {( row?.approveStatus === 'rejected' )  && 'Verify'}
                                            </Button>
                                          </Tooltip>
                                      </>
                                    }
                                    
                                    {
                                      ((['/users','/store' , '/category']?.includes(pathname) && ![ 1, 2]?.includes(session?.user?.role_id) ) ||  
                                     ( [ 'Machinery Request',   'Project report']?.includes(title) && ![1, 3]?.includes(session?.user?.role_id)) || 
                                     ( ['Vendor', 'Brand', 'User', 'Project', 'Category']?.includes(title) && [ 1,3]?.includes(session?.user?.role_id)) ||
                                     ([ 'Vendor' ]?.includes(title) && [ 1, 3]?.includes(session?.user?.role_id) ) ||
                                     ([ 'Material Request' ]?.includes(title) && ![0, 1, 3]?.includes(session?.user?.role_id) )  
                                     || (['Project Assigned']?.includes(title) && [2]?.includes(session?.user?.role_id)))
                                      && (
                                      <> 
                                        <Tooltip title="Edit">
                                          <IconButton
                                            key={ i }
                                            color="primary"
                                            size="small"
                                            aria-label="edit"
                                            disabled={row?.verifiedByAdmin === false || (row?.status === 'Completed')}
                                            style={ {
                                              opacity: ((row?.approveStatus === 'rejected') || (row?.approveStatus === "partialDelivered") ||( row?.approveStatus === "approved" ) || ( row?.approveStatus === "ordered" ) || ( row?.approveStatus === "delivered" ) ) ? '0.4' : 1,
                                              pointerEvents: ( (row?.approveStatus === 'rejected') || (row?.approveStatus === "partialDelivered") || ( row?.approveStatus === "approved" ) || ( row?.approveStatus === "ordered" ) || ( row?.approveStatus === "delivered" ) ) ? 'none' : null,
                                            }}
                                          >
                                           <Image  
                                            onClick={ () => {
                                              if (['Material Request']?.includes(title) ){
                                                if( session?.user?.role_id === 2) {
                                                  router.push( `/request-approval/${ row?.reqId }` )
                                                } else {
                                                  router.push( `/request-management/material-request/update/${ row?.reqId }` )
                                                }
                                              } else if(( session?.user?.role_id === 2) && ( title !== "Project Assigned")){
                                                setOpenUpdateModal(
                                                  !openUpdateModal
                                                );
                                                handleSetRowData( row ); 
                                              } else { 
                                                setOpenUpdateModal(
                                                  !openUpdateModal
                                                );
                                                handleSetRowData( row );
                                              }
                                            } }
                                            src={ editIcon } width={ 18 } height={ 18 } alt='edit' />
                                          </IconButton>
                                        </Tooltip>
                                      </>
                                    ) }

                                    {
                                       (title === "Request Verification")  && <> 
                                      <Tooltip
                                            title="View"
                                          >
                                              <Button
                                                color='error' 
                                                size='small'
                                                variant='outlined'  
                                                aria-label="show_details"
                                                disabled={row?.approveStatus === "approved" || row?.approveStatus === "ordered" || row?.approveStatus === "pending"}
                                                onClick={ () => {
                                                  router.push(`/request-management/request-verification/${row?.reqId}`)
                                                } }>View</Button>  
                                          </Tooltip>
                                      </>
                                    }
                                    {
                                      ( title === 'Staff' && ![0]?.includes(session?.user?.role_id) ) &&
                                      <>
                                        <Tooltip title="Edit">
                                          <IconButton
                                            key={ i }
                                            color="primary"
                                            size="small"
                                            aria-label="edit"
                                            disabled={row?.status ===  'Completed'}
                                            style={ {
                                              opacity: ( ( row?.approveStatus === "approved" ) || ( row?.approveStatus === "ordered" ) ) ? '0.4' : 1,
                                              pointerEvents: ( ( row?.approveStatus === "approved" ) || ( row?.approveStatus === "ordered" ) ) ? 'none' : null,
                                            } }
                                          >
                                            <Image onClick={ () => {
                                              setOpenUpdateModal(
                                                !openUpdateModal
                                              );
                                              handleSetRowData( row );
                                            } } src={ editIcon } width={ 18 } height={ 18 } alt='edit' />
                                          </IconButton>
                                        </Tooltip>
                                      </>
                                    }

                                    {( title === 'User' ) && (
                                        <>
                                          <Tooltip
                                            title="View"
                                          >
                                            <IconButton
                                              color="success"
                                              size="small"
                                              aria-label="show_details"
                                              onClick={ () => {
                                                handleShowUser( row )
                                              } }
                                            >
                                              <Visibility />
                                            </IconButton>
                                          </Tooltip>
                                        </>
                                      )} 
                                    {( title === "Machinery Request" || title === "Material Request" || title === "Return Request" ) && (
                                        <>
                                          <Tooltip
                                            title="Show"
                                          >
                                            <IconButton
                                              color="success"
                                              size="small"
                                              aria-label="show_details"
                                              onClick={ () => {
                                                router.push( `/request-approval/${ row?.reqId }/?isView=true/?isApproved=${ row?.approveStatus }` )
                                              } }
                                            >
                                              <Visibility />
                                            </IconButton>
                                          </Tooltip>
                                        </>
                                      )} 

                                    {( title === "Purchase Management" && (
                                        <>
                                          <Tooltip
                                            title="View"
                                          >
                                            <IconButton
                                              color="success"
                                              size="small"
                                              aria-label="show_details"
                                              onClick={ () => {
                                                router.push( `/purchase-management/${ row?.purchaseOrderNo }` )
                                              } }
                                            >
                                              <Visibility />
                                            </IconButton>
                                          </Tooltip>
                                        </>
                                    ))}   

                                    { (title === "Purchase Management") && (
                                      <> 
                                        { ![0]?.includes(session?.user?.role_id) && <Tooltip
                                          title="Bill Upload"
                                          > 
                                          <IconButton
                                            disabled={(row?.status === 'Ordered')}
                                            color="error"
                                            sx={{color: 'red'}}
                                            size="small"
                                            onClick={( e ) => {
                                              router.push(`/purchase-management/po-closure/${row?.purchaseOrderNo}`) 
                                            }}> 
                                              <BillIcons />
                                          </IconButton>
                                        </Tooltip>} 
                                      </>
                                    ) } 
                                   
                                    { (title === 'Material' || title === 'Category' || title === "Brand" || title === "Vendor" || title === "Staff") && <>
                                          <Tooltip title="View">
                                            <IconButton
                                              key={ i }
                                              color="primary"
                                              size="small"
                                              aria-label="View"
                                            >
                                              <Visibility onClick={ () =>  { 
                                                    handleSetRowData(row) 
                                                    setOpenInventoryDialog(true) 
                                              }} /> 
                                            </IconButton>
                                          </Tooltip>
                                       </> }
                              
                                      { ( (['Brand', 'Staff', 'Category', 'Material' , 'Return Request' ]?.includes(title) && [1, 2, 3, 4, 5]?.includes(session?.user?.role_id) )  
                                        || ([ 'Vendor' ]?.includes(title) && [1, 3]?.includes(session?.user?.role_id) ) || 
                                        ([ 'Material Request' ]?.includes(title) && ![0, 3]?.includes(session?.user?.role_id) ) ||
                                        ([ 'User' ]?.includes(title) && [0, 1]?.includes(session?.user?.role_id) )  
                                      ) && 
                                          <>
                                          <IconButton
                                              color="error"
                                              size="small"
                                              aria-label="delete"
                                              disabled={row?.verifiedByAdmin === false}
                                              style={ {
                                                opacity: ( ( row?.approveStatus === "approved" ) || (row?.approveStatus === 'rejected') || ( row?.approveStatus === "ordered" ) || ( row?.approveStatus === "delivered" ) || (row?.approveStatus === "partialDelivered") ) ? '0.4' : 1,
                                                pointerEvents: ( ( row?.approveStatus === "approved" ) || (row?.approveStatus === 'rejected') || ( row?.approveStatus === "ordered" ) || ( row?.approveStatus === "delivered" ) || (row?.approveStatus === "partialDelivered")) ? 'none' : null,
                                              } }
                                            > 
                                              <CustomTooltip
                                                title={ title }
                                                handleAction={() => {
                                                  handleRemoveRow(row);  
                                                  refreshTableData(filteredResults); 
                                                } }
                                                row={ row }
                                              /> 
                                          </IconButton>
                                          </>
                                      }
  
                                    {( pathname === '/projects' || title === 'Project Assigned' || title === 'Sales Projects' || pathname === '/sales-management/project' ) && (
                                        <>
                                        <IconButton
                                        color="success"
                                        size="small"
                                        aria-label="delete"
                                        onClick={ () => { 
                                          setOpenViewProjectDetails(
                                            !openUpdateModal
                                          );
                                          handleSetRowData( row );
                                        }}>
                                          <Visibility/> 
                                         </IconButton>  
                                        </>
                                      )}
                                    
                                    { title === 'Site Inventory' && <>
                                        <Tooltip title="Info">
                                          <IconButton
                                            key={ i }
                                            color="info"
                                            size="small"
                                            aria-label="info"
                                            onClick={ () => {
                                              setOpenInfoModal( true )
                                              handleSetRowData( row );
                                            } }
                                          >
                                            <InfoOutlinedIcon />
                                          </IconButton>
                                        </Tooltip>
                                      </> }

                                    { title === "Return Request" && <>
                                        <Tooltip title="Edit">
                                          <IconButton
                                            key={ i }
                                            color="primary"
                                            size="small"
                                            aria-label="edit"
                                            style={ {
                                              opacity: ( (row?.approveStatus === "rejected") || ( row?.approveStatus === "approved" ) || ( row?.approveStatus === "ordered" ) ) ? '0.4' : 1,
                                              pointerEvents: ( (row?.approveStatus === "rejected") ||  ( row?.approveStatus === "approved" ) || ( row?.approveStatus === "ordered" ) ) ? 'none' : null,
                                            } }
                                          >
                                            <Image onClick={ () => {
                                              if ( session?.user?.role_id === 2 ){
                                                router.push( `/request-approval/${ row?.reqId }` )
                                              } else 
                                              {  
                                                router.push(`/return-request/material/update/${ row?.reqId }`) 
                                              }
                                            } } src={ editIcon } width={ 18 } height={ 18 } alt='edit' />
                                          </IconButton>
                                        </Tooltip>
                                      </> }

                                     { ((title === "Material Request") && [3]?.includes(session?.user?.role_id) ) &&
                                       <> 
                                        <Button size="small" variant='contained' disabled={ ["pending", "delivered", "ordered"].includes(row?.approveStatus)} onClick={() => router.push(`/purchase-management/purchase-order?projectId=${row?.projectId}&projectName=${row?.projectName}&request=${row?.reqId}`)}>
                                          Generate PO 
                                        </Button>
                                       </>
                                     }
                                  </TableCell>
                                </>
                              );
                            } ) }
                          </TableRow>
                        );
                      } )
                  ) }
                </TableBody>
              </Table>
            </TableContainer>
          </>
        } 

        { ((filteredResults?.length > 0) && (totalItems !== undefined)) && (
          <>  
              <TablePagination
                rowsPerPageOptions={ [2, 5, 10, 15, 25, 50 ] }
                component="div"
                count={ totalItems }
                rowsPerPage={ rowsPerPage } 
                page={ page - 1 }
                onPageChange={ handleChangePage }
                onRowsPerPageChange={ handleChangeRowsPerPage }
              />
          </>
        ) }

      </ContainerMain>

      {/* All imported modals */}
      {
        openInventoryDialog && <>
        <Dialog
           fullWidth
           maxWidth='md'
           open={openInventoryDialog}
           onClose={() => setOpenInventoryDialog(!openInventoryDialog)}>
           <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
             <Toolbar>
               <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                 {title} Detail
               </Typography>
               <DialogActions>
                 <ClearIcon onClick={() => {
                      setOpenInventoryDialog(!openInventoryDialog)
                 }}/> 
               </DialogActions>
             </Toolbar>
           </AppBar>
           <DialogContent>
             <ListItemComponent title={ title } data={ updateRowData } />
           </DialogContent>
         </Dialog>
        </>
      }
      
      { openModal && <>
          <CommonUpdateModal title='Material Verification'>
            <RequestVerificationForm requestData={ updateRowData } 
            refreshData={() => {
              refreshTableData  
            }}
             handleUpdateProps={ handleUpdateProps } />
          </CommonUpdateModal>
        </>}  

        { <Dialog
           fullWidth
           maxWidth='md'
           open={openViewProjectDetails}
           onClose={() => setOpenViewProjectDetails(!openViewProjectDetails)}>
           <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
             <Toolbar>
               <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                 Project Detail
               </Typography>
               <DialogActions>
                 <ClearIcon onClick={() => {
                      setOpenViewProjectDetails(!openViewProjectDetails)
                 }}/> 
               </DialogActions>
             </Toolbar>
           </AppBar>
           <DialogContent>
             <ListItemComponent title={ 'Project Detail' } data={ updateRowData } />
           </DialogContent>
         </Dialog> }
         
       <VerifyVendor rowData={updateRowData} openVerifyByAdmin={openVerifyByAdmin} setOpenVerifyByAdmin={setOpenVerifyByAdmin}
        fetchData={() => {  
          refreshTableData() 
        }}
        />
      
      { openPopup && <PopoverComponent openPopup={openPopup} updateRowData={ updateRowData } handleApproveProject={ handleApproveProject } /> }
            
       <SiteInventoryInfoDialog title={ "Item Info" } data={ updateRowData } open={ openInfoModal } onClose={ () => setOpenInfoModal( false ) } /> 
    { openUpdateModal &&  
      <UpdateModal
        items={ items }
        catItems={ catItems }
        open={ openUpdateModal }
        setOpen={ setOpenUpdateModal }
        title={ title } 
        selectItems={ selectItems } 
        projectItems={projectItems} 
        url={ url }
        updateData={ updateRowData }
        refreshTableData={() => {  
          refreshTableData() 
        }}
        handleUpdateProps={
          handleUpdateProps
        }
      />}
    </MainBox >
  );
};
export default TableMain;
