import styled from 'styled-components';
import { TableCell, IconButton } from '@mui/material';
import RemoveRedEyeIcon from '@mui/icons-material/RemoveRedEye';

export const Container = styled.div`
  text-align: center;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
  color: #000133;
`;

export const Cell = styled(TableCell)``;

export const ButtonIcon = styled(IconButton)``;

export const Permission = styled.div`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background-color: red;
  border-radius: 9999px;
  color: #fff;
  opacity: 0.65;
  cursor:pointer;

`;
export const PermissonBox = styled.div`
  display: flex;
  padding: 3px 11px;
  align-items: center;
  gap: 0px 11px;
`;

export const EyeIcon = styled(RemoveRedEyeIcon)`
`;

export const Blankbox = styled.div`
  line-height: 1.5rem;
`;

export const UploadButton = styled.div`
    display: flex;
    justify-content: end;
    width: 100%;
`