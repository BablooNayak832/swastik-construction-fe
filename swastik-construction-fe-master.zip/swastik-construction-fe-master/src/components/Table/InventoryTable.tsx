import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import { Data } from '../../Interfaces/InventoryInterface';
import ListItem from '@mui/material/ListItem';
import Divider from '@mui/material/Divider';
import ListItemText from '@mui/material/ListItemText';
import Fab from '@mui/material/Fab';
import moment from 'moment';
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, List } from '@mui/material';
import { useSession } from 'next-auth/react';
import { inventoryTablecolumns } from '../../constants/table-columns'

interface Column {
    id: string;
    label: string;
    minWidth?: number;
    align?: 'right' | 'left' | 'center';
    format?: (value: number) => string;
}


const InventoryTable = ({ data, transferBy }) => {
    const session = useSession()

    let inventoryArray: any = [];
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [inventoryData, setInventoryData] = React.useState([]);


    const handleChangePage = (event: unknown, newPage: number) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    function createData(
        id: number,
        itemName: string,
        category: string,
        subCategory: string,
        projectName: string,
        quantity: number,
        availableQuantity: string,
        totalTransferQuantity: string,
        orderBy: string,
        deliveredDate: string,
        vendorName: string,
        transferredBy: string
    ): Data {
        return {
            id,
            itemName,
            category,
            subCategory,
            projectName,
            quantity,
            availableQuantity,
            totalTransferQuantity,
            orderBy,
            deliveredDate,
            vendorName,
            transferredBy,
        };
    }

    const handleInventoryData = () => {
        inventoryArray = data?.map((item, i) => {
            const originalDeliverDateDate = moment(item?.deliverDate);
            const transferedBy = transferBy?.filter((tI) => tI?.inventoryId === item?.id);

            return createData(
                i + 1,
                item.itemName,
                item.categoryName,
                item.subcategoryName,
                item?.projectName,
                item?.quantity,
                item?.availableQuantity,
                item?.totalTransferQuantity,
                item?.orderBy,
                originalDeliverDateDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
                    ? originalDeliverDateDate.format('YYYY-MM-DD HH:mm')
                    : 'Not specified',
                item?.vendorName,
                transferedBy
            );
        });
        setInventoryData(inventoryArray);
        return inventoryArray;
    };

    React.useEffect(() => {
        handleInventoryData();
    }, [data]);


    return (
        <Paper sx={{ width: '100%', overflow: 'hidden' }}>
            <TableContainer sx={{ maxHeight: 440 }}>
                <Table stickyHeader aria-label="sticky table">
                    <TableHead>
                        <TableRow>
                            {inventoryTablecolumns?.map((column) => {
                                return (
                                    <TableCell
                                        key={column.id}
                                        variant="head"
                                        align={'center'}
                                        style={{
                                            minWidth: column.minWidth,
                                            fontSize: '16px',
                                            fontWeight: 'bold',
                                        }}
                                    >
                                        {column.label}
                                    </TableCell>
                                );
                            })}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {inventoryData &&
                            inventoryData?.map((row, i) => {

                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={i}>
                                        {columns?.map((column) => {
                                            const value = row[column?.id];
                                            return (
                                                <TableCell key={column?.id} align={column?.align}>
                                                    {column.id === 'transferredBy' ? <>
                                                        {value?.length ? <ViewTransferedData data={value} /> : <> No Data </>}
                                                    </> : value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5, 10, 15, 25, 50 ]}
                component="div"
                count={data?.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
        </Paper>
    );
};

const ViewTransferedData = ({ data }: any) => {
    const [open, setOpen] = React.useState(false);

    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };

    return (
        <>
            <Fab onClick={handleClickOpen} variant="extended" size='small'>
                View
            </Fab>
            <Dialog
                open={open}
                keepMounted
                onClose={handleClose}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle>{"Transfer record "}</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-slide-description">
                        {
                            data && data?.map((record: any) => {
                                return <>
                                    <List sx={{ minWidth: 500 }}>
                                        <ListItem disablePadding>
                                            <ListItemText >
                                                Project Name : {record?.project?.projectName}
                                            </ListItemText>
                                        </ListItem>
                                        <ListItem disablePadding>
                                            <ListItemText >
                                                Location : {record?.project?.location}
                                            </ListItemText>
                                        </ListItem>
                                        <ListItem disablePadding>
                                            <ListItemText >
                                                Quantity : {record?.quantity}
                                            </ListItemText>
                                        </ListItem>
                                        <ListItem disablePadding>
                                            <ListItemText >
                                                Date : {record?.createdAt}
                                            </ListItemText>
                                        </ListItem>
                                        <Divider variant="inset" component="li" />
                                    </List>
                                </>
                            })
                        }
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>Close</Button>
                </DialogActions>
            </Dialog>
        </>
    )

}

export default InventoryTable;