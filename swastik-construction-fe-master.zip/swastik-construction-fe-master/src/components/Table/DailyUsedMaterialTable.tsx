import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { IconButton, Input, TextField, Tooltip } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import SaveIcon from '@mui/icons-material/Save';
import { RequestMaterialTable } from '../../common/styles/RequestMaterialTable/style'
import ConfirmationDialog from '../ui/ConfirmationDialog'



interface UsedMaterialTableType {
    title?: any,
    data?: any,
    removeMaterial?: any,
    editMaterial?: any,
    editingId?: any,
    handleSave?: any,
    handleChange?: any,
    editedValue?: any,
    isApproved?: any,
    isView?: any,
}

const DailyUsedMaterialTable = ({
    title,
    data,
    removeMaterial,
    editMaterial,
    editingId,
    handleSave,
    handleChange,
    editedValue,
    isApproved,
    isView,
}: UsedMaterialTableType) => {       
    const [open, setOpen] = React.useState(false)
    const [materialData, setMaterialData] = React.useState({})

    const handleClick = (event: React.MouseEvent<HTMLElement>, mId) => {
        let index = event.currentTarget.id;
        setMaterialData({id: index, materialId :mId }) 
        setOpen(true)
    };

    const handleClose = () => { 
        setOpen(false)
    };   

    const handleConfirm = () => {
        setOpen(false);
        removeMaterial(materialData?.id, materialData?.materialId)
    }
 
    return (
        <>
            <RequestMaterialTable>
                <TableContainer component={Paper}>
                    <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell sx={{fontWeight: 'bold'}} width={'20px'}>S No.</TableCell>
                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50%'}>Material Name</TableCell> 
                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'25%'}>Consumed Qty.</TableCell> 
                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'25%'}>Remark</TableCell> 
                                { (isApproved === 'pending' && !isView?.includes("true") ) && 
                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'25%'}>Action</TableCell>}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {data && data?.map((row: any, i: number) => { 
                                const itemName = !!row?.subItem ? `-${row?.subItem}` : !!row?.itemName ? `-${row?.itemName}` : "" ;
                                const specification = row?.specification !== undefined ? `-${row?.specification}` : "";
                                const size = row?.size !== undefined ? `-${row?.size}` : "";
                                const unit = row?.unit;
                                return (
                                    <>
                                        <TableRow key={row?.name} >
                                            <TableCell >{i + 1}</TableCell>
                                            <TableCell align="left" >{row?.machineryOrPrductName}{itemName}{specification}{size}({unit})</TableCell>
                                            <TableCell align="left" > 
                                                {editingId === i ? (
                                                    <TextField 
                                                        autoComplete='off'
                                                        size='small'
                                                        variant='outlined'
                                                        type="number"
                                                        name='quantity'
                                                        value={editedValue?.quantity}
                                                        defaultValue={row?.quantity}
                                                        onChange={(e) => handleChange(e, row)}
                                                    />
                                                ) : (
                                                    row?.quantity
                                                )}
                                            </TableCell> 
                                            <TableCell align="left" >
                                                {editingId === i ? (
                                                    <Input
                                                        type="text"
                                                        name='remark'
                                                        value={editedValue?.remark}
                                                        defaultValue={row?.remark}
                                                        onChange={(e) => handleChange(e)}
                                                    />
                                                ) : (
                                                    row?.remark
                                                )}
                                            </TableCell>
                                            { (isApproved === 'pending' && !isView?.includes("true"))&& 
                                            <TableCell align="left" style={{
                                                opacity: (isView?.includes("true")) ? '0.4' : '1',
                                                pointerEvents: (isView?.includes("true")) ? 'none' : null, 
                                            }}>
                                                <div style={{display:'flex'}}>                                                    
                                                {editingId !== i ? (<>
                                                    {<Tooltip title={"Edit"}> 
                                                        <IconButton disabled={isApproved !== 'pending'}>
                                                            <EditIcon onClick={() => editMaterial(i, row)} color='success' />
                                                        </IconButton>
                                                    </Tooltip>}
                                                </>
                                                ) : (
                                                    <>
                                                        <Tooltip title={"Save"}>
                                                            <IconButton> 
                                                                <SaveIcon onClick={() => handleSave(i, row)} color='success' />
                                                            </IconButton>
                                                        </Tooltip>
                                                    </>
                                                )}
                                                {title !== 'Request Approval' && <Tooltip title={"Delete"}>
                                                    <IconButton disabled={ isApproved !== 'pending'}> 
                                                      <DeleteIcon id={i} onClick={(e) => handleClick(e, row?.id)} color='error' />
                                                    </IconButton>
                                                </Tooltip>}
                                                </div>
                                            </TableCell>}
                                        </TableRow>
                                    </>)
                            }
                            )}
                        </TableBody>
                    </Table>
                </TableContainer>
            </RequestMaterialTable>
            
            <ConfirmationDialog
                open={open}
                onClose={handleClose}
                title="Confirm Deletion"
                message="Are you sure you want to delete this material?"
                onConfirm={handleConfirm}
                confirmText="Delete"
                cancelText="Cancel"
                /> 
        </>
    );
};

export default DailyUsedMaterialTable;