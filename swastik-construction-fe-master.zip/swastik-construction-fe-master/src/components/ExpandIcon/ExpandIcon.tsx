/* eslint-disable react/jsx-no-comment-textnodes */
import KeyboardArrowUpOutlinedIcon from '@mui/icons-material/KeyboardArrowUpOutlined';
import KeyboardArrowDownOutlinedIcon from '@mui/icons-material/KeyboardArrowDownOutlined';
import React from 'react';
type ExpandIconPros = {
  isExpanded: boolean;
  handleClick?: () => void;
};

export default function ExpandIcon({
  isExpanded,
  handleClick,
}: ExpandIconPros) {
  return !isExpanded ? (
    <div style={{ marginLeft: "auto" }} onClick={handleClick}>
      <KeyboardArrowDownOutlinedIcon />
    </div>
  ) : (
    <div style={{ marginLeft: "auto" }} onClick={handleClick} >
      <KeyboardArrowUpOutlinedIcon />
    </div>
  );
}
