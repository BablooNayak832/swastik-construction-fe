"use client"
import React, { useEffect, useState } from "react"; 
import { Heading, HeadingBox, TableBox } from "src/common/styles/Users/styles";
import useGet from "src/hooks/useGet";
import { useSession } from "next-auth/react";
import TableMain from "../Table/Table";
import { projectAssignedColumns } from "src/constants/table-columns";
import { user_assigned_projects, all_user_url, project_update_url } from "src/constants/api-routes";
import { formateDate } from "src/utils/formatDate"
import {Wrapper} from "src/app/styles";
import {Blankbox} from "../Table/styles";
import CommonDialog from "../CommonDialog/CommonDialog";
import MainForm from "../common-form";
import usePatch from "src/hooks/usePatch";
import {TablePagination} from "@mui/material";
import moment from "moment";
import useDownloadExcel from "src/hooks/downloadExcel";

const ProjectAssigned = () => {
    const { data: session } = useSession()
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [ queryParams, setQueryParams ] = useState({})
    const [allUserData, setAllUserData] = useState<any>([]);
    const [ assignedProjects ,setAssignedProjects ] =  useState([])
    const { resData: getUser, handleGetData: handleGetUsersdata } = useGet();
    const { resData: getProjectData, isLoading, handleGetData: handleGetAssignedProject } = useGet()
    const {handleUpdateData} = usePatch()
    const { handleDownloadData } = useDownloadExcel() 
    let projectArray: any = []

    useEffect(() => {
        GetAssignedProjects()
        GetAllUsers()
    }, []);

    useEffect(() => {
        GetAssignedProjects()
    }, [queryParams])
    
    const GetAssignedProjects = async () => { 
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
        searchParams += `${key}=${value}&`
        })
        const details = await handleGetAssignedProject(`${user_assigned_projects}?${searchParams}`)
        return details; 
    };

    const GetAllUsers = async () => { 
        const details = await handleGetUsersdata(`${all_user_url}?page=1&limit=1000`);
        return details; 
    };

    const handleChangePage = (event: unknown, newPage: number) => {
       setPage(newPage);
    };

    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
      setRowsPerPage(+event.target.value);
      setPage(0); 
    };
 
    const searchTableData = (value:any) => {
        setQueryParams((preValue) => {
            return {...queryParams, ['q']:value}
        })
      setPage(0)
    }

    useEffect(() => {    
            getProjectData?.length && getProjectData?.map((Item: any, idx: any) => {
                return Item?.assignProject?.map((project: any, index: number) => {
                    const startDate = formateDate(project?.project?.startDate)
                    const endDate = formateDate(project?.project?.endDate) 
                    const status = project?.project?.status;
                    const toTitleCaseStatus = status?.[0]?.toUpperCase() + status?.slice(1, status?.length);    
                    const startDateFormat = moment(project?.project?.startDate).format('YYYY-MM-DD HH:mm') !== 'Invalid date'
                    ? moment(project?.project?.startDate).format('DD-MM-YYYY')
                    : 'Not specified';
                    const endDateFormat = moment(project?.project?.endDate).format('YYYY-MM-DD HH:mm') !== 'Invalid date'
                    ? moment(project?.project?.endDate).format('DD-MM-YYYY')
                    : 'Not specified';
                    projectArray.push({
                        sNo: index + 1,
                        id: project?.projectId,
                        projectName: project?.project?.projectName,
                        location: project?.project?.location,
                        uniqueid: project?.project?.siteId,
                        projectId: project?.project?.siteId,
                        startDate: startDate,
                        endDate: endDate,
                        status: toTitleCaseStatus,
                        description: project?.project?.description,
                        latitude: project?.project?.latitude,
                        longitude: project?.project?.longitude,
                        startDateFormat,
                        endDateFormat
                    })
                })
            }); 
        setAssignedProjects(projectArray)
        setAllUserData(getUser?.items)
    },[getProjectData])
 
    const resetFilter = async() => {
        setQueryParams({})
        await GetAssignedProjects()
    }

    const handleUpdateProps = async (
        e: { preventDefault: () => void },
        payload: any
      ) => {
        e.preventDefault();
        const res = await handleUpdateData(project_update_url, payload)
          GetAssignedProjects();
        // setOpenDialog(false);
        return res;
      };

     const handleExcelExport = async () => {
            let searchParams = "";
            Object.entries(queryParams)?.map(([key, value]) => {
                searchParams += `&${key}=${value}`
            })
            let url = `${user_assigned_projects}/?type=xls${searchParams}`
            const res = await handleDownloadData(url, "Project")
            return res;
      }
    
    return (<>
     <Wrapper>
        <HeadingBox>
          <Blankbox>
            <Heading>Projects</Heading>
          </Blankbox>
          <Blankbox>
            {
              ((session?.user?.role_id === 0) || (session?.user?.role_id === 1) || (session?.user?.role_id === 2)) &&
              <CommonDialog title="Add Project">
                <MainForm
                  data={{
                    projectName: '',
                    siteId: '',
                    location: '',
                    latitude: '',
                    longitude: '',
                    startDate: '',
                    endDate: "",
                    description: '',
                    projectHead: null,
                    siteHead: [],
                    supervisior: [],
                    purchaseHead: [],
                    status: ''
                  }}
                  url={project_update_url}
                  title={'Add Project'}
                  refreshData={GetAssignedProjects}
                  selectItem={allUserData}
                />
              </CommonDialog>
              }
          </Blankbox>
        </HeadingBox>
        <TableBox> 
                <TableMain
                isVisible={false}
                title='Project Assigned'
                isLoading={isLoading}
                columns={projectAssignedColumns}
                rows={assignedProjects}
                page={page}
                selectItems={[]}
                rowsPerPage={rowsPerPage}
                handleChangePage={handleChangePage}
                handleChangeRowsPerPage={handleChangeRowsPerPage}
                refreshTableData={GetAssignedProjects}
                handleRemoveRow={() => ''}  //{removeRequest}
                handleUpdateProps={handleUpdateProps} //{handleUpdateRequest}
                searchTableData={searchTableData}
                resetFilter={resetFilter}  
                handleExcelExport={handleExcelExport}
                /> 
                <TablePagination
                rowsPerPageOptions={ [5, 10, 15, 25, 50 ] }
                component="div"
                count={ assignedProjects?.length }
                rowsPerPage={ rowsPerPage } 
                page={ page }
                onPageChange={ handleChangePage }
                onRowsPerPageChange={ handleChangeRowsPerPage }
              />
        </TableBox>
        </Wrapper>
    </>);
}

export default ProjectAssigned;