import React, { useEffect, useState } from 'react';
import { TableContainer, Wrapper } from '../../../app/styles';
import {
    HeadingBox,
    Blankbox,
    Heading,
    TableBox,
} from '../../../common/styles/Users/styles';
import dynamic from 'next/dynamic';
import { CentralMaterialInventoryColumns } from '../../../constants/table-columns';
import useDownloadExcel from '../../../hooks/downloadExcel';
import getRequestAPI from '../../../services/getRequest'
import { useSelector } from 'react-redux';
import { central_inventory_url } from '../../../constants/api-routes';
import useGet from '../../../hooks/useGet'; 
const TableMain = dynamic(() => import('../../../components/Table/Table'), {
    ssr: false,
});

function createData(
    id: any,
    sNo: number,
    materialName: string,
    category: string,
    type: string,
    itemName: string,
    specification: string,
    size: number,
    unit: string,
    availableQuantity: number,
): any {
    return {
        id,
        sNo,
        materialName,
        category,
        type,
        itemName,
        specification,
        size,
        unit,
        availableQuantity,
    };
}

const MaterialInventory = () => {
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [data, setData] = useState([]);
    const [allCentralInventory, setAllCentralInventory] = useState<any>([]);
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const [loading, setLoading] = useState(true)
    const { resData:resCategoryData , handleGetData: handleGetCategoryData} = useGet()
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const [categorySelected, setCategorySelected] = useState<any>('')
    const [totalItems, setTotalItems] = useState(0);

    const handleChangePage = (event: any, newPage: number) => { 
        setPage(newPage + 1); 
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };

    const getAllCentralInventory = async () => {
        setLoading(false)
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
 
        const details = await getRequestAPI(`${central_inventory_url}?page=${page}&limit=${rowsPerPage}&${searchParams}`)
        .then((response) => {
            setAllCentralInventory(response?.data);
            setLoading(true);
        }).catch((error) => {
            return error;
        }) 
        return details;
    };

    useEffect(() => {
        getAllCentralInventory();
        getCategoryList()
    }, [selectedProject]);

    useEffect(() => {
        getAllCentralInventory()
    }, [queryParams, page, rowsPerPage])

    useEffect(() => {
        setTotalItems(allCentralInventory?.meta?.totalItems)
        const filteredCentralInventory = allCentralInventory?.items?.filter((sItem: any) => sItem?.materialDetails?.category?.type === 1)
        const projectData = filteredCentralInventory?.map((item: any, index: number) => {
            const type = item?.materialDetails?.category?.type === 1 ? "Material" : "Machinery";
            return createData(
                item?.id,
                index + 1,
                item?.materialDetails?.productName,
                item?.materialDetails?.category?.categoryName,
                type,
                item?.materialDetails?.itemName,
                item?.materialDetails?.specification,
                item?.materialDetails?.size,
                item?.materialDetails?.unit,
                item?.availableQuantity,
            );
        }); 
        setData(projectData);
    }, [allCentralInventory?.items]);

    const getCategoryList = async() => {
       await handleGetCategoryData('/category')
    }

    const searchTableData = async (value: any) => {
        setQueryParams((prevValue) => {
            return {...queryParams, ['searchTerm']: value}
        }) 
        setPage(1)
    };

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${central_inventory_url}/?type=xls${searchParams}`
        const res = handleDownloadData(url, "Central Inventory")
        return res;
    }

    const filterByCategory = (filterParams:any) => {
        let param = ''
        if(filterParams !== undefined) {
            param = filterParams
        }
        setQueryParams((prevValue) => {
            return {...queryParams, ['categoryId']: param}
        })
        setPage(1)
    } 

    const resetFilter = async() => {
        setQueryParams({})
        setCategorySelected('')
        setPage(1)
        await getAllCentralInventory()
    }

    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Central Inventory : Material </Heading>
                    </Blankbox>
                </HeadingBox>

                <TableBox>
                    <TableContainer>
                        <TableMain
                            filterByCategory={filterByCategory}
                            isLoading={loading}
                            columns={CentralMaterialInventoryColumns}
                            handleExcelExport={handleExcelExport}
                            rows={data}
                            page={page}
                            rowsPerPage={rowsPerPage}
                            handleChangePage={handleChangePage}
                            handleChangeRowsPerPage={handleChangeRowsPerPage}
                            refreshTableData={getAllCentralInventory}
                            resetFilter={resetFilter}
                            title={'Central Inventory'}
                            selectItems={resCategoryData}
                            searchTableData={searchTableData}
                            categorySelected={categorySelected}
                            setCategorySelected={setCategorySelected}
                            totalItems={totalItems}
                        /> 
                    </TableContainer>
                </TableBox>
            </Wrapper>
        </>
    )
}

export default MaterialInventory