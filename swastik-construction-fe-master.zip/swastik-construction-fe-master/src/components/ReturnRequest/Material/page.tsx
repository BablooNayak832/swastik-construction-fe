'use client';
import { TableContainer, Wrapper } from '../../../app/styles';
import React, { useEffect, useState } from 'react';
import {
    HeadingBox,
    Blankbox,
    Heading,
    TableBox,
} from '../../../common/styles/Users/styles';
import dynamic from 'next/dynamic';
import { materialReturnReqColumns } from '../../../constants/table-columns';
import useDownloadExcel from '../../../hooks/downloadExcel';
import getRequestAPI from '../../../services/getRequest'
import { Alert, Button } from '@mui/material';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import _ from 'lodash';
import usePatch from 'src/hooks/usePatch';
import { useAllowedNavigation } from 'src/context/context';
import { return_request } from '../../../constants/api-routes';
import {useSelector} from 'react-redux';
import useDelete from 'src/hooks/useDelete';
const TableMain = dynamic(() => import('../../../components/Table/Table'), {
    ssr: false,
});

function createItemsData(
    id: number,
    sNo: number,
    reqId: any,
    materialId: number,
    machineryOrPrductName: string,
    itemName: string,
    specification: string,
    size: string,
    unit: string,
    quantity: number,
    siteAvailableQuantity:string,
    remark: string
): any {
    return {
        id,
        sNo,
        reqId,
        materialId,
        machineryOrPrductName,
        itemName,
        specification,
        size,
        unit,
        quantity,
        siteAvailableQuantity,
        remark,
    };
}

function createData(
    sNo: number,
    reqId: string,
    projectName: string,
    projectLocation: string,
    projectId: number, 
    senderName: string,
    approveStatus: string,
    items: any
): any {
    return {
        sNo,
        reqId,
        projectName,
        projectLocation,
        projectId, 
        senderName,
        approveStatus,
        items
    };
}

const ReturnMaterial = () => {
    const router = useRouter()
    const { data: session } = useSession()
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [data, setData] = useState([]);
    const [allMaterialReturnRequest, setAllMaterialReturnReq] = useState<any>([]);
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const [loading, setLoading] = useState(true)
    const { handleUpdateData } = usePatch()
    const { setOpenDialog } = useAllowedNavigation();
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const { handleDeleteData } = useDelete() 
    const [totalItems, setTotalItems] = useState(0)

    useEffect(() => {
        getMaterialReturnRequest() 
    },[selectedProject?.selectedValue, queryParams, page, rowsPerPage])

    useEffect(() => {
        getMaterialReturnRequest();
    }, [page, rowsPerPage]);

    useEffect(() => {
        setTotalItems(allMaterialReturnRequest?.metaData?.totalItems)
        const projectData = allMaterialReturnRequest?.items?.map((rItem: any, index: number) => {
            let createItems, senderName: any, status: any, items: any = [];
            const projects = rItem?.items?.map((i: any) => { 
                return { projectId: i?.projectId, projectName: i?.projectDetails?.projectName, location: i?.projectDetails?.location}
            })
            const projectName = _.unionBy(projects?.map(i => i?.projectName), 'projectName')?.join('');
            const projectLocation =  _.unionBy(projects?.map(i => i?.location))?.join(''); 
            const projectId = parseInt(_.unionBy(projects?.map(i => i?.projectId), 'projectId')?.join(''));
            
            rItem?.items?.map((item: any, idx: number) => {
                status = item?.status;
                senderName = item?.Sender?.name;
                createItems = createItemsData(item?.id, idx + 1, rItem?.returnRequest, item?.materialId, item?.materialDetails?.productName, item?.materialDetails?.itemName,
                    item?.materialDetails?.specification, item?.materialDetails?.size, item?.materialDetails?.unit, item?.quantity, item?.siteAvailableQuantity, item?.remark
                );
                items.push(createItems);
            })

            return createData(
                (page - 1) * rowsPerPage + index + 1,
                rItem?.returnRequest,
                projectName,
                projectLocation,
                projectId, 
                senderName,
                status,
                items
            );
        });
        setData(projectData);
    }, [allMaterialReturnRequest?.items]);

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage + 1); 
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1);
    };
 
    const getMaterialReturnRequest = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let selectedProjectId = selectedProject?.selectedValue?.id === undefined ? '' : selectedProject?.selectedValue?.id;
        setLoading(false)
        const details = await getRequestAPI(`${return_request}/?page=${page}&limit=${rowsPerPage}&projectId=${selectedProjectId}${searchParams}`).then((response) => {
            setAllMaterialReturnReq(response?.data);
            setLoading(true);
        }).catch((error) => {
            return error;
        })
        // setPage(1)
        return details;
    };

    const searchTableData = async (value: any) => {
        setQueryParams((prevValue: any) => {
            return { ...queryParams, ['searchTerm']: value }
        })
        setPage(1) 
    };

    const handleUpdateProps = async (e: any, payload: any) => {
        const res = await handleUpdateData(return_request, payload)
        getMaterialReturnRequest();
        setOpenDialog(false);
        return res;
    }

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let selectedProjectId = selectedProject?.selectedValue?.id === undefined ? '' : selectedProject?.selectedValue?.id;
        let url = `${return_request}/?projectId=${selectedProjectId}&type=xls${searchParams}`
        const res = handleDownloadData(url, "Return material")
        return res;
    } 

    const filterActiveUser = async (param: any) => { 
        setQueryParams((value: any) => {
          return { ...queryParams, [param.key]: param.value }
        })
        setLoading(false)
        setPage(1) 
    }

    const filterMenuOption = [
        { id: 1, menuText: 'Pending', fun: () => filterActiveUser({ key: 'returnStatus', value: 'pending' }) },
        { id: 2, menuText: 'Approved', fun: () => filterActiveUser({ key: 'returnStatus', value: 'approved' }) },
        { id: 3, menuText: 'Rejected', fun: () => filterActiveUser({ key: 'returnStatus', value: 'rejected' }) }
    ]

    const resetFilter = async() => {
        setQueryParams({})
        await getMaterialReturnRequest()
    }

    const removeRequest = async (mId: number) => {
        const { reqId } = mId;
        const MACHINERY_DELETE = `/return-request/${reqId}`;
        const details = await handleDeleteData(MACHINERY_DELETE);
        // getRequestList()
        getMaterialReturnRequest()
        return details;
    };

    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Return Material</Heading>
                    </Blankbox>
                    <Blankbox>
                        <div style={{display: 'block', fontSize: '10px', direction: 'rtl'}}>
                            {
                            ([2, 4, 5].includes(session?.user?.role_id)) &&
                                <Blankbox>
                                        <Button disabled={selectedProject?.selectedValue?.status === "completed"} style={{color: 'white'}} variant="contained" onClick={() => router.push('/return-request/material/return-req-form')}>
                                            Return Material
                                        </Button> {" "}
                                </Blankbox>} 
                        </div>
                    </Blankbox>
                </HeadingBox> 
                    {selectedProject?.selectedValue?.status === "completed" &&
                        <Alert variant="standard" severity="error"> 
                            Can't create request for completed projects
                        </Alert>
                    }
                <TableBox>
                    <TableContainer>
                        <TableMain
                            isLoading={loading}
                            columns={materialReturnReqColumns}
                            handleExcelExport={handleExcelExport}
                            rows={data}
                            page={page}
                            filterMenuOption={filterMenuOption}
                            rowsPerPage={rowsPerPage}
                            handleChangePage={handleChangePage}
                            handleChangeRowsPerPage={handleChangeRowsPerPage}
                            refreshTableData={getMaterialReturnRequest}
                            title={'Return Request'}
                            searchTableData={searchTableData}
                            handleUpdateProps={handleUpdateProps}
                            resetFilter={resetFilter}
                            handleRemoveRow={removeRequest}
                            totalItems={totalItems}
                        />
                    </TableContainer>
                </TableBox>
            </Wrapper>
        </>
    )
}

export default ReturnMaterial