import React, { useEffect, useState } from 'react'
import { Autocomplete, TextField } from '@mui/material';
import useGet from 'src/hooks/useGet';
import { useDispatch, useSelector } from 'react-redux';
import { setSelectedValue } from '../../redux/features/selectProjectSlice';
import { user_assigned_projects } from 'src/constants/api-routes';
import {useSession} from 'next-auth/react';

const AutocompleteComponent = () => {
  const {data: session} = useSession()
  const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet()
  const { resData: resAllProjectData, handleGetData: handleGetAllProjectData } = useGet()
  const selectedProject = useSelector((state: any) => state?.selectedProject);
  const dispatch = useDispatch();
  const [projectArray, setProjectArray] = useState([])

  useEffect(() => {
    getAssignedProjectData()
    if((session?.user?.role_id === 0) || (session?.user?.role_id === 1) || (session?.user?.role_id === 3)){
      getAllProjectsData()
    }
  }, [])


  useEffect(() => {
    let resArray:any=[]
    resProjectData?.length && resProjectData?.map((Item: any, idx: any) => {
        return Item?.assignProject?.map((project: any) => {
            resArray.push({ id: project?.projectId, name: project?.project?.projectName, location: project?.project?.location, status: project?.project?.status })
            setProjectArray(resArray) 
            if(selectedProject.selectedValue === null){  
                dispatch(setSelectedValue(resArray[0]))
            }
        })
    });
},[resProjectData])


    const getAllProjectsData = async() => {
        // fetching all projects data by superadmin , admin
        const allProjectList = await handleGetAllProjectData('/project/list') 
    return allProjectList;
    }

  const getAssignedProjectData = async () => {
        // fetching assigned projects data by superadmin , admin
    const assignProjectList = await handleGetProjectData(user_assigned_projects);
    return assignProjectList;
  }

  useEffect(() => {
    let resArray:any=[]
    resAllProjectData?.items?.length && resAllProjectData?.items?.map((project) => {
        resArray.push({ id: project?.id, name: project?.projectName, location: project?.project?.location })
        setProjectArray(resArray)
      })
  }, [resAllProjectData?.items])

  return (
    <div>
      <Autocomplete 
        defaultValue={selectedProject?.selectedValue}
        value={selectedProject?.selectedValue}
        sx={{ width: '250px' }}
        size='small'
        options={projectArray}
        getOptionLabel={(option) => option?.name}
        onChange={(e, newValue) => {
          dispatch(setSelectedValue(newValue))
        }}
        renderInput={(params) => <TextField {...params} variant="outlined" value={selectedProject?.name} placeholder="Please select a project" />}
        isOptionEqualToValue={(option, value) => option?.id === value?.id}
        fullWidth
      />
    </div>
  )
}

export default AutocompleteComponent;
