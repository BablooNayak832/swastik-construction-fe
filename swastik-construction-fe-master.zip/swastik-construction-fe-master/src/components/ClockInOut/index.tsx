"use client"
import React, { useState, useEffect } from 'react';

const ProjectLocation = { latitude: 40.7128, longitude: -74.0060 }; // Example coordinates of project location

const ClockInOut = () => {
    const [userLocation, setUserLocation] = useState(null);
    const [distance, setDistance] = useState(null);
    const [clockedIn, setClockedIn] = useState(false);

    useEffect(() => {
        // Fetch user's current location
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                position => {
                    setUserLocation({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    });
                },
                error => console.error(error)
            );
        } else {
            console.error("Geolocation is not supported by this browser.");
        }
    }, []);

    useEffect(() => {
        // Calculate distance when userLocation changes
        if (userLocation) {
            const d = calculateDistance(userLocation, ProjectLocation);
            setDistance(d);
        }
    }, [userLocation]);

    const calculateDistance = (coord1, coord2) => {
        const R = 6371e3; // Earth radius in meters
        const φ1 = (coord1.latitude * Math.PI) / 180; // Latitude in radians
        const φ2 = (coord2.latitude * Math.PI) / 180;
        const Δφ = ((coord2.latitude - coord1.latitude) * Math.PI) / 180;
        const Δλ = ((coord2.longitude - coord1.longitude) * Math.PI) / 180;

        const a =
            Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        const distance = R * c; // Distance in meters
        return distance;
    };

    const handleClockInOut = () => {
        if (distance <= 100) { // Assuming project location radius is 100 meters
            setClockedIn(!clockedIn);
        } else {
            alert("You are not at the project location.");
        }
    };

    return (
        <div>
            <p>User Location: {userLocation ? `${userLocation?.latitude}, ${userLocation?.longitude}` : "Loading..."}</p>
            <p>Distance to Project Location: {distance ? `${distance?.toFixed(2)} meters` : "Calculating..."}</p>
            <button onClick={handleClockInOut}>{clockedIn ? "Clock Out" : "Clock In"}</button>
            <p>Status: {clockedIn ? "Clocked In" : "Clocked Out"}</p>
        </div>
    );
};

export default ClockInOut;
