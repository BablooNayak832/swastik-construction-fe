'use client';
import { TableContainer, Wrapper } from '../../app/styles';
import React, { useEffect, useState } from 'react';
import {
    HeadingBox,
    Blankbox,
    Heading,
    TableBox,
} from '../../common/styles/Users/styles';
import dynamic from 'next/dynamic';
import { siteInventoryColumns } from '../../constants/table-columns';
import useDownloadExcel from '../../hooks/downloadExcel'; 
import { projects_url, site_inventory_url } from '../../constants/api-routes';
import useGet from '../../hooks/useGet';
import { useSelector } from 'react-redux';
import { useSession } from 'next-auth/react';
const TableMain = dynamic(() => import('../../components/Table/Table'), {
    ssr: false,
});

function createData(
    id: number,
    sNo: number,
    reqId: string,
    category: string,
    projectName: string,
    productName: string,
    itemName: string,
    specification: string,
    size: string,
    senderName: string,
    availableQuantity: string,
    receivedQuantity: string,
    usedQuantity: string,
    logsData: any[],
    unit: string,
): any {
    return {
        id,
        sNo,
        reqId,
        category,
        projectName,
        productName,
        itemName,
        specification,
        size,
        senderName,
        availableQuantity,
        receivedQuantity,
        usedQuantity,
        logsData,
        unit
    };
}

const SiteInventory = () => {
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [data, setData] = useState([]); 
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const [loading, setLoading] = useState(true)  
    const [selectedFilterProject, setSelectedFilterProject] = useState<any>('')
    const [selectedProjects, setSelectedProject] = useState<any>(null)
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet() 
    const { resData: resSiteInventory, handleGetData: handleGetSiteInventory } = useGet() 
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const { data: session } = useSession() 
    let projectArray: any = []
    const [totalItems, setTotalItems] = useState(0);
    
    useEffect(() => {
        getProjectData()
    }, [])
    
    let selectedProjectId = selectedProject?.selectedValue !== 'null'  ? selectedProject?.selectedValue?.id : 'null' //'not-selected';
    useEffect(() => {
            if(![0, 1, 3].includes(session?.user?.role_id)){ 
                setQueryParams((preValue: any) => {
                    return { ...queryParams, ['projectId']: selectedProjectId }
                }) 
            } 
    },[selectedProject?.selectedValue]) 

    useEffect(() => {
        if(Object.keys(queryParams).length > 0 ){
            getAllSiteInventory()
        }
        if([0, 1, 3].includes(session?.user?.role_id)){
            getAllSiteInventory()
        }
    }, [queryParams, page, rowsPerPage])

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage+1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {  
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1);
    };


    const getAllSiteInventory = async () => { 
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
        const res = await handleGetSiteInventory(`${site_inventory_url}/?page=${page}&limit=${rowsPerPage}&${searchParams}`)
        return res;
    };

    const getProjectData = async () => { 
    const res = await handleGetProjectData(`${projects_url}?/page=1&limit=100`);
    return res;
    }

    resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
     return projectArray.push({ id: Item?.id, name: Item?.projectName })
    });

    useEffect(() => { 
        setSelectedProject(projectArray)
    }, [resProjectData?.items])
 
    useEffect(() => { 
        setTotalItems(resSiteInventory?.metadata?.totalItems) 
        const filteredSiteInventory = resSiteInventory?.items?.filter((sItem: any) => sItem?.siteInventoryTypeId == 1)
        const projectData = filteredSiteInventory?.map((item: any, index: number) => {
            const type = item?.typeId === 1 ? "Material" : "Machinery";
            const logsData = item.logsData?.length ? item?.logsData : [];
            return createData(
                item?.siteInventoryId,
                (page - 1) * rowsPerPage + index + 1,
                item?.siteInventoryRequestId ,
                item?.categoryName,
                item?.projectName,
                item?.productName,
                item?.itemName,
                item?.productSpecification,
                item?.productSize,
                item?.requesterName,
                item?.siteInventoryAvailableQuantity,
                item?.siteInventoryReceivedQuantity,
                item?.siteInventoryUsedQuantity,
                logsData,
                item?.productUnit
            );
        });       
        setData(projectData);
    }, [resSiteInventory?.items]);
 
    const filterByProject = (param:any) => {
        setQueryParams((prev) => {
            return {...queryParams, ['projectId'] : param}
        })
        setPage(1)
    } 

    const searchTableData = async (value: any) => { 
        setQueryParams((prevValue: any) => {
            return { ...queryParams, ['searchTerm']: value }
        })  
        setPage(1)
    };
 
    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
        let url = `${site_inventory_url}/?type=xls&${searchParams}`
        const res = handleDownloadData(url, "Site Inventory")
        return res;
    }

    const resetFilter = async() => { 
        if(![0, 1, 3].includes(session?.user?.role_id)){ 
            setQueryParams((preValue: any) => {
                return { ['projectId']: selectedProjectId }
            })  
            setSelectedFilterProject('')
        }else{ 
            setQueryParams({})
            setSelectedFilterProject('')
        }
        await getAllSiteInventory()
    } 
   
    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Site Inventory </Heading>
                    </Blankbox>
                </HeadingBox>

                <TableBox>
                    <TableContainer>
                        <TableMain
                            isLoading={loading}
                            columns={siteInventoryColumns}
                            handleExcelExport={handleExcelExport}
                            rows={data}
                            page={page}
                            rowsPerPage={rowsPerPage}
                            handleChangePage={handleChangePage}
                            handleChangeRowsPerPage={handleChangeRowsPerPage}
                            refreshTableData={getAllSiteInventory}
                            title={'Site Inventory'}
                            searchTableData={searchTableData}
                            resetFilter={resetFilter}
                            filterByProject={filterByProject}
                            projectItems={selectedProjects}
                            selectedFilterProject={selectedFilterProject} 
                            setSelectedFilterProject={setSelectedFilterProject} 
                            totalItems={totalItems}
                       />
                    </TableContainer>
                </TableBox>
            </Wrapper> 
        </>
    );
};

export default SiteInventory; 
