'use client'
import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  Dialog, AppBar, Toolbar, Typography, DialogContent, DialogActions, Button, Box, IconButton
} from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { theme } from 'src/common/styles/theme';

interface UploadBrandDialogProps {
  open: boolean;
  loading: boolean;
  file: File | null;
  setOpen: (value: boolean) => void;
  setFile: (file: File | null) => void;
  handleUpload: () => void;
  title?: string;
}

const UploadDialog: React.FC<UploadBrandDialogProps> = ({
  open,
  loading,
  file,
  setOpen,
  setFile,
  handleUpload,
  title
}) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
    }
  }, [setFile]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: false,
    accept: {
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    }
  });

  return (
    <Dialog fullWidth maxWidth="md" open={open} onClose={() => (setOpen(false), setFile(null))}>
      <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
        <Toolbar>
          <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
            {title || "Upload Excel"}
          </Typography>
          <DialogActions>
            <IconButton onClick={() => (setOpen(false), setFile(null))}>
              <ClearIcon sx={{ color: 'white' }} />
            </IconButton>
          </DialogActions>
        </Toolbar>
      </AppBar>

      <DialogContent>
        <Box
          {...getRootProps()}
          sx={{
            border: '2px dashed #ccc',
            padding: 4,
            textAlign: 'center',
            cursor: 'pointer',
            borderRadius: 2,
            backgroundColor: isDragActive ? '#f5f5f5' : 'transparent'
          }}
        >
          <input {...getInputProps()} />
          <CloudUploadIcon fontSize="large" sx={{ color: '#666' }} />
          <Typography mt={2}>
            {isDragActive ? 'Drop the file here…' : 'Drag and drop a file here or click'}
          </Typography>
          {file && (
            <Typography variant="subtitle2" mt={1} color="primary">
              Selected: {file.name}
            </Typography>
          )}
        </Box>
      </DialogContent>

      <DialogActions sx={{justifyContent: 'end', padding: '16px' }}>
        <Button
          variant="contained"
          onClick={handleUpload}
          disabled={loading || !file}
          sx={{ color: '#fff !important' }} 
        >
          {loading ? 'Uploading...' : 'Submit'}
        </Button>
        <Button
          variant="outlined"
          onClick={() => (setOpen(false), setFile(null))}
        >
          Cancel
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default UploadDialog;
