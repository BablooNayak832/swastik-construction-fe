import { MenuItem as MenuItemType } from '../../constants/menu-items';
import React from 'react';
import { Menu } from '../../common/styles/MenuItem/styles';
import MenuItem from '../MenuItem/MenuItem';
import { usePathname } from 'next/navigation';
import { useSession } from 'next-auth/react';
import {Tooltip} from '@mui/material';

type MenuItemsListProps = {
  options: MenuItemType[];
  open?: boolean;
};

export default function MenuItemsList({ options, open }: MenuItemsListProps) {
  const path = usePathname();
  const { data } = useSession();
  const isSubMenuItem = options?.subItems?.length ? "true" : "false";

  return (
    <>
      {options?.map((option) => {
        const isSelected = option?.url == path;
        return option?.role?.includes(data?.user?.role_id) && (
          <Tooltip key={option?.id} title={!open ? option.name : ''} placement="right">
          <Menu key={option.id}>
            <div className={`menu-item-parent ${isSubMenuItem ? 'sub-menu-item' : ''} ${isSelected ? 'selected' : ''}`}>
              <MenuItem isSelected={isSelected} menuItem={option} open={open} />
            </div>
          </Menu>
          </Tooltip>
        );
      })}
    </>
  );
}
