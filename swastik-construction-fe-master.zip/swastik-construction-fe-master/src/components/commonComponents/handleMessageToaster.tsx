const handleMessageToaster = (param: any, title?: any) => { 
    
    let message;
    if (param?.status == 200) {
        switch (param.data.MESSAGE) {
            case 'PROJECT_ASSIGN_SUCCESSFULLY':
                message = 'PROJECT ASSIGN SUCCESSFULLY';
                break;
            case 'SUCCESSFULLY_DELETE_STORE':
                message = 'Successfully Delete Store!';
                break;
            case 'SUCCESSFULLY_DELETE_VENDOR':
                message = 'Successfully Delete Vendor!';
                break;
            case "return request accepted":  
                message = 'Return request accepted';
                break;
            case "SUCCESSFULLY_DELETE":
                message = 'Successfully Delete';
                break;
            default:
                message = "Success";
                break;
        }
        switch (title) {
            case 'Add Type':
                message = 'Type Added successfully';
                break;
            case 'Add Brand':
                message = 'Brand Added successfully';
                break;
            case 'Create Category':
                message = 'Category Added Succesfully!';
                break;
            case 'Create Sub Category':
                message = 'Sub-Category Added Succesfully!';
                break;
            default:
                message = 'Success...';
                break;
        }

    } else {
        switch (param?.response?.data?.MESSAGE) {
            case 'mobile number already exist':
                message = 'Mobile number already exist'
                break;
            case 'PROJECT_DOES_NOT_END_BELOW_START_ DATE_AND_PROJECT_WILL_NOT_END_FOR_FUTURE_DATE':
                message = 'Date is not a valid';
                break;
            case 'File too large':
                message = 'File too large';
                break;
            case 'ERROR.TYPE_ALREADY_EXIST':
                message = 'Type Already Exist';
                break;
            case 'ERROR.BRAND_ALREADY_EXIST':
                message = 'Brand Already Exist';
                break;
            case 'ERROR_BRAND_ALREADY_EXIST':
                message = 'Brand Already Exist';
                break;
            case 'ERROR_SUB_CATEGORY_ALREADY_EXIST':
                message = 'Sub Category Already Exists!';
                break;
            case 'ERROR_CATEGORY_ALREADY_EXIST':
                message = 'Category Already Exists!';
                break;
            case 'STORE_NAME_AND_LOCATION_ALREADY_EXISTS':
                message = 'Store name or location already exists!';
                break;
            case 'ERROR_MOBILE_ALREADY_EXIST':
                message = 'Phone Number Already Exists!';
                break;
            case 'MOBILE_ALREADY_EXIST': 
                message = 'Mobile Number Already Exists!';
                break;
            case 'ERROR_EMAIL_ALREADY_EXIST':
                message = 'Email Address already exists!';
                break;
            case 'ERROR.QUANTITY_IS_NOT_AVAILABLE':
                message = 'Quality is not available';
                break;
            case 'Unexpected field':
                message = 'Unexpected field';
                break;
            case "File too large":
                message = "File too large";
                break;
            case "all quantity of material 66 is verified":
                message = "All quantity of material 66 is verified";
                break; 
            default:
                message = "Something went wrong";
                break;
        }
    }
 
    return message;

}

export const handleValidateForm = (formData: any, title?: any, userRole?: number) => {
    const errors: { [key: string]: string } = {};
    var reMobile = /^[0]?[6789]\d{9}$/;
    let gstinformat = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]{1}[0-9Z]{1}$/;
    let reName = /\d/;
    const imageSizeInBytes: any = formData?.image?.size;
    const imageSizeInKB: any = imageSizeInBytes / 1024;

    switch (title) {
        case 'Add Project':
            if (!formData?.projectName) {
                errors.projectName = 'Project name is required';
            }
            if (!formData?.location) {
                errors.location = 'Location is required';
            }
            if(userRole !== 2){
                if (!formData?.startDate) {
                    errors.startDate = 'Date is required.';
                }
                if (!formData?.projectHead) {
                    errors.projectHead = "Project Head is required";
                }
            }
            if (!formData?.siteId) {
                errors.siteId = 'Project id is required.';
            }
            break;
        case 'Add User':
            if (!formData?.name) {
                errors.name = 'Name is required.';
            } else {
                delete errors.name;
            } 
            if (formData?.email) {
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData?.email)) {
                    errors.email = 'Invalid email format.';
                } else {
                    delete errors.email;
                }
            } 
            if (!formData?.mobileNumber) {
                errors.mobileNumber = 'Number is required.';
            } else if (formData?.mobileNumber.length < 10) {
                errors.mobileNumber = 'Number must have 10 digits.';
            } else if (!reMobile.test(formData?.mobileNumber)) {
                errors.mobileNumber = 'Number is not a valid mobile number.';
            } else {
                delete errors.mobileNumber;
            }
            if (!formData?.roleId) {
                errors.roleId = 'Please select a role.';
            } else {
                delete errors.roleId;
            }

            // if (formData?.roleId === 4 || formData?.roleId === 5) {
            //     if (!formData?.projectId) {
            //         errors.projectId = 'Please select a project.';
            //     } else {
            //         delete errors.projectId;
            //     }
            // }
            if (!formData?.password) {
                errors.password = 'Password is required';
            } else if (formData?.password?.length < 8) {
                errors.password = 'Password must be at least 8 characters';
            } else {
                delete errors.password;
            }
            break;
        case 'Add Material':
            if (!formData?.productName) {
                errors.productName = 'Material name is required';
            } else {
                delete errors.productName;
            }
            if (!formData?.categoryId) {
                errors.categoryId = 'Category is required.';
            } else {
                delete errors.categoryId;
            }
            if (!formData?.unit) {
                errors.unit = 'Unit is required.';
            } else {
                delete errors.unit;
            }
            break;
        case 'Material Request':
            if (!formData?.projectId) {
                errors.projectId = 'Please select a project.';
            } else {
                delete errors.projectId;
            }
            break;
        case 'Add Staff':
            if (!formData?.name) {
                errors.name = 'Name  is required';
            } else {
                delete errors.name;
            }
            if (!formData?.projectId) {
                errors.projectId = 'Please select a project.';
            } else {
                delete errors.projectId;
            }

            if (!formData?.mobileNumber) {
                errors.mobileNumber = 'Number is required.';
            } else if (formData?.mobileNumber.length < 10) {
                errors.mobileNumber = 'Number must have 10 digits.';
            } else if (!reMobile.test(formData?.mobileNumber)) {
                errors.mobileNumber = 'Number is not a valid mobile number.';
            } else {
                delete errors.mobileNumber;
            }
            if (!formData?.image) {
                errors.image = 'Image is required.';
            } else if (imageSizeInKB >= 300) {
                errors.image = 'Please upload an image smaller than 300kb.';
            } else {
                delete errors.image;
            }
            break;
        case 'Add Vendor':
            if (!formData?.name) {
                errors.name = 'Vendor name is required.';
            } else {
                delete errors.name;
            }
            if (!formData?.address) {
                errors.address = 'Address is required.';
            } else {
                delete errors.address;
            }

            if (!formData?.contact) {
                errors.contact = 'Contact number is required.';
            } else if (formData?.contact.length < 10) {
                errors.contact = 'Contact number must have 10 digits.';
            } else if (!reMobile.test(formData?.contact)) {
                errors.contact = 'Number is not a valid number.';
            } else {
                delete errors.contact;
            }

            if (!formData?.GSTIN) {
                errors.GSTIN = 'GSTIN is required.';
            } else if (gstinformat.test(formData?.GSTIN)) {
                errors.GSTIN = 'Please Enter Valid GSTIN Number';
            } else {
                delete errors.GSTIN;
            }
            break;
        case 'Material Request':
            if (!formData?.machineryOrPrductId) {
                errors.machineryOrPrductId = 'Material is required.';
            } else {
                delete errors.machineryOrPrductId;
            }
            if (!formData?.categoryId) {
                errors.categoryId = 'Category is required.';
            } else {
                delete errors.categoryId;
            }
            if (!formData?.quantity) {
                errors.quantity = 'Quantity is required.';
            } else {
                delete errors.quantity;
            }
            break;
        case 'Add Brand': 
            if (!formData?.brandName) {
                errors.brandName = 'Brand name is required.';
            } else {
                delete errors.brandName;
            }
            if (!formData?.type?.length) {
                errors.type = 'Type is required.';
            } else {
                delete errors.type;
            }
            break;
        case 'Add Category':
            if (!formData?.categoryName) {
                errors.categoryName = 'Category name is required.';
            } else {
                delete errors.categoryName;
            }
            if (!formData?.type?.length) {
                errors.type = 'Type is required.';
            } else {
                delete errors.type;
            }
            break;
        default:
            break;
    }
    return errors;

}

export default handleMessageToaster;