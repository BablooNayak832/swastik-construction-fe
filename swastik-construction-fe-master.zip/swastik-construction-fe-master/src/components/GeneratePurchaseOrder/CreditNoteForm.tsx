import React, {useEffect, useState} from 'react'
import _ from 'lodash';
import {Button, ButtonGroup, Grid, IconButton, Input, List, ListItem, ListItemText, Paper, Popover, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Typography} from '@mui/material';
import {Delete, Visibility} from '@mui/icons-material';
import {useParams} from 'next/navigation';
import getRequestAPI from '../../services/getRequest';
import {purchase_order_detail_url} from '../../constants/api-routes';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import {downloadComponentAsPDF} from '../../utils/pdfUtils';
import usePost from '../../hooks/usePost';
import {useSession} from 'next-auth/react';
import usePatch from '../../hooks/usePatch'; 
import {formatString, stringCapitalization} from '../../utils/formatString';
import moment from 'moment';


function createData(
    purchaseOrderNo: any,
    poItemId?: string,
    reqId: string,
    status: string,
    orderItems: any,
    vendorName?: any,
    creditNoteStatus?: string,
    projectName?: string,
    createdAt?: string,
): any {
    return { purchaseOrderNo, poItemId, reqId, status, orderItems , vendorName, creditNoteStatus, projectName, createdAt };
}

function createVendorItemsData(
    sNo: number,
    poItemId: string,
    vendorName?: string,
) {
    return {
        sNo,
        poItemId,
        vendorName,
    }
}

function createItemsData(
    sNo: number,
    poItemId: string,
    reqId: string,
    productName: string,
    productId: any,
    itemName: string,
    specification: string,
    size: string,
    unit: string,
    quantity: any,
    notDeliveredQuantity:any,
    brandName: string,
    vendorName: string,
    remark:string,
) {
    return {
        sNo,
        poItemId,
        reqId,
        productName,
        productId,
        itemName,
        specification,
        size,
        unit,
        quantity,
        notDeliveredQuantity,
        brandName,
        vendorName,
        remark
    }
}

const CreditNoteForm = ({data ,createCreditNote, fetchData}:any) => {  
    const [creditNoteData, setCreditNoteData] = useState<any>([])
    const params = useParams<{ tag: string; item: string }>()
    const [orderDetailData, setOrderDetailData] = useState([])
    const [loading, setLoading] = useState(false)
    const [openCreditNote , setOpenCreditNote] = useState(false) 
    // const [openDeletePopup, setOpenDeletePopup ] = useState(true)
    const { handlePostData  } = usePost()
    const { data: session } = useSession()
    const {handleUpdateData} = usePatch() 
    const [creditItemData, setCreditItemData] = useState<any>([])
    const [enableEditIcons, setEnableEditIcons] = useState(null)
    const [ editCreditData, setEditCreditData] = useState({})
 
    useEffect(() => {
        getDetailsOfPurchaseOrder()
    }, [])

    // get details of purchase order 
    const getDetailsOfPurchaseOrder = async () => {
        setLoading(true)
        try {
            const getDetailsOfPurchaseOrder = getRequestAPI(`${purchase_order_detail_url}/${params.id}`)
                .then((response: any) => {
                    if (!!response?.data) {
                        setLoading(false)
                        setOrderDetailData(response?.data)
                    }
                })
            return getDetailsOfPurchaseOrder;
        } catch (error) {
            return error;
        }
    }

    let reqId: string, status: string, poItemId:string, createOrderedItems, vendorName, createdAt;
    let purchaseOrderNo: number;
    const orderDetails = orderDetailData?.map((i: any, idx: any) => {
        let orderedItems: any = [];
        i?.items?.map((order: any, index: number) => { 
            let isNotDeliveredQty =  order?.vendorItems?.filter(item => item?.notDeliveredQuantity > 0 )?.length;
            if(!!isNotDeliveredQty){
                purchaseOrderNo = params?.id;
                poItemId = order?.poItemId;
                vendorName = order?.vendorName;
                createOrderedItems = createVendorItemsData(index + 1, poItemId, vendorName);
                orderedItems.push(createOrderedItems);
                createdAt = '';
            }
        })
        return createData(purchaseOrderNo, poItemId, reqId, status, orderedItems, '' ,i?.creditNoteStatuses , createdAt )
    });

    const mergeQuantities = (data:any) => {
        const merged :any= {};  
        data.forEach((item:any) => {
          const { productId, quantity} = item; 
          if (merged[productId]) {
            merged[productId].quantity += quantity; 
          } else {
            merged[productId] = { ...item };
          }
        });  
        return Object.values(merged);
    }
    // This function for get details of credit note data
    const getDetailsOfCreditNote = (poId:any) => { 
        let reqId: string, status: string, remark: string, createdAt: string, creditNoteStatus:string ,poItemId:string,poItems:any ,productName, projectName:string, productId, itemName, specification, size, unit, notDeliveredQuantity, orderedQty, createOrderedItems, vendorName: string, brandName: string;
        setOpenCreditNote(true)   
        const poDetails = orderDetailData?.map((i: any, idx: any) => { 
            let orderedItems: any = [];
            i?.items?.map((order: any, index: number) => {
                if (order?.poItemId == poId) {  
                    reqId = _.uniq(order?.vendorItems?.map(i => i?.requestId)).join(', ');
                    order?.vendorItems?.filter(fItem => (fItem?.notDeliveredQuantity !== 0))?.map((vItem: any) => { 
                        poItemId = vItem?.poItemId;
                        productName = vItem?.materialDetails?.productName;
                        productId = vItem?.materialId;
                        itemName = vItem?.materialDetails?.itemName !== null ? vItem?.materialDetails?.itemName : "_";
                        specification = vItem?.materialDetails?.specification !== null ? vItem?.materialDetails?.specification : "_";
                        size = vItem?.materialDetails?.size !== null ? vItem?.materialDetails?.size : "_";
                        unit = vItem?.materialDetails?.unit;
                        orderedQty = vItem?.quantity;
                        notDeliveredQuantity = vItem?.notDeliveredQuantity;
                        status = formatString(vItem?.status);
                        brandName = vItem?.brandDetails?.brandName !== null ? vItem?.brandDetails?.brandName : "_";
                        vendorName = vItem?.vendorDetails?.name;
                        creditNoteStatus = vItem?.creditNoteStatus;
                        projectName = vItem?.projectDetails?.projectName;
                        remark = vItem?.remark;
                        createdAt = vItem?.createdAt;
                        createOrderedItems = createItemsData(index + 1, poItemId, reqId, productName, productId, itemName, specification, size, unit, orderedQty, notDeliveredQuantity,brandName, vendorName, remark);
                        orderedItems.push(createOrderedItems);
                        poItems = mergeQuantities(orderedItems)  
                    })
                }
            }) 
            setCreditItemData(poItems)
            return createData(i?.purchaseOrderNo, poItemId ,reqId, status, orderedItems, vendorName, creditNoteStatus, projectName, createdAt )
         }); 
         setCreditNoteData(poDetails)
         setOpenCreditNote(!openCreditNote)
    } 
    
    // This function for generating the credit note
    const generateCreditNote = async(status:string|null|undefined) => {
    const payloadFormData:Array<any> = []  
    creditNoteData[0]?.orderItems?.map((item) => {
                payloadFormData.push({
                purchaseOrderNumber : orderDetailData?.[0]?.purchaseOrderNo,
                materialId : item?.productId,
                quantity : item?.notDeliveredQuantity,  
                requestId : item?.reqId
                })
    })  
   
    // createCreditNote(payloadFormData) 
        await handlePostData('/credit-note', payloadFormData)
        setOpenCreditNote(false) 
        fetchData() 
        getDetailsOfPurchaseOrder()
        setOpenCreditNote( false )
    }  

    // function for approval / rejection of credit note 
    const handleApproval = async(poNo:any,status:string) => {
     const payload = {
            "purchaseOrderNumber": poNo,
            "status":status
       }
      await handleUpdateData('/credit-note', payload)
      fetchData()
      getDetailsOfPurchaseOrder()
      setOpenCreditNote(false)
    }

    const handleChange = (e: any, data?:any) => { 
        const value = e.target.value;  
        const regex = /^[1-9]\d*$/;  
            if ((value === '' || regex.test(value)) 
               && (data?.notDeliveredQuantity >= value )
            ) { 
                setEditCreditData(prevState => ({
                    ...prevState,
                    ['quantity']: value,  
                }));
            } 
    }

    // const handleSave = (id: any) => { 
    //     let copyData :any = [...creditItemData]
    //     copyData[id] = { ...creditItemData[id], ['quantity']: editCreditData?.quantity  }
    //     setCreditItemData(copyData) 
    //     setEnableEditIcons(null)
    // };

    // const editCreditNoteQty = (id: any, value: any) => {
    //     setEnableEditIcons(id)
    //     setEditCreditData(value) 
    // } 
 
    return !orderDetails[0]?.creditNoteStatus?.every((i) => i === "delivered")  ? (
           <> 
             { !openCreditNote ? 
             <>
              {
               loading ? <h1>Loading...</h1> :
               orderDetails?.map((orderItem: any, index) => {                 
                  return (
                        <>
                            <Grid container spacing={2} key={index}>
                                <Grid item lg={4} xs={3} md={3}>
                                    <List>
                                        <ListItem>
                                            <ListItemText primary={<strong>Purchase Order No.</strong>} secondary={orderItem?.purchaseOrderNo} />
                                        </ListItem>
                                    </List>
                                </Grid>

                                <Grid item lg={12} xs={12} md={12}>
                                    <TableContainer component={Paper}>
                                        <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell sx={{fontWeight: 'bold'}} width={'20px'}>S No.</TableCell>
                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>PO Item Id</TableCell>
                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Vendor</TableCell>
                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'70px'}>Action</TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody> 
                                                {orderItem?.orderItems?.map((row, i: number) => {
                                                    return ( 
                                                        <>
                                                            {
                                                                <TableRow key={row?.name}>
                                                                    <TableCell >{i + 1}</TableCell>
                                                                    <TableCell align="left" >{row?.poItemId?.length ? row?.poItemId : "_"}</TableCell>
                                                                    <TableCell align="left" >{row?.vendorName}</TableCell>
                                                                    <TableCell align="left">
                                                                        <IconButton onClick={() => { 
                                                                            getDetailsOfCreditNote(row?.poItemId)
                                                                        }}>
                                                                            <Visibility color='success'/>
                                                                        </IconButton>
                                                                    </TableCell>
                                                                </TableRow>
                                                            }
                                                        </>
                                                    )
                                                }
                                                )}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Grid>
                                <Grid item lg={12} xs={12} md={12}>
                                    {((orderItem?.creditNoteStatus?.every((status:any) => ((status === 'generated') || (status === "delivered")))) && ([0,1].includes(session?.user?.role_id)) ) && 
                                    <ButtonGroup style={{float:'right'}}> 
                                        <Button disabled={!orderItem?.creditNoteStatus?.includes('generated')} variant='outlined' sx={{float: 'right'}} size="small" onClick={() => handleApproval( orderDetailData?.[0]?.purchaseOrderNo,'rejected')}>Reject</Button>
                                        <Button disabled={!orderItem?.creditNoteStatus?.includes('generated')}  variant='contained' sx={{float: 'right'}} size="small" onClick={() => handleApproval( orderDetailData?.[0]?.purchaseOrderNo,'approved')}>Approve</Button>
                                    </ButtonGroup>} 
                                </Grid>
                            </Grid>
                        </>
                    )
                })
               } 
             </>
              :
              <div id='purchase-order-form'> 
                        {loading ? <h1>Loading...</h1> :
                            creditNoteData?.map((orderItem: any, index:number) => {                                  
                                return (
                                    <>
                                        <Grid lg={12} xs={12} md={12} key={index}> 
                                            <IconButton sx={{color: 'red', padding: 0}} onClick={() => setOpenCreditNote(!openCreditNote)}><ArrowBackIcon/></IconButton> 
                                            {(((orderItem?.creditNoteStatus == "generated")  || (orderItem?.creditNoteStatus == 'approved') ) && ([0,1,3].includes(session?.user?.role_id))) &&
                                                <Button variant='outlined' sx={{float: 'right', color: 'red'}} onClick={() => downloadComponentAsPDF('credit-note-layout', `${orderItem?.projectName}_${orderItem?.poItemId}_Credit Note`)}>
                                                   Download PDF
                                                </Button>}  
                                        </Grid>
                                        <Grid id='credit-note-layout' container spacing={2}>
                                            <Grid item lg={12} xs={12} md={12}>
                                                <Typography sx={ { ml: 0, flex: 1 } } variant="h6" component="div">
                                                    CREDIT NOTE 
                                                </Typography>
                                            </Grid>
                                            <Grid item lg={6} xs={6} md={6}> 
                                                  <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong> Project : </strong>  {orderItem?.projectName}</span>
                                                        </div>
                                                    );
                                                    }} />
                                                 <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong>PO Item ID : </strong>  {orderItem?.poItemId}</span>
                                                        </div>
                                                    );
                                                    }} />
                                                 <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong> Request No. : </strong>  {orderItem?.reqId}</span>
                                                        </div>
                                                    );
                                                    }} />
                                                 <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong> Status : </strong>  {stringCapitalization(orderItem?.creditNoteStatus)}</span>
                                                        </div>
                                                    );
                                                    }} />
                                                 <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong> Vendor Name : </strong>  {orderItem?.vendorName}</span>
                                                        </div>
                                                    );
                                                    }} />
                                                 <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong> Date : </strong>  {moment(orderItem?.createdAt)?.format('DD/MM/YYYY')}</span>
                                                        </div>
                                                    );
                                                    }} />
                                            </Grid>  
                                         
                                            <Grid item lg={12} xs={12} md={12}>
                                                <TableContainer component={Paper}>
                                                    <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell sx={{fontWeight: 'bold'}} width={'20px'}>S No.</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Material Name</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Type / Grade</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Specification</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Size</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Ordered Qty.</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Credit Qty</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Unit</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Brand Name</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Remark</TableCell>                                                                
                                                                 {/* {((orderItem?.creditNoteStatus ==='partialDelivered') && (!!data?.image) && ( session?.user?.role_id === 3)) &&
                                                                   <TableCell align="left" width={'20px'}>Action</TableCell> } */}
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            {  creditItemData?.length === 0 ? <>
                                                             <TableRow>
                                                             <TableCell colSpan={8} sx={{textAlign:'center'}}> 
                                                                <h2>No Data available</h2>
                                                              </TableCell>
                                                              </TableRow>
                                                            </> :
                                                            creditItemData?.map((row: any, i ) => {
                                                              return (
                                                                    <>
                                                                        {row?.productName !== undefined &&
                                                                            <TableRow key={i}>
                                                                                <TableCell>{i + 1}</TableCell>
                                                                                <TableCell align="left" >{row?.productName}</TableCell>
                                                                                <TableCell align="left" >{row?.itemName ?? "_"}</TableCell>
                                                                                <TableCell align="left" >{row?.specification?.length ? row?.specification : "_"}</TableCell>
                                                                                <TableCell align="left" >{row?.size?.length ? row?.size : "_"}</TableCell>
                                                                                <TableCell align="left" >{row?.quantity ?? "_" }</TableCell>
                                                                                <TableCell align="left" > {row?.notDeliveredQuantity ?? "_"}</TableCell>
                                                                                <TableCell align="left" >{row?.unit}</TableCell>
                                                                                <TableCell align="left" >{row?.brandName !== undefined ? row?.brandName : '_'}</TableCell>
                                                                                <TableCell align="left" width={'20px'}>{row?.remark}</TableCell>
                                                                               {/* {  ((orderItem?.creditNoteStatus ==='partialDelivered') && (!!data?.image) && (session?.user?.role_id === 3)) &&
                                                                                <TableCell align="left">
                                                                                    <div style={{display:'flex'}}>
                                                                                    { enableEditIcons !== row?.productId ? (
                                                                                    <>
                                                                                    {<Tooltip title={"Edit"}> 
                                                                                        <IconButton>
                                                                                            <EditIcon onClick={() => editCreditNoteQty(row?.productId, row)} color='success' />
                                                                                        </IconButton>
                                                                                    </Tooltip>}
                                                                                    </>
                                                                                    ) : (
                                                                                    <>
                                                                                    <Tooltip title={"Save"}>
                                                                                        <IconButton> 
                                                                                            <SaveIcon onClick={() => handleSave(i)} color='success' />
                                                                                        </IconButton>
                                                                                    </Tooltip>
                                                                                    </>
                                                                                    )} 
                                                                                    <IconButton onClick={() => {  
                                                                                        setOpenDeletePopup(!openDeletePopup) 
                                                                                        const updatedItem = creditItemData?.filter((obj) => obj.productId !== row?.productId);
                                                                                        setCreditItemData(updatedItem) 
                                                                                    }}> 
                                                                                         <Delete/>
                                                                                    </IconButton>
                                                                                    </div>
                                                                                </TableCell> } */}
                                                                            </TableRow>}
                                                                    </>
                                                                ) }
                                                            )}
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            </Grid>   
                                            <Grid item lg={12} xs={12} md={12}> 
                                                {((data?.status === "approvalPending") && (session?.user?.role_id === 3)) && 
                                                    ((orderItem?.creditNoteStatus ==='partialDelivered') || (orderItem?.creditNoteStatus === "rejected") && (!!data?.image) && ( session?.user?.role_id === 3) ) && 
                                                    <>
                                                    { (creditItemData?.length !== 0) && 
                                                    <Button variant='contained' sx={{float: 'right'}} size='small' onClick={generateCreditNote}>Generate Credit Note</Button> }
                                                </>}
                                            </Grid>
                                        </Grid>
                                    </>
                                )
                            })
                        }
              </div>}  
           </>
         ) : <Typography sx={ { ml: 2, my: 10, flex: 1, textAlign: 'center' } } variant="h6" component="div">
               No Data Available
            </Typography> 
}

export default CreditNoteForm; 