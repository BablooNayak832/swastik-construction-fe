import React, { useEffect, useRef, useState } from 'react'
import { Wrapper } from '../../app/styles'
import { Heading, HeadingBox } from '../../common/styles/Users/styles'
import { Blankbox } from '../Table/styles'
import { AppBar, Autocomplete, Button, Checkbox, Dialog, DialogActions, DialogContent, FormControl, FormHelperText, Grid, IconButton, Input, InputLabel, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Toolbar, Tooltip, Typography } from '@mui/material'
import getRequestAPI from '../../services/getRequest'
import { ContainerMain, MainBox } from '../../common/styles/Dashboard/styles'
import { Asterisk, MainFormLayout } from '../Modal/styles'
import usePost from '../../hooks/usePost'
import { useRouter } from 'next/navigation'
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import _ from 'lodash'
import { ClearIcon } from '@mui/x-date-pickers'
import { theme } from '../../common/styles/theme'
import { purchase_order_url } from '../../constants/api-routes'
import { toast } from 'react-toastify'
import { Delete } from '@mui/icons-material' 
import ConfirmationDialog from '../ui/ConfirmationDialog'

const checkedIcon = <CheckBoxIcon fontSize="small" />;
const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;

const GeneratePurchaseOrder = ({searchParamObj}:any ) => { 
    const router = useRouter()
    const [apiData, setAPIData] = useState<any>(null)
    const [orderFormData, setOrderFormData] = useState<any>({})
    const [approvedReqList, setApprovedReqList] = useState<any>([])
    const { resData, handlePostData, error } = usePost()
    const [itemsData, setItemsData] = useState<any>([])
    const [reqItems, setReqItems] = useState<any>([])
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const [projectListData, setProjectListData] = useState([])
    const [useStockModal, setUseStockModal] = useState(false)
    const [useStockData, setUseStockData] = useState<any>({})
    const [centralData, setCentralData] = useState<any>({})
    const [selectedProject, setSelectedProject] = useState<any>({})
    let requestRef = useRef() 
    const [openConfirm, setOpenConfirm] = useState(false);
    const [selectedFileIndex, setSelectedFileIndex] = useState(null);
  

    const getAPICall = async () => {
        try {
            const res = await getRequestAPI(`${purchase_order_url}?page=1&limit=1000&verified=true`)
            if (res?.status === 200) {  
                setAPIData(res?.data);
                setProjectListData(res?.data?.projectData)
            }
        } catch (error) {
            return error;
        }
    }   
 
    const validateMaterial = () => {
        const errors: { [key: string]: string } = {}; 
        if (!orderFormData.request) {
            errors.request = 'Please select request';
        } else {
            delete errors.request;
        } 
        setFormErrors(errors)
        return Object.keys(errors).length === 0;
    }
    
    const validateRequirement = (itemsData: []) => {
        let isValid = true; 
        let qtyError:any, vendorError:any, rateError :any, gstError:any;
         
           const updateItemData = itemsData.map((item:any) => { 
                if(item.poQuantity === ""){ 
                    qtyError = "Qty is required";
                }else{ 
                    qtyError = ""
                }
                if(item?.poQuantity !== ""){ 
                    if(item.poQuantity > 0 && ((!item.vendorId) || (item.vendorId === undefined))){    
                        isValid = false;
                        vendorError = "Vendor is required";
                    } 
                    if(item.poQuantity > 0 && (!item.rate)){ 
                        isValid = false;
                        rateError = "Rate is required";
                    } 
                    if(item.poQuantity > 0 && (!item.GST)){ 
                        isValid = false;
                        gstError = "GST is required";
                    } 
                }
                return {
                    ...item,
                    isQuantity: qtyError,
                    isVendorError: vendorError,
                    isRateError: rateError,
                    isGstError: gstError
                }; 
            });
            setItemsData(updateItemData)
            return isValid
    };

    const handleFormSubmit = async (e: any) => {
        e.preventDefault()
        let payload: any = []
        let isEmptyQty = itemsData?.filter(fItem => fItem?.poQuantity === '')?.length; 
        const isValid = validateMaterial();
        if (isValid) {
        const valid = validateRequirement(itemsData) 
               // Check if there are empty PO quantity fields
                if(!!isEmptyQty){
                toast.error("Please fill the required fields.", {autoClose:800})
                } 
 
                console.log("reqItems >>>>>>>>>>.", reqItems ,"itemsData>>>>>>>>>",itemsData);
               if(valid){ 
                   if(!isEmptyQty){ 
                       let remianingQyt :any =[];
                       let isCenterActive :any =[];
                       let remianingQytPO :any =[];
                       let isValueUseed :any =[];
                       let usedCenterCount:any=[];
                       let totalUsedCenterQuantity=0;
                       reqItems?.map((element: any) => {  
                       itemsData?.filter((fItem: any) => { 
                        console.log('loop running') 
                           // Check if the product exists and matches
                           if (element?.productDetails !== null && (element?.productDetails?.id === fItem?.productDetails?.id)) {   
                               let checkQty:any = null; 
                                // Check if the quantity is taken from the central inventory
                               if(fItem?.quantityFromCentral > 0){
                                   remianingQyt[element?.machineryOrPrductId] = remianingQyt[element?.machineryOrPrductId] ? remianingQyt[element?.machineryOrPrductId] : 0
                                // Check if PO quantity is greater than used central quantity
                                   if( element?.poQuantity > fItem?.quantityFromCentral ){ 
                                       console.log("isCenterActive", isCenterActive[element?.machineryOrPrductId])

                                       if(isCenterActive[element?.machineryOrPrductId]){
                                        // If remaining quantity is greater than PO quantity
                                           if( remianingQyt[element?.machineryOrPrductId] > element?.poQuantity){
                                               checkQty = 0
                                               remianingQyt[element?.machineryOrPrductId] = remianingQyt[element?.machineryOrPrductId] - element?.poQuantity;
                                               usedCenterCount[element?.machineryOrPrductId]=element?.poQuantity;
                                               totalUsedCenterQuantity+=usedCenterCount[element?.machineryOrPrductId]
                                               console.log("po qty>>>>>>>>.1", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);

                                           }else if(parseInt(fItem?.newQty) > 0){
                                               checkQty = parseInt(fItem?.newQty);
                                               if(totalUsedCenterQuantity < fItem?.quantityFromCentral){
                                                usedCenterCount[element?.machineryOrPrductId] = totalUsedCenterQuantity
                                               }else{
                                                usedCenterCount[element?.machineryOrPrductId] = fItem?.quantityFromCentral - totalUsedCenterQuantity
                                               }
                                              
                                               console.log("po qty>>>>>>>>.2", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);

                                          
                                           }else{
                                               checkQty = element?.poQuantity - remianingQyt[element?.machineryOrPrductId];
                                               usedCenterCount[element?.machineryOrPrductId] = remianingQyt[element?.machineryOrPrductId];
                                               remianingQyt[element?.machineryOrPrductId] =  0;  
                                               console.log("po qty>>>>>>>>.3", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                              
                                           } 
                                       }else{
                                         // If the center is not active, activate it
                                           isCenterActive[element?.machineryOrPrductId] = true;
                                           checkQty =  element?.poQuantity - fItem?.quantityFromCentral; 
                                           usedCenterCount[element?.machineryOrPrductId] = fItem?.quantityFromCentral;
                                           totalUsedCenterQuantity+=fItem?.quantityFromCentral
                                           console.log("po qty>>>>>>>>.4", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                       }   
                                   }else{       
                                    // Handle cases where PO quantity is less than or equal to central quantity                     
                                       if( isCenterActive[element?.machineryOrPrductId]){
                                           if( remianingQyt[element?.machineryOrPrductId] > element?.poQuantity){
                                               checkQty = 0
                                               remianingQyt[element?.machineryOrPrductId] = remianingQyt[element?.machineryOrPrductId] - fItem?.poQuantity;
                                               usedCenterCount[element?.machineryOrPrductId] = fItem?.poQuantity;
                                               console.log("po qty>>>>>>>>.5", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                            
                                           } else { 
                                            if(!Object.keys(fItem)?.includes('newQty')){
                                               checkQty = element?.poQuantity - remianingQyt[element?.machineryOrPrductId];
                                               usedCenterCount[element?.machineryOrPrductId] = remianingQyt[element?.machineryOrPrductId];
                                               totalUsedCenterQuantity +=usedCenterCount[element?.machineryOrPrductId];
                                               remianingQyt[element?.machineryOrPrductId] = 0 
                                               console.log("po qty>>>>>>>>.6", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                            }else{
                                                const remainingCenterQty = fItem?.quantityFromCentral - totalUsedCenterQuantity
                                                if(remainingCenterQty > element?.poQuantity){
                                                    checkQty = 0 
                                                    usedCenterCount[element?.machineryOrPrductId] = remainingCenterQty - element?.poQuantity;
                                                    remianingQyt[element?.machineryOrPrductId] = 0 
                                                    totalUsedCenterQuantity+= usedCenterCount[element?.machineryOrPrductId];
                                                    console.log(totalUsedCenterQuantity,"po qty>>>>>>>>.6.33", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                                }else{
                                                    checkQty = element?.poQuantity - remainingCenterQty;
                                                    usedCenterCount[element?.machineryOrPrductId] = remainingCenterQty;
                                                    totalUsedCenterQuantity+= usedCenterCount[element?.machineryOrPrductId];
                                                    remianingQyt[element?.machineryOrPrductId] = element?.poQuantity - remainingCenterQty
                                                }
                                            }

                                           } 
                                       }else{
                                            if(!Object.keys(fItem)?.includes('newQty')){
                                                checkQty = 0; 
                                                isCenterActive[element?.machineryOrPrductId] = true; 
                                                remianingQyt[element?.machineryOrPrductId] = fItem?.quantityFromCentral - element?.poQuantity;
                                                usedCenterCount[element?.machineryOrPrductId] = element?.poQuantity; 
                                                console.log(element,"po qty>>>>>>>>.7", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                            }else{
                                                isCenterActive[element?.machineryOrPrductId] = true; 
                                                usedCenterCount[element?.machineryOrPrductId] =  element?.poQuantity;
                                                remianingQyt[element?.machineryOrPrductId] =0;
                                                totalUsedCenterQuantity+= usedCenterCount[element?.machineryOrPrductId];
                                                checkQty = 0; 
                                                console.log("PO QTY>>>>", checkQty);
                                            }

                                       }   
                                   }
                               }else; 
                               if(!!Object.keys(fItem)?.includes('newQty')){   
                                   console.log("remianingQytPO >>>>>", remianingQytPO[element?.machineryOrPrductId]);
                                   if(remianingQytPO[element?.machineryOrPrductId] == undefined || (remianingQytPO[element?.machineryOrPrductId] < 1 && isValueUseed[element?.machineryOrPrductId]!== true)){
                                       remianingQytPO[element?.machineryOrPrductId] = parseInt(fItem?.newQty)
                                       isValueUseed[element?.machineryOrPrductId] = true
                                       // usedCenterCount[element?.machineryOrPrductId] = 0;
                                       console.log(fItem?.newQty,"po qty>>>>>>>>.8", checkQty,"remianingQyt---->>>>", remianingQytPO[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                   } 
                                  
                                   if(checkQty > 0){
                                       if( checkQty > remianingQytPO[element?.machineryOrPrductId]){
                                           checkQty = remianingQytPO[element?.machineryOrPrductId];
                                           remianingQytPO[element?.machineryOrPrductId] = 0
                                           console.log("po qty>>>>>>>>.9", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);

                                       }else{
                                            remianingQytPO[element?.machineryOrPrductId]-= checkQty;
                                            console.log("po qty>>>>>>>>.10", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                       }
                                       
                                   }else{
                                       if( element.poQuantity > remianingQytPO[element?.machineryOrPrductId] && (isCenterActive[element?.machineryOrPrductId] == false || isCenterActive[element?.machineryOrPrductId] == undefined) ){
                                           checkQty = remianingQytPO[element?.machineryOrPrductId];
                                           remianingQytPO[element?.machineryOrPrductId] = 0
                                           console.log("po qty>>>>>>>>.11", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);

                                       }else{
                                          if(checkQty !== 0){ 
                                              remianingQytPO[element?.machineryOrPrductId] -= fItem.poQuantity;
                                              checkQty= fItem.poQuantity;
                                              console.log("po qty>>>>>>>>.12", checkQty,"remianingQyt---->>>>", remianingQytPO[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                          } 
                                       }
                                   }
       
                               } else {  
                                   console.log(fItem?.poQuantity,"element?.poQuantity", element?.poQuantity);
                                   if(element?.poQuantity === parseInt(fItem?.poQuantity) && usedCenterCount[element?.machineryOrPrductId] === 0) {
                                       checkQty = parseInt(fItem?.poQuantity);
                                       console.log("po qty>>>>>>>>.13", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);

                                   } else if((parseInt(element?.poQuantity) + element?.creditQuantity) >= element?.remainingToVerified){ 
                                      
                                       if(fItem?.quantityFromCentral > 0){
                                        console.log("po qty>>>>>>>>.14", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);

                                       }else {
                                           checkQty = parseInt(element?.remainingToVerified)
                                           console.log("po qty>>>>>>>>.15", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                       }
       
                                   }else{ 
                                    if(!!element?.remainingToVerified && element?.creditQuantity === null){
                                        checkQty = parseInt(element?.remainingToVerified)
                                        console.log("po qty>>>>>>>>.16", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                    }else{
                                        if(element?.remainingToVerified > 0){ 
                                             checkQty = parseInt(element?.remainingToVerified) + element?.creditQuantity; 
                                        }else{ 
                                        checkQty = parseInt(element?.poQuantity) + element?.creditQuantity; 
                                        console.log("po qty>>>>>>>>.17", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                                        }
                                    } 
                                   }   
                                  
                               }

                               console.log("po qty>>>>>>>>.18", checkQty,"remianingQyt---->>>>", remianingQyt[element?.machineryOrPrductId], "usedCenterCount------->>", usedCenterCount[element?.machineryOrPrductId]);
                               
                                  if((checkQty !== null) && (checkQty !== NaN)) {  
                                      payload.push({
                                          requestId: element.requestId,
                                          materialId: element?.productDetails?.id,
                                          quantity: checkQty,
                                          assignTo: fItem?.vendorId,
                                          brandId: fItem?.brandId,
                                          projectId: selectedProject?.projectId,
                                          rate: fItem?.rate,
                                          GST: fItem?.GST,
                                          remark: fItem?.remark,
                                          quantityFromCentral: usedCenterCount[element?.machineryOrPrductId] ? usedCenterCount[element?.machineryOrPrductId] : '',
                                          CentralInventoryId: usedCenterCount[element?.machineryOrPrductId] ? fItem?.CentralInventoryId : '' ,//fItem?.CentralInventoryId ? fItem?.CentralInventoryId : '',
                                      }) 
                               }
                           }
                       })
                   });
               }
               }
            console.log("payload----->>>>>>>", payload);
            if (!!payload?.length) {    
                await handlePostData('/purchase-head', payload)
            }
        }
    } 

    // Function for get request based on project 
    const getReqByProjectId = async (projectId: any) => {
        setApprovedReqList([])
        try {
            const res = await getRequestAPI(`${purchase_order_url}?page=1&limit=1000&projectId=${projectId}&forPo=true`)     // &approvedAndPartial=true`)
            if (res?.status === 200) {  
                setApprovedReqList(res?.data?.materialRequestData?.items)               
                let materialReqData = res?.data?.materialRequestData; 
                if(!!Object?.keys(searchParamObj)?.length ){
                     materialReqData = res?.data?.materialRequestData?.items?.filter((fItem) => fItem?.request === searchParamObj?.request)
                     setOrderFormData({...orderFormData, 
                            request: materialReqData,
                            projectId: selectedProject.projectId, 
                            projectName: selectedProject.projectName
                        }) 
                 }  
            }
        } catch (error) {
            return error;
        }
    }

    const openUseStockModal = (row: any) => {  
        setUseStockModal(true)
        setUseStockData(row)
        setCentralData(row)
    }

    // Function for use qty from central stock
    const handleUseCentralStock = async () => { 
        const reqQty = centralData?.totalQty;
        const usedQty = parseInt(useStockData?.useQuantity);
        const calculatedQty = parseInt(reqQty) - usedQty;  
        const updateItems = itemsData?.map((element: any) => {            
            if (element?.id === useStockData?.id) {  
                setUseStockData({ ...useStockData, quantityFromCentral: usedQty}) 
                return { ...element, 
                    ["poQuantity"]: calculatedQty,
                    ['quantityFromCentral']: usedQty , 
                    ["CentralInventoryId"]: element?.productDetails?.centralInventory?.id,
                    isQuantity: '',
                    isVendorError: '',
                    isRateError: '',
                    isGstError: ''
                }
            }
            return element;
        }) 
        setItemsData(updateItems)
        console.log("update items ---->>>", updateItems); 
        setUseStockModal(false)  
        setUseStockData({})
    } 

    const confirmRemoveBill = (index:any) => {
        setSelectedFileIndex(index);
        setOpenConfirm(true);
    };

    const handleDeleteMaterial = () => {
        if (selectedFileIndex !== null) {
            const updatedItem = itemsData?.filter((obj) => obj.machineryOrPrductId !== selectedFileIndex);
            setItemsData(updatedItem) 
        }
        setOpenConfirm(false);
    };

    useEffect(() => {
        getAPICall()
    }, [])

    useEffect(() => {
        if (resData?.status === 200) {
            router.push('/purchase-management')
        }
        if (error) {
            console.error("Error", error)
        }
    }, [resData, error])

    useEffect(() => { 
        if(!!Object?.keys(searchParamObj)?.length){
                setSelectedProject({projectId: searchParamObj?.projectId, projectName: searchParamObj?.projectName })
        }
    }, [searchParamObj])

    useEffect(() => {
        if (!orderFormData?.request?.length) {
            setItemsData([])
        } 
    }, [orderFormData])

    useEffect(() => { 
        if (!!reqItems?.length) { 
            const isRemainingToVerify = reqItems.filter(item =>( (item?.remainingToVerified !== 0) || ((item?.remainingToVerified > 0) || ((item?.poQuantity > 0) && (item?.creditQuantity === null)))));
            const grouped = _.groupBy(isRemainingToVerify, 'machineryOrPrductId') 
            const uniqItem = _.map(grouped, (items: any, i) => { 
                let totalQty = 0; 
                items.forEach(item => {
                    if(!!item?.creditQuantity){
                            totalQty += item.poQuantity + item.creditQuantity;
                    }else{
                        if (item.poQuantity > 0) {
                            totalQty += item.poQuantity; 
                        } else if (item.remainingToVerified > 0) {
                            totalQty += item.remainingToVerified; 
                        }
                    }
                }) 
 
                const selectedVendors = apiData?.vendorDate?.items?.filter((vendor: any) => vendor.Category.some((category: any) => category?.id === items[0]?.productDetails?.category?.id));
                return {
                    ...items[0],
                    poQuantity: totalQty, //_.sumBy(items, 'poQuantity'), 
                    totalQty:  totalQty,
                    assignedVendors: selectedVendors || [],
                    rate: '',
                    vendorId: '',
                    vendorName: '',
                    remark: '',
                    quantityFromCentral: '',
                    GST:''
                };
            });
            setItemsData(uniqItem)
        }  
    }, [reqItems, orderFormData]) 
    
    useEffect(()=> { 
        if(!!selectedProject?.projectId){ 
            getReqByProjectId(selectedProject?.projectId) 
        }
    },[selectedProject]) 
      
    useEffect(() => {  
        if (!!orderFormData?.request?.length) {
            orderFormData?.request?.map((item: any) => {
                if (!reqItems?.some((request: any) => request?.requestId === item?.request)) {
                    setReqItems([...reqItems, ...item?.items]); 
                } else { 
                    const reqItemIds = orderFormData.request.flatMap(req => req.request);
                    const filtered = reqItems.filter(item => reqItemIds.includes(item.requestId)); 
                    setReqItems(filtered);
                }
            })
        } else {
            setReqItems([])
            setItemsData([])
        }
    }, [orderFormData])

    return (
        <> 
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>
                            Generate Purchase Order
                        </Heading>
                    </Blankbox>
                </HeadingBox>
                <MainBox>
                    <ContainerMain>
                        <form onSubmit={handleFormSubmit}>
                            <MainFormLayout>
                                <Grid container spacing={2}> 
                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <InputLabel htmlFor="my-input">Project <Asterisk>*</Asterisk> </InputLabel>
                                        <FormControl sx={{ width: '100%' }}>  
                                        <Autocomplete
                                            size="small"
                                            // value={orderFormData?.projectName}
                                            value={ projectListData?.items?.find( (item) => item?.projectName === selectedProject?.projectName ) ?? []}
                                            options={projectListData?.items ?? []}
                                            getOptionLabel={(option) => option?.projectName ?? ""}
                                            onChange={(event, newValue) => {  
                                                setSelectedProject({
                                                    ...selectedProject,
                                                    projectId: newValue?.id,
                                                    projectName: newValue?.projectName,
                                                    request: []
                                                }) 
                                                setOrderFormData({
                                                    ...orderFormData, 
                                                    request: []
                                                })
                                                setUseStockData({})
                                                setCentralData({})
                                            }}
                                            renderInput={(params) => (
                                                <TextField {...params} placeholder="Select Project" />
                                            )}
                                            fullWidth
                                        />
                                        </FormControl>
                                    </Grid> 

                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <InputLabel htmlFor="my-input">Request <Asterisk>*</Asterisk> </InputLabel>
                                        <FormControl sx={{ width: '100%' }}> 
                                            <Autocomplete
                                                ref={requestRef}
                                                multiple
                                                size='small'
                                                options={approvedReqList || []}
                                                value={orderFormData?.request ?? approvedReqList} 
                                                disableCloseOnSelect
                                                getOptionLabel={(option) => {  
                                                    return option?.request || '';
                                                }}
                                                onChange={(event, newValue: any) => { 
                                                    setOrderFormData({
                                                        ...orderFormData,
                                                        request: newValue
                                                    }) 
                                                    setUseStockData({})
                                                    const updatedErrors = { ...formErrors };
                                                    delete updatedErrors.request;
                                                    setFormErrors(updatedErrors); 

                                                }}
                                                renderOption={(props, option: any, { selected }) => (
                                                    <li {...props}> 
                                                        <Checkbox
                                                            icon={icon}
                                                            checkedIcon={checkedIcon}
                                                            style={{ marginRight: 8 }}
                                                            checked={selected}
                                                        />
                                                        {option?.request}
                                                    </li>
                                                )}
                                                renderInput={(params) => (
                                                    <TextField {...params} placeholder="Select Request" />
                                                )}
                                                fullWidth
                                            />
                                            {formErrors.request && (
                                                <FormHelperText id="project-name-error" error>
                                                    {formErrors.request}
                                                </FormHelperText>
                                            )}
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        {!!itemsData?.length &&
                                            <TableContainer component={Paper}>
                                                <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                                                    <TableHead>
                                                        <TableRow>
                                                            <TableCell sx={{fontWeight: 'bold'}} width={'50px'}>S_No.</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Product</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Type/Grade</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Specification</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Size</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'200px'}>Brand</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'180px'}>Quantity</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'170px'}>Available Qty<small>(Central)</small></TableCell> 
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'200px'}>Rate </TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'180px'}>GST</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Unit</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'180px'}>Remark</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'70px'}>Assign To</TableCell>
                                                            <TableCell sx={{fontWeight: 'bold'}} align="left" width={'170px'}>Action</TableCell>
                                                        </TableRow>
                                                    </TableHead>
                                                    <TableBody>
                                                        {itemsData?.map((row: any, i: number) => {                                                     
                                                            const  poQty = row?.poQuantity  ? row?.poQuantity : row?.poQuantity === 0 ? '0' : row?.poQuantity || row?.newQty;        
                                                            return (
                                                                <>
                                                                    {row?.productDetails !== null && <TableRow key={row?.name} >
                                                                        <TableCell >{i + 1}</TableCell>
                                                                        <TableCell align="left" >{row?.productDetails?.productName}</TableCell>
                                                                        <TableCell align="left">{!!row?.productDetails?.itemName? row?.productDetails?.itemName : '_'}</TableCell>
                                                                        <TableCell align="left" >{!!row?.productDetails?.specification ? row?.productDetails?.specification : '_'}</TableCell>
                                                                        <TableCell align="left" >{!!row?.productDetails?.size ? row?.productDetails?.size : '_'}</TableCell>                                                                    
                                                                        <TableCell align="left" >
                                                                            <Grid item lg={4} md={4} sm={4} xs={4}> 
                                                                                <FormControl sx={{ width: '100%' }}>
                                                                                    <Autocomplete
                                                                                        disabled={!row?.status}
                                                                                        sx={{ width: '175px' }}
                                                                                        size='small'
                                                                                        options={row?.brandNames}
                                                                                        getOptionLabel={(option) => option?.brandName}
                                                                                        value={orderFormData?.brandName}
                                                                                        onChange={(e, newValue) => {
                                                                                            let copyArr = [...itemsData]
                                                                                            copyArr[i] = { ...row, brandId: newValue?.id, brandName: newValue?.brandName }
                                                                                            setItemsData(copyArr)
                                                                                        }}
                                                                                        renderInput={(params) => {
                                                                                            return (<TextField {...params} placeholder='Brand' variant='standard'/>)
                                                                                        }}
                                                                                        isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                                                                        fullWidth
                                                                                    />
                                                                                </FormControl>
                                                                            </Grid>
                                                                        </TableCell>
                                                                        <TableCell align="left" > 
                                                                        <FormControl> 
                                                                            <Input 
                                                                                name='quantity'
                                                                                sx={{width: '120px'}} 
                                                                                placeholder='Quantity'
                                                                                value={poQty} 
                                                                                defaultValue={row?.newQty || row?.poQuantity}
                                                                                className={!!row?.isQuantity ? "required-field" : ""}
                                                                                onChange={(e: any) => {  
                                                                                    const enteredValue = e.target.value;  
                                                                                    const regex = /^[0-9]\d*$/;                      
                                                                                    if ((regex.test(enteredValue)) || ( enteredValue === '')){
                                                                                        let copyArr = [...itemsData]
                                                                                        copyArr[i] = { ...row, poQuantity: e.target.value, newQty : e.target.value, isQuantity : !!e?.target?.value ? "" : "Qty is required"  }
                                                                                        setItemsData(copyArr) 
                                                                                    } 
                                                                                }} 
                                                                                />
                                                                        </FormControl>
                                                                            {row?.isQuantity && (
                                                                                <FormHelperText id="quantity-error" error>
                                                                                    {row?.isQuantity}
                                                                                </FormHelperText>
                                                                            )}
                                                                        </TableCell>

                                                                        <TableCell align="left">
                                                                            <Button sx={{color: 'white !important'}} disabled={row?.productDetails?.centralInventory === null} size='small' variant='contained' onClick={() => openUseStockModal(row)}>
                                                                                {row?.productDetails?.centralInventory !== null ? row?.productDetails?.centralInventory?.availableQuantity : 0}
                                                                            </Button>
                                                                            <div style={{ fontSize: "10px" }}>
                                                                                {row?.productDetails?.centralInventory !== null ? "Use Stock" : "Not available"}
                                                                            </div>
                                                                        </TableCell> 

                                                                        <TableCell align="left">  
                                                                            <Input  
                                                                             sx={{width: '100px'}}  
                                                                             className={!!row?.isRateError ? "required-field" : ""}
                                                                             placeholder='Rate' 
                                                                             value={row?.rate} 
                                                                             onChange={(event) => {
                                                                                const enteredValue = event.target.value; 
                                                                                const regex = /^(?!0\d)\d*(\.\d{0,4})?$/;  
                                                                                if ((regex.test(enteredValue)) || ( enteredValue === '')){ 
                                                                                   const updateItems = itemsData?.map((element: any) => {
                                                                                        if (element?.id === row.id) {
                                                                                            return { ...element, ['rate']: event.target.value , isRateError: !!event?.target?.value ? "" : "Rate is required" }
                                                                                        }
                                                                                        return element;
                                                                                    })   
                                                                                    setItemsData(updateItems)  
                                                                                    } 
                                                                                }}/> 
                                                                                {!!row.isRateError && (
                                                                                    <FormHelperText id="rate-error" error>
                                                                                        {row.isRateError}
                                                                                    </FormHelperText>
                                                                                )}
                                                                        </TableCell>

                                                                        <TableCell align="left"> 
                                                                            <FormControl variant="standard" sx={{ minWidth: 120 }}>
                                                                            <Select 
                                                                            labelId="demo-simple-select-label"
                                                                            id="demo-simple-select"
                                                                            sx={{width: '100px'}} 
                                                                            value={row?.GST} 
                                                                            className={!!row?.isGstError ? "required-field" : ""}
                                                                            size='small'
                                                                            onChange={(event) =>{
                                                                                const updateItems = itemsData?.map((element: any) => {
                                                                                    if (element?.id === row.id) {
                                                                                        return { ...element, ['GST']: event.target.value, isGstError: !!event?.target?.value ? "" : "GST is required"}
                                                                                    }
                                                                                    return element;
                                                                                })
                                                                                setItemsData(updateItems) 
                                                                            }}
                                                                            >
                                                                            <MenuItem value={"0%"}>0%</MenuItem>
                                                                            <MenuItem value={"5%"}>5%</MenuItem>
                                                                            <MenuItem value={"12%"}>12%</MenuItem>
                                                                            <MenuItem value={'18%'}>18%</MenuItem>
                                                                            <MenuItem value={'28%'}>28%</MenuItem>
                                                                            </Select>
                                                                            </FormControl>
                                                                            {!!row?.isGstError && (
                                                                                <FormHelperText id="gst-error" error>
                                                                                    {row?.isGstError}
                                                                                </FormHelperText>
                                                                            )}
                                                                        </TableCell>

                                                                        <TableCell align="left">{row?.productDetails?.unit}</TableCell>
                                                                      
                                                                        <TableCell align="left" width={'150px'}> 
                                                                        <FormControl sx={{ width: '100%' }}>
                                                                         <Input
                                                                          type='text' 
                                                                          sx={{width: '150px'}} 
                                                                          placeholder='remark' 
                                                                          value={row?.remark}
                                                                          onChange={(event) => {
                                                                            const updateItems = itemsData?.map((element: any) => {
                                                                                if (element?.id === row.id) {
                                                                                    return { ...element, ['remark']: event.target.value}
                                                                                }
                                                                                return element;
                                                                            })
                                                                            setItemsData(updateItems) 
                                                                          }}/>
                                                                          </FormControl>
                                                                        </TableCell> 

                                                                        <TableCell align='left'>
                                                                            <Grid xs={12}> 
                                                                                <FormControl sx={{ width: '100%' }}>  
                                                                                    <Autocomplete
                                                                                        sx={{ width: '175px'}}
                                                                                        size='small'
                                                                                        options={row?.assignedVendors}
                                                                                        getOptionLabel={(option) => {  
                                                                                            return typeof option !== "object" ? option : option?.name;
                                                                                        }}
                                                                                        value={row?.vendorName}
                                                                                        onChange={(e, newValue) => {
                                                                                            let copyArr = [...itemsData]
                                                                                            copyArr[i] = { ...row, vendorId: newValue?.id, vendorName: newValue?.name, isVendorError: !!newValue?.name ? "" : "Vendor is required"  }
                                                                                            setItemsData(copyArr)
                                                                                        }}
                                                                                        renderInput={(params) => {
                                                                                            return (<TextField {...params} className={!!row?.isVendorError ? "required-field" : ""} variant="standard" placeholder='Please Select Vendor'
                                                                                                />)
                                                                                            }}
                                                                                        isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                                                                        fullWidth
                                                                                     />
                                                                                </FormControl> 
                                                                                {!!row?.isVendorError && (
                                                                                    <FormHelperText id="vendor-error" error>
                                                                                         {row?.isVendorError}
                                                                                    </FormHelperText>
                                                                                )}
                                                                            </Grid>
                                                                        </TableCell> 

                                                                        <TableCell align="left" >
                                                                            <div style={{ width: '100px' }}>
                                                                            <Tooltip title="Delete">
                                                                            <IconButton onClick={() => confirmRemoveBill(row?.machineryOrPrductId)}> 
                                                                                <Delete color='error'/>
                                                                            </IconButton>
                                                                            </Tooltip>
                                                                            </div>
                                                                        </TableCell>

                                                                    </TableRow>
                                                                    }
                                                                </>)
                                                        }
                                                        )}
                                                    </TableBody>
                                                </Table>
                                            </TableContainer>
                                        }
                                    </Grid>
                                    <Grid item lg={6} md={6} sm={6} xs={12}>
                                        <Button onClick={() => router.back()} sx={{margin: '0 10px'}} variant='contained'>
                                          Cancel
                                        </Button>
                                        <Button type='submit' variant='contained'>
                                            Generate PO
                                        </Button>
                                    </Grid>
                                </Grid>
                            </MainFormLayout>
                        </form>
                    </ContainerMain>
                </MainBox>
            </Wrapper>

            <ConfirmationDialog
                    open={openConfirm}
                    onClose={() => setOpenConfirm(false)}
                    title="Confirm Deletion"
                    message="Are you sure you want to delete this material?"
                    onConfirm={handleDeleteMaterial}
                    confirmText="Delete"
                    cancelText="Cancel"
                />
           {/* Modal for Use Quantity from central inventory */}
            <>
                <Dialog
                    maxWidth='lg'
                    open={useStockModal}>
                    <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                        <Toolbar>
                            <Typography sx={{ flex: 1 }} variant="h6" component="div">
                                Use Central Stock
                            </Typography>
                            <DialogActions>
                                <ClearIcon onClick={() => setUseStockModal(false)} />
                            </DialogActions>
                        </Toolbar>
                    </AppBar>
                    <DialogContent>  
                        <div ><b> Available Quantity :</b> <Typography variant='caption' sx={{ margin: '1rem' }} />{centralData?.productDetails?.centralInventory?.availableQuantity}</div>
                        <div><b>Requested Quantity :</b>  <Typography variant='caption' sx={{ margin: '1rem' }} />{centralData?.totalQty}</div>
                        <div><b>Used Quantity :</b>  <Typography variant='caption' sx={{ margin: '1rem' }} />{useStockData?.quantityFromCentral}</div>
                        <div><b>Use Quantity : </b> 
                            <Typography variant='caption' sx={{ margin: '1rem'}}>
                                <Input size='small' 
                                    type="number"
                                    value={useStockData?.useQuantity}
                                    onChange={(e: any) => { 
                                        const enteredValue = e.target.value;
                                        const regex = /^[1-9]\d*$/; 
                                        if ((regex.test(enteredValue) || ( enteredValue === '')) && (enteredValue <= centralData?.totalQty)){  
                                                if(centralData?.productDetails?.centralInventory?.quantity >= enteredValue){
                                                    setUseStockData({ ...useStockData, useQuantity: enteredValue }) 
                                                } 
                                        }  
                                    }} />
                            </Typography>
                        </div>
                        <div ><Button style={{ float: 'right', margin: '15px 0', color: 'white' }} variant='contained' disabled={!useStockData?.useQuantity} size='small' onClick={handleUseCentralStock}>Use</Button></div>
                    </DialogContent>
                </Dialog>
            </>
        </>
    )
}

export default GeneratePurchaseOrder 