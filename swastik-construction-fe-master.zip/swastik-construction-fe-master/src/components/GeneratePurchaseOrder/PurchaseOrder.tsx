import React, {useEffect, useState} from 'react'
import { Alert, AppBar, Box, Button, ButtonGroup, Chip, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, InputLabel, List, ListItem, ListItemText, MenuItem, Paper, Select, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Toolbar, Tooltip, Typography } from '@mui/material';
import { ClearIcon } from '@mui/x-date-pickers';
import { theme } from '../../common/styles/theme';
import usePatch from '../../hooks/usePatch';
import {useSession} from 'next-auth/react';
import CreditNoteForm from './CreditNoteForm'; 
import _ from 'lodash'; 
import {useRouter} from 'next/navigation';   
import moment from 'moment';
import {baseImgUrl} from 'src/constants/api-routes';
import {stringCapitalization} from 'src/utils/formatString'; 
import ConfirmationDialog from '../ui/ConfirmationDialog'  
import {CloudUpload, Delete, Visibility} from '@mui/icons-material';

const PurchaseOrder = ( { data, fetchData }: any ) => {  
    const {data:session} = useSession() 
    const router = useRouter()
    const { handleUpdateData  } = usePatch() 
    const [ openBillUpload, setOpenBillUpload ] = useState(false)
    const [ openCreditNote, setOpenCreditNote ] = useState(false)  
    const [purchaseOrderItem, setPurchaseOrderItem] = useState<any>()
    const [files, setFiles] = useState<[]>([]);
    const orderDate = moment( _.uniqBy(data?.items?.map(item => item?.createdAt), 'createdAt')?.join('')).format('DD-MM-YYYY')  
    const projectName = _.uniqBy(data?.items?.map(item => item?.projectDetails?.projectName), 'projectName')?.join('')   
    const requestId = _.uniqBy(data?.items?.map(item => item?.requestId), 'requestId')?.join('')  
    const vendorName = _.uniqBy(data?.items?.map(item => item?.vendorDetails?.name ), 'name')?.join('')      
    const [openConfirm, setOpenConfirm] = useState(false);
    const [selectedFileIndex, setSelectedFileIndex] = useState(null);
    const [filesObj, setFilesObj]= useState([]);

    useEffect(() => { 
        if(!!data?.image?.length){
            const initialFileObjects = data?.image?.map(url => ({
                imagePreview: url,
                fileObj: {},
                name: url.split("/image-").pop(), 
                type: url.split('.').pop()
            }));   
            setFiles(initialFileObjects);
        }
    }, [data])

    async function createFileFromUrl(url:any, fileName = "file.png") { 
        const fileType = fileName.split('.').pop()
        try {
            const response = await fetch(url); // Fetch the file
            const blob = await response.blob(); // Convert response to Blob
    
            // Create a File object from the Blob
            const file = new File([blob], fileName, { 
                type: `${fileType === 'pdf' ? 'application' : 'image'}/${fileType}`,
                lastModified: new Date().getTime()
            });
     
            return file;
        } catch (error) {
             return error;
        }
    } 
 
    // funtion for bill upload
    const handleBillUpload = async () => {
        const payloadFormData = new FormData();
        payloadFormData.append('purchaseOrderNo', data?.purchaseOrderNo);
  
        // Process files asynchronously and return an array of promises
        const filePromises = files.map(async (file) => {
            if(file?.fileObj instanceof File){ 
                payloadFormData.append('image', file.fileObj);  // Append file directly
            } else {
                try {
                    const createdFile = await createFileFromUrl(file?.imagePreview, file.name); 
                    if (createdFile) {
                        payloadFormData.append('image', createdFile);  // Append transformed file
                    }
                } catch (err) {
                    return err;
                }
            }
        });
    
        // Wait for all files to be processed before proceeding
        await Promise.all(filePromises);

        // Now that payloadFormData is fully populated, make the API request
        await handleUpdateData('/purchase-head', payloadFormData); 
        setOpenBillUpload(false);
        fetchData();
    };

    // function for update purchase order
    const handlePurchaseOrderApproval = async(status:string) => {
        const payloadFormData = new FormData()
        payloadFormData.append('purchaseOrderNo', data?.purchaseOrderNo)
        if(status !== undefined || null){
            payloadFormData.append('status',  status)
        }
        await handleUpdateData('/purchase-head', payloadFormData)
        setOpenBillUpload(false)
        router.push('/purchase-management')  
    }

    // function for create credit note
    const createCreditNote = async (payload:any) => { 
        setOpenCreditNote(false) 
        fetchData() 
    }

    const shouldShowApprovedButton = (creditStatuses:any, poStatus: string) => {
        if(!!creditStatuses?.length) {
            const isCreditNote = creditStatuses?.every(status => status === 'approved' || status === 'delivered')  
            return (isCreditNote && (poStatus === 'approvalPending'));
        }
    };
     
    const showViewCreditButton = (creditNoteStatus:any, bill: string) => { 
        if(!!creditNoteStatus?.length) {
            const isCreditNote = creditNoteStatus?.every(status => status === "delivered") 
            return isCreditNote;
        }
    };

    const mergeQuantities = (data:any) => {
        const merged :any= {};  
        data.forEach((item:any) => {
          const { materialId, quantity, materialRequestDetails} = item; 
          if (merged[materialId]) {
            merged[materialId].quantity += quantity;
            merged[materialId].materialRequestDetails.quantity += materialRequestDetails?.quantity
          } else {
            merged[materialId] = { ...item };
          }
        }); 
        return Object.values(merged);
    }

    useEffect(() => {
        if(!!data?.items){
            const poItems = mergeQuantities(data?.items) 
            setPurchaseOrderItem(poItems)
        }
    }, [data])

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFiles = Array.from(event.target.files || []); 
        const updatedFiles = selectedFiles?.map((file:any) => ({
            imagePreview: URL.createObjectURL(file),
            fileObj: file,
            name: file.name,
            type:  file.name.split(".").pop(),
        }));
    
        setFiles(prevFiles => {
        if (Array.isArray(prevFiles)) {
            return [...prevFiles, ...updatedFiles];
        } else {
            return [...updatedFiles];
        }
        })
    }; 


    const getImageUrl = (path: string) => {
        // Check if the path is already a full URL (starts with 'http' or 'blob:')
        if (path.startsWith("http") || path.startsWith("blob:")) {  
          return path;
        }   
        return `${baseImgUrl}${path}`;
    };

    // Function to open confirmation popup
    const confirmRemoveBill = (index:any) => {
        setSelectedFileIndex(index);
        setOpenConfirm(true);
    };

    // Function to handle bill deletion
    const handleDeleteBill = () => {
        if (selectedFileIndex !== null) {
            const updatedFiles = [...files];
            updatedFiles.splice(selectedFileIndex, 1);
            setFiles(updatedFiles); // Assuming setFiles updates the file state
        }
        setOpenConfirm(false);
    };

    return (
               <> 
                  <Paper elevation={3}>
                       <Grid container sx={{ padding: '20px' }} spacing={ 2 }> 
                        {/* start Purchase Order details */} 
                             <Grid item lg={12} md={6} sm={6} xs={12}>
                                <Typography paragraph={true} component={() => {
                                return (
                                    <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                    <span><strong> PO Number: </strong>  {data?.purchaseOrderNo}</span>
                                    </div>
                                );
                                }} />
                                 <Typography paragraph={true} component={() => {
                                return (
                                    <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                    <span><strong>Request Id: </strong> {requestId ?? "_"}</span>
                                    </div>
                                );
                                }} /> 
                                <Typography paragraph={true} component={() => {
                                return (
                                    <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                    <span><strong>Site:</strong> {projectName}</span> 
                                    </div>
                                );
                                }}/> 
                                <Typography paragraph={true} component={() => {
                                return (
                                    <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                    <span><strong>Ordered Date:</strong> {orderDate ?? "_"}</span>
                                    </div>
                                );
                                }} /> 
                                 <Typography paragraph={true} component={() => {
                                return (
                                    <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                    <span><strong>Vendor:</strong> {vendorName ?? "_"}</span>
                                    </div>
                                );
                                }} />  
                                <Typography paragraph={true} component={() => {
                                return (
                                    <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                    <span><strong>Status:</strong> {stringCapitalization(data?.status) ?? "_"}</span>
                                    </div>
                                );
                                }} />
                             </Grid> 

                            <Grid item lg={ 12 } xs={ 12 } md={ 12 }>
                            <TableContainer>
                                <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                                    <TableHead sx={{background: theme?.colors?.lightGray  }}>
                                        <TableRow>
                                            <TableCell sx={{ fontWeight:'bold'}} width={'20px'}>S No.</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'50px'}>Item</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'50px'}>Type / Grade</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'50px'}>Specification</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'50px'}>Size</TableCell> 
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'50px'}>Approved Qty.</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'50px'}>Ordered Qty.</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'70px'}>Rate</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'70px'}>GST</TableCell>
                                            <TableCell sx={{ fontWeight:'bold'}} align="left" width={'70px'}>Remark</TableCell>
                                        </TableRow>
                                    </TableHead>
                                        { !!purchaseOrderItem?.length && purchaseOrderItem?.map((oItem:any, index:number) => { 
                                            return (
                                                <>          
                                                <TableBody key={index}>
                                                    <TableCell width={'20px'}>{index+1}</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.materialDetails?.productName }</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.materialDetails?.itemName ?? "_"}</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.materialDetails?.specification ?? "_"}</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.materialDetails?.size ?? "_"}</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.materialRequestDetails?.quantity}</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.quantity}</TableCell>
                                                    <TableCell width={'50px'}>{oItem?.rate}</TableCell>
                                                    <TableCell width={'70px'}>{oItem?.GST}</TableCell>
                                                    <TableCell width={'70px'}>{oItem?.remark ?? "_"}</TableCell>
                                                </TableBody>
                                                </>
                                            )}) }
                                </Table>
                            </TableContainer>  
                            </Grid> 
                        {/* -----end Purchase Order details ------ */}

                        {/* ---Start Bill upload & credit note------ */}
                            <Grid item lg={ 12 } xs={ 12 } md={ 12 }>
                              <Typography sx={ { flex: 1 } } variant="body1" component="div"> 
                                     Bill : <Button disabled={ data?.image === null && [0, 1]?.includes(session?.user?.role_id)}
                                     onClick={() => {
                                        setFilesObj(files)
                                        setOpenBillUpload(true)
                                     } }> {!files?.length ?  "Upload" : "Uploaded"}</Button> 
                              </Typography> 
                              <Grid container spacing={1}>  
                                { !!files?.length && 
                                <Box alignItems="center" sx={{ mb: 2, mt:2, width: "50%" }}>
                                <Typography variant="subtitle1" fontWeight="bold">
                                    Uploaded Bill
                                </Typography>
                                <List> 
                                {files?.map((file:any, index) => (
                                    <ListItem
                                        key={index}
                                        sx={{
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            bgcolor: "#F5F5F5",
                                            borderRadius: 2,
                                            px: 2,
                                            mb: 1,
                                        }}
                                    >
                                    <Chip
                                        label={file?.type?.toUpperCase()}
                                        color={file?.type === "pdf" ? "success" : "info"}
                                        sx={{ fontSize: "0.8rem" }}
                                    />
                                    <ListItemText
                                        primary={file.name}
                                        sx={{ ml: 2, overflow: "hidden", textOverflow: "ellipsis" }}
                                    /> 
                                         <Tooltip title="View">
                                            <a href={getImageUrl(`${file?.imagePreview}`) } target='_blank'>
                                                <Visibility/>
                                            </a> 
                                         </Tooltip>
                                    </ListItem>
                                ))}
                                </List>
                            </Box>
                            }
                              </Grid>     
                            </Grid>
                            <Grid item lg={ 12 } xs={ 12 } md={ 12 }> 
                                <Typography sx={ { flex: 1 } } variant="body1" component="div"> 
                                     Credit Note : 
                                    <Button disabled={showViewCreditButton(data?.creditNoteStatuses, data?.image)} onClick={() => setOpenCreditNote(true)}>View</Button>
                                </Typography> 
                            </Grid> 
                        {/* -----end Bill upload & credit note------ */}

                        {/* ----start Close PO & Approve Reject PO ----- */} 
                             { ((session?.user?.role_id !== 3) && data?.status !== "close") && 
                                <Grid item lg={ 12 } xs={ 12 } md={ 12 }> 
                                {
                                    shouldShowApprovedButton(data?.creditNoteStatuses, data?.status) &&
                                    <ButtonGroup sx={{float: "right", color:'white'}}>
                                        <Button variant='outlined' onClick={() => handlePurchaseOrderApproval("rejected")}>Reject</Button>
                                        <Button variant='contained' sx={{color: 'white'}} onClick={() => handlePurchaseOrderApproval("close")}>Approve</Button>
                                    </ButtonGroup>  
                                }  
                                {
                                 ((data?.creditNoteStatuses?.some(status => (status == 'generated' && status == "delivered") || (status === "generated"))) 
                                 && (data?.status === "approvalPending")) &&
                                    <Alert severity="info"> 
                                        Please Approve the credit note, and then you can close the Purchase Order. 
                                    </Alert>
                                }
                                {(data?.creditNoteStatuses?.every(status => (status == 'partialDelivered')) && (data?.status === "approvalPending")) &&
                                    <Alert severity="info">  
                                      Material is not fully delivered. Please either generate a credit note for the undelivered material or wait until the delivery is complete.
                                    </Alert>}
                                </Grid>}  
                        {/* ----end Close PO & Approve Reject PO ----- */}

                       </Grid>
                  </Paper>

               {/* Upload Bill modal */}
                 <Dialog
                    fullWidth
                    maxWidth='md'
                    open={ openBillUpload }
                    onClose={() => setOpenBillUpload( false )}>
                    <AppBar sx={ { position: 'relative', background: theme.colors.Red } }>
                        <Toolbar>
                            <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                                Bill 
                            </Typography>
                            <DialogActions>
                                <ClearIcon onClick={ () => setOpenBillUpload( false ) } />
                            </DialogActions>
                        </Toolbar>
                    </AppBar>

                    <DialogContent> 
                        <Grid container sx={{ padding: '20px' }} spacing={ 2 }>
                          <Grid item lg={ 12 } xs={ 12 } md={ 12 }>
                            {  
                            (((['approvalPending', 'partialDelivered', 'delivered', 'rejected']?.includes(data?.status) && [3]?.includes(session?.user?.role_id))  
                            ||  ( ![ 'partialDelivered', 'delivered']?.includes(data?.status) && [0,1]?.includes(session?.user?.role_id)))  
                             && (data?.status !== 'close')) &&
                            <>   
                            <Box
                                display="flex"
                                justifyContent="center"
                                alignItems="center" 
                                >
                                <Paper elevation={3} sx={{ padding: 2, width: '100%', textAlign: "center", border: '1px solid #e0b8b8', borderStyle: 'dashed' }}>
                                    <Button
                                        variant="contained"
                                        component="label"
                                        color="primary"
                                        startIcon={<CloudUpload />} 
                                        >  Click To Upload <input type="file" accept="image/png, image/jpeg, application/pdf" hidden multiple onChange={handleFileChange} />
                                    </Button> 
                                </Paper>
                            </Box>
                            </> } 

                            <Grid item lg={ 12 } xs={ 12 } md={ 12 }>   
                                { !!files?.length && 
                                <Box alignItems="center" sx={{ mb: 2, mt:2, width: "100%" }}>
                                <Typography variant="subtitle1" fontWeight="bold">
                                    Uploaded Bill
                                </Typography>
                                <List> 
                                {files?.map((file:any, index) => (
                                    <ListItem
                                        key={index}
                                        sx={{
                                            display: "flex",
                                            justifyContent: "space-between",
                                            alignItems: "center",
                                            bgcolor: "#F5F5F5",
                                            borderRadius: 2,
                                            px: 2,
                                            mb: 1,
                                        }}
                                    >
                                    <Chip
                                        label={file?.type?.toUpperCase()}
                                        color={file?.type === "pdf" ? "success" : "info"}
                                        sx={{ fontSize: "0.8rem" }}
                                    />
                                    <ListItemText
                                        primary={file.name}
                                        sx={{ ml: 2, overflow: "hidden", textOverflow: "ellipsis" }}
                                    />
                                    { ['approvalPending', 'partialDelivered', 'delivered', 'rejected']?.includes(data?.status)
                                        &&
                                        <Tooltip title="Delete">
                                            <IconButton onClick={() => confirmRemoveBill(index)} color="error">
                                                <Delete />
                                            </IconButton>
                                        </Tooltip>}
                                         <Tooltip title="View">
                                            <a href={getImageUrl(`${file?.imagePreview}`)} target='_blank'>
                                                <Visibility/>
                                            </a> 
                                         </Tooltip>
                                    </ListItem>
                                ))}
                                </List>
                            </Box> } 
                            </Grid>
                          </Grid>   
                          <Grid item lg={ 12 } xs={ 12 } md={ 12 }> 
                          {['approvalPending', 'partialDelivered', 'delivered', 'rejected']?.includes(data?.status) 
                            && 
                            <Button 
                             disabled={ _.isEqual(filesObj, files) || !files?.length} 
                             variant='contained' sx={{float: 'right', color: 'white !important'}} onClick={handleBillUpload}>
                                Save
                            </Button>
                             }
                          </Grid>     
                        </Grid> 
                    </DialogContent>
                </Dialog>
 
                <ConfirmationDialog
                    open={openConfirm}
                    onClose={() => setOpenConfirm(false)}
                    title="Confirm Deletion"
                    message="Are you sure you want to delete this bill?"
                    onConfirm={handleDeleteBill}
                    confirmText="Delete"
                    cancelText="Cancel"
                />

               {/* Credit note modal */}
                <Dialog
                    fullWidth
                    maxWidth='md'
                    open={ openCreditNote }
                    onClose={() => {
                         setOpenCreditNote(false) 
                         fetchData() 
                    }}>
                    <AppBar sx={ { position: 'relative', background: theme.colors.Red } }>
                        <Toolbar>
                            <Typography sx={ { ml: 0, flex: 1 } } variant="h6" component="div">
                               Generate Credit Note
                            </Typography>
                            <DialogActions>
                                <ClearIcon onClick={ () => setOpenCreditNote( false ) } />
                            </DialogActions>
                        </Toolbar>
                    </AppBar> 
                    <DialogContent> 
                        {
                            data?.creditNoteStatuses?.every(status => status === 'delivered') ? <>
                             <Typography sx={ { ml: 2, my: 10, flex: 1, textAlign: 'center' } } variant="h6" component="div">
                                No Data Available
                            </Typography> 
                            </> : <>
                            <CreditNoteForm data={data} fetchData={fetchData} createCreditNote={createCreditNote}/> 
                            </>
                        } 
                    </DialogContent>
                </Dialog> 
               </>
    )
}

export default PurchaseOrder;