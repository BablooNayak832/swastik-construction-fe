import React, { useState } from "react";
import Highcharts from "highcharts";
import HighchartsExporting from "highcharts/modules/exporting";
import HighchartsReact from "highcharts-react-official";
import { PieChartLayout, DatePickerBox } from "../../common/styles/HighChartsLayout/styles";
import useGet from "../../hooks/useGet";
import { projects_url } from "../../constants/api-routes";

if (typeof Highcharts === "object") {
    HighchartsExporting(Highcharts);
}

const MainPieChart = () => {
    const { resData, handleGetData } = useGet()
    const [pieChartOptions, setPieChartOptions] = useState({
        chart: {
            type: 'pie',
            title: 'Projects'
        },
        title: {
            text: '',
            align: 'left',
            margin: 5,
            x: 50,
            style: {
                fontSize: '24px',
                fontWeight: '700',
                color: '#464255'
            }
        },
        subtitle: {
            text:
                'Active / Inactive'
        },
        plotOptions: {
            series: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: [{
                    enabled: true,
                    distance: 20
                }, {
                    enabled: true,
                    distance: -40,
                    format: '{point.percentage:.1f}%',
                    style: {
                        fontSize: '1.2em',
                        textOutline: 'none',
                        opacity: 0.7
                    },
                    filter: {
                        operator: '>',
                        property: 'percentage',
                        value: 10
                    }
                }]
            }
        },
        series: []
    })

    React.useEffect(() => {
        getCurrentData()
    }, [])

    React.useEffect(() => {
        const runningProject = resData?.items?.filter((fItem: any) => fItem.status === "running")?.length;
        const onholdProject = resData?.items?.filter((fItem: any) => fItem.status === "onhold")?.length;
        const completedProject = resData?.items?.filter((fItem: any) => fItem.status === "completed")?.length;

        setPieChartOptions({
            ...pieChartOptions, series: [
                {
                    name: 'Total',
                    colorByPoint: true,
                    data: [
                        {
                            name: 'Completed Project',
                            y: completedProject,
                        },
                        {
                            name: 'On Hold Projects',
                            y: onholdProject,
                        },
                        {
                            name: 'Active Projects',
                            sliced: true,
                            selected: true,
                            y: runningProject
                        },
                    ]
                }
            ]
        })
    }, [resData?.items])

    const getCurrentData = async () => {
        const url = `${projects_url}/?page=1&limit=100&sales=active`
        const res = handleGetData(url)
        return res;
    }

    return (<>
        <PieChartLayout>
            <DatePickerBox>
                <h3>{pieChartOptions?.chart?.title}</h3>
            </DatePickerBox>
            <HighchartsReact
                highcharts={Highcharts}
                options={pieChartOptions}
                containerProps={{ className: 'container' }}
            />

        </PieChartLayout>
    </>);
}

export default MainPieChart;