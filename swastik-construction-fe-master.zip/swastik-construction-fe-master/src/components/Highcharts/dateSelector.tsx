import * as React from 'react';
import {
    useTheme as useMaterialTheme,
    useColorScheme as useMaterialColorScheme,
    Experimental_CssVarsProvider as MaterialCssVarsProvider,
} from '@mui/material/styles';
import {
    extendTheme as extendJoyTheme,
    useColorScheme,
    // styled,
    CssVarsProvider,
    THEME_ID,
} from '@mui/joy/styles';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import {
    DateRangePicker,
    // DateRangePickerProps,
} from '@mui/x-date-pickers-pro/DateRangePicker'; 
 
const joyTheme = extendJoyTheme();
 

const JoyDateRangePicker = React.forwardRef(
    (   props: any
        // DateRangePickerProps<Dayjs>
        , ref: React.Ref<HTMLDivElement>) => {
        
        const handleDateChange = (newDateRange: any) => {
            // setSelectedDateRange(newDateRange); 
            props?.handleFilter(newDateRange);
        }   

        return (
            <DateRangePicker 
                ref={ref}
                value={props.selectedDateRange}
                onChange={handleDateChange}
                {...props}  
                slotProps={{ textField: { size: 'small' } }}
                localeText={{ start: 'Start Date', end: 'End Date' }} 
            />
        );
    },
);


function SyncThemeMode({ mode }: { mode: 'light' | 'dark' }) {
    const { setMode } = useColorScheme();
    const { setMode: setMaterialMode } = useMaterialColorScheme();
    React.useEffect(() => {
        setMode(mode);
        setMaterialMode(mode);
    }, [mode, setMode, setMaterialMode]);
    return null;
}

interface dateRangePickerType {
    selectedDateRange?:any;
    handleFilter: (data: any) => any;
}


export default function RangePickerWithJoyField({ selectedDateRange ,handleFilter }: dateRangePickerType) {
    const materialTheme = useMaterialTheme();

    return (
        <MaterialCssVarsProvider>
            <CssVarsProvider theme={{ [THEME_ID]: joyTheme }}>
                <SyncThemeMode mode={materialTheme.palette.mode} />
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <JoyDateRangePicker selectedDateRange={selectedDateRange} handleFilter={handleFilter} />
                </LocalizationProvider>
            </CssVarsProvider>
        </MaterialCssVarsProvider>
    );
}