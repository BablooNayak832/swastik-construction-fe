"use client"
import React, { useState } from "react";
import { useEffect } from "react";
import useGet from "../../hooks/useGet";
import { Line } from 'react-chartjs-2';
import { ChartLayout, DatePickerLineBox, GraphFilterLayout } from "../../common/styles/HighChartsLayout/styles";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { project_count } from "../../constants/api-routes";

const month = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];


function ChartPage() {
    const { resData, handleGetData } = useGet();
    const getProjectMonthlyCount = async () => {
        const projectMonthlyCount = await handleGetData(project_count)
        return projectMonthlyCount;
    }

    useEffect(() => {
        getProjectMonthlyCount()
    }, [])

    const sortedProjects = resData?.project?.sort((a, b) => {
        if (a.year !== b.year) {
            return a.year - b.year;
        } else {
            return a.month - b.month;
        }
    });

    const data = sortedProjects?.filter(item => item?.year && item?.month && item?.projectCount)
        .map(item => {
            let d = new Date(item?.year, item?.month - 1);
            return ({
                label: month[d.getMonth()],
                y: parseInt(item?.projectCount)
            })
        }
        );

    const chartData = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], //data?.map(item => item.label),
        datasets: [
            {
                label: 'Number of Projects',
                data: data?.map(item => item?.y),
                fill: true,
                borderWidth: 1,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1
            }
        ]
    }; 

    const [startDate, setStartDate] = useState(new Date());
    return (
        <>
            <ChartLayout>
                <GraphFilterLayout>
                    {/* <DatePickerLineBox>
                        <DatePicker
                            selected={startDate}
                            onChange={(date) => setStartDate(date)}
                            showYearPicker
                            dateFormat="yyyy"
                        /> 
                    </DatePickerLineBox> */}
                </GraphFilterLayout>
                <Line data={chartData} 
                    options={{
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top' as const,
                            },
                            title: {
                                display: true,
                                text: 'Chart.js Line Chart',
                            },
                        },
                        scales: {
                            x: {
                                type: 'time',
                                time: {
                                    unit: 'month'
                                }
                            },
                            y: {
                                title: {
                                    display: true,
                                    text: 'Number of Projects'
                                }
                            }
                        }
                    }}
                />
            </ChartLayout>
        </>
    );
}

export default ChartPage;