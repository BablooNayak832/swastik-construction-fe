import React from 'react'
import { FormControl, Grid, InputLabel, ListItemText, MenuItem, Select, SelectChangeEvent } from '@mui/material'
import { DatePickerLineBox } from '../../../common/styles/HighChartsLayout/styles'
import MinMaxDateRangePicker from '../../Highcharts/dateSelector';
import { AttendanceFilterDate } from 'src/app/styles'; 


const AttendanceFilter = ({ selectedDateRange, filterOnAttendance, projectItems, getUserByRole }: any) => {

    return (
        <>
            <div style={{ display: 'flex', width: "100%" }}>
                <Grid container spacing={2}>
                    <Grid item lg={6} md={6} sm={6} xs={6}>
                        <>
                            <InputLabel id="demo-simple-select-label">
                                Project
                            </InputLabel>

                            <FormControl size="small" sx={{ width: '100%' }}>
                                <Select
                                    size='small'
                                    labelId="demo-multiple-checkbox-label"
                                    id="demo-multiple-checkbox"
                                    placeholder='Select Project'
                                    onChange={(event: SelectChangeEvent<object>) => {
                                        const { target: { value } } = event;
                                        filterOnAttendance(value, 'project')
                                    }}
                                    MenuProps={{ PaperProps: { sx: { maxHeight: 200, background: "rgb(220 226 231)" } } }}
                                >
                                    <MenuItem value="" onClick={ (e) => filterOnAttendance(e,'remove')}>
                                        <em>Clear</em>
                                    </MenuItem>
                                    {projectItems?.map((item: any) => {
                                        return (
                                            <MenuItem key={item?.id} value={item?.projectName}>
                                                <ListItemText primary={item?.projectName} />
                                            </MenuItem>
                                        );
                                    })}
                                </Select>
                            </FormControl>
                        </>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={6}>
                        <div>
                            <InputLabel id="demo-simple-select-label">
                                Role
                            </InputLabel>

                            <FormControl size="small" sx={{ width: '100%' }}>
                                <Select
                                    size='small'
                                    labelId="demo-multiple-checkbox-label"
                                    id="demo-multiple-checkbox"
                                    placeholder='Select Project'
                                    onChange={(event: SelectChangeEvent<object>, item) => {
                                        const { target: { value } } = event;
                                        filterOnAttendance(value, 'role')
                                    }}
                                    MenuProps={{ PaperProps: { sx: { maxHeight: 200, background: "rgb(220 226 231)" } } }}
                                >
                                    <MenuItem value="">
                                        <em>Clear</em>
                                    </MenuItem>
                                    {[
                                        { id: 4, role: "Site Head" },
                                        { id: 5, role: 'Supervisor' },
                                        { id: 'staffData', role: 'Site Staff' }]?.map((item: any) => {
                                            return (
                                                <MenuItem key={item?.id} value={item?.id}>
                                                    <ListItemText primary={item?.role} />
                                                </MenuItem>
                                            );
                                        })}
                                </Select>
                            </FormControl>
                        </div>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={6}>
                        <div>
                            <InputLabel id="demo-simple-select-label">
                                User
                            </InputLabel>
                            <FormControl size="small" sx={{ width: '100%' }}>
                                <Select
                                    size='small'
                                    labelId="demo-multiple-checkbox-label"
                                    id="demo-multiple-checkbox"
                                    placeholder='Select User'
                                    onChange={(event: SelectChangeEvent<object>) => {
                                        const { target: { value } } = event;
                                        filterOnAttendance(value, 'user')
                                    }}
                                    MenuProps={{ PaperProps: { sx: { maxHeight: 200, background: "rgb(220 226 231)" } } }}
                                >
                                    <MenuItem value="">
                                        <em>Clear</em>
                                    </MenuItem>
                                    {getUserByRole?.map((item: any) => {
                                        return (
                                            <MenuItem key={item?.user?.id} value={item?.user?.id}>
                                                <ListItemText primary={item?.user?.name} />
                                            </MenuItem>
                                        );
                                    })}
                                </Select>
                            </FormControl>
                        </div>
                    </Grid>

                    <Grid
                        sx={{ padding: '12px' }}
                        item
                        lg={6} md={6} sm={6} xs={6}
                    >
                        <AttendanceFilterDate>
                            <InputLabel>Select Date</InputLabel>
                            <DatePickerLineBox> 
                                <MinMaxDateRangePicker selectedDateRange={selectedDateRange} handleFilter={(e) => filterOnAttendance(e, 'date')} />
                            </DatePickerLineBox>
                        </AttendanceFilterDate>
                    </Grid>
                </Grid>
            </div>
        </>
    )
}

export default AttendanceFilter