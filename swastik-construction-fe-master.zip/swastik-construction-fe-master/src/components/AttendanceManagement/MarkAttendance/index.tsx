import { Button, Card, FormControl, FormHelperText, Grid, InputLabel, ListItemText, MenuItem, Select, SelectChangeEvent, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { Textarea } from '../../../../src/constants';
import useGet from '../../../hooks/useGet';
import { MarkAttendanceFormLayout } from '../../../app/styles'
import { is_checkin_attendance_url } from '../../../constants/api-routes';


const MarkAttendance = ({ position, handleClockInOut, selectedUser }: any) => {
    const currentDate: any = new Date();
    const selectedProject = useSelector((state: any) => state?.selectedProject)
    const [isClockIn, setIsClockIn] = useState(false);
    const [attendanceData, setAttendanceData] = useState({
        projectId: '',
        checkInTime: '',
        checkOutTime: '',
        userId: '',
        remark: ''
    })
    const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({});
    const { resData, handleGetData } = useGet()

    const submitAttendanceData = () => {
        const payload = {
            projectId: selectedProject?.selectedValue?.id,
            checkInTime: resData?.length === 0 ? currentDate.toISOString() : null,
            checkOutTime: resData?.length === 0 ? null : currentDate.toISOString(),
            latitude: position?.latitude,
            longitude: position?.longitude,
            userId: attendanceData?.userId,
            remark: attendanceData?.remark,
        } 
        const isValid = validateForm()
        if (isValid) {
            handleClockInOut(payload)
            setIsClockIn(!isClockIn)
        }
    }

    const validateForm = () => {
        const errors: { [key: string]: string } = {};
        if (!attendanceData?.userId) {
            errors.userId = 'User is required';
        }
        if (!attendanceData?.remark) {
            errors.remark = 'Remark is required';
        }
        setFormErrors(errors);
        return Object.keys(errors).length === 0;
    }

    const checkUserIsLoggedIn = (id: any) => {
        const res = handleGetData(`${is_checkin_attendance_url}/${id}`)
        return res;
    }

    useEffect(() => {
        if (!!resData) {
            setIsClockIn(true)
        } else {
            setIsClockIn(false)
        }
    }, [resData])

    return (
        <div>
            {
                <MarkAttendanceFormLayout>
                    <Card sx={{ padding: '20px' }}>
                        <Grid container spacing={2}>
                            <Grid item lg={12} md={12} sm={12} xs={12}>
                                <Typography paragraph={true} component={() => {
                                    return <>
                                        <div style={{
                                            fontSize: '20px',
                                            display: 'flex',
                                            justifyContent: ' space-between',
                                            width: '100%'
                                        }}>
                                            <span>Project: {selectedProject?.selectedValue?.name === null ? "" : selectedProject?.selectedValue?.name}  </span>
                                            <span>Location: {selectedProject?.selectedValue?.location === null ? "" : selectedProject?.selectedValue?.location} </span>
                                        </div>
                                    </>
                                }}
                                />
                            </Grid>

                            <Grid item lg={5} md={5} sm={5} xs={5}>
                                <InputLabel id="demo-simple-select-label">
                                    User
                                </InputLabel>
                                <FormControl size="small" sx={{ width: '100%' }}>
                                    <Select
                                        size='small'
                                        placeholder='Select Project'
                                        onChange={(event: SelectChangeEvent<object>) => {
                                            const { target: { value } } = event;
                                            setAttendanceData({ ...attendanceData, userId: value })
                                            checkUserIsLoggedIn(value);
                                            const updatedErrors = { ...formErrors };
                                            delete updatedErrors.userId;
                                            setFormErrors(updatedErrors);
                                        }}
                                        MenuProps={{ PaperProps: { sx: { maxHeight: 200, background: "rgb(220 226 231)" } } }}
                                    >
                                        { !selectedUser?.length ? <MenuItem>No Project Available</MenuItem>
                                            : selectedUser?.map((item: any) => {    
                                                return (
                                                    <MenuItem key={item?.id} value={item?.id}>
                                                        <ListItemText primary={item?.name} />
                                                    </MenuItem>
                                                );
                                            })
                                        }
                                    </Select>
                                </FormControl>
                                {formErrors?.userId && (
                                    <FormHelperText id="project-name-error" error>
                                        {formErrors?.userId}
                                    </FormHelperText>
                                )}
                            </Grid>

                            <Grid item lg={5} md={5} sm={5} xs={5}>
                                <InputLabel>
                                    Remark
                                </InputLabel>
                                <FormControl size="small" sx={{ width: '100%' }}>
                                    <Textarea
                                        sx={{resize: 'none'}}
                                        title="Remark"
                                        aria-label="minimum height"
                                        minRows={1}
                                        placeholder="Remark"
                                        value={attendanceData?.remark}
                                        onChange={(e) => {
                                            const value = e.target.value;
                                            setAttendanceData({
                                                ...attendanceData,
                                                remark: value,
                                            });
                                            const updatedErrors = { ...formErrors };
                                            delete updatedErrors.remark;
                                            setFormErrors(updatedErrors);
                                        }}
                                    />
                                </FormControl>
                                {formErrors?.remark && (
                                    <FormHelperText id="project-name-error" error>
                                        {formErrors?.remark}
                                    </FormHelperText>
                                )}
                            </Grid>

                            <Grid item lg={2} md={2} sm={2} xs={3}>
                                <Button
                                    variant='contained' size='small'
                                    disabled={false}
                                    onClick={submitAttendanceData}
                                >
                                    {resData?.length === 0 ? ' Clock In' : 'Clock Out'}
                                </Button>
                            </Grid>
                        </Grid>
                    </Card>
                </MarkAttendanceFormLayout>
            }
        </div>
    )
}

export default MarkAttendance