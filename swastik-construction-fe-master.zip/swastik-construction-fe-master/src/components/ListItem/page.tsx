import * as React from 'react';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { Autocomplete, Button, Checkbox, Chip, FormControl, Grid, IconButton, InputLabel, MenuItem, Select, SelectChangeEvent, Skeleton, TextField, Tooltip, Typography } from '@mui/material';
import { roles } from '../../constants/roles'
import editIcon from '../../../assets/img/editIcon.png';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import usePatch from '../../hooks/usePatch';
import useDelete from '../../hooks/useDelete';
import Image from 'next/image';
import CustomTooltip from '../../components/Tooltip/Tooltip';
import { useRouter } from 'next/navigation';
import { baseImgUrl, material_url } from '../../constants/api-routes';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import { useSession } from 'next-auth/react';
import useGet from 'src/hooks/useGet';
import {MenuProps} from 'src/constants/table-columns';
import NoImage from '../../../public/images/no-image-png-2.png';
import Link from 'next/link';

interface listItemComponentType {
    data?: any;
    title?: any;
    brandData?: any;
    refreshData?: any;
    catData?: any;
}

const ListItemComponent = ({ data, title, brandData, refreshData, catData }: listItemComponentType) => { 
    const [assignProject, setAssignProject] = React.useState(data)
    const [materialTableData, setMaterialTableData] = React.useState<any>(data?.subItem)
    const [isEditable, setIsEditable] = React.useState(false)
    const [editSubItemData, setEditSubItemData] = React.useState<any>(data)
    const { handleUpdateData } = usePatch()
    const { handleDeleteData } = useDelete()
    const [allBrandsData, setAllBrandsData] = React.useState([])
    const router = useRouter()
    const { data: session }:any = useSession()
    const {resData, handleGetData} = useGet()

    React.useEffect(() => {
        setAllBrandsData(data?.brandNames || [])
        if(title === 'Project Detail' && [2, 4, 5].includes(session?.user?.role_id)){
            fetctAssignedUsers()
        }
    }, [data])

    React.useEffect(() => {
        setAssignProject(data)
        setMaterialTableData(data?.subItem)
        setEditSubItemData(data) 
    }, [data, brandData])

    const onEditSubItem = (itemRow: any) => {
        setIsEditable(!isEditable)
        setEditSubItemData(itemRow)
    }

    const onSaveSubItem = async () => {
        const index = materialTableData?.findIndex(item => item.id === editSubItemData?.id);
     
        const formData = new FormData()
        formData.append('id', editSubItemData?.id)
        formData.append('productName', editSubItemData?.productName)
        formData.append('image', editSubItemData?.image)
        formData.append('categoryId', editSubItemData?.categoryId)
        formData.append('specification', editSubItemData?.specification)
        formData.append('size', editSubItemData?.size)

        if (!!editSubItemData?.brands?.length) {
            formData.append('brandId', editSubItemData?.brands?.map(item => item?.id)?.join(',')) 
        } 
 
        if (index !== -1) {
            const newArray = [...materialTableData];
            newArray[index] = {
                ...newArray[index],
                productName: editSubItemData?.productName,
                specification: editSubItemData?.specification,
                size: editSubItemData?.size,
            };
            await handleUpdateData(material_url, formData)
            setMaterialTableData(newArray)
            refreshData()
            setIsEditable(!isEditable)
        } else {
            const res = await handleUpdateData(material_url, formData)
            router.back()
            return res;
        }
    }

    const removeSubItem = async (id: string) => {
        const newData = materialTableData?.filter((_: any, index: any) => index !== id);
        const res = await handleDeleteData(`${material_url}/${id}`)
        setMaterialTableData(newData)
        refreshData()
        return res;
    }

    const handleCancel = () => {
        if (!materialTableData?.length) {
            router.back()
        } else {
            setIsEditable(!isEditable)
        }
    }

    const fetctAssignedUsers = () => {
        handleGetData(`/project/list?projectId=${data?.projectId}`)
    }
  
    return (
        <>
            {
                title === 'Project Detail' && <> 
                    <Grid container spacing={2}>
                        <Grid item md={3} lg={3} sm={3}>
                        {data?.projectId && <ListItemText primary={"Project Id"} secondary={data?.projectId} />}
                        </Grid>
                        <Grid item md={3} lg={3} sm={3}>
                        <ListItemText primary={"Project Name"} secondary={data?.projectName} />
                        </Grid>
                        <Grid item md={3} lg={3} sm={3}>
                        <ListItemText primary={"Location"} secondary={data?.location} />
                        </Grid>
                        <Grid item md={3} lg={3} sm={3}>
                        <ListItemText primary={"Start Date"} secondary={!!data?.startDate ? data?.startDate : "_"} />
                        </Grid>
                        <Grid item md={3} lg={3} sm={3}>
                        <ListItemText primary={"End Date"} secondary={ !!data?.endDate ? data?.endDate : "_"} />
                        </Grid>
                        <Grid item md={3} lg={3} sm={3}>
                        {data?.status && <ListItemText primary={"Status"} secondary={data?.status} />}
                        </Grid>
                    { data?.description && 
                        <Grid item md={12} lg={12} sm={12}>
                        <ListItemText primary={"Description"} secondary={data?.description} />
                        </Grid>} 
                        { data?.remark && <Grid item md={12} lg={12} sm={12}>
                        <ListItemText primary={"Remark"} secondary={data?.remark} />
                        </Grid>} 
                        
                    </Grid> 
                    <div style={{ margin: '5px 0' }}>
                        <h4>All Assigned Users</h4>
                    </div>
                    <List sx={{ width: '100%', maxWidth: '100%', bgcolor: 'background.paper' }}>
                        {(!assignProject?.assignproject?.length && ![2, 4, 5].includes(session?.user?.role_id)) && <> <ListItemText primary={'Not assigned'} /></>}
                            <Grid container spacing={2}> 
                                {(!!assignProject?.assignproject?.length) && assignProject?.assignproject?.filter((aUser:any) => aUser?.user !== null )?.map((value: any) => {
                                    let userRole = roles?.filter((fItem: any) => fItem?.id === value?.user?.role?.id)?.map(item => item?.label).join('');
                                    return value?.user && (
                                        <>
                                        <Grid item md={6} lg={6} sm={6}>
                                            <ListItem
                                                key={value?.id}
                                                disableGutters
                                                secondaryAction={
                                                    <Chip label={userRole} variant="filled" color='success' />
                                                }>
                                                <ListItemText primary={value?.user?.name} secondary={((value?.user?.email !== null) || (value?.user?.email == "")) ? value?.user?.email : "Not Specified "} />
                                            </ListItem>
                                        </Grid>
                                        </>
                                    )
                                })}

                                {(!![2, 4, 5].includes(session?.user?.role_id) && (!!resData?.items?.[0]?.assignProject)) &&
                                     resData?.items?.[0]?.assignProject?.filter((aUser:any) => aUser?.user !== null )?.map((value: any) => {
                                        let userRole = roles?.filter((fItem: any) => fItem?.id === value?.user?.role?.id)?.map(item => item?.label).join('');
                                        return value?.user && (
                                            <>
                                            <Grid item md={6} lg={6} sm={6}>
                                                <ListItem
                                                    key={value?.id}
                                                    disableGutters
                                                    secondaryAction={
                                                        <Chip label={userRole} variant="filled" color='success' />
                                                    }>
                                                    <ListItemText primary={value?.user?.name} secondary={((value?.user?.email !== null) || (value?.user?.email == "")) ? value?.user?.email : "Not Specified "} />
                                                </ListItem>
                                            </Grid>
                                            </>
                                        )
                                })}
                            </Grid>
                    </List> 
                </>
            } 
            
            {title === 'Material Details' && <TableContainer component={Paper}>
                { 
                    <>
                        <Grid container sx={{ padding: '20px' }} spacing={2}>
                            <Grid item lg={6} md={6} sm={6} xs={6}>
                                <InputLabel htmlFor="my-input">Category</InputLabel>
                                <FormControl
                                    sx={{ width: '100%' }}
                                >
                                    {
                                        !!materialTableData?.length ? <>
                                            <TextField
                                                size='small'
                                                type="text"
                                                id="my-input"
                                                value={editSubItemData?.category?.categoryName}
                                            />
                                        </> : <>
                                            <Select
                                                size='small'
                                                labelId="demo-simple-select-filled-label"
                                                id="demo-simple-select-filled"
                                                displayEmpty={true}
                                                defaultValue={editSubItemData?.category?.categoryName}
                                                value={editSubItemData?.category?.id}
                                                onChange={(e) => {    
                                                    setEditSubItemData({
                                                        ...editSubItemData,
                                                        categoryName: e.target.value,
                                                        categoryId: e.target.value
                                                    });
                                                }}
                                                renderValue={(selected) => { 
                                                    const categoryData=catData?.filter((fItem:any) => fItem.id === selected)?.map((item) => item?.categoryName) 
                                                    return selected === undefined ? editSubItemData?.category?.categoryName : categoryData;
                                                }}
                                                MenuProps={MenuProps}
                                            >
                                                {catData?.map((item: any) => {
                                                    return (
                                                        <MenuItem
                                                            key={item?.id}
                                                            value={item?.id}
                                                        >
                                                            {item?.categoryName}
                                                        </MenuItem>
                                                    );
                                                })}
                                            </Select>

                                        </>
                                    }
                                </FormControl>
                            </Grid>

                            <Grid item lg={6} md={6} sm={6} xs={6}>
                                <InputLabel htmlFor="my-input">Unit</InputLabel>
                                <FormControl sx={{ width: '100%' }}>
                                    <TextField
                                        size='small'
                                        type="text"
                                        id="my-input"
                                        defaultValue={data?.unit}
                                    />
                                </FormControl>
                            </Grid>

                            {(isEditable || !materialTableData?.length) &&
                                <>
                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <InputLabel htmlFor="my-input"> Name</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                type="text"
                                                id="my-input"
                                                defaultValue={data?.productName}
                                                value={editSubItemData?.productName}
                                                onChange={(e) => {
                                                    setEditSubItemData({
                                                        ...editSubItemData,
                                                        productName: e.target.value,
                                                    });
                                                }}
                                                aria-describedby="my-helper-text"
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <InputLabel htmlFor="my-input">Specification</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                type="text"
                                                id="my-input"
                                                disabled={!editSubItemData?.specification}
                                                value={editSubItemData?.specification}
                                                onChange={(e: any) => {
                                                    const value = e.target.value;
                                                    setEditSubItemData({
                                                        ...editSubItemData,
                                                        specification: value,
                                                    });
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <InputLabel htmlFor="my-input">Size</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                            <TextField
                                                size='small'
                                                type="text"
                                                id="my-input"
                                                disabled={!editSubItemData?.size}
                                                value={editSubItemData?.size}
                                                onChange={(e: any) => {
                                                    const value = e.target.value;
                                                    setEditSubItemData({
                                                        ...editSubItemData,
                                                        size: value,
                                                    });
                                                }}
                                            />
                                        </FormControl>
                                    </Grid> 
                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <InputLabel htmlFor="my-input">Brand</InputLabel>
                                        <FormControl sx={{ width: '100%' }}> 
                                            <Autocomplete 
                                                 multiple
                                                size='small'
                                                options={allBrandsData}
                                                value={editSubItemData?.brandNames}
                                                disableCloseOnSelect
                                                getOptionLabel={(option: any) => {
                                                    return option?.brandName || '';
                                                }} 
                                                onChange={(event, newValue: any) => { 
                                                    setEditSubItemData({
                                                        ...editSubItemData,
                                                        brands: newValue,
                                                        brandId: newValue
                                                    })
                                                }}
                                                renderOption={(props, option: any, { selected }) => ( 
                                                    <li {...props}>
                                                        <Checkbox
                                                            checkedIcon={<CheckBoxIcon fontSize="small" />}
                                                            style={{ marginRight: 8 }}
                                                            checked={selected}
                                                        />
                                                        {option?.brandName}
                                                    </li>
                                                )}
                                                renderInput={(params) => ( 
                                                       <TextField {...params} placeholder="Select Request" />
                                                   )}
                                                fullWidth
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item lg={6} md={6} sm={6} xs={6}>
                                        <InputLabel htmlFor="my-input">Image</InputLabel>
                                        <FormControl sx={{ width: '100%' }}>
                                        <TextField
                                            size='small'
                                            type="file"
                                            id="my-input" 
                                            onChange={(e: any) => {
                                                const value = e.target.files[0];
                                                setEditSubItemData({
                                                    ...editSubItemData,
                                                    image: value,
                                                });
                                            }}
                                            inputProps={{
                                              accept: "image/png, image/gif, image/jpeg"
                                             }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <Button sx={{ margin: '24px', float: 'right' }} variant='contained' onClick={() => onSaveSubItem()}>Save</Button>
                                        <Button sx={{ margin: '24px', float: 'right' }} variant='contained' onClick={handleCancel}>Cancel</Button>
                                    </Grid>
                                </>
                            }
                        </Grid>

                        {!isEditable && !!materialTableData?.length && <TableContainer component={Paper}>
                            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                <TableHead>
                                    <TableRow sx={{ fontWeight: '700', fontSize: '14px' }} component="th" scope="row">
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >S No.</TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Image</TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Name</TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Type / Grade </TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Specification</TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Size</TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Brand</TableCell>
                                        <TableCell align="left" sx={{ fontWeight: '700', fontSize: '14px' }} >Action</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody> 
                                    {!!materialTableData?.length ? materialTableData?.map((row: any, index: number) => { 
                                        return <>
                                            <TableRow
                                                key={row?.id}
                                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                            >
                                                <TableCell align="left">{index + 1}</TableCell>
                                                <TableCell align="left">
                                                    {
                                                        !!row?.image ? 
                                                        <Link aria-disabled={true} href={`${baseImgUrl}${row?.image}`} target='_blank'>
                                                        <Image src={`${baseImgUrl+row.image}`} 
                                                        alt="noimage"
                                                        crossOrigin="anonymous"
                                                        height="70" width="70" 
                                                        />
                                                        </Link> :
                                                        <Image 
                                                            src={`${baseImgUrl+NoImage.src}`} 
                                                            alt="noimage"
                                                            crossOrigin="anonymous"
                                                            height="70" width="70" 
                                                        /> } 
                                                </TableCell>
                                                <TableCell align="left"> {data?.productName}</TableCell>
                                                <TableCell align="left"> {row?.productName} </TableCell>
                                                <TableCell align="left">{!!row?.specification?.length ? row?.specification : "_"}</TableCell>
                                                <TableCell align="left">{!!row?.size?.length ? row?.size : "_"}</TableCell>
                                                <TableCell align="left"> {!!assignProject?.brandNames?.length ? assignProject?.brandNames?.map(i => i?.brandName).join() : "_"}</TableCell>
                                                <TableCell align="left">
                                                    <Tooltip title="Edit">
                                                        <IconButton
                                                            color="success"
                                                            size="small"
                                                            aria-label="delete"
                                                            onClick={() => onEditSubItem(row)}
                                                        >
                                                            <Image src={editIcon} width={18} height={18} alt='edit' />
                                                        </IconButton>
                                                    </Tooltip>

                                                    <IconButton
                                                        color="error"
                                                        size="small"
                                                        aria-label="delete"
                                                    >
                                                        <CustomTooltip
                                                            title={"Type / Grade"}
                                                            handleAction={() =>
                                                                removeSubItem(row?.id)
                                                            }
                                                            row={row}
                                                        />
                                                    </IconButton>
                                                </TableCell>
                                            </TableRow>
                                        </>
                                    }) : <> No Data Available</>
                                    }
                                </TableBody>
                            </Table>
                            {<Button sx={{ margin: '25px', float: 'right' }} variant='contained' onClick={() => router.back()}>Cancel</Button>}
                        </TableContainer>
                        }
                    </>
                }

            </TableContainer>
            }

            {(title === "Category") && 
             <div style={{ display: 'block', margin: '10px 0' }}> 
             <Grid container spacing={2}> 
                 <Grid item md={6} lg={6} sm={6}> 
                   <ListItemText primary={"Category Name"} secondary={data?.categoryName} />
                 </Grid>
                 <Grid item md={6} lg={6} sm={6}> 
                   <ListItemText primary={"Type"} secondary={data?.type} />
                 </Grid>   
             </Grid>
            </div>
            }

            {title === "Material" && <>
                <Grid container sx={{ padding: '5px ' }} spacing={2}>  
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                        <ListItemText primary={"Category"} secondary={data?.categoryName} />
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Material"} secondary={data?.productName} /> 
                        </Typography> 
                    </Grid>
                     <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Type / Grade"} secondary={!!data?.itemName ? data?.itemName : "N/A"} />  
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Specification"} secondary={!!data?.specification ? data?.specification : "N/A"} /> 
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Size"} secondary={!!data?.size ? data?.size : "N/A" } />    
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Unit"} secondary={ data?.unit } /> 
                        </Typography>  
                    </Grid>
                    <Grid item lg={12} md={12} sm={12} xs={12}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">  
                       
                       {
                        !!data?.image ? 
                        <Link href={`${baseImgUrl}${data?.image}`} target='_blank'>
                              <Image src={`${baseImgUrl+data?.image}`} 
                              width={100} height={100} 
                              crossOrigin='anonymous' 
                              alt='noimage' 
                              />
                        </Link> :
                        <Image src={`${baseImgUrl+NoImage.src}`} 
                              width={100} height={100} 
                              crossOrigin='anonymous' 
                              alt='noimage' 
                              />
                       } 
                        </Typography> 
                    </Grid>
                </Grid> 
            </>}

            {title === "Brand" && <>
                <Grid container sx={{ padding: '5px ' }} spacing={2}>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                       <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                          <ListItemText primary={"Brand Name"} secondary={data?.brandName} />
                        </Typography> 
                    </Grid> 
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                        <ListItemText primary={"Type"} secondary={data?.type} />
                        </Typography> 
                    </Grid>
                </Grid>
            </>}

            {title === "Vendor" && <>
                <Grid container sx={{ padding: '5px ' }} spacing={2}>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                       <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                          <ListItemText primary={"Vendor"} secondary={data?.name} />
                        </Typography> 
                    </Grid> 
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                        <ListItemText primary={"Address"} secondary={data?.address} />
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                        <ListItemText primary={"Contact No."} secondary={data?.contact} />
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                        <ListItemText primary={"GSTIN"} secondary={data?.GSTIN} />
                        </Typography> 
                    </Grid>
                    <Grid item lg={12} md={12} sm={12} xs={12}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h5" component="div"> 
                        <ListItemText primary={"Category"} secondary={data?.category} />
                        </Typography> 
                    </Grid>
                </Grid>
            </>}

            {title === "Staff" && <>
                <Grid container sx={{ padding: '5px ' }} spacing={2}>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Staff"} secondary={data?.name} /> 
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Mobile Number"} secondary={data?.mobileNumber} /> 
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Project Name"} secondary={data?.projectName} /> 
                        </Typography> 
                    </Grid>
                    <Grid item lg={6} md={6} sm={6} xs={6}> 
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div">
                        <ListItemText primary={"Created By"} secondary={data?.createdBy} /> 
                        </Typography> 
                    </Grid>
                    <Grid item lg={12} md={12} sm={12} xs={12}>  
                        <Typography sx={ { ml: 2, flex: 1 } } variant="h6" component="div"> 
                            {
                                !!data?.image ? 
                                <Link href={`${baseImgUrl}${data?.image}`} target='_blank'>
                                <Image 
                                    src={`${baseImgUrl}${data?.image}`} 
                                    alt='staff-img'
                                    width={100} height={100} 
                                    crossOrigin='anonymous'    
                                /> 
                                </Link>
                                :
                                <Image 
                                    src={`${baseImgUrl+NoImage.src}` } 
                                    alt='no-img'
                                    width={100} height={100} 
                                    crossOrigin='anonymous'    
                                /> 
                            } 
                        </Typography> 
                    </Grid>  
                </Grid> 
            </>}
        </>
    );
}

export default ListItemComponent; 