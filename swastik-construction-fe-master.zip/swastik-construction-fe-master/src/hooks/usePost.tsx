import { useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../constants/api-routes';
import { useAllowedNavigation } from '../context/context';
import handleMessageToaster from 'src/components/commonComponents/handleMessageToaster';
import {toast} from 'react-toastify';

const axiosInstance = axios.create({
  baseURL: baseUrl,
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token =
      typeof window !== 'undefined' ? localStorage.getItem('token') : '';
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const usePost = () => {
  const [isLoading, setIsLoading] = useState(null);
  const [error, setError] = useState(null);
  const [resData, setResData] = useState(null);
  const { setRenderData } = useAllowedNavigation();

  const [openSuccess, setOpenSuccess] = useState(false);
  const [openError, setOpenError] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  const handlePostData = async (url: string, payload: any, title?: string) => {
    setIsLoading(true);

    const result = await axiosInstance.post(url, payload)
      .then((response: any) => {
        if (response.status == 200) { 
          setResData(response);
          setIsLoading(false);
          setRenderData(true);
          // setOpenSuccess(true); 
          
          const message: any = handleMessageToaster(response)
          toast.success(message, {autoClose: 1000});
          // setSnackbarMessage(message);
          setError(null)
          return response;
        }
      })
      .catch((error) => { 
        setResData(null)
        // const message: any = handleMessageToaster(error)
        // setOpenError(true)
        toast.error(error?.response?.data?.MESSAGE) 
        setError(error)
        return error;
      })
    return result;
  };

  return {
    resData,
    isLoading,
    error,
    handlePostData,
    openSuccess,
    openError,
    snackbarMessage,
    setOpenSuccess,
    setOpenError,
    setSnackbarMessage,
  };
};

export default usePost;
