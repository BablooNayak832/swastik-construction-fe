import { useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../constants/api-routes';
import { useAllowedNavigation } from '../context/context';
import handleMessageToaster from 'src/components/commonComponents/handleMessageToaster';
import {toast} from 'react-toastify';
const axiosInstance = axios.create({
  baseURL: baseUrl,
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token =
      typeof window !== 'undefined' ? localStorage.getItem('token') : '';
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const useDelete = () => {
  const [resData, setResData] = useState(null);
  const [isLoading, setIsLoading] = useState(null);
  const [error, setError] = useState(null);
  const { setRenderData } = useAllowedNavigation()

  const [openSuccess, setOpenSuccess] = useState(false);
  const [openError, setOpenError] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');


  const handleDeleteData = async (url) => {
    setIsLoading(true);
    const getData = await axiosInstance.delete(url)
      .then((response) => {
        if (response.status == 200) {
          setResData(response.data);
          setIsLoading(false);
          setRenderData(true)
          setOpenSuccess(true);
          const message: any = handleMessageToaster(response)
          toast.success(message, { autoClose: 1000}); 
          return response.data;
        }
      })
      .catch((error) => {
        const message: any = handleMessageToaster(error)
        toast.error(message);
        setOpenError(true)
        setError(error)
        return error;
      })
    return getData;
  };

  return {
    resData,
    isLoading,
    error,
    handleDeleteData,
    openSuccess,
    openError,
    snackbarMessage,
    setOpenSuccess,
    setOpenError
  };
};

export default useDelete;
