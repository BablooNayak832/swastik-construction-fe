import axios from 'axios';
import { baseUrl } from '../constants/api-routes';
import { signOut } from 'next-auth/react'; 

const axiosInstance = axios.create({
    baseURL: baseUrl
});

axiosInstance.interceptors.request.use(
    (config) => {
        const token =
            typeof window !== 'undefined' ? localStorage.getItem('token') : '';
        if (token) {
            if (config.url?.includes('/pdf')) {
                config.responseType = 'blob';
            }
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

const useDownloadPDF = () => {     
    const handleDownloadPDF = async (url: string, title?: string) => {
        const currentDateTime = new Date().toLocaleString()
        const [datePart, timePart] = currentDateTime.split(', ');
        const formattedDate = datePart.replace(/\//g, '-'); 
        const finalFormat = `[${formattedDate}]&[${timePart}]`; 
        
        const result = await axiosInstance.get(url, { responseType: 'blob' })
            .then((response) => { 
                if (response.status == 200) { 
                    if (response?.data) {
                        const url = URL.createObjectURL(new Blob([response?.data]));
                        const link = document.createElement('a');
                        link.href = url; 
                        link.setAttribute('download', `${title}-${finalFormat}.pdf`); 
                        document.body.appendChild(link);
                        link.click(); 
                    }
                }
            })
            .catch((error) => {
                if (error?.response?.data?.MESSAGE === 'jwt expired' || error?.response?.data?.MESSAGE === 'login_again') {
                   signOut({ callbackUrl: "/auth/signin" })
                }
            })
        return result;
    };

    return { handleDownloadPDF };
};

export default useDownloadPDF;


