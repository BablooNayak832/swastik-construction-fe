'use client';
import React from 'react';
import Login from '../components/Auth/Login/Login';
import { useSession } from "next-auth/react"
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic'; 
import useFCM from '../utils/hooks/useFCM'
const AppLayout = dynamic(() => import('../common/Layouts/appLayout'), { ssr: false });  
function hasRequiredPermissions(permissions: string[], role: any): boolean {
  return permissions?.includes(role)
}

const withAuth = (WrappedComponent: any, requiredPermissions: any[]) => {
  if (requiredPermissions) {
    function AuthComponent(props: any) {
      const { status, data: session } = useSession();
      const router = useRouter();  
      const {messages} = useFCM() 
 
      console.warn("message",messages);
     
      if (status === 'authenticated') {
        if (hasRequiredPermissions(requiredPermissions, session?.user?.role_id)) { 
          return (
            <AppLayout> 
              <WrappedComponent {...props} />
            </AppLayout>
          )
        } else { 
          router.replace('/')
          return null
        }
      }
      return <Login />;
    }
    return AuthComponent;
  }
  return WrappedComponent
};

export default withAuth;
