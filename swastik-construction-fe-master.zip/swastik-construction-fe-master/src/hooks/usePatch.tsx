import { useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../constants/api-routes';
import { useAllowedNavigation } from '../context/context';
import handleMessageToaster from '../components/commonComponents/handleMessageToaster'
import {toast} from 'react-toastify';

const axiosInstance = axios.create({
  baseURL: baseUrl
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token =
      typeof window !== 'undefined' ? localStorage.getItem('token') : '';
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const usePatch = () => {
  const [resData, setResData] = useState(null);
  const [isLoading, setIsLoading] = useState(null);
  const [error, setError] = useState(null);
  const { setRenderData } = useAllowedNavigation()


  const [openSuccess, setOpenSuccess] = useState(false);
  const [openError, setOpenError] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  const handleUpdateData = async (url: string, payload: object, title?: string) => {
    setIsLoading(true);
    const getData = await axiosInstance.patch(url, payload)
      .then((response) => {
        if (response.status == 200) { 
          toast.success(response.data.MESSAGE, {
                position: "top-right",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",  
          })
          // setOpenSuccess(true);
          setResData(response.data);
          setIsLoading(false);
          setRenderData(true)
          setError(null)
          // const message: any = handleMessageToaster(response)
          // setSnackbarMessage(message);
        }
      })
      .catch((error) => {
        setResData(null);
        setOpenError(true)
        setError(error)
        // const message: any = handleMessageToaster(error)
        toast.error(error?.response?.data?.MESSAGE, {
          position: "top-right",
          autoClose: 1000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "light",  
       })
        // setSnackbarMessage(message)
      })
    return getData;
  };

  return {
    resData,
    isLoading,
    error,
    handleUpdateData,
    openSuccess,
    openError,
    snackbarMessage,
    setOpenSuccess,
    setOpenError,
  };
};

export default usePatch;
