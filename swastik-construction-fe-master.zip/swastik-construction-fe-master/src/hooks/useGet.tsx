import { useState } from 'react';
import axios from 'axios';
import { baseUrl } from '../constants/api-routes';
import { useAllowedNavigation } from '../context/context';
import { signOut } from 'next-auth/react';
import handleMessageToaster from 'src/components/commonComponents/handleMessageToaster';

const axiosInstance = axios.create({
  baseURL: baseUrl
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token =
      typeof window !== 'undefined' ? localStorage.getItem('token') : '';
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const useGet = () => {
  const [resData, setResData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const { setRenderData } = useAllowedNavigation()

  const handleGetData = async (url: string) => { 
    setIsLoading(false)
    const result = await axiosInstance.get(url)
      .then((response) => {  
        if (response.status == 200) {
          handleMessageToaster(response)
          setResData(response.data);
          setIsLoading(true);
          setRenderData(false)
        }
      })
      .catch((error) => {
        if (error?.response?.data?.MESSAGE === 'jwt expired' || error?.response?.data?.MESSAGE === 'login_again' || error?.response?.data?.MESSAGE === "Cannot read properties of undefined (reading 'token')") {
          signOut({ callbackUrl: "/auth/signin" })
        }
      })

    return result;
  };

  return { resData, isLoading, setIsLoading, error, handleGetData };
};

export default useGet;
