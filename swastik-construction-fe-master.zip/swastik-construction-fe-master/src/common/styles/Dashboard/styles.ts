import styled from 'styled-components';
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import DashboardCustomizeIcon from '@mui/icons-material/DashboardCustomize';
import AddCircleIcon from '@mui/icons-material/AddCircle';
import NotificationsOutlinedIcon from '@mui/icons-material/NotificationsOutlined';
import { Stack } from '@mui/material';
import { theme } from '../theme';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import { Button } from '@mui/material';

export const MainBox = styled.div`
  // padding: 22px;
  // margin-top: -40px;

  .MuiAvatarGroup-root {
    justify-content: left;
  }

  td {
    td {
      border-bottom: 0px solid;
    }
  }

  .esFOas {
    background-color: white;
    padding: 35px;
    overflow-y: auto;
  }
  .cJdJX {
    background-color: white;
    padding: 35px;
  }
`;

export const RequestVerificationTable = styled.div`
  .MuiTableCell-stickyHeader {
    font-weight: 600;
    font-size: 15px;
  }
  #contained-button-file input: {
    display: none;
  },
`;
export const AvatarInput = styled.div`
  margin-bottom: 32px;
  position: relative;
  align-self: center;
  img {
    width: 186px;
    height: 186px;
    object-fit: cover;
    border-radius: 50%;
  }
  .circle {
    width: 186px;
    height: 186px;
    border-radius: 50%;
  }
  label {
    right: 23em !important;
    position: absolute;
    width: 48px;
    height: 48px;
    background: #312e38;
    border-radius: 50%;
    right: 0;
    bottom: 0;
    border: 0;
    cursor: pointer;
    transition: background-color 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    input {
      display: none;
    }
    svg {
      width: 20px;
      height: 20px;
      color: #f4ede8;
    }
    &:hover {
      background: blue;
    }
  }
`;

export const ContainerMain = styled(Stack)`
  background-color: white;
  padding: 35px;
`;
export const Menuicon = styled(MenuIcon)`
  font-size: 20px;
  margin: 18px 5px;
`;
export const MainContainer = styled.div`
  // display: inline-block;
  width: 100%;
  .MuiFormControl-root.MuiFormControl-fullWidth.MuiTextField-root.css-wb57ya-MuiFormControl-root-MuiTextField-root:focus-visible {
    border: 1px solid;
    outline-color: rgb(255 53 53 / 87%);
  }
  .Mui-focused .MuiOutlinedInput-notchedOutline,
  .css-154xyx0-MuiInputBase-root-MuiOutlinedInput-root:hover
    .MuiOutlinedInput-notchedOutline {
    border: 1px solid;
    border-color: rgb(255 53 53 / 87%) !important;
  }
  .css-154xyx0-MuiInputBase-root-MuiOutlinedInput-root {
    border-radius: 12px;
  }
  .MuiAutocomplete-endAdornment .css-i4bv87-MuiSvgIcon-root {
    fill: rgb(159 150 150 / 54%);
  }
  .MuiAutocomplete-endAdornment
    .css-qzbt6i-MuiButtonBase-root-MuiIconButton-root-MuiAutocomplete-popupIndicator {
    color: rgb(159 150 150 / 54%);
  }
`;

export const FilterLayout = styled.div`
  width: 100%;
`;

export const AvailableQuantityButton = styled(Button)`
  color: red !important;
  border: 1px solid red !important;
`;

export const SortByLayout = styled.div`
  em {
    color: #fff;
    font-size: 14px;
  }
  .css-11u53oe-MuiSelect-select-MuiInputBase-input-MuiOutlinedInput-input {
    background: #6c757d;
  }
`;

export const AppWrapper = styled.div`
  display: flex; 
  height: calc(100vh - (-68px)) 
`;

export const ChildrenLayout = styled.div` 
  height: 100%;  
  overflow: auto;  
  padding: 0 10px;
  background: #f3f2f7;
  .sc-fXSgeo .seUrT {
    height: 90vh;
  }

  .css-1h9z7r5-MuiButtonBase-root-MuiTab-root.Mui-selected {
    color: ${theme.colors.Red};
  }
  .css-1aquho2-MuiTabs-indicator {
    background-color: ${theme.colors.Red};
  }
`;

export const MainLayout = styled.div`
  display: block;
  width: 100%;
  overflow: auto;s
  background-color: #f4f6f9;
`;

export const SiteNameLayout = styled.div`
  font-size: 20px;
  font-weight: 700;
  width: inherit;
  display: block;
`;

export const LoggedinUserText = styled.div`
  width: inherit;
  display: block;
  margin: 30px 30px;
  max-width: fit-content;
`;

export const FilterTextBox = styled.span`
  margin: 0 5px;
`;
export const FilterButtonBox = styled.div`
  display: flex;
  gap: 10px;
  margin-left: auto;
  .MuiButton-root {
    text-transform: none;
    // background: rgba(0, 126, 250, 0.8) !important;
    // width: -webkit-fill-available;
  }
  button#demo-customized-button {
    height: 40px;
  }

  .css-1e6y48t-MuiButtonBase-root-MuiButton-root:hover {
    background: red;
  }
  .MuiFormLabel-root.MuiInputLabel-root,
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    line-height: 15px;
    color: ${theme.colors.Gray};
    // top: -4px;
    font-weight: 500;
  }
`;

export const AttendanceContainer = styled.div`
  float: right;
  margin-top: 25px;
  margin: 22px auto;
  width: 25%;
`;

export const FilterTextLayout = styled.div`
  background: #f3f2f7; 
  width: 250px;
  .css-vkf9rd-MuiTreeItem-root:hover {
    background-color: ${theme.colors.Red};
    color: ${theme.colors.white};
  }
  .css-1bcfi89-MuiTreeItem-content{
    padding: 4px 6px;
  }
  .css-1bcfi89-MuiTreeItem-content.Mui-selected {
    background-color: ${theme.colors.Red} !important;
    color: white;
  }
  .MuiTreeItem-group{
    margin: 0 6px !important;
  }
  .MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded{
     box-shadow: 1px 2px 10px #0601015c !important;
  }
`;

export const SearchFilterLayout = styled.div`
  display: flex;
  align-items: center;
  width: 100%;
  justify-content: space-between;
  padding: 14px 0px 14px;

  em {
    color: #fff;
    font-size: 14px;
  }
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    color: #fff;
  }

  .css-hfutr2-MuiSvgIcon-root-MuiSelect-icon {
    color: ${theme.colors.Gray};
  }
  .css-1vsmau8-MuiButtonGroup-root {
    background: #3699ff; //#6c757d;
  }
  .css-1vsmau8-MuiButtonGroup-root .MuiButtonGroup-grouped {
    min-width: 100px;
    color: #fff;
    border: none;
    font-size: 14px;
  }
  .css-9ddj71-MuiInputBase-root-MuiOutlinedInput-root {
    color: #fff;
    border-radius: 0px;
  }
  .css-1vsmau8-MuiButtonGroup-root .MuiButtonGroup-firstButton,
  .css-1vsmau8-MuiButtonGroup-root .MuiButtonGroup-middleButton {
  }
  .MuiSelect-select.MuiSelect-multiple {
    white-space: nowrap;
    width: 70px;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .css-1i2mftt-MuiFormControl-root {
    margin: 0 10px;
  }
  .MuiFormLabel-root.MuiInputLabel-root,
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    line-height: 15px;
    color: ${theme.colors.Gray};
    // top: 2px;
    font-weight: 500;
  }
  label#demo-customized-select-label.MuiInputLabel-shrink {
    top: -8px;
    color: #000 !important;
    left: -13px;
  }
  .MuiSelect-select.MuiSelect-outlined.MuiInputBase-input {
    // background: ${theme.colors.white};
    // color: ${theme.colors.black};
    padding: 8px;
    // border: 1px solid #66666636;
    // border-radius: 12px;
  }
  .MuiInputBase-root.MuiOutlinedInput-root,
  .css-o9k5xi-MuiInputBase-root-MuiOutlinedInput-root {
    // border-radius: 12px;
    // border: 1px solid #6663;
    // width: max-content;
  }
  input#outlined-start-adornment {
    height: 5px;
  }
`;

export const Container = styled.div`
  display: flex;
  width: 100%;
  background-color: #f4f6f9;
`;
export const Sidebar: any = styled.div`
  position: relative;
  min-height: 100vh;
  background-color: ${theme.colors.white}; //black;
  transition: width 0.3s;
  // box-shadow: 6px 0px 18px 0px #0000000f;
  max-width: ${(props: any) => (props.open ? '265px' : '65px')};
  &.closeSidebar {
    .menu-icons {
      svg {
        transform: rotate(90deg);
      }
    }
  }
  .menu-icons {
    cursor: pointer;
    position: absolute;
    right: -10px;
    top: 47%;
    width: 25px;
    height: 25px;
    background: rgb(255, 255, 255);
    border-radius: 50%;
    text-align: center;
    line-height: 16px;
    box-shadow: rgb(221, 221, 221) 0px 0px 6px 4px;
    border: 1px solid rgb(219, 213, 213);
    svg {
      transform: rotate(-90deg);
      transition: 0.5s;
      path {
        stroke: ${theme.colors.Red};
      }
    }
  }
  .menu-item-parent
    .sub-menu-item
    svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeMedium.css-i4bv87-MuiSvgIcon-root {
    margin-left: ${(props: any) => (props.open ? 'block' : '-35px')};
  }
  transition: 0.2s;
  width: 100%;
`;
export const Box = styled.div`
  width: 100%;
  height: 85px;
  background-color: white;
  display: flex;
  align-items: center;
  padding: 12px;
  box-shadow: 11px 0px 18px 0px #0000000f;
  .css-1e6y48t-MuiButtonBase-root-MuiButton-root {
    color: ${theme.colors.Red};
  }

  .css-106c1u2-MuiBadge-badge {
    background-color: ${theme.colors.Red};
  }
`;
export const Logo = styled.div`
  .MuiAvatar-root.MuiAvatar-circular {
    background-color: #88888a !important;
  }
  height: 60px;
  display: flex;
  align-items: center;
  margin: 0px 10px;
  gap: 12px;
  font-family: system-ui;
  padding: 5px;
`;
export const LogoContainer = styled.div`
  align-items: center;
  padding: ${(props: any) => (props.open ? '20px 20px' : '20px 16px')};
`;
export const LogoImage = styled.img`
  height: 35px;
  width: 35px;
  border-radius: 9999px;
`;

export const LogoName: any = styled.p`
  color: #88888a;
  font-weight: 500;
  font-size: 18px;
  display: ${(props: any) => (props.open ? '' : 'none')};
`;
export const LogoEmail: any = styled.p`
  color: #88888a;
  font-size: 14px;
  display: ${(props: any) => (props.open ? '' : 'none')};
`;

export const UserContainer: any = styled.div`
  display: block;
`;
export const HorizontalLine = styled.div`
  height: 3px;
  background-color: #ebeff2;
`;
export const HorizontalBox = styled.div`
  padding: 10px;
  margin-top: 0px;
`;
export const SearchBox = styled.div`
  width: 100%;
  display: flex;
  align-items: left;
  justify-content: left;
  height: 55px;
  padding: 7px;
  box
`;
export const SearchInputBox: any = styled.div`
  position: relative;
  display: flex;
  svg {
    position: absolute;
    top: 10px;
    left: 8px;
    color: #565656;
  }
`;
export const SearchInput = styled.input`
  height: 40px;
  width: 100%;
  border-radius: 5px;
  padding: 0 30px;
  color: rgba(194, 207, 224, 1);
  outline: none;
  border: 1px solid #dbdbdb;
`;
export const SearchiconBox: any = styled.div`
  height: 40px;
  width: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(194, 207, 224, 1);
  border-radius: ${(props: any) =>
    props.open ? '0px 3px 3px 0px' : '3px 3px 3px 3px'};
  cursor: pointer;
  svg.MuiSvgIcon-root {
    color: ${theme.colors.Red};
  }
`;
export const Searchicon = styled(SearchIcon)``;
export const Options = styled.div`
  .css-16alkdk-MuiTreeItem-root {
    line-height: 2.3;
    padding: ${(props: any) => (props.open ? '0px 0' : '0px 20px')};
  }
  .MuiTreeItem-label {
    display: ${(props: any) => (props.open ? 'block' : 'none')};
  }

  .css-1bcfi89-MuiTreeItem-content.Mui-selected {
    background-color: rgb(255 76 77) !important;
    color: white;
    border-radius: 5px;
    line-height: 2.1;
    margin: 15px 0px;
  }
  padding: ${(props: any) => (props.open ? '0px 20px' : '0px 0')};
  overflow: scroll;
  height: 100vh;
  ::-webkit-scrollbar {
    width: 0px !important;
    height: 0px !important;
  }
  ::-webkit-scrollbar-thumb {
    background:rgba(207, 192, 192, 0.68) !important;
    width: 10px;
  }
`;
export const Dashboardselected = styled.div`
  background-color: #3f474e;
  border-radius: 3px 3px 3px 3px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: left;
  gap: 10px;
  margin-top: 0px;
`;
export const Dashboardicon = styled(DashboardCustomizeIcon)`
  color: white;
  font-size: 22px;
  margin-left: 18px;
`;
export const Plus = styled(AddCircleIcon)`
  color: white;
  font-size: 22px;
  margin-left: 18px;
`;
export const Dashbordtext: any = styled.div`
  color: white;
  font-size: 16px;
  font-family: system-ui;
  display: ${(props: any) => (props.open ? 'block' : 'none')};
`;
export const LogoutProfile = styled.div`
  margin-right: 35px;
  border-radius: 9999px;
`;
export const NotificationIcon = styled(NotificationsOutlinedIcon)`
  margin-right: 15px;
`;

export const StaffImageBox = styled.div`
  text-align: center;
  img {
    justify-content: center;
    height: 250px;
    width: 350px;
    margin-left: 5px;
    border-radius: 5px;
    object-fit: cover;
  }
`;

export const TableCategoryImageBox = styled.div`
  img {
    height: 65px;
    width: 80px;
    margin-left: 5px;
    border-radius: 5px;
    object-fit: cover;
  }
`;
// ----------------------------------------------------
// DashBoard Css
export const CountLayout = styled(Grid)`
  margin: 20px 0;
`;
export const CountGrid = styled(Grid)`
  display: flex;
  width: 100%;
  gap: 30px;
`;

export const CountCard = styled(Card)`
  width: 25%;
  height: 150px;
  cursor: pointer;
  text-align: center;
  h4 {
    color: #464255 !important;
    font-weight: 600 !important;
  }
  p {
    color: white !important;
    margin-top: 10px;
    font-weight: 400 !important;
    font-size: 16px;
  }
`;

export const CardItem = styled.div`
  display: flex;
  justify-content: center;
  margin: 25px 0;
`;

export const TotalCount = styled.div`
  font-size: 40px;
  font-weight: 700;
`;

export const TotalText = styled.div`
  font-family: 'Barlow', sans-serif;
  font-size: 12px;
  font-weight: 500;
  line-height: 19.2px;
`;

export const CardTextLayout = styled.div`
  display: block;
  margin-left: 20px;
`;

export const Actions = styled(CardActions)`
  background-color: rgba(0, 0, 0, 0.1);
  color: white;
  display: flex;
  justify-content: center;
  align-items: normal !important;
`;
export const DashboardProjectsection = styled.div`
  display: flex;
  width: 100%;
`;
export const ProjectGraph = styled.div`
  width: 50%;
  padding: 20px;
  .MuiInput-root.MuiInput-variantOutlined.MuiInput-colorNeutral.MuiInput-sizeMd.MuiInput-formControl.css-iosh9v-JoyInput-root {
    width: 160px;
  }
`;
export const ProjectTable = styled.div`
  width: 50%;
  padding: 20px;
`;
export const Table = styled.table`
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  margin-top: 20px;
  td,
  th {
    text-align: left;
    padding: 15px;
    color: #757575;
    font-size: 12px;
    text-transform: uppercase;
  }
  th {
    font-weight: 600;
  }
  tr:nth-child(even) {
    border-top: 2px solid #dee2e6;
    border-bottom: 1px solid #e3e7ea;
    background-color: #f2f2f2;
  }
`;

export const TableContainer = styled.div`
  height: 100%;
  p {
    color: #424242;
    font-size: 20px;
    font-weight: 700;
    padding: 8px 0px 0px 20px;
  }
  button {
  }
`;
export const HeaderTableContainer = styled.div`
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  padding: 1rem;
`;
export const PaginationContainer = styled.div`
  display: flex;
  text-align: center;
  justify-content: center;
  margin-top: 5px;
`;
export const DetailButton = styled(Button)`
  :hover {
    border: 1px solid ${theme?.colors?.Red} !important;
  }
`;

export const DPRDateFilterLayout = styled.div`
  display: flex;
  align-content: stretch;
  flex-wrap: wrap;
  justify-content: flex-end;
  flex-direction: row;
  align-items: center;
  gap: 10px;

  .MuiFormLabel-root.MuiInputLabel-root,
  .css-14s5rfu-MuiFormLabel-root-MuiInputLabel-root {
    line-height: 15px;
    color: ${theme.colors.Gray};
    top: -4px;
    font-weight: 500;
  }
`;

export const ErrorMessage = styled.div`
    color: red;
    font-size: 12px; 
    width: 10rem;
`
