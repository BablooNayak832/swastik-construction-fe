import styled from 'styled-components';
export const RequestMaterialTable = styled.div`
  .remark-cell {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    margin: 5px;
  }
`;
