import styled from 'styled-components';

export const DatePickerLineBox = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  .css-mxn4xy-MuiButtonBase-root-MuiPickersDay-root-MuiDateRangePickerDay-day.Mui-selected {
    background-color: #d2197e;
  }
  h3 {
    font-size: 24px;
    font-weight: bold;
  }
  .MuiFormLabel-root {
    font-size: 16px;
  }
  input {
    font-size: 14px;
    div {
      font-size: 14px;
    }
  }
  #placeholder {
    font-size: 12px;
  }

  .MuiStack-root {
    justify-content: end;
    .MuiFormControl-root.MuiFormControl-vertical.MuiFormControl-sizeMd {
      margin-left: 5px;
    }
    .MuiInput-root.MuiInput-variantOutlined.MuiInput-colorNeutral {
      width: 130px !important;
      padding: 0 0 !important;
    }
  }
  .MuiInputBase-root.MuiOutlinedInput-root.MuiInputBase-colorPrimary.MuiInputBase-fullWidth.MuiInputBase-formControl {
    height: 40px;
  }
`;

export const DatePickerBox = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  h3 {
    font-size: 24px;
    font-weight: bold;
  }
  .MuiFormLabel-root {
    font-size: 10px;
  }
  input {
    font-size: 14px;
    div {
      font-size: 14px;
    }
  }
  #placeholder {
    font-size: 10px;
  }

  .MuiStack-root {
    justify-content: end;
    .MuiFormControl-root.MuiFormControl-vertical.MuiFormControl-sizeMd {
      margin-left: 5px;
    }
    .MuiInput-root.MuiInput-variantOutlined.MuiInput-colorNeutral {
      width: 130px !important;
      padding: 0 0 !important;
    }
  }
`;
export const DataSelectorLayout = styled.div`
.MuiFormLabel-root.MuiInputLabel-root{
  top:-9px;
}
.MuiInputLabel-shrink.MuiFormLabel-root.MuiInputLabel-root{
  top:0px;
}
  .MuiInputBase-root.MuiOutlinedInput-root.MuiInputBase-colorPrimary.MuiInputBase-fullWidth.MuiInputBase-formControl.css-md26zr-MuiInputBase-root-MuiOutlinedInput-root {
    height: 35px;
    width: 110px;
    font-size: 12px;
  }
  .MuiInputBase-root .MuiOutlinedInput-root .MuiInputBase-colorPrimary .css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root{
    height: 35px;
    margin: 0px 10px;
}
  }
`;

export const ChartLayout = styled.div`
  display: block;
  height: 100%;
  width: 100%;
  overflow: auto;
  padding-top: 30px;
  text.highcharts-credits {
    display: none;
  }
  .chartjs-render-monitor {
    display: block !important;
    width: 100% !important;
    height: 500px !important;
    padding: 50px !important;
  }
`;

export const PieChartLayout = styled.div`
  display: block;
  height: 100%;
  width: 100%;
  overflow: auto;
  padding: 25px;
  .MuiGrid-root,
  .MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded {
    height: 100%;
  }
  span.MuiStack-root.css-m69qwo-MuiStack-root {
    margin: 20px;
    display: flex;
    align-items: center;
    justify-content: end;
  }
  text.highcharts-credits {
    display: none;
  }
`;

export const GraphFilterLayout = styled.div`
  display: flex;
  margin: 5px 35px;
  .MuiInputBase-root.MuiOutlinedInput-root.MuiInputBase-colorPrimary.css-1yk1gt9-MuiInputBase-root-MuiOutlinedInput-root-MuiSelect-root {
    height: 35px;
    margin: 0 12px;
  }
  .MuiInput-root.MuiInput-variantOutlined.MuiInput-colorNeutral.MuiInput-sizeMd.MuiInput-formControl.css-iosh9v-JoyInput-root {
    width: 160px;
  }
`;

export const SelectLayout = styled.div`
  display: inline-block;
`;
