import { createGlobalStyle, css } from 'styled-components';
import { theme } from './theme';

export const GlobalStyles = createGlobalStyle`
@font-face {
    font-family: 'Lato';
    src: url('/fonts/Lato-Regular.ttf') format('truetype');
    font-weight: 400;
    font-style: normal;
  }

  @font-face {
    font-family: 'Lato';
    src: url('/fonts/Lato-Bold.ttf') format('truetype');
    font-weight: 700;
    font-style: normal;
  }

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
button{
  cursor: pointer;
}
  .MuiDateRangeCalendar-root {
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
  }
 .MuiDateRangeCalendar-root > div:first-of-type {
  background-color:rgb(216, 201, 201); 
  border: 1px solid #ccc;
  display: none;
}

${({ theme }) => css`
  body {
    height: 100%;
    background-color: #ffffff;
    font-family: system-ui;
  }
  path.highcharts-button-symbol {
    display: none;
  }
`} 
.MuiInputBase-root.MuiOutlinedInput-root.MuiInputBase-colorPrimary.MuiInputBase-formControl.MuiInputBase-adornedEnd.css-o9k5xi-MuiInputBase-root-MuiOutlinedInput-root {
  height: 40px;
}

header.MuiPaper-root.MuiPaper-elevation.MuiPaper-elevation4.MuiAppBar-root.MuiAppBar-colorPrimary.MuiAppBar-positionFixed.mui-fixed.css-10ghrmp-MuiPaper-root-MuiAppBar-root{
  background-color: ${theme.colors.Red} ; 
}

button .MuiButtonBase-root.MuiButton-root.MuiButton-contained{
  background-color: #444545;
} 

.MuiButton-containedPrimary{
  background-color: ${theme.colors.Red} !important;
}

.MuiButton-outlined.MuiButton-outlinedPrimary{
    border: 1px solid #ff5b5b61;
    color: ${theme.colors.Red};
} 

 .MuiButton-outlined.MuiButton-outlinedPrimary&:hover{
      border: 1px solid #ff5b5b61;  
      color: ${theme.colors.Red};
  }

.MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded {
  box-shadow: 1px 2px 10px #dddddd2e;
}
.css-mxn4xy-MuiButtonBase-root-MuiPickersDay-root-MuiDateRangePickerDay-day.Mui-selected{
  background-color: #d21953;
}

::-webkit-scrollbar-thumb{
  background: rgb(212 198 198 / 96%) !important;
  width: 6px;
}

::-webkit-scrollbar-track {
  background: rgb(255 255 255) !important;
}
::-webkit-scrollbar {
  width: 8px !important;
  height: 8px !important;
}

.loader{
  position: fixed;
  width: 100%;
  height: 100%;
  z-index: 9999;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
}
.MuiPaper-root .MuiPaper-elevation .MuiPaper-rounded .MuiPaper-elevation8 .MuiMenu-paper .MuiPopover-paper  {
  height: 199px;
}
  .Mui-disabled{
  color: #ffff;
  }
  .MuiButton-contained.Mui-disabled{
    color: white;
    background-color: #e6a3a4 !important;
  }
 
.cancel-bill {
    position: relative;
    width: 0.99rem;
    background: #ff4c4d !important;
    color: white !important;
    border: none;
    top: 0px;
    height: 15px;
}

.invalid-field{ 
    border: 2px solid red !important;
}
.required-field{
    border-bottom: 2px solid red !important;
}
`;
