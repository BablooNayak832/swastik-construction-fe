import styled from 'styled-components';
import { theme } from '../theme';

export const MenuItemLayout = styled.a<{ depth: number }>`
  display: flex;
  flex-direction: row;
  font-size: 20px;
  padding: 10px 0px 10px 10px;
  align-items: center;
  justify-content: space-between;
  a {
    background: #000104c9;
  }
  & svg {
    height: 20px;
    margin-right: 10px;
    color: #000;
  }

  // &:hover {
  //   color: #007bff;
  //   opacity: 1.5;
  //   cursor: pointer;
  //   border-radius: 0.25rem;
  // }

  .menu-item {
    display: flex;
    flex-direction: row;
    align-items: center;
    margin-left: ${({ depth }) => `${depth}rem`};
    color: rgba(194, 207, 224, 1);
    font-size: medium;
    font-family: sans-serif;
  }
  svg {
    stroke: #000;
  }
  .menu-item.selected {
    background: ${theme?.colors?.red};
    svg {
      color: #fff;
      stroke: #fff;
    }
    a {
      background: ${theme?.colors?.red};
    }
  }

  &.selected {
    color: #007bff;
    border-radius: 3px 3px 3px 3px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: left;
    gap: 10px;
    margin-top: 2px;
    background: #027eff;
    svg {
      color: #fff;
      stroke: #fff !important;
    }
  }

  border-radius: 3px 3px 3px 3px;
  display: flex;
  align-items: right;
  justify-content: left;
  gap: 20px;
  margin-top: 0px;
`;

export const MenuItemContainer = styled.a<{ depth: number }>`
  display: flex;
  flex-direction: row;
  font-size: 20px;
  padding: 10px 0px 10px 10px;
  align-items: center;
  justify-content: space-between;
  a {
    background: #000104c9;
  }
  & svg {
    height: 20px;
    margin-right: 10px;
    color: #000;
  }

  &:hover {
    color: #007bff;
    opacity: 1.5;
    cursor: pointer;
    border-radius: 0.25rem;
  }

  .menu-item {
    display: flex;
    flex-direction: row;
    align-items: center;
    margin-left: ${({ depth }) => `${depth}rem`};
    color: rgba(194, 207, 224, 1);
    font-size: medium;
    font-family: sans-serif;
  }
  svg {
    stroke: #000;
  }
  .menu-item.selected {
    background: ${theme?.colors?.red};
    svg {
      color: #fff;
      stroke: #fff;
    }
    a {
      background: ${theme?.colors?.red} !important;
    }
  }

  &.selected {
    color: #007bff;
    border-radius: 3px 3px 3px 3px;
    display: flex;
    align-items: center;
    justify-content: left;
    gap: 10px;
    margin-top: 2px;
    background: #027eff !important;
    height: auto !important;
    padding: 12px 7px !important;
    svg {
      color: #fff;
      stroke: #fff !important;
    }
  }

  border-radius: 3px 3px 3px 3px;
  display: flex;
  align-items: right;
  justify-content: left;
  gap: 20px;
  margin-top: 0px;
`;

export const Menu: any = styled.div<{ activeLink: any }>`
  .selected {
    background: ${theme?.colors?.red} !important;
    border-radius: 12px;
    overflow: hidden;

    a {
      background: ${theme?.colors?.Red};
      color: white;
      font-weight: 500;
      .menu-item {
        div {
          font-weight: 500;
          color: white;
        }
      }
      svg {
        color: #fff !important;
        stroke: #fff !important;
        path {
          stroke: #fff !important;
        }
      }
      div {
        color: #88888a;
      }
    }
  }
  a {
    text-decoration: none;
  }
  margin-bottom: 12px;
  margin: ${(props: any) => (!props.open ? '15px' : '10px 14px')};
`;
export const Dashbordtext: any = styled.div<{ href; pathName }>`
  line-height: 20px;
  letter-spacing: 0.01em;
  color: #000000;
  gap: 26px;
  font-family: 'Barlow', sans-serif;
  font-size: 16px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: 0em;
  text-align: left;

  text-align: left;
  display: ${(props: any) => (props.open ? 'block' : 'none')};
  transition: 0.2s;

  &:hover {
    color: #007bff;
  }
`;

export const SubmenuText: any = styled.div<{ href; pathName }>`
  line-height: 20px;
  letter-spacing: 0.01em;
  color: #000000;
  gap: 26px;
  font-family: 'Barlow', sans-serif;
  font-size: 16px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: 0em;
  text-align: left;

  text-align: left;
  display: ${(props: any) => (props.open ? 'block' : 'none')};
  transition: 0.2s;
`;
