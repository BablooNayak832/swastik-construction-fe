import styled, { css } from 'styled-components';
import { theme } from '../theme';

export const Container = styled.div``;
export const HeadingBox = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  margin-top: -5px;
`;
export const Blankbox = styled.div``;

export const Heading = styled.p`
  font-size: 40px;
  font-weight: 700;
  line-height: 60px;
  letter-spacing: 0px;
  text-align: left;
  color: #464255;
`;

export const AddRoleButton = styled.button`
  background-color: green;
  width: 150px;
  height: 40px;
  border: none;
  outline: none;
  font-size: 14px;
  font-family: system-ui;
  font-weight: 600;
  color: white;
  border-radius: 5px;
  margin-right: 35px;
`;

export const AddRoleBox = styled.div`
  width: 100%;
  height: 40px;
`;
export const TableBox = styled.div`
  padding: 10px 20px;

  .css-2rshpx-MuiButtonBase-root-MuiIconButton-root {
    color: ${theme.colors.DarkGray};
  }
`;
