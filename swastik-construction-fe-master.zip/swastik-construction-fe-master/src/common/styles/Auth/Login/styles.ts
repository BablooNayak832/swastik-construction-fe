import { Checkbox } from '@mui/material';
import styled from 'styled-components';
import { theme } from '../../theme';

export const Blankbox = styled.div``;
export const Wrapper = styled.div`
  height: 100vh;
  background-color: #e9ecef;
  display: flex;
  justify-content: center;
  align-items: center;
`;
export const Container = styled.div`
  height: 275px;
  width: 360px;
`;
export const Header = styled.div`
  height: 60px;
  font-size: 2rem;
  display: flex;
  justify-content: center;
  align-items: center;
  color: #495057;
`;

export const Admintext = styled.p`
  font-weight: 400;
  margin-bottom: 20px;
`;

export const LogoContainerLayout = styled.div`
  height: 60px;
  font-size: 2rem;
  display: block;
  justify-content: center;
  align-items: center;
  color: #495057; 
  margin: 1rem;
`;

export const LogoTitleText = styled.p`
  font-weight: 400;
  margin-bottom: 5px;
  color: #84868b; 
  font-size: 30px;
`;

export const LogoSubTitletext = styled.p`
  font-weight: 400;
  margin-bottom: 5px;
  color: #fe2f15;
  font-size: 24px;
  text-align: center;
`;

export const LTEtext = styled.p`
  font-weight: 400;
  margin-bottom: 20px;
  color: #84868b
`;

export const LoginCard = styled.div`
  background-color: white;
  height: 275px;
  color: #666;
  box-shadow: 0 0 1px rgba(0, 0, 0, 0.125), 0 1px 3px rgba(0, 0, 0, 0.2);
  p.MuiFormHelperText-root {
    color: ${theme.colors.Red};
    margin-right: auto; 
  }
`;
export const Paragraph = styled.p`
  margin: 0;
  padding: 20px 20px 20px;
  text-align: center;
  font-size: 15px;
`;
export const Form = styled.form`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 10px 20px;
`;

export const Input = styled.input`
  display: block;
  width: 100%;
  height: calc(2.25rem + 2px);
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  box-shadow: inset 0 0 0 transparent;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
  margin-top: 12px;
`;
export const ButtonBox = styled.div`
  width: 100%;
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;
export const CheckBoxLabel = styled.label`
  font-weight: 700;
  color: #666;
  margin-top: 10px;
`;
export const CheckboxInput = styled(Checkbox)``;

export const RememberText = styled.span``;

export const SigninButton = styled.button`
  color: #fff;
  background-color: #0069d9;
  outline: none;
  border: 1px solid #0062cc;
  height: 40px;
  width: 98px;
  border-radius: 6px;
  font-size: 15px;
  margin-top: 13px;
`;

export const FacebookButton = styled.button`
  color: #fff;
  background-color: #0069d9;
  outline: none;
  border: 1px solid #0062cc;
  height: 40px;
  width: 90%;
  border-radius: 6px;
  font-size: 15px;
  margin-left: 5%;
`;
export const GoogleButton = styled.button`
  color: #fff;
  background-color: #dc3545;
  outline: none;
  border: 1px solid #dc3545;
  height: 40px;
  width: 90%;
  border-radius: 6px;
  font-size: 15px;
  margin-top: 5px;
  margin-left: 5%;
`;
export const SocialBox = styled.div``;

export const BottomLinks = styled.p`
  color: #0069d9;
  font-size: 14px;
  padding: 10px 0px 0px 20px;
  cursor: pointer;
`;
