import styled from 'styled-components';

export const HeaderContainer = styled.header`
  display: flex;
  background-color: #fff;
  color: #1f2d3d;
  height: 50px;
  align-items: center;
  justify-content: center;
  border-bottom: 2px solid #55505029;
`;

export const TitleContainer = styled.div`
  margin: auto;
`;
export const IconContainer = styled.div`
  padding: 10px;
  cursor: pointer;

  & svg {
    height: 30px;
  }
`;
