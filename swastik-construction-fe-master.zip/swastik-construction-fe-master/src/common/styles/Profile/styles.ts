import styled from 'styled-components';
export const Container = styled.div``;
export const CoverPhoto = styled.div`
  position: relative;
  height: 100px;
  width: 101.6%;
  margin: -10px;
  img {
    height: 170px;
    width: 100%;
    object-fit: cover;
  }
`;
export const ImageText = styled.div`
  position: absolute;
  top: 80%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
  font-size: 24px;
  text-align: center;
  background-color: darkcyan;
  border-radius: 9999px;
  height: 110px;
  width: 110px;
  border: 3px solid white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 70px;
`;
export const Text = styled.p``;
export const DetailsBox = styled.div`
  position: relative;
  z-index: 1;
  color: white;
  width: 100%;
  height: 34px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 50px;
  margin-top: 46px;
  font-size: 16px;
`;
export const DetailName = styled.div``;
export const DetailRole = styled.div``;
export const DetailWork = styled.div``;
export const DetailEmail = styled.div``;
