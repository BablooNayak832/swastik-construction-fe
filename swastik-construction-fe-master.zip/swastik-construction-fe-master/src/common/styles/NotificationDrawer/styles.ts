import styled from 'styled-components';
import Box from '@mui/material/Box';
import { IconButton } from '@mui/material';

export const CloseBtnBox = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: #1b1b1c;
  color: #fff;
  display: flex;
  margin-bottom: 10px;
  margin-left: 10px;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  svg {
    width: 15px;
  }
`;
export const NotificationBox = styled.div`
  text-align: center;
  background-color: white;
  height: 350px;
  width: 450px;
  border-radius: 10px;

  Button {
    float: right;
    color: black;
  }
`;
export const BlankBox = styled.div`
  p {
    width: 100%;
    padding: 10px 10px;
    display: flex;
    justify-content: space-between;
    span {
      width: 50%;
    }
  }
`;
export const ConformationBox = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  margin-top: 25px;
`;

export const NotificationHeader = styled.div`
  border: none;
  outline: none;
  padding: 4px 12px; 
  width: 440px;
`;

export const NotificationButton = styled.button`
  border: none;
  outline: none;
  padding: 4px 4px;
  cursor: pointer;
  width: 440px;
`;

export const IconButtonContent = styled(IconButton)`
  border: none;
  border-radius: 5px;
  font-size: 16px;
  cursor: pointer;
  color: white;
  position: relative;
  margin: 5px;
`;

export const BadgeContentCount = styled.div`
  width: 1.2rem;
  font-size: 0.8rem;
  padding: 0.1rem;
  position: absolute;
  right: 1px;
  top: 1px;
  text-align: center;
  border-radius: 1rem;
  background-color: red;
  color: white;
`;
