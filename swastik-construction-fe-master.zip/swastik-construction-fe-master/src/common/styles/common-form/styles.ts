import styled from 'styled-components';
import Card from '@mui/material/Card';
import { Input } from '@mui/material';
import { theme } from '../theme';
export const MainConteiner = styled(Card)`
  .MuiButton-containedSizeMedium {
    background-color: ${theme?.colors?.red} !important;
  }
  max-width: 100%;
  box-shadow: none !important;
  height: 100%;   
`;
export const FormInput = styled(Input)`
  padding: 0px 0px 2px 13px;
`;
export const SelectCategoryImageBox = styled.div`
  display: flex;
  img {
    height: 100px;
    width: 100px;
    margin-left: 5px;
    border-radius: 5px;
  }
`;
export const ButtonBox = styled.div`
  position: absolute;
  top: 0px;
  left: 75px;
  button {
    border: none;
    border-radius: 100px;
    height: 25px;
    cursor: pointer;
  }
`;

export const UpdateModalLayout = styled.div`
  .css-sghohy-MuiButtonBase-root-MuiButton-root {
    background-color: #ffff;
  }

  button.MuiButtonBase-root.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium.sc-eyvILC.css-sghohy-MuiButtonBase-root-MuiButton-root {
    background: ${theme.colors.Red};
  }

  button.MuiButtonBase-root.MuiButton-root.MuiButton-contained {
    background-color: ${theme.colors.Red};
  }
  span.MuiTouchRipple-root.css-8je8zh-MuiTouchRipple-root {
    background-color: blue;
  }
`;
