import { MenuOutlined } from '@mui/icons-material';
import styled from 'styled-components';

export const Container = styled.div`
  text-align: left;
  display: flex;
`;

export const Content = styled.div`
  display: flex;
  flex: 1;
`;

export const PageContainer = styled.div`
  width: 100%;
`;

export const Box = styled.div`
  width: 100%;
  height: 40px;
  background-color: white;
  display: flex;
  align-items: center;
`;
export const Menuicon = styled(MenuOutlined)`
  margin-left: 5px;
  font-size: 20px;
`;
