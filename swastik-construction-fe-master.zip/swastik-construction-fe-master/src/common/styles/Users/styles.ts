import styled, { css } from 'styled-components';
import { theme } from '../theme';

export const Container = styled.div``;
export const HeadingBox = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 22px 0;
  margin-top: -5px;

  button.MuiButtonBase-root{
    text-transform: none !important; 
    }

  }
`;
export const Blankbox = styled.div`
  display: flex;
  gap: 10px;
`;

export const Heading = styled.p`
  font-size: 40px;
  font-weight: 700;
  line-height: 60px;
  letter-spacing: 0px;
  text-align: left;
  color: #464255;
`;
export const button=`
  display: flex;
  justify-content: space-between;
  `

export const SubHeading = styled.p`
    font-size: 19px;
    font-weight: 700;
    line-height: 1.5rem; 
    letter-spacing: 0px;
    text-align: left;
    color: #464255;
    text-decoration: underline;
`

export const AddRoleButton = styled.button`
  background-color: green;
  width: 150px;
  height: 40px;
  border: none;
  outline: none;
  font-size: 14px;
  font-family: system-ui;
  font-weight: 600;
  color: white;
  border-radius: 5px;
  margin-right: 35px;
`;

export const AddRoleBox = styled.div`
  width: 100%;
  height: 40px;
`;
export const TableBox = styled.div`
  padding: 10px 0;
  .css-2rshpx-MuiButtonBase-root-MuiIconButton-root {
    color: ${theme.colors.DarkGray};
  }
  th.MuiTableCell-root.MuiTableCell-head {
    font-size: 15px;
    font-weight: bold;
    align-items: center;
  }
  .MuiStack-root.sc-iXzfSG.dtlbUZ.css-nen11g-MuiStack-root {
    background: grey;
  }
  .MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation8.MuiMenu-paper.MuiPopover-paper.MuiMenu-paper.css-3dzjca-MuiPaper-root-MuiPopover-paper-MuiMenu-paper {
    height: 170px;
  }
`;
