import React, { useState } from 'react';
import {
  Sidebar,
  Options,
  LogoContainer,
} from '../../common/styles/Dashboard/styles';
import MenuItemsList from '../../components/MenuItemsList';
import Swastik from '../../../public/images/swastik-logo.png';
import SwastikMobileLogo from '../../../assets/img/SwastikMobileLogo.png';
import Image from 'next/image'
import ArrowIcons from '../../../assets/svg/ArrowIcons';
import { useDispatch, useSelector } from 'react-redux';
import { setOpenSubMenu } from 'src/redux/features/collapseExpandedSlice';

const AppSidebar = () => {
  const dropDownMenus = useSelector((state: any) => state.collapseExpande?.dropdownMenus);
  const [open, setOpen] = useState<boolean>(true);
  const dispatch = useDispatch();

  const handleok = () => {
    setOpen(!open);
    dispatch(setOpenSubMenu(null))
  }; 

  return (
    <>
      <Sidebar
        open={open}
        className={`sidebar-demo ${open ? 'openSidebar' : 'closeSidebar'}`}
      >
        <LogoContainer open={open}>
          {open ? <Image
            src={Swastik}
            alt="logo image"
            width={230}
            height={50}
          /> : <Image alt='logo' src={SwastikMobileLogo} width={42} />}
        </LogoContainer>
        <Options open={open}>
          <MenuItemsList open={open} options={dropDownMenus} />
        </Options>
        <div className='menu-icons' onClick={() => handleok()}>
          <ArrowIcons />
        </div>
      </Sidebar>
    </>
  );
};

export default AppSidebar;
