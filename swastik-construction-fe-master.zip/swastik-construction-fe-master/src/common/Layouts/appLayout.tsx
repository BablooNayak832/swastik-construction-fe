import React, { useState } from 'react';
import dynamic from 'next/dynamic';
import {
  Box,
  SearchBox,
  MainContainer,
  AppWrapper,
  MainLayout,
  ChildrenLayout,
  HorizontalLine,
  LoggedinUserText,
  SiteNameLayout,
} from '../../common/styles/Dashboard/styles';
import AccountMenu from '../../components/Dashboard/ProfileIcon';
import SwipeableDrawerCustom from '../../components/SwipeableDrawer/SwipeableDrawer';
import { redirect } from 'next/navigation';
import MetadataContext from '../../context/context'
import { useSession } from "next-auth/react"
import { Divider, Typography } from '@mui/material';
import AutocompleteComponent from '../../components/AutoComplete/index'
import { useSelector } from 'react-redux';
const AppSidebar = dynamic(() => import('./appSidebar'), { ssr: false });
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';

function AppLayout({ children }: any) {
  const selectedProject = useSelector((state: any) => state?.selectedProject);
  const { status, data:session } = useSession();
  if (status !== "authenticated") {
    // If not authenticated, redirect to the login page
    return redirect("/auth/signin")
  }

  return (
    <>
      <MetadataContext>
        <AppWrapper className="app-wrapper bg-light">
          <AppSidebar />
          <MainLayout>
          <ToastContainer/>
            <MainContainer>
              <Box>
                <SearchBox>
                  <SiteNameLayout>
                    { selectedProject?.selectedValue?.name === null ? "" : selectedProject?.selectedValue?.name?.toUpperCase() }
                  </SiteNameLayout>
                </SearchBox>

                {(session?.user?.role_id !== 0) && (session?.user?.role_id !== 1) && (session?.user?.role_id !== 3) && <AutocompleteComponent />}
                <SwipeableDrawerCustom />
                <Divider orientation="vertical" variant="middle" flexItem />
                <LoggedinUserText >
                  <Typography variant="subtitle2" gutterBottom>
                    Hello,
                  </Typography>
                  <Typography variant="subtitle2" gutterBottom>
                    {session?.user?.name}
                  </Typography>
                </LoggedinUserText>
                <AccountMenu />
              </Box>
              <HorizontalLine></HorizontalLine>
              <ChildrenLayout className="app-div">{children}</ChildrenLayout>
            </MainContainer>
          </MainLayout>
        </AppWrapper>
      </MetadataContext>
    </>
  );
}

export default AppLayout;
