import Image from 'next/image';
import {
  CountGrid,
  CountCard,
  TotalCount,
  TotalText,
  CardItem,
  CardTextLayout, 
} from '../../common/styles/Dashboard/styles';
import CardContent from '@mui/material/CardContent';
import TotalUser from "../../../assets/img/total-user.png";
import TotalStock from "../../../assets/img/total-stock.png";
import TotalProjects from "../../../assets/img/total-projects.png";
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

const CountCardComponent = ({ CountData, UserRoleEnum, materialData, Projects, totalCount }:any) => {
  const router = useRouter()
  const { data: session } = useSession();
    
  const adminCount = CountData?.adminCount === undefined ? 0 : CountData?.adminCount;
  const purchaseHead = CountData?.purchaseHeadCount === undefined ? 0 : CountData?.purchaseHeadCount;
  const siteHeadCount = CountData?.siteHeadCount === undefined ? 0 : CountData?.siteHeadCount;
  const projectHeadCount = CountData?.projectHeadCount === undefined ? 0 : CountData?.projectHeadCount; //CountData?.filter(item => item?.roleId === 2)?.map(i => i)?.length;  //
  const supervisorCount = CountData?.supervisiorCount === undefined ? 0 : CountData?.supervisiorCount;
  const materialCount = materialData?.meta?.totalItems;
  const totalUser = adminCount + purchaseHead + siteHeadCount + projectHeadCount + supervisorCount;


  const cardData = [
    {
        id: 2,
        count: `${Projects?.items?.length}`,
        title: 'Total Projects',
        link: 'More Info',
        color: `#FFFFFF`,
        imgUrl: TotalProjects,
        onClick: () => router.push('/projects'),
        role: [
        UserRoleEnum.SuperAdmin,
        UserRoleEnum.Admin,
        ],
    },
    {
        id: 1,
        count: totalUser,
        title: 'Total User',
        link: 'More Info',
        color: `#FFFFFF`,
        imgUrl: TotalUser,
        onClick: () => router.push('/users'),
        role: [
        UserRoleEnum.SuperAdmin,
        UserRoleEnum.Admin,
        ],
    },
    {
        id: 3,
        count: projectHeadCount,
        title: 'Project Head',
        link: 'More Info',
        color: `#FFFFFF`,
        imgUrl: TotalUser,
        onClick: () => {
        router.push(`/users/2`)
        },
        role: [
        UserRoleEnum.SuperAdmin,
        UserRoleEnum.Admin,
        ],
    },
    {
        id: 3,
        count: materialCount,
        title: 'Material',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/stock-inventory/product'),
        role: [
        UserRoleEnum.SuperAdmin,
        UserRoleEnum.Admin,
        ],
    },
    {
        id: 3,
        count: totalCount?.assignedProject === undefined ? 0 : totalCount?.assignedProject,//machinery,
        title: 'Assigned Projects',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/project-assigned'),
        role: [ 
        UserRoleEnum.ProjectHead
        ],
    },  
    {
        id: 4,
        count: totalCount?.request?.pendingRequestCount === undefined ? 0 : totalCount?.request?.pendingRequestCount,
        title: 'Pending Requests',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/approved/material-request?status=pending'),
        role: [ 
        UserRoleEnum.PurchaseManager,
        UserRoleEnum.SuperVisior,
        UserRoleEnum.SiteManager
        ],
    },
    {
        id: 4,
        count: totalCount?.poCount?.materialCount === undefined ? 0 : totalCount?.poCount?.materialCount,
        title: 'Ordered PO',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/purchase-management'),
        role: [ 
        UserRoleEnum.PurchaseManager
        ],
    },
    {
        id: 4,
        count: totalCount?.vendorCount?.materialCount === undefined ? 0 : totalCount?.vendorCount?.materialCount,
        title: 'Total no. of vendors',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/vendor'),
        role: [ 
        UserRoleEnum.PurchaseManager
        ],
    },
    {
        id: 4,
        count: totalCount?.request?.approvedRequestCount === undefined ? 0 : totalCount?.request?.approvedRequestCount ,
        title: 'Material Request',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/approved/material-request'),
        role: [ 
        UserRoleEnum.PurchaseManager
        ],
    }, 
    {
        id: 5,
        count: totalCount?.userCount?.siteHeadCount === undefined ? 0 : totalCount?.userCount?.siteHeadCount,
        title: 'Site head',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/users/4'),
        role: [ 
        UserRoleEnum.ProjectHead
        ],
    },
    {
        id: 5,
        count:  totalCount?.userCount?.supervisorCount === undefined ? 0 : totalCount?.userCount?.supervisorCount,
        title: 'Supervisor',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/users/5'),
        role: [ 
        UserRoleEnum.ProjectHead
        ],
    }, 
    {
        id: 5,
        count: totalCount?.request?.pendingRequestCount === undefined ? 0 : totalCount?.request?.pendingRequestCount,
        title: 'Pending Request',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/request-management/material-request?status=pending'),
        role: [ 
        UserRoleEnum.ProjectHead
        ],
    },
    {
        id: 5,
        count:  totalCount?.returnRequest?.pendingRequestCount === undefined ? 0 : totalCount?.returnRequest?.pendingRequestCount + totalCount?.returnRequest?.approvedRequestCount + totalCount?.returnRequest?.rejectRequestCount ,
        title: 'Return Request',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/return-request/material'),
        role: [ 
        UserRoleEnum.ProjectHead
        ],
    }, 
    {
        id: 5,
        count: totalCount?.request?.approvedRequestCount === undefined ? 0 : totalCount?.request?.approvedRequestCount,
        title: 'Approved Request',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/request-management/material-request'),
        role: [ 
        UserRoleEnum.SiteManager,
        UserRoleEnum.SuperVisior
        ],
    },
    {
        id: 5,
        count: totalCount?.returnRequest?.approvedRequestCount === undefined ? 0 : totalCount?.returnRequest?.approvedRequestCount,
        title: 'Approved Return Request',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/return-request/material'),
        role: [ 
        UserRoleEnum.SiteManager,
        UserRoleEnum.SuperVisior
        ],
    },
    {
        id: 5,
        count: totalCount?.returnRequest?.pendingRequestCount === undefined ? 0 : totalCount?.returnRequest?.pendingRequestCount,
        title: 'Pending return request',
        link: 'More Info',
        color: `red`,
        imgUrl: TotalStock,
        onClick: () => router.push('/return-request/material'),
        role: [ 
        UserRoleEnum.SiteManager,
        UserRoleEnum.SuperVisior
        ],
    },
 ];
      
  return (
    <>
        <CountGrid>
            {cardData && cardData?.map((cardItem, index) => {
            return cardItem?.role?.includes(session?.user?.role_id) && (
                <CountCard key={index} onClick={cardItem?.onClick}>
                <>
                    <CardContent>
                    <CardItem>
                        <Image alt='img' src={cardItem?.imgUrl?.src} width={84} height={85} />
                        <CardTextLayout>
                        <TotalCount>
                            {cardItem?.count === 'undefined' ? 0 : cardItem?.count}
                        </TotalCount>
                        <TotalText>
                            {cardItem.title}
                        </TotalText>
                        </CardTextLayout>
                    </CardItem>
                    </CardContent>
                </>
                </CountCard>
            )
            }
            )}
        </CountGrid> 
    </>
)
}
export default CountCardComponent;
