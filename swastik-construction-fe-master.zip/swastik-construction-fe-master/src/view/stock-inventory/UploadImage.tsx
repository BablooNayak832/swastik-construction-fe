import {Button, FormControl, Grid, InputLabel, ListItemText, MenuItem, Paper, Select, TextField, Typography} from '@mui/material';
import React, { useEffect, useState } from 'react';
import {MenuProps} from 'src/constants/table-columns';
import useGet from 'src/hooks/useGet';
import usePatch from 'src/hooks/usePatch';

const UploadImage = ({handleClose}: any) => {  
  const [selectData, setSelectData] = useState({categoryId: '', name: '', image: ''}) 
  const {resData: categoryData, handleGetData: getCategoryData} = useGet()
  const {resData: materialData, handleGetData: getMaterialData} = useGet()
  const { handleUpdateData } = usePatch()
 
  const fetchCategoryData = async() => {
    const res = await getCategoryData('/category')
    return res;
  }

  useEffect(() => {
    fetchCategoryData()
  }, [])

  const fetchMaterialData = async(cId:number) => {
     await getMaterialData(`/material/unique-name?categoryId=${cId}`)
  }

  const submitUploadImage = async() => {  
    const formdata = new FormData()
     Object.entries(selectData).map(([key, value]) => { 
        formdata.append(key, value)
     }) 
     await handleUpdateData('/material', formdata)
     handleClose()
  } 
 
  return (
    <> 
    <Paper elevation={3} >
        <Grid container sx={{ padding: '20px ' }} spacing={2}>
           <Grid item lg={6} md={6} sm={6} xs={6}>
            <InputLabel>
              Select Category
            </InputLabel>
            <FormControl sx={{ width: '100%' }}>
                <Select
                    size='small'
                    labelId="demo-multiple-checkbox-label"
                    value={selectData?.categoryId}
                    onChange={(event: any) => {
                    const { target: { value } } = event; 
                    setSelectData({
                        ...selectData,
                        categoryId: value,
                    }); 
                    fetchMaterialData(value)
                    }}
                    renderValue={(selected: any[]) => {
                    return categoryData?.filter((selectItem: any) => selectItem?.id == selected)?.map((item: any) => item?.categoryName)?.join(', ');
                    }}
                    MenuProps={MenuProps}
                >
                   {!categoryData?.length ? <MenuItem>No Data Available</MenuItem> : 
                    categoryData?.map((item: any) => {
                        return (
                        <MenuItem key={item?.id} value={item?.id}>
                            <ListItemText primary={item?.categoryName} />
                        </MenuItem>
                        );
                    })}
                </Select>
            </FormControl> 
           </Grid>

           <Grid item lg={6} md={6} sm={6} xs={6}>
           <InputLabel>
              Select Material
            </InputLabel>
            <FormControl sx={{ width: '100%' }}>
                <Select
                    size='small'
                    labelId="demo-multiple-checkbox-label"
                    value={selectData?.name}
                    onChange={(event: any) => {
                    const { target: { value } } = event;
                    setSelectData({
                        ...selectData,
                        name: value,
                    }); 
                    }}
                    renderValue={(selected: any[]) => {
                    return materialData?.filter((selectItem: any) => selectItem?.productName == selected)?.map((item: any) => item?.productName)?.join(', ');
                    }}
                    MenuProps={MenuProps}
                >
                    {!materialData?.length ? <MenuItem>No Data Available</MenuItem> : 
                     materialData?.map((item: any) => {
                        return (
                        <MenuItem key={item?.id} value={item?.productName}>
                            <ListItemText primary={item?.productName} />
                        </MenuItem>
                        );
                    })}
                </Select>
            </FormControl> 
           </Grid>
 
           <Grid item lg={12} md={12} sm={12} xs={12}>
              <InputLabel htmlFor="my-input">Upload Image</InputLabel>
                <FormControl sx={{ width: '100%' }}>
                <TextField 
                    type="file" 
                    size='small'
                    name="image"
                    inputProps={{
                        accept: "image/png, image/gif, image/jpeg"
                    }}  
                    onChange={(e) => { 
                        const file = e?.target?.files[0];  
                            if(!!file){
                                setSelectData({
                                    ...selectData,
                                    image: file,
                                })
                        }
                    }}
                    />
                </FormControl>
           </Grid>

            <Grid item lg={12} md={12} sm={12} xs={12}>
                <Button sx={{float:'right'}} variant='contained' onClick={() => submitUploadImage()}>Save</Button>
            </Grid>
            
        </Grid> 
    </Paper> 
    </>
  )
}

export default UploadImage