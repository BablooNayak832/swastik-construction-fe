'use client';
import React, { ChangeEvent, useEffect, useState } from 'react';
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow, 
  TableCell,
  IconButton, 
  Menu, 
  Tooltip, 
  Select,
  MenuItem, 
  ListItemText,
  InputLabel,
  FormControl,
  Badge,
  AppBar,
  Toolbar,
  Dialog,
  Typography,
  DialogActions,
  DialogContent, 
} from '@mui/material';
import TablePagination from '@mui/material/TablePagination';
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment'; 
import CircularProgress from '@mui/material/CircularProgress'; 
import {
  ContainerMain,
  SearchFilterLayout,
  Searchicon,
  MainBox,
  TableCategoryImageBox, 
  FilterButtonBox, 
  FilterTextLayout, 
} from '../../../common/styles/Dashboard/styles';
import CustomTooltip from '../../../components/Tooltip/Tooltip'; //'../Tooltip/Tooltip';
import { TableColumn } from '../../../Interfaces/Tableinterface';
import { Cell } from '../../../components/Table/styles'; 
import { headers, MenuProps } from '../../../constants/table-columns';  
import {
  Button,
} from '@mui/material'; 
import Visibility from '@mui/icons-material/Visibility'; 
import ListItemComponent from '../../../components/ListItem/page'; 
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { TreeView } from '@mui/x-tree-view/TreeView'; 
import { TreeItem } from '@mui/x-tree-view/TreeItem';  
import ImageIcon from '@mui/icons-material/Image'; 
import MinMaxDateRangePicker from '../../../components/Highcharts/dateSelector';
import {DatePickerLineBox} from '../../../common/styles/HighChartsLayout/styles'; 
import TuneIcon from '@mui/icons-material/Tune';
import {theme} from 'src/common/styles/theme';
import ClearIcon from '@mui/icons-material/Clear';
import { formatString } from '../../../utils/formatString';  
import Link from 'next/link';
import {baseImgUrl} from '../../../constants/api-routes';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';

type TableType = {
  isVisible?: boolean;
  isLoading?: boolean;
  columns: TableColumn[]; // Replace 'any' with a specific type for columns
  rows: any; //use any because row is getting different from parent component
  rowsPerPage?: number;
  page?: number;
  handleChangePage?: (
    event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => void;
  handleChangeRowsPerPage?: (event: ChangeEvent<HTMLInputElement>) => void;
  refreshTableData: (data: any) => void; //use any because row is getting different from parent component
  handleOpenDialogBox?: (id: number) => void;
  handleUpdateProps?: (
    e: React.MouseEvent<HTMLButtonElement>,
    payload: any
  ) => void;
  handleRemoveRow?: (data: any) => void; //use any because data is getting different from parent component
  url?: string;
  title?: string;
  editData?: any; //use any because data is getting different from parent component
  selectItems?: any; //use any because data is getting different from parent component 
  filterMenuOption?: any[];
  handleAvailableQuantity?: any;
  searchTableData?: any;
  handleApproveProject?: any
  handleExcelExport?: any;
  catItems?: any;
  roleItems?: any[];
  projectItems?: any[];
  getUserByRole?: any[];
  filterOnAttendance?: (data: any, type: any) => void;
  applyFilter?: any;
  items?: any[];
  filterOnProject?:any;
  resetFilter?:() => void;
  filterByCategory?: any;
  filterByProject?:any;
  selectedDateRange?:any;
  categorySelected?:any;
  setCategorySelected?:any;
  selectedFilterProject?:any; 
  setSelectedFilterProject?:any;
  totalItems?:any; 
  uploadMaterial?: () => void;
  uploadMaterialFormat?: () => void;
};

const TableMain = ({
  isVisible,
  isLoading,
  columns,
  rows,
  rowsPerPage,
  page,
  handleChangePage,
  handleChangeRowsPerPage,
  refreshTableData, 
  handleRemoveRow, 
  selectItems,
  filterMenuOption,
  title,
  searchTableData, 
  handleExcelExport, 
  filterOnProject,
  resetFilter,
  filterByCategory, 
  selectedDateRange,
  categorySelected,
  setCategorySelected, 
  totalItems, 
  uploadMaterial,
  uploadMaterialFormat
}: TableType) => {    
  const [searchInput, setSearchInput] = useState<string>('');
  const [filteredResults, setFilteredResults] = useState<any>([]);
  const [columnsData, setColumnsData] = useState<any>(columns); 
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
  const [updateRowData, setUpdateRowDAta] = useState<any>();  
  const [isFilterSelected, setFilterSelected] = useState<boolean>(false) 
  const [openInventoryDialog, setOpenInventoryDialog] = useState(false) 
  const open = Boolean( anchorEl );

  const handleSetRowData = ( row: any ) => {
    setUpdateRowDAta( row );
  };

  const handleClick = ( event: React.MouseEvent<HTMLElement> ) => {
    setAnchorEl( event.currentTarget );  
  };
  
  const handleClose = () => {
    setAnchorEl( null );
  };

  const tableSearch = ( searchValue: any ) => {
    setSearchInput( searchValue.target.value );
    searchTableData( searchValue.target.value )
  };


  useEffect(() => {
    if ((title !== 'Attendance') && (title !== 'Central Inventory') ) {
      setColumnsData([...columns, ...headers]);
    } 
  }, [columns]);

  useEffect(() => {
    setFilteredResults(rows); 
  }, [rows]);

  useEffect(() => {
    setFilteredResults(rows); 
  }, []);
  
  const selectFilter = (item:any) => { 
    if(Object.keys(item).includes('fun')){
      item?.fun()
      setFilterSelected(!!item?.id)
    } 
  }

  const filterMenu = (menuData: any) => {
    return menuData?.map((item: any, index: number) => {  
      return !!Object.keys(item)?.length && ( 
        <div key={index}>
           <FilterTextLayout> 
              <TreeItem className='parent-item' key={item?.id} nodeId={item?.id?.toString()} label={item?.menuText} onClick={() => selectFilter(item)}>
                {item?.subItem && item?.subItem?.map((subMenuItem: any) => (
                  <TreeItem className='SubItem' key={subMenuItem?.id} nodeId={subMenuItem?.id?.toString()} label={subMenuItem?.menuText} onClick={subMenuItem?.fun} />
                ))}
            </TreeItem>  
          </FilterTextLayout>
        </div>
      )});
  };

  const checkPagination = totalItems !== undefined ? filteredResults : filteredResults?.slice( page * rowsPerPage, page * rowsPerPage + rowsPerPage );
 
  return (
    <MainBox>
      <ContainerMain>
        {
          <> 
            <SearchFilterLayout>
              {!isVisible &&
                <SearchFilterLayout>
                    <Button variant='contained' style={{whiteSpace: 'nowrap'}} onClick={() => handleExcelExport()}>
                      Download Excel
                    </Button>
                    
                     
                    { title === "Project" &&
                    
                    <div style={{display: 'block', margin:' 0 12px'}}>
                          <DatePickerLineBox> 
                            <MinMaxDateRangePicker selectedDateRange={selectedDateRange} handleFilter={(e) =>  filterOnProject(e)} />
                          </DatePickerLineBox>  
                    </div> 
                     }
                </SearchFilterLayout>
              }
            
              <FilterButtonBox>  
                {/* filter by category for material request*/}
                 { (title == "Material") && <>  
                  <FormControl sx={{width:"20rem",borderRadius: '10px'}}>
                  <InputLabel sx={{top: '-4px'}} id="demo-simple-select-label">
                     Select Category
                  </InputLabel>
                  <Select  
                    id="demo-simple-select"
                    label="Select Category" 
                    value={categorySelected}  
                    sx={{ 
                       padding: '0px 20px 0px 8px'
                    }} 
                    onChange={(event: any) => {
                      const { target: { value } } = event; 
                      setCategorySelected(value) 
                      filterByCategory(value) 
                    }} 
                    renderValue={(selected: any[]) => { 
                      return selectItems?.filter((item:any) => selected == item?.id)?.map(item => item?.category)?.join(','); 
                    }}
                    MenuProps={MenuProps}
                  >  
                     { selectItems?.map((item: any) => { 
                        return (
                          <MenuItem key={item?.id} value={item?.id}> 
                            <ListItemText primary={item?.category} />
                          </MenuItem>
                        );
                      })}
                    </Select>  
                  </FormControl> 
                  </> } 
        
                <TextField
                  id="outlined-start-adornment"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Searchicon />
                      </InputAdornment>
                    ),
                  } }
                  placeholder='Search'
                  value={ searchInput }
                  name="search"
                  onChange={ ( e ) => tableSearch( e ) }
                />
                 { !!filterMenuOption?.length && 
                <IconButton id="demo-customized-button" color='info' onClick={ handleClick }>
                 <Badge color="info" variant="dot" invisible={!isFilterSelected}> 
                     <TuneIcon />  
                 </Badge> 
                </IconButton>
                 } 
        

                <Button variant='contained' onClick={() => {
                  setSearchInput('')
                  resetFilter()  
                  setFilterSelected(false)  
                }}>Reset</Button>  
              </FilterButtonBox>
 
              <Menu
                sx={ { borderRadius: "2%" } }
                anchorEl={ anchorEl }
                open={ open }
                onClose={ handleClose }
                id="demo-customized-menu"
                MenuListProps={ {
                  'aria-labelledby': 'demo-customized-button',
                } }
              >
                <TreeView 
                  aria-label="menu"
                  defaultCollapseIcon={ <ExpandMoreIcon /> }
                  defaultExpandIcon={ <ChevronRightIcon /> }
                >
                  { filterMenu( filterMenuOption ) }
                </TreeView>
              </Menu>
            </SearchFilterLayout>

            <TableContainer sx={ { maxHeight: 440 } }>
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow hover role="checkbox" tabIndex={ -1 }>
                    { columnsData?.map( ( column ) => (
                      <Cell
                        key={ column.id }
                        variant="head"
                        align={ 'center' }
                        style={ {
                          background: '#F3F6F9',
                          border: 'none', 
                          minWidth: column.minWidth,
                          fontSize: '15px',
                          fontWeight: 'bold',
                          fontFamily: '"Poppins", sans-serif'
                        } }
                      >
                        { column.label }
                      </Cell>
                    ) ) }
                  </TableRow>
                </TableHead>
                
                <TableBody>
                  { checkPagination?.length === 0 ? (
                    <> 
                      <TableRow>
                       {<TableCell align="center" colSpan={ columnsData?.length }>
                        <h1>Data Not Found...</h1> 
                        </TableCell>}
                      </TableRow>  
                    </>
                  ) : !isLoading ? (
                    <>
                      <TableRow>
                        <TableCell align="center" colSpan={ columnsData?.length }>
                          <CircularProgress />
                        </TableCell>
                      </TableRow>
                    </>
                  ) : ( checkPagination?.map( ( row, i ) => {
                        return (
                          <TableRow
                            hover
                            role="checkbox"
                            tabIndex={ 1 }
                            key={ row.id }
                          >
                            { columnsData?.map( ( column ) => {
                              const value = row[ column?.id ];
                              const formattedValue = typeof value === "string" ?  formatString(value) : value;   
                              return column?.id !== 'action' ? (
                                <>
                                  <TableCell style={ {
                                    border: 'none',
                                    color: '#000000',
                                    alignItems:'center', 
                                    textAlign: 'center', 
                                    minWidth: column?.minWidth,
                                    width: column?.width ,
                                    fontSize: '14px',
                                    fontWeight: '100',
                                    fontFamily: '"Poppins", sans-serif',
                                  } }
                                    align='left'
                                    key={ column?.id }>
                                    { row[ column?.id ] === null ? (
                                      'Not Specified'
                                    ) : column.label === 'Images' ? (
                                      <>
                                        <TableCategoryImageBox>
                                          { !!row?.img.length && row?.img?.map( ( item ) => (
                                           <Link href={`${baseImgUrl}${item}`} target='_blank'>
                                           <img
                                              src={ `${baseImgUrl}${item}` }
                                              alt="noimage"
                                              crossOrigin="anonymous" 
                                            />
                                           </Link> 
                                          ) ) }
                                        </TableCategoryImageBox>
                                      </>
                                    ) : column?.label === 'img' ? (
                                      <>
                                        <TableCategoryImageBox>
                                          { row?.img?.map( ( item ) => (
                                             <Link href={`${baseImgUrl}${item}`} target='_blank'>
                                               <img
                                                 width={20}
                                                 height={20}
                                                 src={`${baseImgUrl}${item}`}
                                                 alt="noimage"
                                                 crossOrigin="anonymous" 
                                               /> 
                                             </Link>
                                          ) ) }
                                        </TableCategoryImageBox>
                                      </>
                                    ) : column?.label === 'Image' ? (
                                      <> 
                                        <TableCategoryImageBox>
                                          { !!row?.image ? 
                                           <Link href={`${baseImgUrl}${row?.image}`} target='_blank'>
                                             <img  
                                             src={ `${baseImgUrl}${row?.image}` }
                                             alt="noimage"
                                             crossOrigin="anonymous"  
                                           /> 
                                           </Link>
                                          : <ImageIcon /> } 
                                        </TableCategoryImageBox>
                                      </>
                                    ) : (
                                        <> 
                                          { formattedValue } 
                                        </>
                                      )
                                    }
                                  </TableCell>
                                </>
                              ) : (
                                <>
                                  <TableCell align="center" style={{
                                    border: 'none',
                                    color: 'rgba(0, 0, 0, 0.26)',
                                    minWidth: '150px',
                                    fontSize: '14px',
                                    fontWeight: '600',
                                    fontFamily: '"Poppins", sans-serif',
                                    width: '250px'
                                  } } >  
                                      <Tooltip title="View">
                                        <IconButton
                                          key={ i }
                                          color="primary"
                                          size="small"
                                          aria-label="View"
                                        >
                                          <Visibility onClick={ () =>  { 
                                                handleSetRowData(row) 
                                                setOpenInventoryDialog(true) 
                                          }} /> 
                                        </IconButton>
                                      </Tooltip>  
                                      <IconButton
                                          color="error"
                                          size="small"
                                          aria-label="delete"
                                          disabled={row?.verifiedByAdmin === false}
                                          style={ {
                                            opacity: ( ( row?.approveStatus === "approved" ) || (row?.approveStatus === 'rejected') || ( row?.approveStatus === "ordered" ) || ( row?.approveStatus === "delivered" ) || (row?.approveStatus === "partialDelivered") ) ? '0.4' : 1,
                                            pointerEvents: ( ( row?.approveStatus === "approved" ) || (row?.approveStatus === 'rejected') || ( row?.approveStatus === "ordered" ) || ( row?.approveStatus === "delivered" ) || (row?.approveStatus === "partialDelivered")) ? 'none' : null,
                                          } }
                                        > 
                                          <CustomTooltip
                                            title={ title }
                                            handleAction={() => {
                                              handleRemoveRow(row);  
                                              refreshTableData(filteredResults); 
                                            } }
                                            row={ row }
                                          /> 
                                      </IconButton> 
                                  </TableCell>
                                </>
                              );
                            } ) }
                          </TableRow>
                        );
                      } )
                  ) }
                </TableBody>
              </Table>
            </TableContainer>
          </>
        } 

        { ((filteredResults?.length > 0) && (totalItems !== undefined)) && (
          <>  
              <TablePagination
                rowsPerPageOptions={ [2, 5, 10, 15, 25, 50 ] }
                component="div"
                count={ totalItems }
                rowsPerPage={ rowsPerPage } 
                page={ page - 1 }
                onPageChange={ handleChangePage }
                onRowsPerPageChange={ handleChangeRowsPerPage }
              />
          </>
        ) }

      </ContainerMain>
       {
              openInventoryDialog && <>
              <Dialog
                 fullWidth
                 maxWidth='md'
                 open={openInventoryDialog}
                 onClose={() => setOpenInventoryDialog(!openInventoryDialog)}>
                 <AppBar sx={{ position: 'relative', background: theme?.colors?.Red }}>
                   <Toolbar>
                     <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                       {title} Detail
                     </Typography>
                     <DialogActions>
                       <ClearIcon onClick={() => {
                            setOpenInventoryDialog(!openInventoryDialog)
                       }}/> 
                     </DialogActions>
                   </Toolbar>
                 </AppBar>
                 <DialogContent>
                   <ListItemComponent title={ title } data={ updateRowData } />
                 </DialogContent>
               </Dialog>
              </>
            }
    </MainBox >
  );
};
export default TableMain;
