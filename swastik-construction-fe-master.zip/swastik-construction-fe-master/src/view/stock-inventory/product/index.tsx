'use client'
import React, { useEffect, useState } from "react";
import withAuth from '../../../hooks/withAuth';
import TableMain from './ProductTable';//'../../../components/Table/Table' 
import { Heading, HeadingBox } from "../../../common/styles/Users/styles";
import { Blankbox, UploadButton } from "../../../components/Table/styles";
import CommonDialog from "../../../components/CommonDialog/CommonDialog";
import MainForm from "../../../components/common-form";
import useGet from "../../../hooks/useGet";
import { Wrapper } from "../../../app/styles";
import usePatch from "../../../hooks/usePatch";
import useDelete from "../../../hooks/useDelete";
import { useAllowedNavigation } from "../../../context/context";
import useDownloadExcel from "../../../hooks/downloadExcel";
import { inventoryMaterialColumns } from "../../../constants/table-columns";
import { brand_url, category_url, materialExcel, material_url } from "../../../constants/api-routes";
import { Button, IconButton } from "@mui/material";
import Dialog from '@mui/material/Dialog';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import { DialogContent, DialogActions } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import { theme } from '../../../../src/common/styles/theme';
import UploadImage from '../../../view/stock-inventory/UploadImage';
import { useSession } from "next-auth/react";
import axios from "axios";
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import usePost from "src/hooks/usePost";
import UploadDialog from "src/components/UploadDialog";
import { toast } from "react-toastify";

function createData(
    id: number,
    sNo: number,
    category: string,
): any {
    return { id, sNo, category };
}

function createProductData(
    id: number,
    sNo: number,
    productName: string,
    image: string,
    categoryName: string,
    categoryId: string,
    specification: string,
    size: string,
    unit: string,
    subItems: any[],
    itemName: string,
    subItemCount: number,
    brandItems: any[],
): any {
    return {
        id,
        sNo,
        productName,
        image,
        categoryName,
        categoryId,
        specification,
        size,
        unit,
        subItems,
        itemName,
        subItemCount,
        brandItems
    }
}

const Product = () => {
    const { resData, handleGetData, isLoading } = useGet()
    const { resData: brandData, handleGetData: handleGetBrand } = useGet()
    const { resData: getCategoryData, handleGetData: handleGetCategory } = useGet()
    const { handleUpdateData } = usePatch();
    const { handleDeleteData } = useDelete()
    const { setOpen } = useAllowedNavigation();
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const [page, setPage] = useState(1);
    const [totalItems, setTotalItems] = useState(0);
    const [productData, setProductData] = useState([])
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [categorySelected, setCategorySelected] = useState<any>('')
    const [openDialog, setOpenDialog] = useState(false)
    const { data: session } = useSession()
    const [openUploadMaterialDialog, setOpenUploadMaterialDialog] = useState(false);
    const [openUploadMaterialFormatDialog, setOpenuploadMaterialFormatDialog] = useState(false);
    const { handlePostData } = usePost();

    const [file, setFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);

    const handleChangePage = (event, newPage) => {
        setPage(newPage + 1);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1);
    };

    const getCategory = async () => {
        const category = await handleGetCategory(`${category_url}?type=1`);
        return category;
    }

    const getProduct = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
        const product = await handleGetData(`${material_url}?page=${page}&limit=${rowsPerPage}&${searchParams}`);
        return product;
    }

    const getBrands = async () => {
        const brand = await handleGetBrand(brand_url);
        return brand;
    }

    const handleFileChange = (event) => {
        setFile(event.target.files?.[0] || null);
    };

   const handleUpload = async () => {
    if (!file) {
        toast.warning("Please select a file.");
        return;
    }

    const formData = new FormData();
    formData.append("excelFile", file);

    try {
        await handlePostData(materialExcel, formData);
        await getProduct()
        setFile(null);
        setOpenUploadMaterialDialog(false);

        toast.success("Upload successful!");
    } catch (error) {
        toast.error("Upload failed.");
        console.error(error);
    }
};


    useEffect(() => {
        getProduct()
        getCategory()
        getBrands()
    }, [])

    useEffect(() => {
        setTotalItems(resData?.meta?.totalItems)
        const dataArray = resData?.items?.map((i: any, index: number) => {
            let size = i?.size === '' ? '__' : i?.size;
            let specification = i?.specification === '' ? '__' : i?.specification;
            let brandNames = !!i?.brandNames?.length ? i?.brandNames?.map((i: any) => i?.brandName).join(', ') : "__";
            return createProductData(i?.id, (page - 1) * rowsPerPage + index + 1, i.productName, i?.image, i?.category?.categoryName, i?.category?.id, specification, size, i?.unit, i?.subItem, i?.itemName, i?.subItem?.length, brandNames);
        });
        setProductData(dataArray)
    }, [resData])

    useEffect(() => {
        getProduct()
    }, [queryParams, page, rowsPerPage])

    const categories = getCategoryData?.map((i: any, index: number) => {
        return createData(i?.id, index + 1, i?.categoryName);
    });

    const handleUpdateProduct = async (e: any, payload: any) => {
        const url = material_url;
        const res = await handleUpdateData(url, payload)
        setOpen(false);
        getProduct();
        return res;
    }

    const removeProduct = async (proId: number) => {
        const { id } = proId;
        const PRODUCT_DELETE = `${material_url}/${id}`;
        const details = await handleDeleteData(PRODUCT_DELETE);
        setPage(1)
        return details;
    };

    const searchTableData = async (value: any) => {
        if (value === undefined) {
            value = ''
        }
        setQueryParams((v: any) => {
            return { ...queryParams, ['searchParamByNameCatSizeUnit']: value }
        })
        setPage(1)
    }

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${material_url}/?type=xls&page=${page}&limit=${rowsPerPage}&${searchParams}`
        const res = handleDownloadData(url, "Material")
        return res;
    }

    const filterByCategory = (value: any) => {
        let param = '';
        if (value !== undefined) {
            param = value
        }
        setQueryParams((v: any) => {
            return { ...queryParams, ['categoryId']: param }
        })
        setCategorySelected(param)
        setPage(1)
    }

    const resetFilter = () => {
        setQueryParams({})
        setCategorySelected(null)
        setPage(1)
    }

    const handleCloseDialog = () => {
        setOpenDialog(false)
        getProduct()
    }

    const uploadMaterial = () => {
        console.log("uploadMaterial");
        setOpenUploadMaterialDialog(true);
    }

    const uploadMaterialFormat = () => {
        console.log("uploadMaterialFormat");
        setOpenuploadMaterialFormatDialog(true);
    }
    console.log("productData", productData, "openUploadMaterialDialog", openUploadMaterialDialog);


    const handleDownload = async () => {
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Dummy Data');

        // Define columns
        worksheet.columns = [
            { header: 'MATERIALNAME', key: 'productName', width: 20 },
            { header: 'GRADETYPE', key: 'itemName', width: 20 },
            { header: 'CATEGORY', key: 'categoryId', width: 15 },
            { header: 'SPECIFICATIONS', key: 'specification', width: 20 },
            { header: 'SIZE', key: 'size', width: 10 },
            { header: 'UNIT', key: 'unit', width: 10 },
            { header: 'BRAND', key: 'brandId', width: 10 },
        ];

        // Add dummy row
        worksheet.addRow({
            productName: 'CONCRETE',
            itemName: 'M30',
            categoryId: "cemeent",
            specification: 'PQC',
            size: null,
            unit: 'CUM',
            brandId: 'Fosroc',
        });

        // Generate file and download
        const buffer = await workbook.xlsx.writeBuffer();
        const blob = new Blob([buffer], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        saveAs(blob, 'dummy_material_format.xlsx');
    };

    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Material</Heading>
                    </Blankbox>
                    <Blankbox>
                        <Button variant='contained'  onClick={uploadMaterial} >Upload Material</Button>
                        <Button variant='contained' sx={{ margin: '0px 2px 0px 2px' }} onClick={handleDownload}>
                            Export Material Template
                        </Button>
                        {[1, 3].includes(session?.user?.role_id) && 
                        <>
                         <Button sx={{ margin: '0px 2px 0px 0px' }} variant="contained" onClick={() => setOpenDialog(true)}>
                                Upload Image
                         </Button>
                        <CommonDialog title="Add Material">
                            <MainForm
                                data={{
                                    productName: '',
                                    categoryId: null,
                                    size: [''],
                                    unit: '',
                                    brandId: []
                                }}
                                url={material_url}
                                title={'Add Material'}
                                brandItems={brandData}
                                selectItem={categories}
                                refreshData={getProduct}
                            />
                        </CommonDialog>
                        </>
                           }
                        
                    </Blankbox>

                    {/* {[1, 3].includes(session?.user?.role_id) &&
                        <Blankbox>
                            <Button sx={{ margin: '10px' }} variant="contained" onClick={() => setOpenDialog(true)}>
                                Upload Image
                            </Button>
                            <CommonDialog title="Add Material">
                                <MainForm
                                    data={{
                                        productName: '',
                                        categoryId: null,
                                        size: [''],
                                        unit: '',
                                        brandId: []
                                    }}
                                    url={material_url}
                                    title={'Add Material'}
                                    brandItems={brandData}
                                    selectItem={categories}
                                    refreshData={getProduct}
                                />
                            </CommonDialog>
                        </Blankbox>
                    } */}
                </HeadingBox>
                <TableMain
                    title="Material"
                    isLoading={isLoading}
                    columns={inventoryMaterialColumns}
                    rows={productData}
                    handleExcelExport={handleExcelExport}
                    page={page}
                    brandItems={brandData}
                    rowsPerPage={rowsPerPage}
                    handleChangePage={handleChangePage}
                    handleChangeRowsPerPage={handleChangeRowsPerPage}
                    refreshTableData={getProduct}
                    handleRemoveRow={removeProduct}
                    handleUpdateProps={handleUpdateProduct}
                    handleAvailableQuantity={() => 'handleAvailableQuantity'}
                    selectItems={categories}
                    items={productData}
                    searchTableData={searchTableData}
                    resetFilter={resetFilter}
                    filterByCategory={filterByCategory}
                    categorySelected={categorySelected}
                    setCategorySelected={setCategorySelected}
                    totalItems={totalItems}
                    uploadMaterial={uploadMaterial}
                    uploadMaterialFormat={uploadMaterialFormat}
                />
                {/* Dialoag for upload material image */}
                {openDialog &&
                    <Dialog
                        fullWidth
                        maxWidth='md'
                        open={openDialog}>
                        <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
                            <Toolbar>
                                <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
                                    Upload Material Image
                                </Typography>
                                <DialogActions>
                                    <ClearIcon onClick={() => setOpenDialog(false)} />
                                </DialogActions>
                            </Toolbar>
                        </AppBar>
                        <DialogContent>
                            <UploadImage handleClose={handleCloseDialog} />
                        </DialogContent>
                    </Dialog>
                }

                <UploadDialog
                    open={openUploadMaterialDialog}
                    loading={loading}
                    file={file}
                    setOpen={setOpenUploadMaterialDialog}
                    setFile={setFile}
                    handleUpload={handleUpload}
                    title="Upload Material Excel"
                />

            </Wrapper>
        </>
    );
}

export default withAuth(Product, [0, 1, 3]);