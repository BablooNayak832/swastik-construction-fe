import React from "react";
import { Button, FormControl, Grid, InputLabel, ListItemText, MenuItem, Select, SelectChangeEvent } from '@mui/material'
import {MenuProps} from "src/constants/table-columns";

const FilterInventoryData = ({
    loading,
    subItems,
    specificationArray,
    sizeItems,
    handleChangeMaterial,
    projectData,
    materialData,
    categoryData,
    applyFilter,
    clearFilter,
    handleScroll,
    setPage,
    onCategoryOpen
    }:any) => {  
    return ( 
    <>
        <div style={{ display: 'flex', width: "100%" }}>
            <Grid container spacing={2}>
                <Grid sx={{textAlign: "right"}} lg={12} md={12} sm={12} xs={12}>
                    <Button onClick={applyFilter} variant="contained" sx={{margin: '1rem 0.2rem'}}>Apply</Button>
                    <Button onClick={clearFilter} variant="outlined" sx={{margin: '1rem 0.2rem', color: 'red', border: '1px solid red'}}>Clear</Button> 
                </Grid>

                <Grid item lg={3} md={3} sm={3} xs={3}>
                    <>
                        <InputLabel id="demo-simple-select-label">
                            Project
                        </InputLabel>

                        <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                                size='small'
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                placeholder='Select Project'
                                onChange={(event: SelectChangeEvent<object>) => {
                                    const { target: { value } } = event; 
                                    handleChangeMaterial(value, 'projectId')
                                }}
                                MenuProps={MenuProps}
                            > 
                                <MenuItem value="">
                                    <em>Clear</em>
                                </MenuItem>
                                {projectData?.map((item: any) => {
                                    return (
                                        <MenuItem key={item?.id} value={item?.id}>
                                            <ListItemText primary={item?.projectName} />
                                        </MenuItem>
                                    );
                                })}
                            </Select>
                        </FormControl>
                    </>
                </Grid>

                <Grid item lg={3} md={3} sm={3} xs={3}>
                    <div>
                        <InputLabel id="demo-simple-select-label">
                            Category 
                        </InputLabel>
                        <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                                size='small'
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                placeholder="Select Category"
                                onOpen={onCategoryOpen}
                                onChange={(event: SelectChangeEvent<object>) => {
                                    const { target: { value } } = event; 
                                    handleChangeMaterial(value, 'q') 
                                }}
                                MenuProps={MenuProps}
                            > 
                                <MenuItem value="">
                                    <em>Clear</em>
                                </MenuItem>
                                {categoryData?.map((item: any) => {
                                    return (
                                        <MenuItem key={item?.id} value={item?.id}>
                                            <ListItemText primary={item?.categoryName} />
                                        </MenuItem>
                                    );
                                })}
                            </Select>
                        </FormControl>
                    </div>
                </Grid>

                <Grid item lg={3} md={3} sm={3} xs={3}>
                    <div>
                        <InputLabel id="demo-simple-select-label">
                                Material name 
                        </InputLabel>
                        <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                                size='small'
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                placeholder='Select material' 
                                onOpen={() => setPage(1)} 
                                onChange={(event: SelectChangeEvent<object>) => {
                                    const { target: { value } } = event;
                                    handleChangeMaterial(value, 'productName')
                                }}
                                MenuProps={{ PaperProps: { sx: { maxHeight: 200, background: "rgb(220 226 231)" }, onScroll: handleScroll } }}
                            >
                                <MenuItem value="">
                                    <em>Clear</em>
                                </MenuItem>
                                {materialData?.map((item: any) => {
                                    return (
                                        <MenuItem key={item?.id} value={item?.productName}>
                                            <ListItemText primary={item?.productName} />
                                        </MenuItem>
                                    );
                                })} 
                                {loading && <MenuItem value="">Loading...</MenuItem>}
                            </Select>
                        </FormControl>
                    </div>
                </Grid>

                {!!subItems?.length &&  
                 <Grid item lg={3} md={3} sm={3} xs={3}>
                    <div>
                        <InputLabel id="demo-simple-select-label">
                                Type / Grade
                        </InputLabel>
                        <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                                size='small'
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                placeholder='Select type / grade'
                                onChange={(event: SelectChangeEvent<object>) => {
                                    const { target: { value } } = event;
                                    handleChangeMaterial(value, 'item')
                                }}
                                MenuProps={MenuProps}
                            > 
                                <MenuItem value="">
                                    <em>Clear</em>
                                </MenuItem>
                                {subItems?.map((item: any) => {
                                    return (
                                        <MenuItem key={item?.id} value={item?.itemName}>
                                            <ListItemText primary={item?.itemName} />
                                        </MenuItem>
                                    );
                                })}
                            </Select>
                        </FormControl>
                    </div>
                </Grid>}

                {!!specificationArray?.length && <Grid item lg={3} md={3} sm={3} xs={3}>
                    <div>
                        <InputLabel id="demo-simple-select-label">
                                Specification
                        </InputLabel>
                        <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                                size='small'
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                placeholder='Select specification'
                                onChange={(event: SelectChangeEvent<object>) => {
                                    const { target: { value } } = event;
                                    handleChangeMaterial(value, 'specification')
                                }}
                                MenuProps={MenuProps}
                            >
                                <MenuItem value="">
                                    <em>Clear</em>
                                </MenuItem>
                                {specificationArray?.map((item: any) => {
                                    return (
                                        <MenuItem key={item?.id} value={item?.specification}>
                                            <ListItemText primary={item?.specification} />
                                        </MenuItem>
                                    );
                                })}
                            </Select>
                        </FormControl>
                    </div>
                </Grid>}

               {!!sizeItems?.length && <Grid item lg={3} md={3} sm={3} xs={3}>
                    <div>
                        <InputLabel id="demo-simple-select-label">
                            Size 
                        </InputLabel>
                        <FormControl size="small" sx={{ width: '100%' }}>
                            <Select
                                size='small'
                                labelId="demo-multiple-checkbox-label"
                                id="demo-multiple-checkbox"
                                placeholder='Select size'
                                onChange={(event: SelectChangeEvent<object>) => {
                                    const { target: { value } } = event;
                                    handleChangeMaterial(value, 'size')
                                }}
                                MenuProps={MenuProps}
                            >
                                <MenuItem value="">
                                    <em>Clear</em>
                                </MenuItem>
                                {sizeItems?.map((item: any) => {
                                    return (
                                        <MenuItem key={item?.id} value={item?.size}>
                                            <ListItemText primary={item?.size} />
                                        </MenuItem>
                                    );
                                })}
                            </Select>
                        </FormControl>
                    </div>
                </Grid>}  
            </Grid>
        </div>
    </> 
    );
}
 
export default FilterInventoryData;