import React, {useCallback, useEffect, useMemo, useState} from "react";
import { Heading, HeadingBox, TableBox } from "../../../common/styles/Users/styles";
import { Blankbox } from "../../../components/Table/styles";
import { Wrapper } from "../../../app/styles";
import TableReport from "./ReportTable"
import {
    ContainerMain,
    SearchFilterLayout,
    Searchicon,
    MainBox,
    FilterButtonBox,
  } from '../../../common/styles/Dashboard/styles';
import { Button, TablePagination } from "@mui/material"; 
import TextField from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';  
import useGet from "../../../hooks/useGet";
import useDownloadExcel from "../../../hooks/downloadExcel";
import FilterInventoryData from "./FilterInventoryData"
import _ from "lodash";
import {useSelector} from "react-redux";
import {useSession} from "next-auth/react";
import { material_url } from "../../../constants/api-routes";
import getRequestAPI from "../../../services/getRequest";
 
interface Column {
    id: string;
    label: string;
    minWidth?: number;
    align?:  string;
    format?: (value: number) => string;
}
  
const columns: Column[] = [
    { id: 'sNo', label: 'S No.', minWidth: 100 },
    { id: 'projectName', label: 'Project Name', minWidth: 170 },
    { id: 'productName', label: 'Product', minWidth: 100 },
    {
    id: 'categoryName',
    label: 'Category',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toLocaleString('en-US'),
    },
    {
    id: 'itemName',
    label: 'Type / Grade',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toLocaleString('en-US'),
    },
    {
    id: 'productSpecification',
    label: 'Specification',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toFixed(2),
    },
    {
    id: 'productSize',
    label: 'Size',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toFixed(2),
    },
    {
    id: 'productUnit',
    label: 'Unit',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toFixed(2),
    },
    {
    id: 'siteInventoryAvailableQuantity',
    label: 'Available Quantity',
    minWidth: 170,
    align: 'right',
    format: (value: number) => value.toFixed(2),
    },
];

interface Data {
    sNo: number,
    projectName: string, 
    productName: string, 
    categoryName: string, 
    itemName: string, 
    productSpecification: string, 
    productSize: string, 
    productUnit: string, 
    siteInventoryAvailableQuantity: string, 
}

function createData(
    sNo: number,
    projectName: string, 
    productName: string, 
    categoryName: string, 
    itemName: string, 
    productSpecification: string, 
    productSize: string, 
    productUnit: string, 
    siteInventoryAvailableQuantity: string, 
):  any { 
return { sNo,
    projectName,
    productName,
    categoryName,
    itemName,
    productSpecification,
    productSize,
    productUnit,
    siteInventoryAvailableQuantity };
}
   
const SiteInventoryReport = () => {
    const { resData, handleGetData } = useGet()
    const { handleDownloadData } = useDownloadExcel()
    const [ queryParams, setQueryParams ] = useState<any>({})
    const [materialParams, setMaterialParams] = useState<any>({})
    const [ searchInput, setSearchInput ] = useState<string>('');
    const [ showFilterLayout, setShowFilterLayout ] = useState(false)
    const { resData: projectDataRes, handleGetData: handleGetProject } = useGet()
    const { resData: categoryDataRes, handleGetData: handleGetCategory } = useGet() 
    const [materialData, setMaterialData] = useState<any>([]) 
    const [subItems, setSubItems] = useState<any>([])
    const [specificationArray, setSpecificationArray] = useState<any>([]);
    const [sizeItems, setSizeItems] = useState<any>([])
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10); 
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const session = useSession()
    const [itemData, setItemsData] = useState<any>({totalItems: 0, items: []});
    const [pageMaterial, setPageMaterial] = useState(1)
    const [loading, setLoading] = useState(false)
    const [totalItems, setTotalItems] = useState(false)
    const [resMaterialAllData, setMaterialAllData] = useState([])
    let selectedProjectId = selectedProject?.selectedValue != 'null'  ? selectedProject?.selectedValue?.id : ''
     
    useEffect(()=> { 
        if(((![0, 1, 3 ].includes(session?.data?.user?.role_id)) && !!selectedProject?.selectedValue?.id)){
            fetchSiteInventoryData()
        }
        if([0, 1, 3].includes(session?.data?.user?.role_id)){
            fetchSiteInventoryData()
        }
        fetchProjectData()
        fetchCategoryData() 
    },[ queryParams, page, rowsPerPage])
            
    useEffect(() => {  
        if(![0, 1, 3].includes(session?.user?.role_id)){
               setQueryParams((preValue: any) => {
                   return { ...queryParams, ['projectId']: selectedProjectId }
               })  
        }   
    },[selectedProject?.selectedValue?.id])

    useEffect(() => {
        if(!!Object.keys(materialParams)?.length){
            fetchMaterialData()
        }
    }, [materialParams, pageMaterial])
    
    useEffect(() => {
            let updateArray = !!resData?.items?.length && resData?.items?.map((item:Data, index:number) => {
                return createData(
                    (page - 1) * rowsPerPage + index + 1,
                    item?.projectName || "_",
                    item?.productName || "_",
                    item?.categoryName || "_",
                    item?.itemName || "_",
                    item?.productSpecification || "_",
                    item?.productSize || "_",
                    item?.productUnit || "_",
                    item?.siteInventoryAvailableQuantity || "_"
                )
            }) 
            setItemsData({totalItems: resData?.metadata?.totalItems,  items: updateArray})
    }, [resData?.items])
    
    useEffect(() => {   
        if (!!Object.keys(materialParams)?.length) {
            const uniqueMaterials = _.uniqBy(resMaterialAllData ,'productName')  
            const combinedMaterials = [...materialData, ...uniqueMaterials];
            const uniqueCombinedMaterials = _.uniqBy(combinedMaterials, "productName");
            setMaterialData(uniqueCombinedMaterials)
            if (!!resMaterialAllData?.length ) {
                const specification = _.uniqBy(_.filter(resMaterialAllData, p => ((p?.specification !== '') && (p?.specification !== null))), 'specification');
                const size = _.uniqBy(_.filter(resMaterialAllData, p => ((p.size !== '') && (p.size !== null))), 'size');
                const itemName = _.uniqBy(_.filter(resMaterialAllData, p => ((p.itemName !== '') && (p?.itemName !== null))), 'itemName')
                setSubItems(itemName) 
                setSpecificationArray(specification)
                setSizeItems(size) 
            }  
        }
    }, [ materialParams, pageMaterial, resMaterialAllData])
 
    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage+1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1);
    };

    const fetchSiteInventoryData = async() => {
        let searchParam = ''; 
        Object?.entries(queryParams)?.map(([key, value]) => {
          searchParam += `${key}=${value}&`
        }) 
        await handleGetData(`/site-inventory/?page=${page}&limit=${rowsPerPage}&${searchParam}`)
    }

    const fetchProjectData = async() => {
        const res = await handleGetProject('/project/list/?page=1&limit=100')
        return res;
    }

    const fetchCategoryData = async() => {
        const res = await handleGetCategory('/category')
        return res;
    }

    const fetchMaterialData = useCallback( async () => { 
        setLoading(true)
        try {
          let searchParams = "";
          Object.entries(materialParams)?.map(([key, value]) => {
              searchParams += `&${key}=${value}`
          })                                                               
          const response = await getRequestAPI(`${material_url}/?page=${pageMaterial}&limit=50${searchParams}`) 
            setTotalItems(response?.data?.meta?.totalItems)
            setMaterialAllData(response?.data?.items)
            setLoading(false)
        } catch (error) {
            setLoading(false) 
        }
      }, [ page, materialParams, resMaterialAllData]);
  

    const handleChangeMaterial = (value:any, key:string) => { 
        setMaterialParams((prev) => { 
            if (key === "q") {
                setMaterialAllData([])
                setSubItems([])
                setSpecificationArray([])
                setSizeItems([])
                delete materialParams?.["productName"] && delete materialParams?.item && delete materialParams?.specification && delete materialParams?.size
            }
            if(key === "productName"){ 
                setSubItems([])
                setSpecificationArray([])
                setSizeItems([])
                setPageMaterial(1)
               delete materialParams?.item || delete materialParams?.specification || delete materialParams?.size
            }
            if(key === "item"){ 
                setSpecificationArray([])
                setSizeItems([])
               delete materialParams?.specification || delete materialParams?.size 
            }
            if(key === "specification"){ 
                setSizeItems([])
                delete materialParams?.size  
            }
            return { ...materialParams, [key]: value }
        })
    }

    const handleExcelExport = async() => {
        let searchParam = ''; 
        Object?.entries(queryParams)?.map(([key, value]) => {
          searchParam += `${key}=${value}&`
        })
        const res = await handleDownloadData(`/site-inventory?type=xls&${searchParam}`, "Site inventory Report")
        return res;
    }

    const handleApplyFilter = () => {
      const obj = {}
      if(!!materialParams?.projectId){
        obj.projectId = materialParams?.projectId
      }
      if(!!materialParams?.q){
        obj.q = materialParams?.q

      }
      if(!!materialParams?.productName){
        obj.productName = materialParams?.productName
      } 
      if(!!materialParams?.item){
        obj.itemName = materialParams?.item
      }
      if(!!materialParams?.specification){
        obj.specification = materialParams?.specification
      }
      if(!!materialParams?.size){
          obj.size = materialParams?.size
      }
      setQueryParams(obj)
    }

    const handleClearFilter = () => {
        setShowFilterLayout( !showFilterLayout )
        setQueryParams({}) 
        setMaterialParams({})
        setMaterialData([])
        setSubItems([])
        setSpecificationArray([])
        setSizeItems([])
    }

    const handleScroll = (event:any) => {
        const listboxNode = event.currentTarget;
        if ( listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight ) {  
               
                 if((materialData?.length <= totalItems )) { 
                    setPageMaterial(pageMaterial + 1) 
                  } 
        } 
    } 
 
    return ( 
        <>
        <Wrapper>
            <HeadingBox>
                <Blankbox>
                    <Heading>Site Inventory Report</Heading>
                </Blankbox> 
            </HeadingBox>

            <TableBox> 
                <MainBox>
                <ContainerMain> 
                    <SearchFilterLayout>
                        <SearchFilterLayout>
                            <Button variant='contained' style={{whiteSpace: 'nowrap'}} onClick={() => handleExcelExport()}>
                                Download Excel
                            </Button>  
                        </SearchFilterLayout>
                    
                        <FilterButtonBox>   
                            <TextField
                                id="outlined-start-adornment"
                                InputProps={{
                                endAdornment: (
                                        <InputAdornment position="end">
                                        <Searchicon />
                                        </InputAdornment>
                                    ),
                                }}
                                placeholder='Search'
                                value={ searchInput }
                                name="search"
                                onChange={( e ) => {
                                    const value = e.target.value;
                                    setSearchInput(  value )
                                    setQueryParams((item: any) => {
                                        return { ...queryParams,
                                        ["searchTerm"]: value , 
                                    }})
                                    setPage(1)
                                }}
                            /> 
                        </FilterButtonBox>

                        <FilterButtonBox>
                            {!showFilterLayout && 
                            <Button 
                            variant="contained" 
                            style={{margin: '10px', whiteSpace: 'nowrap'}} 
                            onClick={ () => setShowFilterLayout( !showFilterLayout ) }>
                                + Add New Filter
                            </Button>}
                        </FilterButtonBox> 
                    </SearchFilterLayout>

                    { showFilterLayout && 
                        <FilterInventoryData 
                            loading={loading}
                            subItems={subItems}
                            specificationArray={specificationArray}
                            sizeItems={sizeItems}
                            handleChangeMaterial={handleChangeMaterial}  
                            projectData={projectDataRes?.items}  
                            materialData={materialData} 
                            categoryData={categoryDataRes}
                            applyFilter={handleApplyFilter} 
                            clearFilter={handleClearFilter}
                            handleScroll={handleScroll}
                            setPage={setPageMaterial}
                            onCategoryOpen={() => {
                                setMaterialData([])
                                setPageMaterial(1) 
                            }}
                    /> }

                    <TableReport rows={itemData?.items} columns={columns}/>  
                    <TablePagination
                        rowsPerPageOptions={ [5, 10, 15, 25, 50 ] }
                        component="div"
                        count={ itemData?.totalItems }
                        rowsPerPage={ rowsPerPage } 
                        page={ page - 1 }
                        onPageChange={ handleChangePage }
                        onRowsPerPageChange={ handleChangeRowsPerPage }
                    />  
                </ContainerMain>
                </MainBox>
            </TableBox>
        </Wrapper>
        </>
  );
}
 
export default SiteInventoryReport;