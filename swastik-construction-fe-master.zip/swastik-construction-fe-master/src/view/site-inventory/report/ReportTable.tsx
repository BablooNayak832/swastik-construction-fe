"use client"

import React from 'react';
import {
  Table,
  TableBody,
  TableContainer,
  TableHead,
  TableRow, 
  TableCell, 
} from '@mui/material';  
import { Cell } from '../../../components/Table/styles';
import { formatString } from '../../../utils/formatString'
   
const TableReport = ({rows, columns}: any) => { 
  return (
          <>  
            <TableContainer sx={ { maxHeight: 440, padding: '20px 0' }}>
                <Table>
                  <TableHead>
                    <TableRow  hover role="checkbox" tabIndex={ -1 }>
                      { columns?.map( ( column ) => (
                        <Cell
                          key={ column.id }
                          variant="head"
                          align={ 'center' }
                          style={ {
                            background: '#F3F6F9',
                            border: 'none', 
                            minWidth: column.minWidth,
                            fontSize: '15px',
                            fontWeight: 'bold',
                            fontFamily: '"Poppins", sans-serif'
                          } }
                        >
                          { column.label }
                        </Cell>
                      ) ) }
                    </TableRow>
                  </TableHead>

                  <TableBody>
                    {  !rows?.length  ? (
                      <> 
                        <TableRow>
                        {<TableCell align="center" colSpan={ columns?.length }>
                          <h1>No Data Available...</h1> 
                          </TableCell>}
                        </TableRow>  
                      </>
                    ) 
                    : ( 
                      !!rows?.length && rows?.map( ( row, i ) => {
                          return (
                            <TableRow
                              hover
                              role="checkbox"
                              tabIndex={ 1 }
                              key={ row.id }
                            >
                              { columns?.map( ( column ) => {
                                const value = row[ column?.id ];
                                const formattedValue = typeof value === "string" ?  formatString(value) : value;   
                                return column?.id !== 'action' ? (
                                  <>
                                    <TableCell style={ {
                                      border: 'none',
                                      color: '#000000',
                                      alignItems:'center' , 
                                      textAlign: 'center', 
                                      minWidth: column?.minWidth,
                                      width: column?.width ,
                                      fontSize: '14px',
                                      fontWeight: '100',
                                      fontFamily: '"Poppins", sans-serif',
                                    } }
                                      align='left'
                                      key={ column?.id }>
                                      {formattedValue}
                                    </TableCell>
                                  </>
                                ) : (
                                  <>
                                    <TableCell align="center" style={ {
                                      border: 'none',
                                      color: 'rgba(0, 0, 0, 0.26)',
                                      minWidth: '150px',
                                      fontSize: '14px',
                                      fontWeight: '600',
                                      fontFamily: '"Poppins", sans-serif',
                                      width: '250px'
                                    } } >
                                        
                                    </TableCell>
                                  </>
                                );
                              } ) }
                            </TableRow>
                          );
                        })
                    ) }
                  </TableBody>
                </Table>
            </TableContainer>
          </>
  );
};
export default TableReport;
