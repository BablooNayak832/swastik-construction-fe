import React, { useReducer, useEffect, useCallback } from 'react';
import { AddButton, Asterisk, Form } from '../../components/Modal/styles';
import { Autocomplete, Button, CircularProgress, FormControl, FormHelperText, Grid, InputLabel, TextField, Typography } from '@mui/material';
import MaterialRequestTable from '../../components/Table/RequestMaterialTable';
import getRequestAPI from 'src/services/getRequest';
import { material_request_item_delete_url, material_url, materialRequestUpdate } from 'src/constants/api-routes'; 
import { toast } from 'react-toastify';
import useDelete from 'src/hooks/useDelete';
import usePatch from 'src/hooks/usePatch';
import _ from 'lodash';
import {Textarea} from 'src/constants';
import { useRouter } from 'next/navigation';
import {ArrowLeftIcon} from '@mui/x-date-pickers';

const initialState = { 
  isFormOpen: false,
  dataArray: [],
  editingId: null,
  materialData: [], 
  specificationArray: [],
  subItems: [],
  sizeItems: [], 
  editedValue: { quantity: '', remark: '' },
  requestFormData: {},
  queryParams: {},
  formErrors: {},
  page: 1,
  loading: false,
  totalItems: 0
};

const reducer = (state, action) => {
  switch (action.type) {
    case 'SET_FORM_OPEN':
      return { ...state, isFormOpen: action.payload };
    case 'SET_DATA_ARRAY':
      return { ...state, dataArray: action.payload };
    case 'SET_EDITING_ID':
      return { ...state, editingId: action.payload };
    case 'SET_MATERIAL_DATA':
      return { ...state, materialData: action.payload };
    case 'SET_SPECIFICATION_ARRAY':
      return { ...state, specificationArray: action.payload };
    case 'SET_SUB_ITEMS':
      return { ...state, subItems: action.payload };
    case 'SET_SIZE_ITEMS':
      return { ...state, sizeItems: action.payload };
    case 'SET_EDITED_VALUE':
      return { ...state, editedValue: { ...state.editedValue, ...action.payload } };
    case 'SET_REQUEST_FORM_DATA':
      return { ...state, requestFormData: { ...state.requestFormData, ...action.payload } };
    case 'SET_QUERY_PARAMS':
      return { ...state, queryParams: { ...state.queryParams, ...action.payload } };
    case 'SET_FORM_ERRORS':
      return { ...state, formErrors: action.payload };
    case 'SET_LOADING':
        return { ...state, loading: action.payload };
    case 'SET_TOTAL_ITEMS':
        return { ...state, totalItems: action.payload };
    case "SET_PAGE":
        return { ...state, page: action.payload };
    default:
      return state;
  }
};

const RequestUpdate = ({ updateData, catItems, refreshTableData }:any) => {
    const initialReqObj = {
      typeId: "1",
      categoryId: 0,
      categoryName: '',
      materialId: 0,
      machineryOrPrductName: '',
      specification: '',
      itemName: '',
      size: '',
      quantity: '',
      availableQty: '',
      unit: ''
    }
    const router = useRouter()
    const { handleDeleteData } = useDelete();
    const { handleUpdateData } = usePatch();
    const { handleUpdateData: updateQuantity } = usePatch();
    const [state, dispatch] = useReducer(reducer, { ...initialState, dataArray: updateData.items });
    const { isFormOpen,
              dataArray ,
              editingId ,
              materialData , 
              specificationArray ,
              subItems ,
              sizeItems , 
              editedValue ,
              requestFormData ,
              queryParams ,
              formErrors , 
              loading } = state;  

    useEffect(() => {
        dispatch({ type: 'SET_DATA_ARRAY', payload: updateData.items });
    }, [updateData.items]);
 
    const validateMaterial = useCallback(() => {
        const errors = {};
        if (!requestFormData.machineryOrPrductId) errors.machineryOrPrductId = 'Material is required.';
        if (!requestFormData.categoryId) errors.categoryId = 'Category is required.';
        if (subItems.length && !requestFormData.itemName) errors.itemName = 'Type or Grade is required.';
        if (specificationArray.length && !requestFormData.specification) errors.specification = 'Specification is required.';
        if (sizeItems.length && !requestFormData.size) errors.size = 'Size is required.';
        if (!requestFormData.quantity) errors.quantity = 'Quantity is required.';
        else if (requestFormData.quantity <= "0") errors.quantity = "Quantity should be greater than zero.";
        dispatch({ type: 'SET_FORM_ERRORS', payload: errors });
        return Object.keys(errors).length === 0;
    }, [requestFormData, subItems, specificationArray, sizeItems]);
 
    const removeMaterial = async(id, mId) => { 
        const newData = dataArray?.filter((_, index:any) => index != id) 
        await handleDeleteData(`${material_request_item_delete_url}/${mId}`);  
          dispatch({ type: 'SET_DATA_ARRAY', payload: newData }); 
        await refreshTableData()
        if(newData?.length == undefined){
         await router.push('/request-management/material-request');
        } 
    }  
 
    const editMaterial = (id, value) => {
        dispatch({ type: 'SET_EDITING_ID', payload: id });
        dispatch({ type: 'SET_EDITED_VALUE', payload: value });
    };

    const handleChange = (e) => {
        const value = e.target.value;
        const key = e.target.name;
        const regex = /^[1-9]\d*$/;
        if (key === 'quantity') {
        if (value === '' || regex.test(value)) {
            const newQuantity = parseInt(value);
            dispatch({ type: 'SET_EDITED_VALUE', payload: { [e.target.name]: newQuantity } });
        }
        } else {
        dispatch({ type: 'SET_EDITED_VALUE', payload: { [e.target.name]: value } });
        }
    };
 
    const handleSave = (id, row) => {   
      let copyData = [...dataArray];
      copyData[id] = { ...dataArray[id], machineryOrPrductId: row?.machineryOrPrductId ,quantity: editedValue.quantity, remark: editedValue.remark, projectId: updateData.projectId, itemName: row?.itemName, specification: row?.specification, size: row?.size } 
      dispatch({ type: 'SET_DATA_ARRAY', payload: copyData }); 
      updateQuantity(materialRequestUpdate, copyData);
      dispatch({ type: 'SET_EDITING_ID', payload: null });
    }; 

    const getMaterialData = async(requestedParams:any) => {
      try {
        let searchParams = "";
        const params = Object.keys(requestedParams).reduce((acc: any, key) => {
            if (requestedParams[key] !== undefined &&  requestedParams[key] !== null ) {
              acc[key] = requestedParams[key];
            }
            return acc;
          }, {});
        Object.entries(params)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        }) 
        dispatch({ type: "SET_LOADING", payload: true });  
        const response = await getRequestAPI(`${material_url}/?page=1&limit=50&${searchParams}`) 
        dispatch({ type: "SET_LOADING", payload: false }); 
        return response
    } catch (err){
        throw err;
    }       
    }

    const addMaterialForm = useCallback(async () => {
        const exists = dataArray.some(item => item.machineryOrPrductId == requestFormData.machineryOrPrductId);
        const isValid = validateMaterial();
        if (exists) {
            toast.error('This item is already exist', { autoClose: 1000 });
        } else if (isValid && !exists) {
            const sizeOfMaterial = typeof requestFormData?.size == 'object' ? requestFormData?.size?.size : requestFormData?.size;
            const specificationSelect = typeof requestFormData?.specificatiion  == 'object'? requestFormData.specification.specification : requestFormData.specification;
        dispatch({
            type: 'SET_DATA_ARRAY',
            payload: [...dataArray, {
            categoryId: requestFormData.categoryId,
            machineryOrPrductId: requestFormData.machineryOrPrductId,
            machineryOrPrductName: requestFormData.machineryOrPrductName,
            subItem: requestFormData.itemName,
            quantity: requestFormData.quantity,
            unit: requestFormData.unit,
            size: sizeOfMaterial,
            //  typeof requestFormData?.size === 'object' ? requestFormData?.size?.size : requestFormData?.size, //!!requestFormData.size ? requestFormData.size : requestFormData.size,
            specification: specificationSelect,
            categoryName: requestFormData.categoryName,
            remark: requestFormData.remark,
            typeId: requestFormData.typeId,
            requestId: updateData.reqId
            }]
        });
        dispatch({ type: 'SET_FORM_OPEN', payload: false });
        let payload = [];
        if (Object.keys(requestFormData).length !== 0) {
            payload.push({
            requestId: updateData.reqId,
            projectId: updateData.projectId,
            categoryId: requestFormData.categoryId,
            categoryName: requestFormData.categoryName,
            machineryOrPrductId: requestFormData.machineryOrPrductId,
            machineryOrPrductName: requestFormData.machineryOrPrductName,
            subItem: requestFormData.itemName,
            quantity: requestFormData.quantity,
            unit: requestFormData.unit,
            size: sizeOfMaterial,
            specification: specificationSelect,
            remark: requestFormData.remark,
            typeId: requestFormData.typeId,
            createdById: updateData.createdById
            });
        }
        if (payload.length) {
            await handleUpdateData(materialRequestUpdate, payload);
        } 
        dispatch({ type: 'SET_QUERY_PARAMS', payload: {}})
        dispatch({
            type: "SET_REQUEST_FORM_DATA",
            payload: {
            ...requestFormData,
            machineryOrPrductId: '',
            machineryOrPrductName: '',
            unit: '',
            itemName: "",
            specification: "",
            size: "",
            quantity: "",
            },
        })
        dispatch({ type: "SET_QUERY_PARAMS", payload: { productName: '', item:'', specification: '', size: '' }});
        refreshTableData();
    } 
    },[dataArray, requestFormData, validateMaterial]);
 
    const getMaterialByCategory = async (catId: any) => {
      const params = { }
      dispatch({
        type: "SET_QUERY_PARAMS",
        payload: params
      })
      try { 
          const material_unique_name = '/material/unique-name'
          const response = await getRequestAPI(`${material_unique_name}/?categoryId=${catId}`)   
          return response
      } catch (err){
          throw err;
      }        
    }

    useEffect(() => {
      if(!!catItems?.length) {
        const params = {q :requestFormData?.categoryId } 
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        })
        getMaterialByCategory(requestFormData?.categoryId).then((res: any) => { 
            dispatch({ type: "SET_MATERIAL_DATA", payload: res?.data });  
        })
      } 
    }, [requestFormData.categoryId])

    useEffect(() => {
      if(!!catItems?.length && requestFormData?.machineryOrPrductName != '') {
        const params = { q :requestFormData?.categoryId, productName: requestFormData?.machineryOrPrductName}
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        }) 
        getMaterialData(params).then((res: any) => {
            const items = _.uniqBy(res?.data?.items.filter((item: any) => item?.itemName != null), 'itemName');
            if(items?.length == 0) {
              dispatch({
                type: "SET_REQUEST_FORM_DATA",
                payload: { ...requestFormData, itemName: null}
              }) 
            } 
            dispatch({ type: "SET_SUB_ITEMS", payload: items }); 
        })
      } 
    }, [requestFormData?.machineryOrPrductName])

    useEffect(() => {
      if(!!catItems?.length && requestFormData?.machineryOrPrductName != '' && (requestFormData?.itemName != '' || requestFormData?.itemName == null)) {
        const params = {q :requestFormData?.categoryId, productName: requestFormData?.machineryOrPrductName, item: requestFormData?.itemName}   
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        }) 
        getMaterialData(params).then((res: any) => { 
            const items = _.uniqBy(res?.data?.items?.filter((item: any) => item?.specification != null), 'specification');   
            if(items?.length == 0) { 
                dispatch({
                  type: "SET_REQUEST_FORM_DATA",
                  payload: { ...requestFormData, specification: null }
                }) 
            } 
            dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: items });
        })
      } 
    }, [requestFormData?.itemName])

    useEffect(() => {
        if(!!catItems?.length && requestFormData?.machineryOrPrductName != '' && (requestFormData?.itemName != '' ||  requestFormData?.itemName == null) && (requestFormData?.specification != '' || requestFormData?.specification == null)) {
          const params = {q :requestFormData?.categoryId, productName: requestFormData?.machineryOrPrductName, item: requestFormData?.itemName, specification: requestFormData?.specification} 
          dispatch({
            type: "SET_QUERY_PARAMS",
            payload: params
          }) 
          getMaterialData(params).then((res: any) => {
              const items:[] = _.uniqBy(res?.data?.items?.filter((item: any) => item?.size != null), 'size');    
              if(items?.length == 0) { 
                  dispatch({
                    type: "SET_REQUEST_FORM_DATA",
                    payload: { ...requestFormData, size: null }
                  }) 
              }  
              dispatch({ type: "SET_SIZE_ITEMS", payload: items }); 
          })
        } 
    }, [requestFormData?.specification])

    useEffect(() => {
      if(!!catItems?.length && requestFormData?.machineryOrPrductName != '' && requestFormData?.itemName != '' && requestFormData?.specification != '' && (requestFormData?.size != '' || requestFormData?.size == null)) {
        const params = {q :requestFormData?.categoryId, productName: requestFormData?.machineryOrPrductName, item: requestFormData?.itemName, specification: requestFormData?.specification, size: requestFormData?.size}   
        dispatch({
          type: "SET_QUERY_PARAMS",
          payload: params
        })  
        getMaterialData(params).then((res: any) => { 
            dispatch({
              type: "SET_REQUEST_FORM_DATA",
              payload: { ...requestFormData,  
                machineryOrPrductId: res?.data?.items[0]?.id, 
                unit: res?.data?.items[0]?.unit }
            })    
        })
      } 
    }, [requestFormData?.size])

    const handleCategoryChange = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: {
          ...requestFormData,
          typeId: "1",
          categoryId: newValue?.id ?? 0,
          categoryName: newValue?.categoryName,  
          machineryOrPrductId: "",
          machineryOrPrductName: "",
          itemName: "",
          specification: "",
          size: "",
          quantity: "",
          unit: "",
        }}) 
      const params = {q: newValue?.id }
      dispatch({
        type: "SET_QUERY_PARAMS",
        payload: params
      }) 
      dispatch({ type: "SET_MATERIAL_DATA", payload: [] });  
      dispatch({ type: "SET_SUB_ITEMS", payload: [] });
      dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: [] });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] }); 
      const updatedErrors = { ...formErrors };
      delete updatedErrors.categoryId;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });  
    }

    const handleProductName = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: {
          ...requestFormData, 
          machineryOrPrductName: newValue?.productName,
          // unit: newValue?.unit,
          itemName: "",
          specification: "",
          size: "",
          quantity: "",
        }}) 
      dispatch({ type: "SET_SUB_ITEMS", payload: [] });
      dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: [] });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] }); 
      const updatedErrors = { ...formErrors };
      delete updatedErrors.machineryOrPrductId;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors }); 
    }

    const handleItems = (e: any, newValue: any) => {  
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: { ...requestFormData, itemName: newValue?.itemName, specification: '', size: '', quantity: '' },
      });
      dispatch({ type: "SET_SPECIFICATION_ARRAY", payload: [] });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] });
      const updatedErrors = { ...formErrors };
      delete updatedErrors.itemName; 
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });
    }

    const handleSpec = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: { ...requestFormData, specification: newValue?.specification, size: '', quantity: '' },
      });
      dispatch({ type: "SET_SIZE_ITEMS", payload: [] });
      const updatedErrors = { ...formErrors };
      delete updatedErrors.specification;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });
    }

    const handleSizeChange = (e: any, newValue: any) => { 
      dispatch({
        type: "SET_REQUEST_FORM_DATA",
        payload: { ...requestFormData, size: newValue?.size },
      });
      dispatch({ type: "SET_QUERY_PARAMS", payload: { ...queryParams, size: newValue?.size } });
      const updatedErrors = { ...formErrors };
      delete updatedErrors.size;
      dispatch({ type: "SET_FORM_ERRORS", payload: updatedErrors });
    }   
    
  return (
    <Form>
      {!isFormOpen && 
        <Grid container spacing={2}>
          <Grid item lg={12} md={6} sm={6} xs={12}>
            <Typography paragraph={true} component={() => {
              return (
                <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                  <span>Request : {updateData.reqId}</span>
                </div>
              );
            }} />
             <Typography paragraph={true} component={() => {
              return (
                <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                  <span>Project: {updateData.projectName}</span> 
                </div>
              );
            }} />
             <Typography paragraph={true} component={() => {
              return (
                <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                  <span>Location: {updateData.location}</span>
                </div>
              );
            }} />
             <Typography paragraph={true} component={() => {
              return (
                <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                  <span>Requested Date: {updateData?.requestedDate ?? "_"}</span>
                </div>
              );
              }} />
              <Typography paragraph={true} component={() => {
              return (
                <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                  <span>Sender Name: {updateData?.senderName ?? "_"}</span>
                </div>
              );
              }} />
                 <Typography paragraph={true} component={() => {
              return (
                <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                  <span>Status: {updateData?.approveStatus ?? "_"}</span>
                </div>
              );
              }} />
          </Grid>

          <Grid item lg={12} md={6} sm={6} xs={12}>
            <MaterialRequestTable
              title={"Material Request"}
              data={dataArray}
              handleSave={handleSave}
              editingId={editingId}
              removeMaterial={removeMaterial}
              editMaterial={editMaterial}
              handleChange={handleChange}
              editedValue={editedValue}
              isApproved={updateData.approveStatus}
              fetchData={refreshTableData}
            />
          </Grid>

          {!!dataArray?.length &&
            <Grid item alignItems={'end'} lg={12} md={6} sm={6} xs={12}>
              <Button disabled={updateData.approveStatus !== 'pending'} style={{ float: 'right', color: 'white' }} variant='contained' type='button'
                onClick={() => dispatch({ type: 'SET_FORM_OPEN', payload: !isFormOpen })}
              > + Add Material</Button>
            </Grid>
          }

          <Grid item lg={12} md={6} sm={6} xs={12}>
            <AddButton
              style={{ margin: "0 10px", float: "right" }}
              variant="contained"
              onClick={() => router.back()}
            >  Save
            </AddButton>
            <AddButton
              style={{ margin: "0 10px", float: "right" }}
              variant="outlined"
              onClick={() => router.back()}
            > <ArrowLeftIcon /> Go Back
            </AddButton>
          </Grid>
        </Grid>
      }

      {isFormOpen && (
              <Grid sx={{ padding: "20px" }} container spacing={2}>
                <Grid item lg={12} md={6} sm={6} xs={12}>
                  <InputLabel htmlFor="my-input">
                    Category <Asterisk>*</Asterisk>
                  </InputLabel>
                  <FormControl sx={{ width: "100%" }}>
                    <Autocomplete
                        size='small'
                        disabled={!catItems?.length}
                        options={catItems}
                        getOptionLabel={(option) => {
                            return typeof option === 'object' ? option?.categoryName : option;
                        }}
                        value={requestFormData?.categoryName}
                        onChange={handleCategoryChange}
                        renderInput={(params) => {
                            return (<TextField {...params} />)
                        }}
                        fullWidth
                    /> 
                  </FormControl>
                  {formErrors.categoryId && (
                    <FormHelperText id="project-name-error" error>
                      {formErrors.categoryId}
                    </FormHelperText>
                  )}
                </Grid>
    
                  <Grid item lg={12} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">
                      Material <Asterisk>*</Asterisk>
                    </InputLabel> 
                    <FormControl sx={{ width: "100%" }}>
                        <Autocomplete
                            disabled={materialData.length == 0} 
                            size='small'
                            options={materialData}
                            getOptionLabel={(option) => typeof option == 'object' ? option?.productName : option}
                            value={requestFormData?.machineryOrPrductName}
                            ListboxProps={{  sx: { maxHeight: 150 } }}
                            onChange={handleProductName}
                            renderInput={(params) => (
                                <TextField
                                    {...params}
                                InputProps={{
                                        ...params.InputProps,
                                        endAdornment: (
                                            <>
                                                {loading && <CircularProgress color="info" size={30} />}
                                                {params.InputProps.endAdornment}
                                            </>
                                        ),
                                    }}
                                />
                            )}
                            isOptionEqualToValue={(option, value) => option?.id === value?.id}
                            fullWidth
                        />
                    </FormControl>
                    {formErrors.machineryOrPrductId && (
                      <FormHelperText id="project-name-error" error>
                        {formErrors.machineryOrPrductId}
                      </FormHelperText>
                    )}
                  </Grid>
    
                {!!subItems?.length && (
                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Type / Grade</InputLabel>
                    <FormControl sx={{ width: "100%" }}> 
                      <Autocomplete
                          size='small'
                          options={subItems}
                          getOptionLabel={(option) => typeof option == 'object' ? option?.itemName : option}
                          value={requestFormData?.itemName}
                          onChange={handleItems}
                          renderInput={(params) => {
                              return (<TextField {...params} />)
                          }}
                          fullWidth
                      />
                    </FormControl>
                    {formErrors.itemName && (
                      <FormHelperText id="error" error>
                        {formErrors.itemName}
                      </FormHelperText>
                    )}
                  </Grid>
                )}
    
                {!!specificationArray?.length && (
                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Specification</InputLabel>
                    <FormControl sx={{ width: "100%" }}>
                      <Autocomplete
                          size='small' 
                          options={specificationArray}
                          getOptionLabel={(option) => typeof option == 'object' ? option?.specification : option} 
                          value={requestFormData?.specification}
                          onChange={handleSpec}
                          renderInput={(params) => {
                              return (<TextField {...params} />)
                          }}
                          fullWidth
                      /> 
                    </FormControl>
                    {formErrors.specification && (
                      <FormHelperText id="error" error>
                        {formErrors.specification}
                      </FormHelperText>
                    )}
                  </Grid>
                )}
    
                {!!sizeItems.length && (
                  <Grid item lg={6} md={6} sm={6} xs={12}>
                    <InputLabel htmlFor="my-input">Size</InputLabel>
                    <FormControl sx={{ width: "100%" }}> 
                       <Autocomplete
                          size='small' 
                          options={sizeItems}
                          getOptionLabel={(option) => typeof option == 'object' ? option?.size : option}  
                          value={requestFormData?.size}
                          onChange={handleSizeChange}
                          renderInput={(params) => {
                              return (<TextField {...params} />)
                          }}
                          fullWidth
                      />
                    </FormControl>
                    {formErrors.size && (
                      <FormHelperText id="project-name-error" error>
                        {formErrors.size}
                      </FormHelperText>
                    )}
                  </Grid>
                )}
    
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <InputLabel htmlFor="my-input">
                    Quantity <Asterisk>*</Asterisk>
                  </InputLabel>
                  <FormControl sx={{ width: "100%" }}>
                    <TextField
                      size="small"
                      type="text"
                      id="my-input"
                      autoComplete='off'
                      value={requestFormData?.quantity}
                      onChange={(e) => {
                        const value = e.target.value;
                        const regex = /^[1-9]\d*$/;
                        if (regex.test(value) || value === "") {
                          dispatch({
                            type: "SET_REQUEST_FORM_DATA",
                            payload: { ...requestFormData, quantity: value },
                          });
                          dispatch({ type: "SET_FORM_ERRORS", payload: { ...formErrors, quantity: undefined } });
                        }
                      }}
                      aria-describedby="my-helper-text"
                    />
                  </FormControl>
                  {formErrors.quantity && (
                    <FormHelperText id="project-name-error" error>
                      {formErrors?.quantity}
                    </FormHelperText>
                  )}
                </Grid>
    
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <InputLabel htmlFor="my-input">Unit</InputLabel>
                  <FormControl sx={{ width: "100%" }}>
                    <TextField
                      size="small"
                      type="text"
                      id="my-input"
                      autoComplete='off'
                      disabled
                      defaultValue={requestFormData?.unit}
                      aria-describedby="my-helper-text"
                    />
                  </FormControl>
                </Grid>
    
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <InputLabel htmlFor="my-input">Remark </InputLabel>
                  <FormControl sx={{ width: "100%" }}>
                    <Textarea  
                      id="my-input"
                      sx={{resize: 'none'}}
                      value={requestFormData?.remark}
                      onChange={(e) => {
                        const value = e.target.value;
                        dispatch({
                          type: "SET_REQUEST_FORM_DATA",
                          payload: { ...requestFormData, remark: value },
                        });
                      }}
                      aria-describedby="my-helper-text"
                    />
                  </FormControl>
                </Grid>
    
                <Grid item lg={12} md={6} sm={6} xs={12}>
                  <Button variant="contained" style={{ margin: "10px", float: "right" }} onClick={addMaterialForm}>
                    Add
                  </Button>
                  <Button
                    variant="contained"
                    style={{ margin: "10px", float: "right" }}
                    onClick={() => {
                      dispatch({ type: "SET_FORM_OPEN", payload: false }); 
                      dispatch({ type: "SET_REQUEST_FORM_DATA", payload: initialReqObj });
                    }}
                  >
                    Cancel
                  </Button>
                </Grid>
              </Grid>
      )}
    </Form>
  );
};

export default RequestUpdate;
 