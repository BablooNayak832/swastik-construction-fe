import React, {useCallback, useEffect, useState} from 'react'
import {AddButton, Asterisk, Form} from '../../components/Modal/styles';
import {Autocomplete, Button, CircularProgress, FormControl, FormHelperText, Grid, InputLabel, TextField, Typography} from '@mui/material';
import MaterialRequestTable from '../../components/Table/RequestMaterialTable'; 
import {Textarea} from 'src/constants';
import getRequestAPI from 'src/services/getRequest';
import { return_request, site_inventory_url} from 'src/constants/api-routes'; 
import _ from 'lodash'; 
import {toast} from 'react-toastify';
import {useSelector} from 'react-redux';
import useDelete from 'src/hooks/useDelete'; 
import usePatch from 'src/hooks/usePatch';
import { useRouter } from 'next/navigation';
import {ArrowLeftIcon} from '@mui/x-date-pickers';

const RequestUpdate = ({setOpen, updateData, refreshTableData}:any) => { 
const initialReqObj = {
    typeId: "1",
    categoryId: 0,
    categoryName: '',
    materialId: 0,
    machineryOrPrductName: '',
    specification: '',
    itemName: '',
    size: '',
    quantity: '',
    availableQty: '',
    unit: ''
}
const router = useRouter()
const [isFormOpen, setIsFormOpen] = useState(false); 
const [dataArray, setDataArray] = useState<any>(updateData.items)
const [editingId, setEditingId] = useState(null);
const [materialData, setMaterialData] = useState<any>([]) 
const [specificationArray, setSpecificationArray] = useState<any>([]) 
const [sizeItems, setSizeItems] = useState<any>([]) 
const [editedValue, setEditedValue] = useState({ quantity: '', remark: '' });
const [requestFormData, setRequestFormData] = useState<any>(initialReqObj);
const [queryParams, setQueryParams] = useState<any>({})
const [formErrors, setFormErrors] = useState<{ [key: string]: string }>({}); 
const [categoryData, setCategoryData] = useState<any>([])
const selectedProject = useSelector((state: any) => state?.selectedProject); 
const [itemNameArray, setItemNameArray] = useState<any>([])
const { handleDeleteData } = useDelete()
const [page, setPage] = useState(1)
const [totalItems, setTotalItems] = useState(0)
const [loading, setLoading] = useState(false)
const { handleUpdateData } = usePatch()

    useEffect(() => {
        setDataArray(updateData?.items)
    }, [updateData?.items]) 

    useEffect(() => {
        if(selectedProject?.selectedValue?.name) {
            const params = {projectName: selectedProject?.selectedValue?.name}
            setQueryParams(params)
            getMaterialData(params).then((res: any) => {
                const uniqCat = _.uniqBy(res.data.items, 'categoryName')
                setCategoryData(uniqCat)
            })
        } 
    }, [selectedProject])

    useEffect(() => {
      if(!!categoryData.length) {
        const params = {...queryParams}
        params['q'] = requestFormData.categoryId
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            let resData = _.uniqBy(res.data.items, 'productName')
            setMaterialData(resData)
        })
      }
    }, [requestFormData.categoryId])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '') {
        const params = {...queryParams}
        params['productName'] = requestFormData.machineryOrPrductName
        setQueryParams(params)
        getMaterialData(params).then((res: any) => {
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.itemName != null), 'itemName');
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    itemName: null,
                })
            }
            setItemNameArray(items)
        })
      }
    }, [requestFormData.machineryOrPrductName])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' || requestFormData.itemName == null)) {
        const params = {...queryParams}
        params['itemName'] = requestFormData.itemName
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            const items = _.uniqBy(res.data.items.filter((item: any) => item?.productSpecification != null), 'productSpecification');   
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    specification: null
                })
            }
            setSpecificationArray(items)
        })
      }
    }, [requestFormData.itemName])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && (requestFormData.itemName != '' ||  requestFormData.itemName == null) && (requestFormData.specification != '' || requestFormData.specification == null)) {
        const params = {...queryParams}
        params['specification'] = requestFormData.specification
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => {
            const items:[] = _.uniqBy(res.data.items.filter((item: any) => item?.productSize != null), 'size');    
            if(items.length == 0) {
                setRequestFormData({
                    ...requestFormData,
                    size: null
                })
            }
            setSizeItems(items)
        })
      }
    }, [requestFormData.specification])

    useEffect(() => {
      if(!!categoryData.length && requestFormData?.machineryOrPrductName != '' && requestFormData.itemName != '' && requestFormData.specification != '' && (requestFormData.size != '' || requestFormData.size == null)) {
        const params = {...queryParams}
        params['size'] = requestFormData.size
        setQueryParams(params) 
        getMaterialData(params).then((res: any) => { 
            setRequestFormData({
                ...requestFormData,
                machineryOrPrductId: res?.data?.items[0]?.productId,
                availableQty: res?.data?.items[0]?.siteInventoryAvailableQuantity,
                unit: res?.data?.items[0]?.productUnit
            }) 
        })
      }
    }, [requestFormData.size])

    const getMaterialData = async (requestedParams: any) => {
        try {
            let searchParams = "";
            const params = Object.keys(requestedParams).reduce((acc: any, key) => {
                if (requestedParams[key] !== undefined &&  requestedParams[key] !== null ) {
                    acc[key] = requestedParams[key];
                }
                return acc;
                }, {});
            Object.entries(params)?.map(([key, value]) => {
                searchParams += `${key}=${value}&`
            })
            setLoading(true)
            const response = await getRequestAPI(`${site_inventory_url}/?page=${page}&limit=50&${searchParams}`)
            setTotalItems(response?.data?.metadata?.totalItems)
            setLoading(false)
            return response
        } catch (err){
            throw err;
        }        
    }
 
    const validateMaterial = () => {
        const errors: { [key: string]: string } = {};
        if (!requestFormData?.machineryOrPrductId) {
            errors.machineryOrPrductId = 'Material is required.';
        } else {
            delete errors.machineryOrPrductId;
        }
        if (!requestFormData?.categoryId) {
            errors.categoryId = 'Category is required.';
        } else {
            delete errors.categoryId;
        }
        if (!requestFormData?.quantity) {
            errors.quantity = 'Quantity is required.';
        } else {
            delete errors.quantity;
        }
        setFormErrors(errors)
        return Object.keys(errors).length === 0;
    }  

    const removeMaterial = async(id: any, mId:number) => { 
        const newData = dataArray.filter((item: any, index: any) => item?.id !== mId)
        setDataArray(newData); 
        if(!newData?.length){
        setOpen(!open)
        }
        const removeItem = await handleDeleteData(`return-request/item/${mId}`)
        refreshTableData()
        return removeItem;
    }

    const editMaterial = (id: any, value: any) => {
        setEditingId(id);
        setEditedValue(value);
    }

    const handleChange = (e: any, data:any) => {    
        const value = e.target.value;  
        const key = e.target.name; 
        if(key === 'quantity'){ 
            if (value === '' || /^[0-9]*$/.test(value)) {
                const newQuantity = value === '' ? '' : parseInt(value, 10); 
                // Check if the value is within the allowed range only when it's not empty
                if (newQuantity === '' || newQuantity <= data?.siteAvailableQuantity) {
                    setEditedValue(prevState => ({
                        ...prevState,
                        [key]: newQuantity
                    }));
                }
            }
        }else{
            setEditedValue(prevState => ({
                ...prevState,
                [e.target.name]: value
            }));
        } 
    }

    const handleSave = async(id: any, row:any) => { 
        let copyData = [...dataArray]
        copyData[id] = { ...dataArray[id], materialId: row?.materialId, ['quantity']: editedValue.quantity, ['remark']: editedValue.remark,  } 
        setDataArray(copyData)
        setEditingId(null); 
        await handleUpdateData(return_request, copyData);
        await refreshTableData()
    };

    const addMaterialForm = async() => { 
        const exists = dataArray.some(item => item?.materialId == requestFormData?.machineryOrPrductId);  
        if(exists){
            toast.error('This item is already exist',
                {
                    position: "top-right",
                    autoClose: 1000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "light",  
                }) 
            } 
        const isValid = validateMaterial();
        if (isValid && !exists) {
            setDataArray((prevState: any) => [...prevState, {
                ['categoryId']: requestFormData?.categoryId,
                ['materialId']: requestFormData?.machineryOrPrductId,
                ['machineryOrPrductName']: requestFormData?.machineryOrPrductName,
                ['subItem']: requestFormData?.itemName,  
                ['quantity']: requestFormData?.quantity,
                ['availableQty']: requestFormData?.availableQty,
                ['unit']: requestFormData?.unit,
                ['size']: !!requestFormData?.size ? requestFormData?.size : requestFormData?.productName?.size,
                ['specification']: requestFormData?.specification?.productSpecification ,
                ['categoryName']: requestFormData?.categoryName,
                ['remark']: requestFormData?.remark,
                ['typeId']: requestFormData?.typeId,
                ['reqId']: updateData?.reqId,
                ['projectId']: updateData?.projectId
            }]);
            let payload = [...dataArray] 
            payload.push({   
                    "remark": requestFormData?.remark, 
                    "categoryId": requestFormData?.categoryId,
                    "materialId": requestFormData?.machineryOrPrductId,
                    "machineryOrPrductName": requestFormData?.machineryOrPrductName,
                    "subItem":requestFormData?.itemName,
                    "quantity":requestFormData?.quantity,
                    "availableQty": requestFormData?.availableQty,
                    "unit": requestFormData?.unit,
                    "size": !!requestFormData?.size ? requestFormData?.size : requestFormData?.productName?.size,
                    "categoryName": requestFormData?.categoryName,
                    "typeId": "1",
                    "reqId": updateData?.reqId,
                    "projectId": updateData?.projectId
            })
            if (Object.keys(requestFormData).length !== 0) {
                if( !!payload.length ){ 
                const res = await handleUpdateData(return_request, payload);
                setRequestFormData(initialReqObj)
                refreshTableData()
                setIsFormOpen(false)
                setQueryParams({})
                return res;
                }
            }
        }
    } 
  
    const handleScroll = useCallback((event: React.SyntheticEvent) => {
        const listboxNode = event.currentTarget;
        if ( listboxNode.scrollTop + listboxNode.clientHeight >= listboxNode.scrollHeight ) {  
            if(!loading ){
                if((materialData?.length <= totalItems )) { 
                setPage(page + 1) 
                }
            }
        } 
    },[loading, page]);

    const handleCancelMaterial = () => {
        setRequestFormData(initialReqObj)
        setIsFormOpen(false)
    }

    const handleCategoryChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            categoryId: newValue?.categoryId ?? 0,
            categoryName: newValue?.categoryName,    
            machineryOrPrductName: '',
            itemName: '',
            specification: '',
            size: '',
            availableQty: ''

        })
        const params = {projectName: selectedProject?.selectedValue?.name}
        setQueryParams(params)
        setMaterialData([])
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.categoryId;
        setFormErrors(updatedErrors);
    }

    const handleProductName = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            machineryOrPrductName: newValue?.productName,
            machineryOrPrductId: newValue?.productId,
            itemName: '',
            specification: '',
            size: '', 
        }) 
        setItemNameArray([])
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.machineryOrPrductId;
        setFormErrors(updatedErrors)
    }

    const handleItems = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            itemName: newValue?.itemName, 
            specification: '',
            size: '',  
        })  
        setSpecificationArray([])
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.itemName;
        setFormErrors(updatedErrors)
    }

    const handleSpec = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            specification: newValue?.productSpecification, 
            size: '',  
        }) 
        setSizeItems([])
        const updatedErrors = { ...formErrors };
        delete updatedErrors.specification;
        setFormErrors(updatedErrors)
    }

    const handleSizeChange = (e: any, newValue: any) => { 
        setRequestFormData({
            ...requestFormData,
            size: newValue?.productSize, 
        })
        const updatedErrors = { ...formErrors };
        delete updatedErrors.size;
        setFormErrors(updatedErrors)
    }
 
  return (
    <>
    <Form>
        {!isFormOpen && 
        <Grid container spacing={2}>
            <Grid item lg={12} md={6} sm={6} xs={12}>
            <Typography paragraph={true} component={() => {
                return <>
                <div style={{
                    fontSize: '20px',
                    display: 'flex',
                    justifyContent: ' space-between',
                    width: '100%'
                }}>
                    <span>Request : {updateData?.reqId}</span> <span> Project: {updateData?.projectName}</span> <span >Location: {updateData?.location}</span>
                </div>
                </>
            }}
            />
            </Grid>

            <Grid item lg={12} md={6} sm={6} xs={12}>
            <MaterialRequestTable
                data={dataArray}
                handleSave={handleSave}
                editingId={editingId}
                removeMaterial={removeMaterial}
                editMaterial={editMaterial}
                handleChange={handleChange}
                editedValue={editedValue}
                isApproved={updateData?.approveStatus}
                title={"Return Request"}
                requestType={"Return Request"}
            />
            </Grid>

            {!!dataArray?.length &&
            <Grid item alignItems={'end'} lg={12} md={6} sm={6} xs={12}>
                <Button disabled={updateData?.approveStatus !== 'pending' } style={{ float: 'right', color: 'white' }} variant='contained' type='button'
                onClick={() => setIsFormOpen(!isFormOpen)}
                > + Add Material</Button>
            </Grid>}

            <Grid item lg={12} md={6} sm={6} xs={12}>
            <AddButton
                style={{ float: 'right' }}
                variant="contained"
                onClick={() => router.back()}
            > <ArrowLeftIcon />Go Back
            </AddButton>
            </Grid>
        </Grid>}

         <Grid sx={{ padding: '20px' }} container spacing={2}>
            {
                isFormOpen &&
                <Grid container spacing={2}>
                    <Grid item lg={12} md={6} sm={6} xs={12}>
                        <Typography paragraph={true} component={() => {
                            return <>
                                <div style={{
                                    fontSize: '30px',
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    width: '70%'
                                }}>
                                    <span> Return Material Request</span>
                                </div>
                            </>
                        }}
                        />
                    </Grid>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Category <Asterisk>*</Asterisk></InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                            <Autocomplete
                                size='small'
                                disabled={!categoryData.length}
                                options={categoryData}
                                getOptionLabel={(option) => {
                                    return typeof option == 'object' ? option?.categoryName : option;
                                }}
                                value={requestFormData?.categoryName}
                                onChange={handleCategoryChange}
                                renderInput={(params) => {
                                    return (<TextField {...params} />)
                                }}
                                fullWidth
                            />
                        </FormControl>
                        {formErrors.categoryId && (
                            <FormHelperText id="project-name-error" error>
                                {formErrors.categoryId}
                            </FormHelperText>
                        )}
                    </Grid>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Material <Asterisk>*</Asterisk></InputLabel>
                            <FormControl
                                sx={{ width: '100%' }}
                            >
                                <Autocomplete
                                    disabled={materialData.length == 0} 
                                    size='small'
                                    options={materialData}
                                    getOptionLabel={(option) => typeof option == 'object' ? option?.productName : option}
                                    value={requestFormData?.machineryOrPrductName}
                                    ListboxProps={{ onScroll: handleScroll, sx: { maxHeight: 150 } }}
                                    onChange={handleProductName}
                                    renderInput={(params) => (
                                        <TextField
                                            {...params}
                                        InputProps={{
                                                ...params.InputProps,
                                                endAdornment: (
                                                    <>
                                                        {loading && <CircularProgress color="info" size={30} />}
                                                        {params.InputProps.endAdornment}
                                                    </>
                                                ),
                                            }}
                                        />
                                    )}
                                    isOptionEqualToValue={(option, value) => option?.id === value?.id}
                                    fullWidth
                                />
                            </FormControl>
                            {formErrors.machineryOrPrductId && (
                                <FormHelperText id="project-name-error" error>
                                    {formErrors.machineryOrPrductId}
                                </FormHelperText>
                            )}
                    </Grid>

                    {!!itemNameArray?.length && <>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Type / Grade</InputLabel>
                            <FormControl sx={{ width: '100%' }}>
                                <Autocomplete
                                    size='small'
                                    options={itemNameArray}
                                    getOptionLabel={(option) => typeof option == 'object' ? option?.itemName : option}
                                    value={requestFormData?.itemName}
                                    onChange={handleItems}
                                    renderInput={(params) => {
                                        return (<TextField {...params} />)
                                    }}
                                    fullWidth
                                />
                            </FormControl>
                            {formErrors.itemName && (
                                <FormHelperText id="itemName-error" error>
                                    {formErrors?.itemName}
                                </FormHelperText>
                            )}
                        </Grid>
                    </>}

                    {!!specificationArray?.length && <>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Specification</InputLabel>
                            <FormControl
                                sx={{ width: '100%' }}
                            >
                                <Autocomplete
                                    size='small' 
                                    options={specificationArray}
                                    getOptionLabel={(option) => option?.productSpecification ?? option}
                                    value={requestFormData?.specification}
                                    onChange={handleSpec}
                                    renderInput={(params) => {
                                        return (<TextField {...params} />)
                                    }}
                                    fullWidth
                                />
                            </FormControl>
                            {formErrors.specification && (
                                <FormHelperText id="specification-error" error>
                                    {formErrors?.specification}
                                </FormHelperText>
                            )}
                        </Grid>
                    </>}

                    {!!sizeItems.length && <>
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Size</InputLabel>
                            <FormControl sx={{ width: '100%' }}>
                                <Autocomplete
                                    size='small' 
                                    options={sizeItems}
                                    getOptionLabel={(option) => option?.productSize ?? option}
                                    value={requestFormData?.size}
                                    onChange={handleSizeChange}
                                    renderInput={(params) => {
                                        return (<TextField {...params} />)
                                    }}
                                    fullWidth
                                />
                            </FormControl>
                            {formErrors.size && (
                                <FormHelperText id="size-error" error>
                                    {formErrors?.size}
                                </FormHelperText>
                            )}
                        </Grid>
                    </>}

                    { !!requestFormData?.availableQty &&
                        <Grid item lg={6} md={6} sm={6} xs={12}>
                            <InputLabel htmlFor="my-input">Available Qty</InputLabel>
                            <FormControl
                                sx={{ width: '100%' }}
                            >
                                <TextField
                                    autoComplete='off'
                                    size='small'
                                    type="text"
                                    id="my-input"
                                    disabled={true}
                                    value={requestFormData?.availableQty}
                                    aria-describedby="my-helper-text"
                                />
                            </FormControl>
                        </Grid>}

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Quantity <Asterisk>*</Asterisk></InputLabel>
                        <FormControl sx={{ width: '100%' }}>
                            <TextField
                                autoComplete='off'
                                size='small'
                                type="text"
                                id="my-input"
                                value={requestFormData?.quantity}
                                onChange={(e) => {
                                    let value = e.target.value;
                                    const numericValue = Number(value);
                                    const regex = /^[1-9]\d*$/;
                                    regex.test(value)
                                    if (((regex.test(value)) || (value === '')) && requestFormData?.availableQty >= numericValue) {
                                        setRequestFormData({
                                            ...requestFormData,
                                            quantity: value,
                                        })
                                        const updatedErrors = { ...formErrors };
                                        delete updatedErrors.quantity;
                                        setFormErrors(updatedErrors)
                                    }
                                }}
                                aria-describedby="my-helper-text"
                            />
                        </FormControl>
                        {formErrors.quantity && (
                            <FormHelperText id="project-name-error" error>
                                {formErrors?.quantity}
                            </FormHelperText>
                        )}
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Unit</InputLabel>
                        <FormControl
                            sx={{ width: '100%' }}
                        >
                            <TextField
                                autoComplete='off'
                                size='small'
                                type="text"
                                id="my-input"
                                value={requestFormData?.unit}
                                aria-describedby="my-helper-text"
                            />
                        </FormControl>
                    </Grid>

                    <Grid item lg={6} md={6} sm={6} xs={12}>
                        <InputLabel htmlFor="my-input">Remark <Asterisk>*</Asterisk></InputLabel>
                        <FormControl
                            sx={{ width: '100%' }}
                        >
                            <Textarea
                                size='small'
                                type="text"
                                id="my-input"
                                sx={{resize: 'none'}}
                                value={requestFormData?.remark}
                                onChange={(e) => {
                                    let value = e.target.value;
                                    setRequestFormData({
                                        ...requestFormData,
                                        remark: value,
                                    })
                                }}
                                aria-describedby="my-helper-text"
                            />
                        </FormControl>
                    </Grid>

                    <Grid item lg={12} md={6} sm={6} xs={12}>
                        <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={addMaterialForm}>Add</Button>
                        <Button variant='contained' style={{ margin: '10px', float: 'right' }} onClick={() => handleCancelMaterial()}>Cancel</Button>
                    </Grid>
                </Grid>
            }
        </Grid>
     </Form>
    </>
  )
}

export default RequestUpdate;