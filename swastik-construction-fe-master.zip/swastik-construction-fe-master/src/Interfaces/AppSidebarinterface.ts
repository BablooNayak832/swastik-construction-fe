export interface LoginData {
  name: string;
  email: string;
}
