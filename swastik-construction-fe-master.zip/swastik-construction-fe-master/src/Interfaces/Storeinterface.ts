export interface StoreData {
  location(id: number, name: (id: number, name: any, location: any, categoryName: any, category_id: number, subCategoryName: any, sub_category_id: number, quantity: any, typeName: any, brandName: any, addStoreData: any) => unknown, location: any, categoryName: any, category_id: number, subCategoryName: any, sub_category_id: number, quantity: any, typeName: any, brandName: any, addStoreData: any): unknown;
  name(id: number, name: any, location: any, categoryName: any, category_id: number, subCategoryName: any, sub_category_id: number, quantity: any, typeName: any, brandName: any, addStoreData: any): unknown;
  createdByName: string;
  id: number;
  storeName: string;
  storeLocation: string;
  category: number;
  category_id: number;
  subCategory: string;
  sub_category_id: number;
  quantity: number;
  type?: string;
  brand?: string;
}
export interface StoreColumn {
  id: string;
  label: string;
  minWidth?: number;
  align?: string;
  format?: (value: number) => string;
}
export interface createData {
  id?: number | undefined;
  storeName?: string;
  storeLocation?: string;
  category?: string;
  categoryId: number;
  subCategory?: string;
  subCategoryId: number;
  quantity?: number;
  type?: string;
  brand?: string;
  action?: number | React.FC | undefined;
}
