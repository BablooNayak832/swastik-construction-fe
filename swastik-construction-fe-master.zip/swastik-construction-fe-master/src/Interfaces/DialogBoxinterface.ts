export interface PermissionItem {
  id: number;
  moduleId: number;
  isCreate: boolean;
  isView: boolean;
  isEdit: boolean;
  isUpdate: boolean;
  module: {
    id: number;
    name: string;
  };
}

export interface DialogBoxProps {
  isDialogBox: boolean;
  handleCloseDialogBox: () => void;
  getPermisson: {
    id?: number;
    permission?: PermissionItem[];
  };
  permission?: () => void;
}

export interface CheckboxState {
  [key: string]: boolean;
}
