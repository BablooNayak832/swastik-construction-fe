export interface TableColumn {
  id: 'id' | 'name' | 'action' | 'assigned';
  label: string;
  minWidth?: number;
  align?: 'center';
  format?: (value: number) => string;
}

export enum Id {
  ONE = 1,
  TWO = 2,
  THREE = 3,
  FOUR = 4,
}
