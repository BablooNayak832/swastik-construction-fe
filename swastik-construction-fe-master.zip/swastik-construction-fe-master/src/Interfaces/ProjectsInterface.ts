export interface projectColumn {
  id: string;
  label: string;
  minWidth?: string;
  align?: 'right' | 'left' | 'center';
  textAlign?: string;
  format?: (value: number) => string;
}

export interface project {
  id: 3;
  projectName: string;
  location: string;
  startDate: string;
  endDate: null;
}

export interface assignUserType {
  id: number;
  projectId: number;
  userId: number;
  project: project;
  role: string;
}

export interface assignProject {
  id: number;
  projectId: number;
  userId: number;
  project: project;
}

export interface Data {
  id: number;
  projectId: string;
  projectName: string;
  location: string;
  assignproject: assignProject;
  startDate: string;
  endDate: string;
  projectHead?: assignUserType[];
  siteHead?: assignUserType[];
  supervisor?: assignUserType[];
  purchaseManagers?: assignUserType[];
  progress?: string;
  status?: any;
  description?: string;
  verifiedByAdmin: boolean;
}

export interface projectAssignedColumn {
  id: string;
  label: string;
  minWidth?: string;
  align?: 'right' | 'left' | 'center';
  format?: (value: number) => string;
}

export interface ProjectAssignedData {
  id: number;
  projectName: string;
  location: any;
  startDate: string;
  endDate: string;
  // createdById: string;
}
