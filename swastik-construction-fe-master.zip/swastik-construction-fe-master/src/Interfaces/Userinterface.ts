export interface UserData {
  typeId(
    id: number,
    name: string,
    email: string,
    mobileNumber: number,
    name1: string,
    id1: number | undefined,
    name2: any,
    projectNames: any,
    typeId: any
  ): unknown;
  createdByName: string;
  id: number;
  name: string;
  email: string;
  createdAt: string;
  mobileNumber: number;
  role: {
    name: string;
    id?: number;
    key?: string;
  };
  createBy?: string;
  assignProject?: string;
  status: boolean;
}

export interface UserColumn {
  id: string;
  label: string;
  minWidth?: string;
  align?: string | 'right' | 'left' | 'center';

  format?: (value: number) => string;
}
export interface createData {
  id?: number | undefined;
  name?: string;
  email?: string;
  mobileNumber?: number;
  userStatus: boolean;
  role?: string;
  roleId?: string;
  createdeBy?: string;
  assignedProject?: string;
  adminCreate?: string;
  action?: number | React.FC | undefined;
}
