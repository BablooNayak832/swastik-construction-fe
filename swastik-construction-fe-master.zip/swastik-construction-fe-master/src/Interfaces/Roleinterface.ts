export interface RoleColumn {
    id: 'id' | 'Roles' | 'Created_By' | 'Permission' | 'action';
    label: string;
    minWidth?: number;
    align?: 'right';
    format?: (value: number) => string;
  }
  
  export interface RoleData {
    id?: number;
    Roles?: string;
    Created_By?: string;
    Permission?: string;
    action?: any;
  }
  export interface rolesmapdata {
    createdBy: any;
    id: number;
    name: string;
  }