export interface BrandColumn {
    id: string;
    label: string;
    minWidth?: number;
    align?: string;
    format?: (value: number) => string;
  }
  export interface Data {
    id: number;
    name: string;
    image: string;
  } 
  