export interface InventoryColumn {
  id:
    | 'id'
    | 'itemName'
    | 'category'
    | 'subCategory'
    | 'projectName'
    | 'location'
    | 'quantity'
    | 'orderBy'
    | 'deliveredDate'
    | 'vendorName'
    | 'transferredBy'
    | 'availableQuantity';
  label: string;
  minWidth?: number;
  align?: 'right';
  format?: (value: number) => string;
}

export interface Data {
  id: number;
  itemName: string;
  category: string;
  subCategory: string;
  projectName: string;
  quantity: number;
  orderBy: string;
  deliveredDate?: string;
  vendorName?: string;
  transferredBy?: string;
  availableQuantity?: string;
  totalTransferQuantity?: string;
}
