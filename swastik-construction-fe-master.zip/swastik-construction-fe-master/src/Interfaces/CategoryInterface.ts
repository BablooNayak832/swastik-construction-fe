export interface CategoryColumn {
  id: string;
  label: string;
  minWidth?: number;
  align?: 'right';
  filterData?: (a: any, b: any) => any;
  format?: (value: number) => string;
}

export interface Data {
  id: number;
  category: string;
  images: string[];
  type: string;
  createby: string;
  status: boolean;
  parentId: number;
  typeId: number;
}
