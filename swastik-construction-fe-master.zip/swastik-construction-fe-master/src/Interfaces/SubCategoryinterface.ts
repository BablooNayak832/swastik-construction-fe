export interface SubCategoryColumn {
  id: string;
  label: string;
  minWidth?: number;
  align?: 'right' | 'left' | 'center';
  filterData?: (a: any, b: any) => any;
  format?: (value: number) => string;
}

export interface subcategory {
  id: number;
  parentId: number;
  status: boolean;
  category: string;
}

export interface Data {
  id: number;
  category: string;
  img: string[];
  subcategory: subcategory[];
}

export interface projectListDashboard {
  id: string;
  label: string;
  minWidth?: number;
  align?: string;
  format?: (value: number) => string;
}
