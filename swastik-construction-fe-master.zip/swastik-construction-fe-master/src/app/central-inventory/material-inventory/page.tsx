"use client"
import React from 'react';
import CentralInventoryForMaterial from '../../../components/CentralInventory/MaterialCentralInventory';
import withAuth from '../../../hooks/withAuth';

const CentralInventoryMaterial = () => {
    return (
        <>
            <CentralInventoryForMaterial />
        </>
    )
}

export default withAuth(CentralInventoryMaterial, [0, 1, 2, 3, 4, 5])