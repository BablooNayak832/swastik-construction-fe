'use client'
import React from "react";
import withAuth from "../../hooks/withAuth"; 
import { TableContainer } from "@mui/material";
import { Wrapper } from "../../app/styles"; 
import { Blankbox } from  "../../components/Table/styles"; 
import { Heading, HeadingBox, TableBox } from "../../common/styles/Users/styles";
import { MainBox, ContainerMain } from "../../common/styles/Dashboard/styles";
import DailyProgressReportTable from "../../components/Table/DailyProgressReportTable";

const DailyProgressReport = () => { 
     return (
        <>
            <Wrapper> 
                <HeadingBox>
                    <Blankbox>
                        <Heading>Daily Progress Report</Heading>
                    </Blankbox> 
                </HeadingBox> 
                <TableBox>
                    <TableContainer> 
                    <MainBox>
                        <ContainerMain>
                            <DailyProgressReportTable/> 
                        </ContainerMain>
                    </MainBox>
                    </TableContainer>
                </TableBox>
            </Wrapper> 
        </>
    );
}

export default withAuth(DailyProgressReport, [0, 1, 2, 4, 5]);