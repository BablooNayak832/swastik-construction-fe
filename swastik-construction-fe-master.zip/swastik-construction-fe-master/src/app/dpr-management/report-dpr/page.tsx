'use client'
import React from "react";
import withAuth from "../../../hooks/withAuth"; 
import { Button } from "@mui/material";
import { Wrapper } from "../../../app/styles"; 
import { Blankbox } from  "../../../components/Table/styles";  
import { Heading, HeadingBox } from "../../../common/styles/Users/styles";
import {useRouter} from "next/navigation";
import DailyProgressForm from "../../../components/common-form/DailyProgressReportForm";
import {ArrowLeftIcon} from "@mui/x-date-pickers";

const DailyProgressReport = () => {
    const router = useRouter()
     return (
        <>
            <Wrapper>  
                    <HeadingBox>
                        <Blankbox>
                            <Heading>Daily Progress Record</Heading>
                        </Blankbox>
                        <Blankbox>
                            <Button variant="contained" onClick={() => router.back()}>
                            <ArrowLeftIcon /> Go Back
                            </Button>
                        </Blankbox>
                    </HeadingBox> 
                <DailyProgressForm/>
            </Wrapper> 
        </>
    );
}

export default withAuth(DailyProgressReport, [2, 4, 5]);