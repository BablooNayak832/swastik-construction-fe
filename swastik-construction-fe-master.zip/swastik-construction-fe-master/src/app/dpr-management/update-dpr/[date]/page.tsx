'use client'
import React, {useEffect}from "react";
import withAuth from "../../../../hooks/withAuth"; 
import { Button } from "@mui/material";
import { Wrapper } from "../../../styles"; 
import { Blankbox } from  "../../../../components/Table/styles";  
import { Heading, HeadingBox } from "../../../../common/styles/Users/styles";
import {useParams, useRouter} from "next/navigation";
import UpdateDailyProgressForm from "../../../../components/UpdateModal/UpdateDprForm";
import useGet from "../../../../hooks/useGet";
import {useSelector} from "react-redux";
import {ArrowLeftIcon} from "@mui/x-date-pickers";

const UpdateDailyProgressReport = () => {
    const params = useParams<{ tag: string; item: string }>()
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const router = useRouter() 
    const {resData, handleGetData}:any = useGet()

    const getDPRData = async () => { 
        const projectId = selectedProject?.selectedValue?.id;
        const url = `/dpr?projectId=${projectId}&date=${params?.date}`;
        await handleGetData(url);
    };

    useEffect(() => {
       getDPRData()
    }, [params?.date]) 
    
     return (
        <>
            <Wrapper> 
                    <HeadingBox>
                        <Blankbox>
                            <Heading>Daily Progress Record</Heading>
                        </Blankbox>
                        <Blankbox>
                            <Button variant="contained" onClick={() => router.replace('/dpr-management')}>
                            <ArrowLeftIcon /> Go Back
                            </Button>
                        </Blankbox>
                    </HeadingBox> 
                 <UpdateDailyProgressForm data={resData} recordedDate={params?.date}/>
            </Wrapper> 
        </>
    );
}

export default withAuth(UpdateDailyProgressReport, [0, 1, 2, 4, 5]);