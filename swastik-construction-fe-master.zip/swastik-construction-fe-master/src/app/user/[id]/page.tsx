'use client'
import React, { useEffect, useState } from "react";
import withAuth from '../../../hooks/withAuth'
import { Blankbox, Heading, HeadingBox, TableBox } from "../../../common/styles/Users/styles";
import { Box, Button, Grid, List, ListItem, ListItemIcon, ListItemText, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, styled } from "@mui/material";
import useGet from "../../../hooks/useGet"; 
import { useParams, useRouter } from "next/navigation";
import moment from "moment";
import { Wrapper } from "../../../app/styles";
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import CallIcon from '@mui/icons-material/Call';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';
import EmailIcon from '@mui/icons-material/Email';
import ArrowLeftIcon from '@mui/icons-material/ArrowLeft';
import { roles } from "../../../constants/roles";
import { downloadComponentAsPDF } from "../../../utils/pdfUtils";
import { ContainerMain } from "../../../common/styles/Dashboard/styles";
import { particular_user } from "../../../constants/api-routes";

const Demo = styled('div')(({ theme }) => ({
    backgroundColor: theme.palette.background.paper,
}));

const UsersList = () => {
    const params = useParams<{ tag: string; item: string }>()
    const router = useRouter()
    const { resData, handleGetData } = useGet() 
    const [showAssignedProjects, setShowAssignedProjects] = useState(false)

    useEffect(() => {
        const isVisibleProject = ([2, 4, 5].includes(resData?.role?.id))         
        setShowAssignedProjects(isVisibleProject)
    },[resData])
 
    useEffect(() => {
        getDataByUserId();
    }, []);

    const getDataByUserId = async () => {
        const res = await handleGetData(`${particular_user}/${params.id}`)
            .then((data) => {
                return data;
            })
            .catch((error) => {
                return error;
            });
        return res;
    };
   
    let userRole = roles?.filter((fItem: any) => fItem?.id === resData?.role?.id)?.map(item => item?.label).join('');

    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading> User Details</Heading>
                    </Blankbox>
                    
                    <Blankbox> 
                        <Button variant="contained"  onClick={() => router.back()}>
                            <ArrowLeftIcon /> Go Back
                        </Button> 
                        <Button variant='contained' onClick={() => downloadComponentAsPDF('user-detail-layout', 'User')}>
                            Download PDF
                        </Button>
                    </Blankbox>
                </HeadingBox>

                <div id="user-detail-layout">
                    <ContainerMain>
                        <Box
                            height={'100%'}
                            width={'100%'}
                            display="block"
                            gap={4}
                            sx={{ background: 'white' }}
                        > 
                            <Grid container spacing={2}>
                                <Grid item xs={12} md={12} lg={12}> 
                                    <Typography
                                        sx={{ flex: '1 1 100%', margin: '0 15px' }}
                                        variant="h5"
                                        id="tableTitle"
                                        component="div">
                                        Personal information
                                    </Typography>
                                </Grid>
                                <Grid item alignContent={'center'} lg={6} xs={6} md={6}>
                                    <Demo>
                                        <List>
                                            <ListItem>
                                                <ListItemIcon>
                                                    <AccountCircleIcon fontSize="large" />
                                                </ListItemIcon>
                                                <ListItemText primary={"Name"} secondary={resData?.name} />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemIcon>
                                                    <CallIcon />
                                                </ListItemIcon>
                                                <ListItemText primary={"Phone Number"} secondary={resData?.mobileNumber} />
                                            </ListItem>
                                        </List>
                                    </Demo>
                                </Grid>
                                <Grid item xs={12} md={6}>
                                    <Demo>
                                        <List >
                                            <ListItem>
                                                <ListItemIcon>
                                                    <EmailIcon />
                                                </ListItemIcon>
                                                <ListItemText primary={"Email"} secondary={resData?.email} />
                                            </ListItem>
                                            <ListItem>
                                                <ListItemIcon>
                                                    <AssignmentIndIcon />
                                                </ListItemIcon>
                                                <ListItemText primary={"Role"} secondary={userRole} />
                                            </ListItem>
                                        </List>
                                    </Demo>
                                </Grid>
                            </Grid> 
                            { showAssignedProjects ?
                            <TableBox>
                                <Typography
                                    sx={{ flex: '1 1 100%', margin: '15px' }}
                                    variant="h5"
                                    id="tableTitle"
                                    component="div"
                                >
                                    Assigned Projects
                                </Typography>
                                <TableContainer
                                >
                                    <Table sx={{ minWidth: 650 }} size="small" aria-label="a dense table">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>S No.</TableCell>
                                                <TableCell>Project Name</TableCell>
                                                <TableCell align="left">Location</TableCell>
                                                <TableCell align="left">Start Date</TableCell>
                                                <TableCell align="left">End Date</TableCell>
                                                <TableCell align="left">Status</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {resData?.assignProject?.length === 0 ? <>
                                                <TableCell align="center" colSpan={6}>
                                                   No Data Available
                                                </TableCell>

                                            </> : resData?.assignProject?.map((row: any, i: number) => { 
                                                let projectStatus = row?.project?.status;
                                                return (
                                                    <TableRow
                                                        key={row?.id}
                                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                                                    >
                                                        <TableCell align="left" component="th" scope="row"> {i + 1} </TableCell>
                                                        <TableCell align="left" component="th" scope="row">
                                                            {row?.project?.projectName}
                                                        </TableCell>
                                                        <TableCell align="left">{row?.project?.location}</TableCell>
                                                        <TableCell align="left">{moment(row?.project?.startDate).format('MM/DD/YYYY')}</TableCell>
                                                        <TableCell align="left">{row?.project?.endDate === null ? "Not specified" : moment(row?.project?.endDate).format('MM/DD/YYYY')}</TableCell>
                                                        <TableCell align="left">{projectStatus}</TableCell> 
                                                    </TableRow>
                                                )
                                            })}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </TableBox> : null }  
                        </Box>
                    </ContainerMain>
                </div>
            </Wrapper>
        </>
    );
}

export default withAuth(UsersList, [0, 1, 2]);