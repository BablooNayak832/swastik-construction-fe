'use client'
import React from 'react'
import BrandPage from '../../../components/Brand'
import withAuth from '../../../hooks/withAuth'

const Brand = () => {
    return (
        <div>
            <BrandPage />
        </div>
    )
}

export default withAuth(Brand, [0, 1, 3])