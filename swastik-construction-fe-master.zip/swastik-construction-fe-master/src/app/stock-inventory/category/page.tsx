
'use client'
import React, { useEffect, useState } from "react";
import withAuth from '../../../hooks/withAuth';
import TableMain from '../../../components/Table/Table'
import { AppBar, Dialog, DialogActions, DialogContent, TablePagination, Toolbar, Typography } from "@mui/material";
import { Heading, HeadingBox } from "../../../common/styles/Users/styles";
import { Blankbox } from "../../../components/Table/styles";
import CommonDialog from "../../../components/CommonDialog/CommonDialog";
import MainForm from "../../../components/common-form";
import useGet from "../../../hooks/useGet";
import { Wrapper } from "../../../app/styles";
import usePatch from "../../../hooks/usePatch";
import { useAllowedNavigation } from "../../../context/context";
import useDelete from "../../../hooks/useDelete";
import useDownloadExcel from "../../../hooks/downloadExcel";
import { invetoryCategoryColumns } from "../../../constants/table-columns";
import { categoryExcel, category_url } from "../../../constants/api-routes";
import { useSession } from "next-auth/react";
import { Button, IconButton } from "@mui/material";
import { ClearIcon } from "@mui/x-date-pickers";
import axios from "axios";
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import usePost from "src/hooks/usePost";
import UploadDialog from "../../../components/UploadDialog";
import { toast } from "react-toastify";

const Category = () => {
  const { resData, handleGetData, isLoading } = useGet()
  const { resData: getCategoryData, handleGetData: handleGetCategory } = useGet()
  const { setOpen, setRenderData } = useAllowedNavigation()
  const { handleDeleteData } = useDelete()
  const { handleUpdateData } = usePatch()
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const { handleDownloadData } = useDownloadExcel()
  const [queryParams, setQueryParams] = useState({})
  const { data: session } = useSession()
  const [openUploadMaterialDialog, setOpenUploadMaterialDialog] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const { handlePostData } = usePost();

  const handleChangePage = (event: any, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };



  function createProductData(
    id: number,
    sNo: number,
    categoryName: string,
    typeId: any[],
    type: string,
  ): any {
    return {
      id,
      sNo,
      categoryName,
      typeId,
      type
    }
  }

  const categoryData = resData?.map((i: any, index: number) => {
    const catType = i?.type === 1 ? "Material" : "Machinery";
    const cType = i?.type && i?.type?.map((i: any) => i === 1 ? "Material" : "Machinery").join(", ");
    return createProductData(i?.id, index + 1, i.categoryName, i?.type, cType);
  });

  const getCategory = async () => {
    let searchParams = "";
    Object?.entries(queryParams)?.map(([key, value]) => {
      searchParams += `${key}=${value}&`
    })
    const category = await handleGetData(`${category_url}?${searchParams}`);
    return category;
  }

  useEffect(() => {
    getCategory()
  }, [])

  function createData(
    id: number,
    category: string,
    type: any[],
  ): any {
    return { id, category, type };
  }

  const categories = getCategoryData?.map((i: any) => {
    return createData(i?.id, i?.categoryName, i?.type);
  });

  const searchTableData = async (value: any) => {
    setQueryParams((prevValue: any) => {
      return { ...queryParams, ['q']: value }
    })
    setPage(0)
  }

  const filterCategory = async (param: any) => {
    setQueryParams((value: any) => {
      return { ...queryParams, [param.key]: param.value }
    })
    setPage(0)
  }

  const filterMenuOption = [
    { id: 1, menuText: 'Material', fun: () => filterCategory({ key: 'typeId', value: 1 }) },
    { id: 2, menuText: 'Machinery', fun: () => filterCategory({ key: 'typeId', value: 2 }) },
  ]

  const handleUpdateCategory = async (
    e: { preventDefault: () => void },
    payload: any
  ) => {
    e.preventDefault();
    const res = await handleUpdateData(category_url, payload)
      .then((data) => {
        setRenderData(true);
      })
      .catch((error) => {
        alert(`Invalid Credentials, Try Again ${error.message}`);
      });
    setOpen(false);
    getCategory();
    return res;
  };

  const removeCategory = async (mId: any) => {
    const { categoryName } = mId;
    const CATEGORY_DELETE = `${category_url}/${categoryName}`;
    const details = await handleDeleteData(CATEGORY_DELETE);
    getCategory()
    return details;
  };

  const handleExcelExport = async () => {
    let searchParams = "";
    Object.entries(queryParams)?.map(([key, value]) => {
      searchParams += `&${key}=${value}`
    })
    const res = handleDownloadData(`${category_url}?type=xls${searchParams}`, "Category")
    return res;
  }

  const handleUpload = async () => {
    if (!file) {
      toast.warning("Please select a file.");
      return;
    }

    const formData = new FormData();
    formData.append("excelFile", file);
    await handlePostData(categoryExcel, formData)
    await getCategory()
    setOpenUploadMaterialDialog(false)
  };


  const handleFileChange = (event) => {
    setFile(event.target.files?.[0] || null);
  };

  useEffect(() => {
    getCategory()
  }, [queryParams])

  const resetFilter = () => {
    setQueryParams({})
    setPage(0)
  }

  const handleDownload = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Dummy Data');

    // Define columns
    worksheet.columns = [
      { header: 'Head', key: 'productName', width: 20 }
    ];

    // Add dummy row
    worksheet.addRow({
      productName: 'CONCRETE'
    });

    // Generate file and download
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    saveAs(blob, 'dummy_material_format.xlsx');
  };

  return (
    <>
      <Wrapper>
        <HeadingBox>
          <Blankbox>
            <Heading>Category</Heading>
          </Blankbox>
          <Blankbox>
            <Button variant='contained'  onClick={() => setOpenUploadMaterialDialog(true)}>Upload Category</Button>
            <Button variant='contained' sx={{ margin: '0px 2px' }} onClick={handleDownload}>
              Export Category Template
            </Button> 
            {session?.user?.role_id === 1 && 
              <CommonDialog title="Add Category">
                <MainForm
                  data={{
                    categoryName: '',
                    type: [],
                    size: ''
                  }}
                  url={category_url}
                  title={'Add Category'}
                  selectItem={categories}
                  refreshData={getCategory}
                />
              </CommonDialog>
            } 
          </Blankbox>
 
        </HeadingBox>
        <TableMain
          title='Category'
          isLoading={isLoading}
          handleExcelExport={handleExcelExport}
          columns={invetoryCategoryColumns}
          rows={categoryData}
          page={page}
          resetFilter={resetFilter}
          rowsPerPage={rowsPerPage}
          handleChangePage={handleChangePage}
          handleChangeRowsPerPage={handleChangeRowsPerPage}
          refreshTableData={getCategory}
          handleRemoveRow={removeCategory}
          handleUpdateProps={handleUpdateCategory}
          handleAvailableQuantity={() => 'handleAvailableQuantity'}
          searchTableData={searchTableData}
          filterMenuOption={filterMenuOption}
        />
        <TablePagination
          rowsPerPageOptions={[5, 10, 15, 25, 50]}
          component="div"
          count={categoryData?.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />

        <UploadDialog
          open={openUploadMaterialDialog}
          loading={loading}
          file={file}
          setOpen={setOpenUploadMaterialDialog}
          setFile={setFile}
          handleUpload={handleUpload}
          title="Upload Category Excel"
        />

      </Wrapper>
    </>
  );
}

export default withAuth(Category, [0, 1, 3]);