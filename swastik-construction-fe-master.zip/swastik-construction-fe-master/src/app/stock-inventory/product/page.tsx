import React from "react";
import Product from "../../../view/stock-inventory/product/index"
export default async function Page() { 
    return <><Product/></>
}