'use client';
import React from 'react';
import withAuth from '../../../hooks/withAuth';
import SiteInventoryReport from '../../../view/site-inventory/report/SiteInventoryReport'

const Reports = () => { 
  return (
    <>
    <SiteInventoryReport/>
    </>
  );
};

export default withAuth(Reports, [0, 1, 2, 3, 4, 5]);