'use client';
import React, {useEffect, useState} from 'react';
import withAuth from '../../../hooks/withAuth';
import ProgressReport from '../../../components/Table/ProgressReport';
import useGet from '../../../hooks/useGet';
import {Button, Container, FormControl, InputLabel, ListItemText, MenuItem, Select} from '@mui/material';
import useDownloadExcel from '../../../hooks/downloadExcel';
import {Wrapper} from '../../../app/styles';
import {Heading, HeadingBox} from '../../../common/styles/Users/styles';
import {Blankbox} from '../../../components/Table/styles' 
import {useSelector} from 'react-redux';
import { FilterButtonBox} from '../../../common/styles/Dashboard/styles';
import {MenuProps} from '../../../constants/table-columns';
import {useSession} from 'next-auth/react';
import {projects_url} from '../../../constants/api-routes';

function getWeekStartAndEnd(date:any) {
  date = new Date(date); 
  // Get the day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
  const dayOfWeek = date.getDay(); 
  const startDate = new Date(date);
  startDate.setDate(date.getDate() - dayOfWeek); 
  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + 6);

  const formatDate = (date:any) => {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
  };

  return {
      start: formatDate(startDate),
      end: formatDate(endDate)
  };
}
 
const DailyProgressReport = () => {
    const {resData, handleGetData}:any = useGet()  
    const { handleDownloadData } = useDownloadExcel()  
    const [queryParams, setQueryParams] = useState({})
    const selectedProjectData = useSelector((state: any) => state?.selectedProject);
    const selectedProject = selectedProjectData?.selectedValue?.id;
    const currentDate:any = new Date()  
    const { data: session }:any = useSession()
    const [selectedFilterProject, setSelectedFilterProject] = React.useState<any>('')
    const [selectedProjectItems, setSelectedProjectItems] = React.useState<any>(null)
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet() 
    const [projectId , setProjectId] = React.useState(null)
    const project = [0, 1].includes(session?.user?.role_id) ? projectId : selectedProject; 
    let projectArray:any = []
   
    const getDPRData = async() => {  
      let searchParam = ''; 
      Object?.entries(queryParams)?.map(([key, value]) => {
        searchParam += `${key}=${value}&`
      })   
      const url = `/dpr/dpr-report?projectId=${project}&${searchParam}`  
      const res = await handleGetData(url) 
      return res;
   }

    const getProjectData = async () => {
      const res = await handleGetProjectData(`${projects_url}?page=1&limit=100`);
      return res;
    }

    const handleExcelExport = async () => { 
        let searchParam = ''; 
        Object?.entries(queryParams)?.map(([key, value]) => {
          if(key === 'year'){
            key = 'yearForMonth'
          }
          searchParam += `${key}=${value}&`
        })
        const res = await handleDownloadData(`/dpr?type=xls&projectId=${project}&${searchParam}`, "DPR")
        return res;
    }

    const handleWeeklyFilter = (startDate:any, endDate:any) => {
      setQueryParams(() => {
        return { ['startDate'] : startDate , ['endDate'] : endDate } 
      })  
    }

    const handleFilterByMonth = (month:any) => {
      setQueryParams(() => {
        return {['month'] : month}
      })  
    }

    const handleFilterByYear = (year:string) => {
      setQueryParams(() => {
        return {['year'] : year}
      })
    }
   
    const filterByProject = (param:any) => { 
      setProjectId(param) 
    }
 
    resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
      return projectArray.push({ id: Item?.id, name: Item?.projectName })
    });

    useEffect(() => {
      const date = getWeekStartAndEnd(currentDate) 
      setQueryParams(() => {
        return { ['startDate'] : date?.start , ['endDate'] : date?.end } 
      }) 
      getDPRData()
      getProjectData()
    },[]) 

    React.useEffect(() => { 
      setProjectId(projectArray[0]?.id) 
      setSelectedFilterProject(projectArray[0]?.id)
      setSelectedProjectItems(projectArray)
    }, [resProjectData?.items])
    
    useEffect(() => {
      getDPRData()
    },[selectedProject])

    useEffect(() => {
      getDPRData()
    }, [queryParams, selectedProject, projectId]) 
    
  return (
    <> 
      <Wrapper>
          <Container>
              <HeadingBox>
                  <Blankbox>
                      <Heading>Daily Progress Report</Heading>
                  </Blankbox>
                  <Blankbox>
                      { ( [0, 1]?.includes(session?.user?.role_id))  && <> 
                      <FilterButtonBox>
                        <FormControl sx={{width:"200px",borderRadius: '12px',height:"42px",border:"1px solid #66666636"}}>
                        <InputLabel  id="demo-simple-select-label">
                          Select Project 
                        </InputLabel>
                          <Select  
                            id="demo-simple-select"
                            label="Select Project"
                            sx={{
                              '.MuiOutlinedInput-notchedOutline':{
                                border: 'none !important',
                              },
                              '.MuiSelect-outlined':{
                                lineHeight: '10px',
                                color: 'grey', 
                                },
                              '.MuiSelect-icon':{
                                top:'8px'
                              }
                            }} 
                            value={selectedFilterProject}    
                            onChange={(event: any) => { 
                              const { target: { value }} = event;  
                              setSelectedFilterProject( value )
                              filterByProject(value)    
                            }}  
                            renderValue={(selected: any[]) => { 
                              return selectedProjectItems?.filter(item => selected == item?.id)?.map(item => item?.name)?.join(','); 
                            }}
                            MenuProps={MenuProps}
                            > 
                            { selectedProjectItems?.map((item: any) => { 
                            return (
                              <MenuItem key={item?.id} value={item?.id}> 
                                <ListItemText primary={item?.name} />
                              </MenuItem>
                            );
                            })}
                          </Select>  
                        </FormControl> 
                      </FilterButtonBox>
                        </> }
                  </Blankbox>
                  <Blankbox> 
                      <Button variant='contained' onClick={handleExcelExport}>Download Excel</Button>
                  </Blankbox>
              </HeadingBox>
              <ProgressReport data={resData} handleFilter={handleWeeklyFilter} filterByMonth={handleFilterByMonth} filterByYear={handleFilterByYear}/>  
          </Container>
     </Wrapper>
  
    </>
  );
};

export default withAuth(DailyProgressReport, [0, 1, 2, 4, 5]);
