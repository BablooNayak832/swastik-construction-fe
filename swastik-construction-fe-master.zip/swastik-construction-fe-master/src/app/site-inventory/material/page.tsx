'use client'
import React from 'react'
import withAuth from '../../../hooks/withAuth'
import dynamic from 'next/dynamic';
const SiteInventoryPage = dynamic(() => import('../../../components/SiteInventory/MaterialSiteInventory'));

const MaterialInventory = () => {
    return (
        <>
            <SiteInventoryPage />
        </>
    )
}

export default withAuth(MaterialInventory, [0, 1, 2, 3, 4, 5])