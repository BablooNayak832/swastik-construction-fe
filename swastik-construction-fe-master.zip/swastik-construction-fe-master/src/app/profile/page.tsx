'use client';

import React from 'react';
import withAuth from '../../hooks/withAuth';
import { Wrapper } from '.././styles';
import dynamic from 'next/dynamic';
const ProfilePage = dynamic(() => import('../../components/profile'));

function Profile() {
    return (
        <>
            <Wrapper>
                <ProfilePage />
            </Wrapper>
        </>

    );
}
export default withAuth(Profile, [0, 1, 2, 3, 4, 5]);