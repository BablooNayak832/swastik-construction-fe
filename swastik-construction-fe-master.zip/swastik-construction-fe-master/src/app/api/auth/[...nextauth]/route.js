import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { baseUrl, login } from "../../../../constants/api-routes";

const handler = NextAuth({
  // Configure one or more authentication providers
  secret: process.env.NEXTAUTH_SECRET,

  providers: [
    CredentialsProvider({
      // The name to display on the sign in form (e.g. "Sign in with...")
      id: "credentials",
      name: "Credentials",
      // `credentials` is used to generate a form on the sign in page.
      // You can specify which fields should be submitted, by adding keys to the `credentials` object.
      // e.g. domain, username, password, 2FA token, etc.
      // You can pass any HTML attribute to the <input> tag through the object.
      credentials: {
        username: { label: "username", type: "email" },
        password: { label: "Password", type: "password" },
        firebaseToken: { label: "firebaseToken", type: "string" },
      },
      async authorize(credentials, req) {
        const payload = {
          username: credentials?.username,
          password: credentials?.password,
          firebaseToken: credentials?.firebaseToken
        };
        
        const res = await fetch(`${baseUrl + login}`, {
          method: "POST",
          body: JSON.stringify(payload),
          headers: {
            "Content-Type": "application/json",
          },
        });
        
        const user = await res.json();
        console.log("user-------->>>", user);
        let userRes = user;
        if (res.status !== 200) {
          if (user.error === "MESSAGES.USER.INVALID_LOGIN") {
            throw new Error(user.error);
          } else if (
            user.MESSAGE ===
            "MOBILE_NUMBER_NOT_REGISTERED_OR_EMAIL_NOT_REGISTERED"
          ) {
            throw new Error(user.MESSAGE);
          } else if (user.MESSAGE === "CAN_NOT_LOGIN_THIS_USER") {
            throw new Error(user.MESSAGE);
          }
        }

        if (userRes) {
          return { ...userRes };
        }

        return null;
      },
    }),
  ],

  callbacks: {
    async jwt({ token, user, account }) {
      if (account && user) { 
        return {
          ...token,
          user: user.token,
          name: user.full_name,
          mobile: user.mobile_number,
          role: user.roleName,
          role_id: user.role_id,
        };
      }
      return token;
    },

    async session({ session, token }) {
      session.user.accessToken = token.user;
      session.user.id = token.sub;
      session.user.mobile = token.mobile;
      session.user.role = token.role;
      session.user.role_id = token.role_id; 
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
  },
});
export { handler as GET, handler as POST };
