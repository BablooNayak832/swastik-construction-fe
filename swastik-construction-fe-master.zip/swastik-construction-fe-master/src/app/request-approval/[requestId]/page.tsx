'use client'
import { useParams, useRouter } from 'next/navigation';
import React, { useCallback, useEffect, useState } from 'react'
import useGet from '../../../hooks/useGet';
import withAuth from '../../../hooks/withAuth';
import { AppBar, Dialog, DialogActions, DialogContent, Grid, List, ListItem, ListItemText, TextField, Toolbar, Typography } from "@mui/material";
import { Wrapper } from "../../../app/styles"
import { ContainerMain, MainBox } from '../../../../src/common/styles/Dashboard/styles';
import { Button } from '@mui/material';
import moment from 'moment';
import { Heading, HeadingBox } from '../../../common/styles/Users/styles';
import { Blankbox } from '../../../components/Table/styles';
import usePatch from '../../../hooks/usePatch';
import MaterialRequestTable from '../../../components/Table/RequestMaterialTable'; 
import { downloadComponentAsPDF } from 'src/utils/pdfUtils';
import getRequestAPI from 'src/services/getRequest';
import { materialRequestUpdate, material_request_data, material_request_item_delete_url, notification_url, return_request, return_request_url } from '../../../constants/api-routes';
import {useSession} from 'next-auth/react'; 
import useDelete from 'src/hooks/useDelete';
import { formatString, stringCapitalization } from 'src/utils/formatString';
import { ArrowLeftIcon, ClearIcon } from '@mui/x-date-pickers'; 
import { theme } from 'src/common/styles/theme';

function createRequestItem(
    id: number,
    machineryOrPrductId: number,
    machineryOrPrductName: string, 
    itemName?: string,
    specification: string,
    size: number,
    unit: string,
    quantity: number,
    remark: string,
    siteAvailableQuantity?:string,
    typeId: number,
    categoryId: number,
    projectId: number,
    reqId?:string, 
): any {
    return {
        id,
        machineryOrPrductId,
        machineryOrPrductName,
        itemName,
        specification,
        size,
        unit,
        quantity,
        remark,
        siteAvailableQuantity,
        typeId,
        categoryId,
        projectId,
        reqId, 
    }
}

 
function createRequestData(
    reqId?: number,
    requestDate?: string,
    productName?: string,
    location?: string,
    type?: string,
    categoryName?: string,
    projectId?: number,
    projectName?: string,
    quantity?: number,
    approveStatus?: string,
    senderName?: string,
    items?: [],
    approvedBy?: string,
): any {
    return {
        reqId,
        requestDate,
        productName,
        location,
        type,
        categoryName,
        projectId,
        projectName,
        quantity,
        approveStatus,
        senderName,
        items,
        approvedBy
    }
}

const RequestApproval = () => {
    let searchParam = new URLSearchParams(document.location.search);
    let isView = searchParam.get("isView");
    // let isApproved = searchParam.get("isApproved")
    const Router = useRouter()
    const { data: session } = useSession()
    const params = useParams<{ tag: string; item: string }>()
    const { resData, handleGetData } = useGet()
    const { handleUpdateData } = usePatch()
    const { handleUpdateData: updateQuantity } = usePatch()
    const [dataArray, setDataArray] = useState<any>({});
    const [dataReturnReq, setDataReturnReq] = useState<any>({});
    const [editingId, setEditingId] = useState(null);
    const [editedValue, setEditedValue] = useState({ quantity: '' , remark:''});
    const [returnRequestData, setReturnRequestData] = useState<any>([])
    const { handleDeleteData } = useDelete()
    const [remark, setRemark] = useState("")
    const [openRemarkModel, setOpenRemarkModel] = useState(false) 
    
    const getRequestData = () => {
        const res = handleGetData(`${material_request_data}/${params?.requestId}`)
        return res;
    }

    const getReturnRequestData = () => {
        const res = getRequestAPI(`${return_request_url}/${params?.requestId}`).then((res) => {
            setReturnRequestData(res?.data)
        }).catch((err: any) => err)
        return res;
    }

    useEffect(() => {
        getRequestData()
        getReturnRequestData()
    }, [])

    let itemId, requestDate: any, materialId: any, siteAvailableQuantity:any, requestId: any,itemName: any, machineryOrPrductName: any, itemSpecification: any, projectName: any, projectId: any, location: any, materialType: any, categoryId:number ,categoryName: any, quantity: any, approveStatus: any, senderName: any, createitems, itemSize, itemUnit, approvedBy:string;
    let materialItems: any = []

    useEffect(() => {
        resData?.map((i: any, idx: any) => {
            requestId = i?.request 
            i?.items && i?.items?.map((request: any) => { 
                approvedBy = request?.acceptedby?.name; 
                itemId = request?.id;
                requestDate = moment(request?.createdAt).format('DD/MM/YYYY');
                projectId = request.projectDetails?.id;
                projectName = request?.projectDetails?.projectName;
                location = request?.projectDetails?.location;
                materialType = request.typeId === 1 ? "Material" : "Machinery";
                categoryName = (request?.productDetails !== null) ? (request?.productDetails?.category?.categoryName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.categoryDetails?.categoryName) : 'Null';
                materialId = request?.materialId !== undefined ? request?.materialId : request?.machineryOrPrductId;
                machineryOrPrductName = (request?.productDetails !== null) ? (request?.productDetails?.productName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.machineryName) : 'Null';
                itemName = (request?.productDetails !== null) ? (request?.productDetails?.itemName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.itemName) : 'Null';
                itemSpecification = (request?.productDetails !== null) ? (request?.productDetails?.specification) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.specification) : 'Null';
                itemSize = (request?.productDetails !== null) ? (request?.productDetails?.size) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.size) : 'Null';
                itemUnit = (request?.productDetails !== null) ? (request?.productDetails?.unit) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.unit) : 'Null';
                quantity = request?.quantity;
                approveStatus = request?.status;
                senderName = request?.requesterDetails?.name;
                createitems = createRequestItem(itemId, materialId, machineryOrPrductName, itemName, itemSpecification, itemSize, itemUnit, request?.quantity, request?.remark, siteAvailableQuantity ,request?.typeId, request?.productDetails?.categoryId, projectId);
                materialItems.push(createitems);
            })
            const requestData = createRequestData(i?.request, requestDate, machineryOrPrductName, location, materialType, categoryName, projectId, projectName, quantity, approveStatus, senderName, materialItems, approvedBy);
            setDataArray(requestData);
            return requestData;
        });
    }, [resData]) 

    useEffect(() => {
        returnRequestData && returnRequestData?.map((requestData: any) => {   
            requestId = requestData?.returnRequest
            requestData?.items && requestData?.items?.map((request: any) => {
                approvedBy = request?.acceptedby?.name; 
                itemId = request?.id;
                requestDate = moment(request?.createdAt).format('DD/MM/YYYY');
                projectId = request?.projectId;
                projectName = request?.projectDetails?.projectName;
                location = request?.projectDetails?.location;
                materialType = request.typeId === 1 ? "Material" : "Machinery";
                categoryId = (request?.materialDetails !== null) ? (request?.materialDetails?.categoryId) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.categoryDetails?.categoryId) : 'Null';
                categoryName = (request?.materialDetails !== null) ? (request?.materialDetails?.category?.categoryName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.categoryDetails?.categoryName) : 'Null';
                machineryOrPrductName = request?.materialDetails?.productName;
                itemName = request?.materialDetails?.itemName;
                itemSpecification = (request?.materialDetails?.specification !== '') ? request?.materialDetails?.specification : "_";
                itemSize = (request?.materialDetails?.size !== '') ? (request?.materialDetails?.size) : '_';
                itemUnit = request?.materialDetails?.unit;
                quantity = request?.quantity;
                approveStatus = request?.status;
                senderName = request?.Sender?.name;
                siteAvailableQuantity = request?.siteAvailableQuantity;
                createitems = createRequestItem(itemId, request?.materialId, machineryOrPrductName,itemName ,itemSpecification, itemSize, itemUnit, request?.quantity, request?.remark, siteAvailableQuantity, 1, categoryId, projectId, requestId);
                materialItems.push(createitems);
            })
            const returnRequestData = createRequestData(requestData?.returnRequest
               , requestDate, machineryOrPrductName, location, materialType, categoryName, projectId, projectName, quantity, approveStatus, senderName, materialItems, approvedBy);
            setDataReturnReq(returnRequestData);    
            return returnRequestData;
        })
    }, [returnRequestData])

    const checkRemark = (isAccept:boolean) => {
        let error:any = {}
        if(isAccept === false && !remark){
            error.remark = true;
        }else {
            delete error.remark;
        }
        return !Object.keys(error)?.length;
    }

    const submitRequestApproval = async (id: number, isAccept: boolean, type: string ) => {
        let payload = {
            "requestId": id,
            "isAccept": isAccept,
        }
        if(!isAccept){
            payload.remark = remark;
        }
        const isValid = checkRemark(isAccept)
        if (isValid) { 
            const res = await handleUpdateData(notification_url, payload)
            getRequestData()
            setOpenRemarkModel(false)
            return res;
        } 
    }

    const submitReturnRequestApproval = async (id: number, isAccept: boolean, type: string) => {
        const payload = {
            "returnRequestId": id,
            "isAccept": isAccept
        }
          if(!isAccept){
            payload.remark = remark;
        }
        const isValid = checkRemark(isAccept)
        if (isValid) { 
            const res = await handleUpdateData(notification_url, payload) 
            getReturnRequestData()
            setOpenRemarkModel(false)
            return res;
        }
    }

    const handleSave = (index: any, row: any) => { 
        let copyData = [...dataArray?.items]
        copyData[index] = { ...copyData[index], machineryOrPrductId: row?.machineryOrPrductId, ['quantity']: editedValue?.quantity, ['remark'] : editedValue?.remark, ['projectId']: dataArray?.projectId, itemName: row?.itemName, specification: row?.specification, size: row?.size}
        setDataArray({ ...dataArray, items: copyData })
        updateQuantity(materialRequestUpdate, copyData)
        setEditingId(null);
    }; 

    const handleReturnReqSave = (index: any, row: any) => {
        let copyData = [...dataReturnReq?.items]
        copyData[index] = { ...copyData[index],materialId: row?.materialId , ['quantity']: editedValue?.quantity, ['projectId']: dataReturnReq?.projectId, ['remark']: editedValue?.remark }
        setDataReturnReq({ ...dataReturnReq, items: copyData })
        let payload: any = [] 

        copyData.map((item) => {
            payload.push({
                id: item?.id,
                projectId: item?.projectId,
                materialId: item?.materialId ?? item?.machineryOrPrductId,
                quantity: item?.quantity,
                remark: item?.remark
            })
        })
        updateQuantity(return_request, payload)
        setEditingId(null);
    };

    const editMaterial = (id: any, value: any) => {
        setEditingId(id);
        setEditedValue(value);
    }

    const handleChange = (e: any, row:any) => {
        const value = e.target.value;  
        const key = e.target.name
        const regex = /^[1-9]\d*$/; 
        if(key === 'quantity'){
            if ((value === '') ||( regex.test(value))){
                const newQuantity = parseInt(value ); 
                setEditedValue(prevState => ({
                    ...prevState,
                    [e.target.name]: newQuantity
                }));
            } 
        }else{
            setEditedValue(prevState => ({
                ...prevState,
                [e.target.name]: value
            }));
        }
    } 
    
    const handleChangeReturnReq = (e:any ,row:any) => {  
        const value = e.target.value;
        const key = e.target.name;
        if (key === 'quantity') {
            if (value === '' || /^[0-9]*$/.test(value)) {
                const newQuantity = value === '' ? '' : parseInt(value, 10); 
                // Check if the value is within the allowed range only when it's not empty
                if (newQuantity === '' || newQuantity <= row?.siteAvailableQuantity) {
                    setEditedValue(prevState => ({
                        ...prevState,
                        [key]: newQuantity
                    }));
                }
            }
        } else {
            setEditedValue(prevState => ({
                ...prevState,
                [key]: value
            }));
        }
    } 

    const removeMaterial = useCallback(async(id:number, mId:number) => { 
        const res = await handleDeleteData(`${material_request_item_delete_url}/${mId}`);
        if(res?.success === true) { 
            setDataArray((prevData: any) => {
                const newData = prevData?.items?.filter((_: any, index: number) => index != id); 
                return { ...prevData, items: newData };
            }); 
        } 
    }, [dataArray]);   

    const handleRejection = () => {
      setRemark('');
      setOpenRemarkModel(true) 
    }

    const handleReject = () => { 
        if(Object.keys(dataReturnReq).length !== 0){ 
            submitReturnRequestApproval(dataReturnReq?.reqId, false, 'Material')
        }
        if(Object.keys(dataArray).length !== 0){ 
            submitRequestApproval(dataArray?.reqId, false, dataArray?.type);  
        }
    } 
 
    return (
        <>
            <Wrapper> 
                <HeadingBox>
                    <Blankbox>
                    <Heading>Material Request</Heading>  
                    </Blankbox>
                    
                    <Blankbox> 
                       {(!!isView || approveStatus !== "pending") && 
                        <Button sx={{margin: '0 6px'}} variant="contained"  onClick={() => Router.back()}>
                            <ArrowLeftIcon /> Go Back
                        </Button> 
                        }
                        {( !!isView || dataArray?.approveStatus !== 'pending') && 
                            <Button variant='contained' onClick={() => downloadComponentAsPDF('request-approval-layout', 'RequestApproval')}>
                                    Download PDF
                            </Button>}
                    </Blankbox>
                </HeadingBox>
                <div id="request-approval-layout">
                    <ContainerMain >
                        <MainBox>
                            <>
                                <Grid container spacing={2}>
                                    <Grid item lg={12} xs={12} md={12}>  
                                       <Typography
                                            sx={{ flex: '1 100%', margin: '0 10px' }}
                                            variant="h5"
                                            id="tableTitle"
                                            component="div">Material Request Info.</Typography>  
                                    </Grid>
                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Project Name</Typography>} secondary={!!dataArray?.projectName ? dataArray?.projectName : dataReturnReq?.projectName} />
                                            </ListItem>
                                        </List>
                                    </Grid>

                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Location</Typography>} secondary={!!dataArray?.location ? dataArray?.location : dataReturnReq?.location} />
                                            </ListItem>
                                        </List>
                                    </Grid>

                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Request No.</Typography>} secondary={!!dataArray?.reqId ? dataArray?.reqId : dataReturnReq?.reqId} />
                                            </ListItem>
                                        </List>
                                    </Grid>

                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Requested Date</Typography>} secondary={!!dataArray?.requestDate ? dataArray?.requestDate : dataReturnReq?.requestDate} />
                                            </ListItem>
                                        </List>
                                    </Grid>

                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Sender Name</Typography>} secondary={ !!dataArray?.senderName ? dataArray?.senderName : dataReturnReq?.senderName} />
                                            </ListItem>
                                        </List>
                                    </Grid> 

                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Status</Typography>} secondary={ !!dataArray?.approveStatus ? stringCapitalization(dataArray?.approveStatus) : stringCapitalization(dataReturnReq?.approveStatus)} />
                                            </ListItem>
                                        </List>
                                    </Grid>  

                                    <Grid item lg={3} xs={3} md={3}>
                                        <List>
                                            <ListItem>
                                                <ListItemText primary={<Typography fontWeight="bold">Approved By</Typography>} secondary={ !!dataArray?.approvedBy ? formatString(dataArray?.approvedBy) ?? "_" : formatString(dataReturnReq?.approvedBy) ?? "_"} />
                                            </ListItem>
                                        </List>
                                    </Grid>  

                                    {dataArray?.items && <Grid item lg={12} md={12} sm={12} xs={12}>
                                        <MaterialRequestTable
                                            requestType={"Request"}
                                            isView={isView}
                                            isApproved={dataArray?.approveStatus} //{isApproved}
                                            title={"Material Request"}
                                            data={dataArray?.items}
                                            handleSave={handleSave}
                                            editingId={editingId}
                                            editMaterial={editMaterial}
                                            handleChange={handleChange}
                                            editedValue={editedValue}
                                            fetchData={getRequestData}
                                            removeMaterial={removeMaterial}
                                        />
                                    </Grid>}

                                    {
                                        dataReturnReq?.items &&
                                        <Grid item lg={12} md={12} sm={12} xs={12}>
                                            <MaterialRequestTable
                                                requestType={"Return Request"}
                                                isView={isView}
                                                isApproved={dataReturnReq?.approveStatus} //{isApproved}
                                                title={"Return Request"}
                                                data={dataReturnReq?.items}
                                                handleSave={handleReturnReqSave}
                                                editingId={editingId}
                                                editMaterial={editMaterial}
                                                handleChange={handleChangeReturnReq}
                                                editedValue={editedValue}
                                                fetchData={getReturnRequestData}
                                            />
                                        </Grid>
                                    }

                                    { (dataArray?.approveStatus === 'pending') && (!!Object.keys(dataArray)?.length && !isView && approveStatus !== "pending" && session?.user?.role_id === 2) && <Grid item lg={12} xs={12} md={12}>
                                        <Button style={{ float: 'right', margin: '0 10px', background: 'green', color: "white" }} onClick={() => submitRequestApproval(dataArray?.reqId, true, dataArray?.type)} variant='outlined'>Approve</Button>
                                        <Button style={{ float: 'right', margin: '0 10px' }}
                                        onClick={handleRejection}
                                        variant='contained'>Reject</Button>
                                    </Grid>} 
       
                                    {
                                    ((dataReturnReq?.approveStatus === 'pending' )) &&
                                    (!!Object.keys(dataReturnReq)?.length && !isView && approveStatus !== "pending" && session?.user?.role_id === 2) && 
                                    <Grid item lg={12} xs={12} md={12}>
                                        <Button style={{ float: 'right', margin: '0 10px', background: 'green', color: "white" }} onClick={() => submitReturnRequestApproval(dataReturnReq?.reqId, true, 'Material')} variant='outlined'>Approve</Button>
                                        <Button style={{ float: 'right', margin: '0 10px' }} onClick={handleRejection} variant='contained'>Reject</Button>
                                    </Grid>}
                                </Grid>
                            </>
                        </MainBox> 
                    </ContainerMain>
                </div> 
            </Wrapper>
            {
                openRemarkModel && 
                <>
                 <Dialog
                    fullWidth
                    maxWidth='xs' 
                    open={openRemarkModel}>
                    <AppBar sx={{ position: 'relative', background: theme.colors.Red }}> 
                        <Toolbar>
                            <Typography sx={{ flex: 1 }} variant="h6" component="div">
                                Reject Request
                            </Typography>
                            <DialogActions>
                            <ClearIcon onClick={() => setOpenRemarkModel(false)} />
                            </DialogActions>
                        </Toolbar> 
                    </AppBar>  
                    <DialogContent>
                        <TextField
                            label="Remark"
                            fullWidth
                            multiline
                            rows={2}
                            value={remark}
                            onChange={(e) => setRemark(e.target.value)}
                        />
                        {!remark && <Typography color={"red"} sx={{fontSize: '14px'}}>Remark is required.</Typography>}
                        <DialogActions>
                            <Button size='small' onClick={() => setOpenRemarkModel(false)} variant='outlined' color="primary">Cancel</Button>
                            <Button size='small' sx={{color:'white !important'}} onClick={handleReject} disabled={!remark} variant="contained">Reject</Button>
                        </DialogActions>
                    </DialogContent> 
                    </Dialog>
                </>
            }
        </>
    )
}

export default withAuth(RequestApproval, [0, 1, 2, 3, 4, 5]) 