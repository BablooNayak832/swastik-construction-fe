'use client';

import React, { useState } from 'react';
import styled from 'styled-components';

const PageWrapper = styled.div`
  background-color: #eef0f3;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 40px 20px;
`;

const Box = styled.div`
  background-color: #fff;
  padding: 40px;
  border-radius: 12px;
  width: 100%;
  max-width: 500px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.08);
  text-align: center;
`;

const Title = styled.h1`
  font-size: 1.8rem;
  font-weight: 600;
  color: #444;
  margin-bottom: 16px;
`;

const Description = styled.p`
  font-size: 1rem;
  color: #666;
  margin-bottom: 24px;
`;

const ErrorMessage = styled.p`
  font-size: 14px;
  color: red;
  position: relative;
  right: ${(props) => (props.$type === 'email' ? '140px' : '120px')};
  bottom: 16px;
`;

const Input = styled.input`
  width: 100%;
  padding: 12px;
  font-size: 1rem;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-bottom: 20px;

  &:focus {
    outline: none;
    border-color: #ff3b30;
  }
`;

const DeleteButton = styled.button`
  background-color: #ff3b30;
  color: white;
  padding: 12px 24px;
  border: none;
  font-size: 1rem;
  border-radius: 8px;
  cursor: pointer;

  &:hover {
    background-color: #e63228;
  }

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const Message = styled.p.attrs(() => ({
  role: 'alert',
}))`
  margin-top: 20px;
  font-size: 1rem;
  color: ${props => (props.$success ? 'green' : 'red')};
`;

export default function DeleteAccount() {
  const [emailOrNumber, setEmailOrNumber] = useState('');
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState(false);

  const validateInput = (input) => {
    if (!input) return 'Input is required';

    const startsWithNumber = /^\d/.test(input);

    if (startsWithNumber) {
      const numeric = input.replace(/\D/g, '');
      if (numeric.length !== 10) {
        return 'Number must be 10 digits';
      }
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(input)) {
        return 'Invalid email format';
      }
    }

    return '';
  };

  const getErrorType = () => {
    if (message.includes('email')) return 'email';
    if (message.includes('Number')) return 'number';
    return '';
  };

  const handleDelete = async () => {
    const validationError = validateInput(emailOrNumber);
    if (validationError) {
      setSuccess(false);
      setMessage(validationError);
      return;
    }

    try {
      const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
      const endpoint = process.env.NEXT_PUBLIC_DELETE_ACCOUNT_URL;
      const url = `${baseUrl}${endpoint}/${emailOrNumber}`;

      const res = await fetch(url, {
        method: 'DELETE',
      });

      const data = await res.json();
      setSuccess(res.ok);
      setMessage(data.message || 'Something went wrong.');
    } catch (error) {
      setSuccess(false);
      setMessage('Something went wrong.');
    }
  };

  return (
    <PageWrapper>
      <Box>
        <Title>Delete Your Account</Title>
        <Description>
          Enter your email address or phone number below and confirm to permanently delete your account.
        </Description>

        <Input
          type="text"
          placeholder="Enter your email address or phone number"
          value={emailOrNumber}
          onChange={e => {
            const input = e.target.value;
            const startsWithNumber = /^\d/.test(input);

            if (startsWithNumber) {
              const digitsOnly = input.replace(/\D/g, '');
              if (digitsOnly.length <= 10) {
                setEmailOrNumber(digitsOnly);
              }
            } else {
              setEmailOrNumber(input);
            }
          }}
        />

        {message && (
          <ErrorMessage $success={success} $type={getErrorType()}>
            {message}
          </ErrorMessage>
        )}

        <DeleteButton onClick={handleDelete} disabled={!emailOrNumber}>
          Delete Account
        </DeleteButton>
      </Box>
    </PageWrapper>
  );
}
