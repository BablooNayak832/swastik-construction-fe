'use client'
import React, { useEffect, useState } from 'react' 
import withAuth from '../../../../../hooks/withAuth' 
import useGet from '../../../../../hooks/useGet'
import { MainFormLayout } from '../../../../../components/Modal/styles'
import { CardContent, Typography } from '@mui/material'
import { MainConteiner } from '../../../../../common/styles/common-form/styles'
import { category_url, material_request_data } from '../../../../../constants/api-routes'
import { useParams } from 'next/navigation'
import RequestUpdate from 'src/view/material-request-update/RequestUpdate'
import {Heading, HeadingBox} from 'src/common/styles/Users/styles'
import {Blankbox} from 'src/components/Table/styles'

function createRequestData(
  sNo: any,
  reqId: string,
  productName: any,
  location: any,
  type: any,
  categoryName: any,
  projectId: any,
  projectName: any,
  quantity: any,
  approveStatus: any,
  senderName: any,
  items: any,
  requestedDate: any,
  createdById: any,
): any {
  return { 
    sNo,
    reqId,
    productName,
    location,
    type,
    categoryName,
    projectId,
    projectName,
    quantity,
    approveStatus,
    senderName,
    items,
    requestedDate,
    createdById, 
  }
}

const MaterialReqForm = () => {
  const params = useParams<{ tag: string; item: string }>()
  const {resData ,handleGetData} = useGet()
  const [updateData, setUpdateData] = useState({})
  const {resData: catItems, handleGetData:handleGetCatItems} = useGet()

  const getCategory = async () => {
      const category = await handleGetCatItems(`${category_url}?type=1`);
      return category;
  }
  
  const getRequestData = () => {
      const res = handleGetData(`${material_request_data}/${params?.reqId}`)
      return res;
  }

  useEffect(() => {
    getRequestData()
    getCategory()
  }, [])
  
  let obj :any= {}, sNo:number, productName:string, location: string, categoryName:string, projectId:number, projectName:string ,quantity: number, status:string, requesterName:string, createdAt:string, createdById:number, items:any = [];
  useEffect(() => { 
        if(!!resData?.length ){
          resData?.map((item:any, index:number) => {
            const reqId = item?.request;
            obj = item?.items?.map((sItem:any) => { 
                sNo = index + 1, 
                reqId, 
                productName = sItem?.productDetails?.productName, 
                location = sItem?.projectDetails?.location, 
                categoryName = sItem?.productDetails?.category?.categoryName,
                projectId = sItem?.projectId,
                projectName = sItem?.projectDetails?.projectName,
                quantity = sItem?.quantity,
                status = sItem?.status,
                requesterName = sItem?.requesterDetails?.name,
                createdAt = sItem?.createdAt,
                createdById = sItem?.createdById,
                items.push({
                  id: sItem?.id,
                  machineryOrPrductId: sItem?.machineryOrPrductId,
                  machineryOrPrductName: sItem?.productDetails?.productName, 
                  itemName : (sItem?.productDetails !== null) ? (sItem?.productDetails?.itemName) : (sItem?.machineryDetails !== null) ? (sItem?.machineryDetails?.itemName) : 'Null',
                  specification : (sItem?.productDetails !== null) ? (sItem?.productDetails?.specification) : (sItem?.machineryDetails !== null) ? (sItem?.machineryDetails?.specification) : 'Null',
                  size : (sItem?.productDetails !== null) ? (sItem?.productDetails?.size) : (sItem?.machineryDetails !== null) ? (sItem?.machineryDetails?.size) : 'Null',
                  unit: sItem?.productDetails?.unit,
                  quantity: sItem?.quantity,
                  remark: sItem?.remark,
                  typeId: sItem?.typeId,
                  categoryId: sItem?.productDetails?.categoryId
                })
            }) 
            obj = createRequestData(sNo, reqId, productName, location, 'Material', categoryName, projectId, projectName, quantity, status, requesterName, items, createdAt, createdById )
          })
        }
        setUpdateData(obj)
  }, [resData])  

  return (
    <>
    <HeadingBox>
        <Blankbox>
            <Heading>Material Request Update</Heading>
        </Blankbox> 
    </HeadingBox>
      <MainConteiner>
        <CardContent> 
          <MainFormLayout> 
            <RequestUpdate  
              updateData={updateData}  
              catItems={catItems}
              refreshTableData={getRequestData}/> 
          </MainFormLayout>
        </CardContent>
      </MainConteiner>
    </>
  )
}

export default withAuth(MaterialReqForm, [2, 3, 4, 5])