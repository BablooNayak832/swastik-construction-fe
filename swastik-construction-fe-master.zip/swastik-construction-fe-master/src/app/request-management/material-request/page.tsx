'use client'
import React, { useEffect, useState } from "react";
import withAuth from "../../../hooks/withAuth";
import TableMain from '../../../components/Table/Table'
import { Alert, Button, TableContainer } from "@mui/material";
import { Heading, HeadingBox, TableBox } from "../../../common/styles/Users/styles";
import { Blankbox } from "../../../components/Table/styles";
import useGet from "../../../hooks/useGet";
import { Wrapper } from "../../styles";
import usePatch from "../../../hooks/usePatch";
import { useAllowedNavigation } from "../../../context/context";
import { useSelector } from "react-redux";
import useDownloadExcel from "../../../hooks/downloadExcel";
import { useRouter, useSearchParams } from "next/navigation";
import { useSession } from "next-auth/react";
import { materialRequestColumns } from "../../../constants/table-columns";
import { category_url, materialRequestUpdate, material_request_url, projects_url } from "../../../constants/api-routes";
import useDelete from "../../../hooks/useDelete"; 
import moment from "moment";
import {stringCapitalization} from "src/utils/formatString";

function createRequestData(
    reqId?: number,
    sNo: number,
    productName?: string,
    location?: string,
    type?: string, 
    categoryName?: string,
    projectId?: number,
    projectName?: string,
    quantity?: number,
    approveStatus?: string,
    reqApproveStatus?:string,
    senderName?: string,
    items?: [],
    requestedDate?:string,
    createdById: number
): any {
    return {
        reqId,
        sNo,
        productName,
        location,
        type, 
        categoryName,
        projectId,
        projectName,
        quantity,
        approveStatus,
        reqApproveStatus,
        senderName,
        items,
        requestedDate,
        createdById
    }
}

function createRequestItem(
    id: number,
    machineryOrPrductId: any,
    machineryOrPrductName: string,
    specification: string,
    size: number,
    itemName: string,
    unit: string,
    quantity: number,
    remark: string,
    typeId: number,
    categoryId: number,
): any {
    return {
        id,
        machineryOrPrductId,
        machineryOrPrductName,
        specification,
        size,
        itemName,
        unit,
        quantity,
        remark,
        typeId,
        categoryId
    }
}
 
const Request = () => { 
    const searchParams = useSearchParams();
    const status = searchParams.get('status');   
    const router = useRouter()  
    const { data: session } = useSession()
    const { handleDeleteData } = useDelete() 
    const { resData: resCategoryData, handleGetData: handleGetCategoryData } = useGet()
    const { resData: resRequestListData, handleGetData: handleRequestListData, isLoading } = useGet()
    const { handleUpdateData  } = usePatch();
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const { setOpen } = useAllowedNavigation();
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [totalItems, setTotalItems] = useState(0);
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({}) 
    const [materialReqList, setMaterialReqList] = useState([])
    const [selectedFilterProject, setSelectedFilterProject] = useState<any>('')
    const [selectedProjects, setSelectedProject] = useState<any>(null)
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet() 
    let projectArray: any = []  
    let selectedProjectId = selectedProject?.selectedValue !== 'null'  ? selectedProject?.selectedValue?.id : 'null'
  
    useEffect(() => { 
        if(![0, 1, 3].includes(session?.user?.role_id)){
               setQueryParams((preValue: any) => {
                   return { ...queryParams, ['projectId']: selectedProjectId }
               })                           
        }   
    },[selectedProject?.selectedValue?.id])
 
    useEffect(() => { 
        if(Object.keys(queryParams).length > 0 ){
            getRequestList()  
        } 
    },[ queryParams, page, rowsPerPage])

    useEffect(() => { 
        getCategory()
        getAssignedProjectData()
        if([0,1].includes(session?.user?.role_id) ){
            getRequestList()  
        }
    }, [page, rowsPerPage])

    useEffect(() => { 
        resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
            return projectArray.push({ id: Item?.id, name: Item?.projectName })
        });
        setSelectedProject(projectArray)
    }, [resProjectData?.items])

    useEffect(() => {
        setTotalItems(resRequestListData?.metaData?.totalItems)
        const requestDataList = resRequestListData?.items?.map((i: any, idx: any) => {
            let itemId, machineryOrPrductName, projectName, materialId ,createdById:number, requestedDate ,projectId, location, materialType,itemName, categoryName, quantity, approveStatus, reqApproveStatus, senderName, createitems, itemSpecification: any, itemSize, itemUnit;
            let items: any = []; 
            i?.items?.map((request: any) => { 
                itemId = request?.id;
                projectId = request.projectDetails?.id;
                projectName = request?.projectDetails?.projectName;
                location = request?.projectDetails?.location;
                materialType = request.typeId === 1 ? "Material" : "Machinery";
                categoryName = (request?.productDetails !== null) ? (request?.productDetails?.category?.categoryName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.categoryDetails?.categoryName) : 'Null';
                materialId = (request?.productDetails !== null) ? (request?.productDetails?.id) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.id) : 'Null';
                machineryOrPrductName = (request?.productDetails !== null) ? (request?.productDetails?.productName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.machineryName) : 'Null';
                itemSize = (request?.productDetails !== null) ? (request?.productDetails?.size) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.size) : 'Null';
                itemUnit = (request?.productDetails !== null) ? (request?.productDetails?.unit) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.unit) : 'Null';
                itemSpecification = (request?.productDetails !== null) ? (request?.productDetails?.specification) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.specification) : 'Null';
                itemName = (request?.productDetails !== null) ? (request?.productDetails?.itemName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.itemName) : 'Null';
                quantity = request?.quantity;
                approveStatus = request?.status;
                reqApproveStatus = stringCapitalization(request?.status);
                senderName = request?.requesterDetails?.name;
                createdById = request?.createdById;
                requestedDate = moment(request?.createdAt).format('YYYY-MM-DD HH:mm') !== 'Invalid date'
                ? moment(request?.createdAt).format('DD-MM-YYYY') : 'Not specified'; 
                createitems = createRequestItem(itemId, materialId, machineryOrPrductName, itemSpecification, itemSize, itemName ,itemUnit, request?.quantity, request?.remark, request?.typeId, request?.productDetails?.categoryId );
                items.push(createitems);
            })
            return createRequestData(i?.request,  (page - 1) * rowsPerPage + idx + 1, machineryOrPrductName, location, materialType, categoryName, projectId, projectName, quantity, approveStatus, reqApproveStatus, senderName, items, requestedDate, createdById)
        });
        setMaterialReqList(requestDataList)
    }, [resRequestListData?.items ,selectedProject?.selectedValue?.id ])

    const handleChangePage = (event: any, newPage: number) => { 
        setPage(newPage + 1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };
    
    const getRequestList = async () => { 
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })  
        const request = await handleRequestListData(`${material_request_url}/?page=${page}&limit=${rowsPerPage}&type=1${searchParams}`);
        return request;
    }
 
    const getAssignedProjectData = async () => {
        const machinery = await handleGetProjectData(`${projects_url}?page=1&limit=1000`);
        return machinery;
    }

    const getCategory = async () => {
        const category = await handleGetCategoryData(`${category_url}?type=1`);
        return category;
    }
  
    const handleUpdateRequest = async (e: any, payload: any) => { 
        e.preventDefault();
        const res = await handleUpdateData(materialRequestUpdate, payload)
            .then((data: any) => {
                return data;
            })
            .catch((error: any) => {
                alert(`Invalid Credentials, Try Again ${error.message}`);
            });
        setOpen(false);
        // getRequest();
        getRequestList()
        return res;
    }

    const searchTableData = (value: any) => {
        setQueryParams((preValue: any) => {
            return { ...queryParams, ['q']: value }
          }) 
        setPage(1)
    }

    const removeRequest = async (mId: number) => {
        const { reqId } = mId;
        const MACHINERY_DELETE = `/material-request/${reqId}`;
        const details = await handleDeleteData(MACHINERY_DELETE);
        getRequestList()
        return details;
    };

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${material_request_url}/?page=${page}&limit=${rowsPerPage}&type=xls${searchParams}`
        const res = handleDownloadData(url, "Material Request")
        return res;
    }

    const filterActiveUser = async (param: any) => {
        setQueryParams((value: any) => {
          return { ...queryParams, [param.key]: param.value }
        })  
        setPage(1)
    }
    
    const filterMenuOption = [
        { id: 1, menuText: 'Pending', fun: () => filterActiveUser({ key: 'status', value: 'pending' }) },
        { id: 2, menuText: 'Approved', fun: () => filterActiveUser({ key: 'status', value: 'approved' }) },
        { id: 3, menuText: 'Ordered', fun: () => filterActiveUser({ key: 'status', value: 'ordered' }) },
        { id: 4, menuText: 'Partial Delivered', fun: () => filterActiveUser({ key: 'status', value: 'partialDelivered' }) },
        { id: 5, menuText: 'Delivered', fun: () => filterActiveUser({ key: 'status', value: 'delivered' }) },
        { id: 6, menuText: 'Rejected', fun: () => filterActiveUser({ key: 'status', value: 'rejected' }) }
    ] 
       
    const filterByProject = (param:any) => {
        setQueryParams((prev) => {
            return {...queryParams, ['projectId'] : param}
        })
        setPage(1)
    }

    useEffect(() => {
        if(status !== null){
            setQueryParams(() => {
                return {...queryParams, ['status'] : status}
            })
        }
    },[status])

    const resetFilter = async() => { 
          setQueryParams({})
          setSelectedFilterProject('') 
          await getRequestList()
    }    
    
    return (
        <>
            <Wrapper> 
                    <HeadingBox>
                        <Blankbox>
                            <Heading>Material Request</Heading>
                        </Blankbox> 
                        {((session?.user?.role_id === 4) || (session?.user?.role_id === 5) || (session?.user?.role_id === 2)) &&   
                        <Blankbox> 
                            <Button disabled={selectedProject?.selectedValue?.status === "completed"} style={{color: 'white'}} variant="contained" onClick={() => router.push('/request-management/material-request/req-form')}>Material Request</Button> {" "}
                        </Blankbox> 
                        } 
                    </HeadingBox>
                        {selectedProject?.selectedValue?.status === "completed" &&
                             <Alert  variant="standard" severity="error"> 
                                Can't create request for completed projects
                              </Alert>
                        }
                        <TableBox>
                            <TableContainer>
                                <TableMain
                                    isVisible={false}
                                    title='Material Request'
                                    isLoading={isLoading}
                                    columns={materialRequestColumns}
                                    rows={materialReqList}
                                    handleExcelExport={handleExcelExport}
                                    page={page}
                                    filterMenuOption={filterMenuOption}
                                    rowsPerPage={rowsPerPage}
                                    catItems={resCategoryData}
                                    handleChangePage={handleChangePage}
                                    handleChangeRowsPerPage={handleChangeRowsPerPage}
                                    refreshTableData={getRequestList}
                                    handleRemoveRow={removeRequest}
                                    handleUpdateProps={handleUpdateRequest}
                                    searchTableData={searchTableData}
                                    resetFilter={resetFilter}
                                    filterByProject={filterByProject}
                                    projectItems={selectedProjects}
                                    selectedFilterProject={selectedFilterProject} 
                                    setSelectedFilterProject={setSelectedFilterProject}
                                    totalItems={totalItems}
                                /> 
                            </TableContainer>
                         </TableBox>
            </Wrapper>
        </>
    );
}

export default withAuth(Request, [0, 1, 2, 4, 5]);