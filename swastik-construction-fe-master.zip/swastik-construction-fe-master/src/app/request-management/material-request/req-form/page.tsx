'use client'
import React, { useEffect } from 'react'
import MaterialRequestForm from '../../../../components/common-form/MaterialRequestForm'
import withAuth from '../../../../hooks/withAuth'
import { useSelector } from 'react-redux' 
import useGet from '../../../../hooks/useGet'
import { MainFormLayout } from '../../../../components/Modal/styles'
import { Alert, CardContent, Typography } from '@mui/material'
import { MainConteiner } from '../../../../common/styles/common-form/styles'
import { category_url, machinery_url, material_request_add_item } from '../../../../constants/api-routes'
import { HeadingBox} from 'src/common/styles/Users/styles'
import {Blankbox} from 'src/components/Table/styles'

const MaterialReqForm = () => {
  const selectedProject = useSelector((state: any) => state?.selectedProject); 
  const { resData: resMachineryData, handleGetData: handleGetMachineryData } = useGet()
  const { resData: resCategoryData, handleGetData: handleGetCategoryData } = useGet()

  const getMachinery = async () => {
    const machinery = await handleGetMachineryData(machinery_url);
    return machinery;
  }

  const getCategory = async () => {
    const category = await handleGetCategoryData(`${category_url}/?type=1`);
    return category;
  }

  useEffect(() => { 
    getMachinery()
    getCategory() 
  }, [])

  return (
    <>
      <HeadingBox>
          <Blankbox> 
                <Typography sx={ {   flex: 1 } } variant="h5" component="div">
                   Create Material Request
              </Typography>  
          </Blankbox>
      </HeadingBox>
      <MainConteiner>
        <CardContent> 
        {  !!selectedProject?.selectedValue?.name ? 
        <>
        {
          selectedProject?.selectedValue?.status === "completed" ? 
            <Alert variant="standard" severity="error"> 
              Can't create request for completed projects
            </Alert>
            : 
            <MainFormLayout> 
              <MaterialRequestForm
                data={{
                  projectId: selectedProject?.selectedValue?.id,
                  projectName: selectedProject?.selectedValue?.name,
                  location: selectedProject?.selectedValue?.location,
                  machineryOrPrductId: null,
                  typeId: null,
                  quantity: '',
                  unit: '',
                  remark: '',
                  size: ''
                }}
                url={material_request_add_item}
                title={'Material Request'} 
                catItems={resCategoryData}  
                typeItems={resMachineryData} 
              />
            </MainFormLayout>
        }
        </>
          : 
           <Alert variant="standard" severity="error"> 
              Please select any project...
            </Alert> 
          }
        </CardContent>
      </MainConteiner>
    </>
  )
}

export default withAuth(MaterialReqForm, [2, 3, 4, 5])