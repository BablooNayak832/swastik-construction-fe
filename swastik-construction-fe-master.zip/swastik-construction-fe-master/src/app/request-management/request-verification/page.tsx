'use client'
import React, { useEffect, useState } from "react";
import withAuth from "../../../hooks/withAuth";
import TableMain from '../../../components/Table/Table' 
import { Heading, HeadingBox } from "../../../common/styles/Users/styles";
import { Blankbox } from "../../../components/Table/styles";
import useGet from "../../../hooks/useGet";
import { Wrapper } from "../../styles";
import { approvedReqColumns } from "../../../constants/table-columns";
import {  material_request_url } from "../../../constants/api-routes";
import usePost from "../../../hooks/usePost";
import { verifyMaterial } from '../../../constants/api-routes';
import { useDispatch, useSelector } from "react-redux";
import { setCloseModal } from "../../../redux/features/openModalSlice"; 
import { useSession } from "next-auth/react";
import useDownloadExcel from "src/hooks/downloadExcel";
import { setSelectedValue } from '../../../redux/features/selectProjectSlice'; 
import {stringCapitalization} from "src/utils/formatString";
import { useAllowedNavigation } from "src/context/context";

function createRequestData(
    reqId?: number,
    sNo: number,
    productName?: string,
    location?: string,
    type?: string,
    categoryName?: string,
    projectId?: number,
    projectName?: string,
    quantity?: number,
    approveStatus?: string,
    reqApproveStatus:string,
    approvedBy?: string,
    requestedDate?: string,
    dateApproved?: string,
    senderName?: string,
    items?: [],
    typeId?: number,
): any {
    return {
        reqId,
        sNo,
        productName,
        location,
        type,
        categoryName,
        projectId,
        projectName,
        quantity,
        approveStatus,
        reqApproveStatus,
        approvedBy,
        requestedDate,
        dateApproved,
        senderName,
        items,
        typeId,
    }
}

function createRequestItem(
    id: number,
    machineryOrProductId: any,
    machineryOrPrductName: string,
    materialStatus: boolean,
    itemName: string,
    specification: string,
    size: number,
    unit: string,
    quantity: number,
    remainingToVerified: number,
    verifiedRemark: string,
    purchaseOrderNo : number,
): any {
    return {
        id,
        machineryOrPrductName,
        machineryOrProductId,
        materialStatus,
        itemName,
        specification,
        size,
        unit,
        quantity,
        remainingToVerified,
        verifiedRemark,
        purchaseOrderNo
    }
} 

const Request = () => {
    const { data: session } = useSession()
    const [queryParams, setQueryParams] = useState({}) 
    const { resData: resRequestData, handleGetData: handleGetRequestData, isLoading } = useGet()
    const selectedProject = useSelector((state: any) => state?.selectedProject);
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [totalItems, setTotalItems] = useState(0);
    const [requestListUpdatedData, setRequestListUpdatedData] = useState<any>([])
    const { handlePostData } = usePost()
    const dispatch = useDispatch()
    const { handleDownloadData } = useDownloadExcel()
    const {setResLoading} = useAllowedNavigation()
    let selectedProjectId = ((selectedProject?.selectedValue != null) && (selectedProject?.selectedValue != "null"))  ? selectedProject?.selectedValue?.id : ''

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage + 1); 
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };

    const getRequest = async () => { 
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })   
        const category = await handleGetRequestData(`${material_request_url}?page=${page}&limit=${rowsPerPage}${searchParams}`);
        return category;
    }

    const searchTableData = async (value: string) => {
        setQueryParams((preValue: any) => {
            return { ...queryParams, ['q']: value }
        })  
        setPage(1)
    }

    const handleUpdateProps = async (verifyPayload: any) => { 
        setResLoading(true)
        const res = await handlePostData(verifyMaterial, verifyPayload);
        if(res?.status === 200){
            setResLoading(false)
            dispatch(setCloseModal());
            getRequest()
        } 
    }

    const resetFilter = async() => {
        if([0,1].includes(session?.user?.role_id)){ 
            dispatch(setSelectedValue(null)) 
            setQueryParams({['projectId'] : ''}) 
        }else{  
            setQueryParams((preValue: any) => { 
                return { ['projectId']: selectedProjectId }
            })  
        } 
        await getRequest()
    } 

     const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${material_request_url}/?type=xls${searchParams}`
        const res = handleDownloadData(url, "Verified Material Request")
        return res;
    }

    useEffect(() => {
        if([0,1].includes(session?.user?.role_id) ){
            getRequest() 
        }
    }, [ page, rowsPerPage])

    useEffect(() => {
        setTotalItems(resRequestData?.metaData?.totalItems) 
        const requestDataList = resRequestData?.items?.map((i: any, idx: any) => {
            let itemId, machineryOrPrductName, machineryOrProductId, materialStatus, purchaseOrderNo, projectName, projectId, location, materialType, categoryName, quantity, itemName, specification, remainingToVerified, approvedBy, approveStatus, reqApproveStatus, senderName, createitems, itemSize, itemUnit, requestedDate, dateApproved, typeId;
            let items: any = []
            i?.items?.map((request: any) => { 
                itemId = request?.id;
                purchaseOrderNo = request?.purchaseOrderData?.purchaseOrderNo;
                requestedDate = request?.createdAt;
                dateApproved = request?.updatedAt;
                projectId = request.projectDetails?.id;
                projectName = request?.projectDetails?.projectName;
                location = request?.projectDetails?.location;
                materialType = request.typeId === 1 ? "Material" : "Machinery";
                materialStatus = request.materialStatus;
                categoryName = (request?.productDetails !== null) ? (request?.productDetails?.category?.categoryName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.categoryDetails?.categoryName) : 'Null';
                machineryOrPrductName = (request?.productDetails !== null) ? (request?.productDetails?.productName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.machineryName) : 'Null';
                machineryOrProductId = request?.machineryOrPrductId;
                itemSize = (request?.productDetails !== null) ? (request?.productDetails?.size) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.size) : 'Null';
                itemUnit = (request?.productDetails !== null) ? (request?.productDetails?.unit) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.unit) : 'Null';
                quantity = request?.quantity;
                remainingToVerified = request?.remainingToVerified;
                reqApproveStatus = stringCapitalization(request?.status);
                approveStatus = request?.status;
                approvedBy = request?.acceptedby?.name;
                senderName = request?.requesterDetails?.name;
                typeId = request?.typeId; 
                itemName = request?.productDetails?.itemName;
                specification = request?.productDetails?.specification;
                createitems = createRequestItem(itemId, machineryOrProductId, machineryOrPrductName, materialStatus,itemName, specification, itemSize, itemUnit, request?.quantity, remainingToVerified, request?.verifiedRemark, purchaseOrderNo);
                items.push(createitems);
            })
            return createRequestData(i?.request, (page - 1) * rowsPerPage + idx + 1, machineryOrPrductName, location, materialType, categoryName, projectId, projectName, quantity, approveStatus, reqApproveStatus ,approvedBy, requestedDate, dateApproved ,senderName, items, typeId)
        });
        setRequestListUpdatedData(requestDataList)
    }, [resRequestData?.items])
   
    useEffect(() => {  
        setQueryParams((preValue: any) => {
            return { ...queryParams, ['projectId']: selectedProjectId }
        }) 
    },[selectedProject?.selectedValue?.id])
 
    useEffect(() => { 
        if(Object.keys(queryParams).length > 0 ){
            getRequest()  
        } 
    },[ queryParams, page, rowsPerPage])
 
    return (
        <>
            <Wrapper> 
                    <HeadingBox>
                        <Blankbox>
                            <Heading>Request Verification</Heading>
                        </Blankbox>
                    </HeadingBox>
                    <TableMain
                        isVisible={false}
                        title='Request Verification'
                        isLoading={isLoading}
                        columns={approvedReqColumns}
                        rows={requestListUpdatedData}
                        page={page}
                        rowsPerPage={rowsPerPage}
                        handleChangePage={handleChangePage}
                        handleChangeRowsPerPage={handleChangeRowsPerPage}
                        refreshTableData={getRequest}
                        searchTableData={searchTableData}
                        handleUpdateProps={handleUpdateProps}
                        resetFilter={resetFilter}
                        totalItems={totalItems}
                        handleExcelExport={handleExcelExport}
                    /> 
            </Wrapper>
        </>
    );
}

export default withAuth(Request, [0, 1, 2, 4, 5]);