'use client'
import React, {useEffect, useState} from 'react';
import withAuth from '../../../../hooks/withAuth'
import { useParams, useRouter } from 'next/navigation'; 
import { AppBar, Dialog, DialogActions, DialogContent, Grid, TablePagination, Toolbar, Typography } from "@mui/material";
import { Heading, HeadingBox, SubHeading } from "../../../../common/styles/Users/styles";
import { Blankbox } from "../../../../components/Table/styles";
import { Wrapper } from "../../../styles";
import { ContainerMain, RequestVerificationTable } from '../../../../common/styles/Dashboard/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Button } from '@mui/material'; 
import Paper from '@mui/material/Paper'; 
import useGet from '../../../../hooks/useGet';
import {theme} from '../../../../common/styles/theme';
import ClearIcon from '@mui/icons-material/Clear';
import {formateDate} from '../../../../utils/formatDate';
import { GalleryItemLayout } from '../../../styles';
import {ArrowLeftIcon} from "@mui/x-date-pickers";
import {baseImgUrl} from '../../../../constants/api-routes';
import Image from 'next/image';
 
 const RequestVerificationForm = () => { 
    const router = useRouter()
    const params = useParams<{ tag: string; item: string }>()
    const {resData ,handleGetData} = useGet()
    const [isGalleryOpen, setOpenGallery] = useState(false)
    const [galleryData, setGalleryData] = useState([]) 
     const [itemsData, setItemsData] = useState([])
 
     const fetchData = async() => {
        const res = await handleGetData(`verify-material?requestId=${params.id}`)
        return res;
     }

    useEffect(() => { 
         fetchData()
    }, [])
 

   const handleClickView = (value:any) => { 
    setOpenGallery(!isGalleryOpen)
    resData?.map((item) => { 
        const productItem = item?.items?.filter(fItem => fItem?.machineryOrPrductId === value?.machineryOrPrductId )
        setGalleryData(productItem)
    })
   }


   useEffect(() => { 
     setItemsData(resData)
   }, [resData])  
    
    return (
        <>
            <Wrapper> 
                <HeadingBox>
                    <Blankbox>
                        <Heading>Request Verification</Heading> 
                        <SubHeading>Request No: {params.id}</SubHeading> 
                    </Blankbox>
                </HeadingBox> 

                <ContainerMain>
                    <Grid container spacing={2}> 

                        <Grid item lg={12} md={12} sm={12} xs={12}>
                            <Paper sx={{ width: '100%' }}>
                                <RequestVerificationTable>
                                    <TableContainer sx={{ maxHeight: 350, border: '1px solid #3333' }}>
                                        <Table stickyHeader aria-label="sticky table">
                                            <TableHead>  
                                                <TableRow>
                                                    <TableCell width={'100px'}>S No.</TableCell>
                                                    <TableCell width={'200px'}>
                                                        Product Name
                                                    </TableCell>
                                                    <TableCell width={'200px'}>
                                                        Type / Grade
                                                    </TableCell>
                                                    <TableCell width={'200px'}>
                                                         Specification
                                                    </TableCell>
                                                    <TableCell width={'200px'}>
                                                         Size
                                                    </TableCell>
                                                    <TableCell width={'200px'}>
                                                        Unit
                                                    </TableCell>
                                                    <TableCell width={'200px'}>
                                                       Requested Qty.
                                                    </TableCell>
                                                    <TableCell width={'200px'}>
                                                        Received Qty.
                                                    </TableCell > 
                                                    <TableCell width={'200px'}>
                                                        Gallery
                                                    </TableCell> 
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                { !!itemsData?.length ? itemsData?.[0]?.items?.map((row: any, i: any) => {   
                                                    return (
                                                        <TableRow hover role="checkbox" tabIndex={-1} key={i}>
                                                            <TableCell key={i}>{i + 1}</TableCell>
                                                            <TableCell key={i}>{row.materialDetails?.productName}</TableCell>
                                                            <TableCell width={'200px'}>{row?.materialDetails?.itemName}</TableCell>
                                                            <TableCell width={'200px'}>{row?.materialDetails?.specification}</TableCell>
                                                            <TableCell width={'200px'}>{row?.materialDetails?.size}</TableCell>
                                                            <TableCell width={'200px'}>{row?.materialDetails?.unit}</TableCell>
                                                            <TableCell width={'200px'}>{row?.materialRequestDetails?.quantity }</TableCell>
                                                            <TableCell width={'200px'}>{row?.receivedQuantity}</TableCell> 
                                                            <TableCell key={i}>
                                                                <Button color='error' size='small' variant='outlined' onClick={() => handleClickView(row)}>View</Button> 
                                                            </TableCell>
                                                        </TableRow>
                                                    );
                                                })
                                             : <>
                                             <TableRow hover role="checkbox" tabIndex={-1}>
                                             <TableCell sx={{textAlign: 'center'}} colSpan={8}>
                                                <h3> Data not available </h3>
                                             </TableCell>
                                             </TableRow>
                                             </>
                                            }
                                            </TableBody>
                                        </Table>
                                    </TableContainer> 
                                </RequestVerificationTable>
                            </Paper>
                        </Grid>

                        <Grid item lg={12} xs={12} md={12}>
                            <Button style={{ float: 'right' }} onClick={() => router.back()} variant='contained'> <ArrowLeftIcon /> Go Back</Button>
                        </Grid>
                    </Grid>
                </ContainerMain>
            </Wrapper>
 
            <Dialog
            fullWidth
            maxWidth='lg'
            open={isGalleryOpen}>
            <AppBar sx={{ position: 'relative', background: theme.colors.Red }}>
            <Toolbar>
            <Typography sx={{ ml: 2, flex: 1 }} variant="h6" component="div">
              Gallery
            </Typography>
            <DialogActions>
            <ClearIcon onClick={() => setOpenGallery(!isGalleryOpen)} />
            </DialogActions>
            </Toolbar>
            </AppBar>
            <DialogContent> 
            <h3>Verified Products Image</h3>
            <div style={{display: 'flex'}}>
                <Grid container spacing={2}>
                {!!galleryData?.length && galleryData?.[0]?.gallery?.map((gItem) =>{
                    let verifyAtt = formateDate(gItem?.verifyAt)                 
                    return <> 
                    <Grid item lg={3} xs={3} md={3}>
                        <GalleryItemLayout>
                            <span>{gItem?.imageName.split(",")[0]}</span>
                            <Image alt='galleryData' src={`${baseImgUrl}${gItem?.image}`} width={150} height={150} style={{margin:'20px'}} crossOrigin='anonymous'/> 
                            <span>Received Qty : {gItem?.receivedQty}</span>
                            <span>Verify At : {verifyAtt}</span>
                            <span>Verify by : {gItem?.userDetails !== null ? gItem?.userDetails?.name : "Used From Central"}</span>
                            <span>Comment : {gItem?.verifiedRemark}</span> 
                        </GalleryItemLayout> 
                    </Grid>
                    </>
                    })}
                </Grid>
            </div>
            </DialogContent>
            </Dialog>
        </>
    )
}

export default withAuth(RequestVerificationForm, [0, 1, 2, 4, 5])