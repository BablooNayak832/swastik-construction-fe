'use client';
import { TableContainer, Wrapper } from '../styles';
import React, { useEffect, useState } from 'react';
import withAuth from '../../hooks/withAuth';
import {
    HeadingBox,
    Blankbox,
    Heading,
    TableBox,
} from '../../common/styles/Users/styles';
import dynamic from 'next/dynamic';
import { useAllowedNavigation } from '../../context/context';
import useGet from '../../hooks/useGet';
import { attendanceListColumns } from '../../constants/table-columns';
import moment from 'moment'; 
import { useSession } from 'next-auth/react'; 
import CommonDialog from '../../components/CommonDialog/CommonDialog';
import MarkAttendance from '../../components/AttendanceManagement/MarkAttendance'
import usePost from '../../hooks/usePost';
import { useSelector } from 'react-redux';
import useDownloadExcel from '../../hooks/downloadExcel';
import { projects_url, get_roles_url, attendance_url, site_staff_labour_url } from '../../constants/api-routes';
import { formateDate } from '../../utils/formatDate'
const TableMain = dynamic(() => import('../../components/Table/Table'), {
    ssr: false,
});

function createData(
    sNo: number,
    id: number,
    projectId: string | number,
    projectName: string,
    checkInAddress: string,
    checkoutAddress: string,
    checkInDate: string,
    checkInTime: string,
    checkOutTime: string,
    staffId: number,
    attendanceMarkedBy: string,
    image: string,
    user: string,
    userRole: string,
    userId: any,
    attandanceStatus: string
): any {
    return {
        sNo,
        id,
        projectId,
        projectName,
        checkInAddress,
        checkInDate,
        checkoutAddress,
        checkInTime,
        checkOutTime,
        staffId,
        attendanceMarkedBy,
        image,
        user,
        userRole,
        userId,
        attandanceStatus
    };
}

const AttendanceList = () => {
    let userR: any = []
    let selectedUser: any = [];
    const currentDate = new Date();
    const selectedProject = useSelector((state: any) => state?.selectedProject)
    let selectedProjectId = selectedProject?.selectedValue !== 'null'  ? selectedProject?.selectedValue?.id : 'null'
    const { data: session } = useSession()
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [data, setData] = useState([]); 
    const { setRenderData, setOpenDialog } = useAllowedNavigation();
    const { resData: projectData, handleGetData: handleProjectData } = useGet();
    const { resData: roleData, handleGetData: handleRoleData } = useGet();
    const { resData, handleGetData, isLoading: loadAttendanceData } = useGet();
    const { resData: siteStaffData, handleGetData: getStaffData } = useGet()
    const { handlePostData: handlePostAttendance } = usePost()
    const [position, setPosition] = useState<any>({ latitude: null, longitude: null });
    const [selectProject, setSelectProject] = useState([])
    const [selectUserOnFilter, setSelectUserOnFilter] = useState([]) 
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState<any>({startDate: moment(currentDate).format('YYYY-MM-DD'), endDate: moment(currentDate).format('YYYY-MM-DD'), projectId: selectedProjectId})
    const [attendanceQueryParams, setAttendanceQueryParams] = useState<any>({startDate: moment(currentDate).format('YYYY-MM-DD'), endDate: moment(currentDate).format('YYYY-MM-DD')})
    const [assignedUser, setAssignedUser] = useState({ projectId: null, users: [] });
    const [selectedDateRange, setSelectedDateRange] = React.useState<any>([null, null]);
    const [totalItems, setTotalItems] = useState(0); 
    let defaultStartDate = moment(currentDate).format('YYYY-MM-DD');
    let defaultEndDate = moment(currentDate).format('YYYY-MM-DD');

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage+1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1);
    };

    const getAllStaffData = async () => {
        const res = await getStaffData(`${site_staff_labour_url}?page=1&limit=1000`)
        return res;
    }

    const GetAllProjectList = async () => { 
        const details = await handleProjectData(`${projects_url}?page=${page}&limit=100`);
        return details;
    };

    const GetAllRoleList = async () => {
        const details = await handleRoleData(get_roles_url) 
        return details;
    };

    const getAllAttendanceList = async () => {
        let searchParams = "";
        Object.entries(attendanceQueryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        }) 
        const details = await handleGetData(`${attendance_url}/?page=${page}&limit=${rowsPerPage}&${searchParams}`);
        return details;
    };

    const searchTableData = async (value: any) => {   
            setAttendanceQueryParams((prev) => { return { ...attendanceQueryParams, ["name"]: value}})
            setPage(1)
    };

    const applyFilter = async () => {  
        setAttendanceQueryParams(queryParams)
        setPage(1) 
    }

    // Filter on a specific attribute value 
    const filterOnAttendance = async (filterParams?: any, type?: string) => {  
        if (type === 'project') { 
            setQueryParams((value: any) => {
                if (Object.keys(queryParams)?.includes('startDate') && Object.keys(queryParams)?.includes('endDate')){
                    delete queryParams?.["startDate"] && delete queryParams?.["endDate"]
                } { return { ...queryParams, ["projectName"]: filterParams } }
            })
            selectProject?.map((projectItem: any) => {
                if (projectItem?.projectName === filterParams) {
                    setAssignedUser({
                        projectId: projectItem?.projectName,
                        users: projectItem?.assignProject
                    })
                }
            })
            
        }

        if (type === 'date') {
            let startDate: any = null;
            let endDate: any = null;
            const newStartDate = formateDate(filterParams?.[0]?.$d)
            const newEndDate = formateDate(filterParams?.[1]?.$d) 
            if (Array.isArray(filterParams)) {
                startDate = newStartDate , 
                endDate = newEndDate
            } 
            setSelectedDateRange(filterParams)
            setQueryParams((value) => { return { ...queryParams, ["startDate"]: startDate, ['endDate']: endDate } })
        }

        if (type == 'role') {
            if (filterParams == 'staffData') {
                queryParams?.["staffId"] && delete queryParams?.["staffId"] || queryParams?.["q"] && delete queryParams?.["q"]
                setQueryParams((value: any) => {
                    if (Object.keys(queryParams)?.includes('role')) {
                        delete queryParams?.["role"]
                    } { return { ...queryParams, ["user"]: filterParams } }
                })
                const siteStaff = siteStaffData?.items?.map((item: any) => {
                    return {
                        user: {
                            name: item?.name,
                            id: item?.id
                        }
                    };
                })
                setSelectUserOnFilter(siteStaff)
                return
            }
            queryParams?.["staffId"] && delete queryParams?.["staffId"] || queryParams?.["q"] && delete queryParams?.["q"]
            setQueryParams((value: any) => {
                if (Object.keys(queryParams)?.includes('user')) {
                    delete queryParams?.["user"]
                }
                return { ...queryParams, ["role"]: filterParams }
            })
            assignedUser?.users?.filter((item: any) => item?.user?.role?.id === filterParams)?.map((fItem: any) => {
                userR.push(fItem)
            })
            setSelectUserOnFilter(userR)
        }

        if (type === 'user') {
            if (Object.keys(queryParams)?.includes('user')) {
                setQueryParams((value: any) => {
                    if (Object.keys(queryParams)?.includes('q')) {
                        delete queryParams?.["q"]
                    }
                    return { ...queryParams, ["staffId"]: filterParams }
                }) 
                return
            }
            setQueryParams((value: any) => {
                if (Object.keys(queryParams)?.includes('staffId')) {
                    delete queryParams?.["staffId"]
                }
                return { ...queryParams, ["q"]: filterParams }
            }) 
        }

        if (type === 'remove') {
            let searchParams = "";
            Object.entries(queryParams)?.map(([key, value]) => {
                searchParams += `&${key}=${value}`
            }) 
            setQueryParams({})
            setSelectedDateRange([null, null])
            return handleGetData(`${attendance_url}/?page=${page}&limit=${rowsPerPage}&${searchParams}`);
        }
        setPage(1)
    }

    const handleClockInOut = async (payload: any) => { 
        const res = await handlePostAttendance(attendance_url, payload)
        setOpenDialog(false)
        getAllAttendanceList()
        return res;
    }

    const handleSelectedUser = () => {
        projectData?.items?.filter((projItem: any) => projItem.id === selectedProject?.selectedValue?.id)?.map((item: any) => {
            item?.assignProject?.map((assignProject: any) => {
                if (assignProject?.user !== null && assignProject?.user?.role?.id !== 2 && assignProject?.user?.role?.id !== 1 && assignProject?.user?.role?.id !== 3) {
                    selectedUser.push({ id: assignProject?.user?.id, name: assignProject?.user?.name })
                }
            })
        })
        return selectedUser;
    }

    const users = handleSelectedUser()

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(attendanceQueryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${attendance_url}/?page=${page}&limit=${rowsPerPage}&type=xls${searchParams}`
        const res = handleDownloadData(url, "Staff Attendance")
        return res;
    }

    const resetFilter = async() => {                                                                                
        setAttendanceQueryParams({startDate: defaultStartDate, endDate: defaultEndDate}) 
    }

    useEffect(() => {
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(function (position) {
                setPosition({
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                });
            });
        } else {
            console.error("Geolocation is not available in your browser.");
        }
    }, []);
 
    useEffect(() => {
        setSelectProject(projectData?.items)
    }, [projectData?.items])

    useEffect(() => {
        getAllAttendanceList();
        GetAllProjectList()
        if([0, 1].includes(session?.user?.role_id)){
            GetAllRoleList()
        }
        getAllStaffData()
    }, [queryParams,page, rowsPerPage, attendanceQueryParams]);

    useEffect(() => {
        setTotalItems(resData?.meta?.totalItems)
        const attendanceData = resData?.items?.map((i: any, index: number) => {
            let inTime = moment(i?.checkInTime).format('DD-MM-YYYY hh:mm:ss a');
            let outTime = moment(i?.checkOutTime).format('DD-MM-YYYY hh:mm:ss a');
            let checkInTime = inTime;
            let checkOutTime = i?.checkOutTime === null ? 'Not specified' : outTime;
            const userName = i?.user === null ? i?.staff?.name : i?.user?.name;
            const userRole = i?.user === null ? 'Site Staff' : i?.user?.role?.roleName;
            const attendanceMarkedby = i?.attendanceMarkedby === null ? 'Self' : i?.attendanceMarkedby?.name;
            const userImage = i?.image;
            const userId = i?.user === null ? i?.staff?.id : i?.user?.id;
            const checkInAddress = i?.checkInAddress === null ? "Not specified" : `${i?.checkInAddress?.projectName}-${i?.checkInAddress?.location}`; 
            const checkoutAddress =  i?.checkoutAddress === null ? "Not specified" : `${i?.checkoutAddress?.projectName}-${i?.checkoutAddress?.location}`;
            const checkInDate = moment(i?.checkInTime).format('DD-MM-YYYY');
            const attandanceStatus =  i?.attendanceStatus === "H" ? "Halfday" : i?.attendanceStatus === "F" ? "Fullday" : "Absent";
            return createData( 
                (page - 1) * rowsPerPage + index + 1,
                i?.id,
                i?.Project?.id,
                i?.Project?.projectName,
                checkInAddress,
                checkoutAddress,
                checkInDate,
                checkInTime,
                checkOutTime, 
                i?.staffId,
                attendanceMarkedby,
                userImage,
                userName,
                userRole,
                userId,
                attandanceStatus
            );
        });

        setRenderData(true);
        setData(attendanceData);
    }, [resData?.items]); 
    
    useEffect(() => {  
        setAttendanceQueryParams((preValue: any) => {
            return { ...attendanceQueryParams, ['projectName']: selectedProject?.selectedValue?.name }
        })     
    },[selectedProject?.selectedValue?.id]) 

    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Staff Attendance</Heading>
                    </Blankbox>
                    <Blankbox>
                        {
                            (session?.user?.role_id === 2) &&
                            <CommonDialog title="Mark Attendance">
                                <MarkAttendance selectedUser={users} position={position} handleClockInOut={handleClockInOut} />
                            </CommonDialog>
                        }
                    </Blankbox>
                </HeadingBox>
                <TableBox>
                    <TableContainer>
                        <TableMain
                            selectedDateRange={selectedDateRange}
                            applyFilter={applyFilter}
                            filterOnAttendance={filterOnAttendance}
                            isLoading={loadAttendanceData}
                            columns={attendanceListColumns}
                            rows={data}
                            handleExcelExport={handleExcelExport}
                            page={page}
                            rowsPerPage={rowsPerPage}
                            handleChangePage={handleChangePage}
                            handleChangeRowsPerPage={handleChangeRowsPerPage}
                            refreshTableData={getAllAttendanceList}
                            // selectItems={allUserData}
                            // catItems={projectData}
                            roleItems={roleData}
                            getUserByRole={selectUserOnFilter}
                            projectItems={selectProject}
                            title={'Attendance'}
                            url={attendance_url}
                            searchTableData={searchTableData}
                            totalItems={totalItems}
                            resetFilter={resetFilter}
                        />
                    </TableContainer>
                </TableBox>
            </Wrapper> 
        </>
    );
};

export default withAuth(AttendanceList, [0, 1, 2]); 