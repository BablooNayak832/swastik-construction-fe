"use client"
import React from "react";
import styled from 'styled-components';

const PageWrapper = styled.div`
  background-color: #eef0f3;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 60px 20px;
`;

const ContentBox = styled.div`
  background-color: #fff;
  padding: 40px;
  border-radius: 12px;
  max-width: 800px;
  width: 100%;
  box-shadow: 0 8px 24px rgba(0,0,0,0.08);
`;

const Title = styled.h1`
  font-size: 2rem;
  font-weight: 600;
  color: #444;
  margin-bottom: 24px;
`;

const Paragraph = styled.p`
  font-size: 1rem;
  line-height: 1.8;
  color: #555;
  margin-bottom: 16px;
`;

export default function PrivacyPolicy() {
    return (
        <PageWrapper>
            <ContentBox>
                <Title>Privacy Policy</Title>
                <Paragraph>
                    At Swastik Construction, we value your privacy and are committed to protecting your personal information. This Privacy Policy outlines how we collect, use, and safeguard your data when you interact with our services.
                </Paragraph>

                <Title>1. Information We Collect</Title>
                <Paragraph>
                    We may collect personal details such as your name, email address, phone number, project location, and other relevant information when you:
                </Paragraph>
                <Paragraph>- Fill out a form on our website</Paragraph>
                <Paragraph>- Contact us via email or phone</Paragraph>
                <Paragraph>- Request a service or quote</Paragraph>

                <Title>2. How We Use Your Information</Title>
                <Paragraph>Your data is used to:</Paragraph>
                <Paragraph>- Respond to your inquiries or requests</Paragraph>
                <Paragraph>- Provide project updates or quotations</Paragraph>
                <Paragraph>- Improve our services and communication</Paragraph>
                <Paragraph>- Comply with legal or regulatory obligations</Paragraph>

                <Title>3. Data Sharing</Title>
                <Paragraph>
                    We do not sell or share your personal data with third parties except:
                </Paragraph>
                <Paragraph>- When required by law</Paragraph>
                <Paragraph>- To trusted partners who help us operate our business (with confidentiality agreements)</Paragraph>

                <Title>4. Data Security</Title>
                <Paragraph>
                    We implement standard security practices to protect your information from unauthorized access, alteration, or disclosure. However, no digital platform is 100% secure.
                </Paragraph>

                <Title>5. Cookies & Tracking</Title>
                <Paragraph>
                    We may use cookies to enhance user experience and analyze website traffic. You can disable cookies in your browser settings at any time.
                </Paragraph>

                <Title>6. Your Rights</Title>
                <Paragraph>You have the right to:</Paragraph>
                <Paragraph>- Access or update your personal data</Paragraph>
                <Paragraph>- Request deletion of your information</Paragraph>
                <Paragraph>- Withdraw consent for communication</Paragraph>

                <Title>7. Contact Us</Title>
                <Paragraph>
                    If you have any questions about this policy or want to exercise your data rights, please contact us at:
                </Paragraph>
                <Paragraph>
                    <strong>Email:</strong> support@swastikconstruction.com
                </Paragraph>

                <Paragraph>
                    By using our services, you agree to this Privacy Policy. We may update it from time to time, and all changes will be reflected on this page.
                </Paragraph>

            </ContentBox>
        </PageWrapper>
    );
}
