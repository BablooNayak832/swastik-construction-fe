'use client';
import React, { useEffect, useState } from 'react';
import withAuth from '../../hooks/withAuth';
import User from '../../components/Users/Users';
import useGet from '../../hooks/useGet';
import useDownloadExcel from '../../hooks/downloadExcel' 
import { all_user_url } from 'src/constants/api-routes'; 
import {useSelector} from 'react-redux';
import {useSession} from 'next-auth/react';

const Users = () => { 
  const { data: session } = useSession()
  const { resData, handleGetData, isLoading } = useGet()
  const { handleDownloadData } = useDownloadExcel() 
  const [queryParams, setQueryParams] = useState({})
  const [totalItems, setTotalItems] = useState(0);
  const [page, setPage] = useState(1); 
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const selectedProject = useSelector((state: any) => state?.selectedProject);
  const projectSelectedId = selectedProject?.selectedValue !== null ? selectedProject?.selectedValue?.id : '';
  
  const handleChangePage = (event: React.ChangeEvent<HTMLInputElement>, newPage: number) => {
    setPage(newPage + 1);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(1); 
  };

  const refreshTableData = async () => {
    let searchParams = "";
    Object?.entries(queryParams)?.map(([key, value]) => {
      searchParams += `${key}=${value}&`
    })      
    const res = await handleGetData(`${all_user_url}/?page=${page}&limit=${rowsPerPage}&${searchParams}`) 
    return res;
  };
  
  const filterActiveUser = async (param: any) => {  
    setQueryParams((value: any) => {
      return { ...queryParams, [param.key]: param.value }
    }) 
    setPage(1)
  }

  const handleSearch = async (searchValue: any) => {
    setQueryParams((value: any) => {
      return { ...queryParams, ['q']: searchValue };
    }) 
    setPage(1)
  };

  const handleExcelExport = async () => {
    let searchParams = "";
    Object.entries(queryParams)?.map(([key, value]) => {
      searchParams += `&${key}=${value}`
    })
    let url = `${all_user_url}/?page=${page}&limit=${rowsPerPage}&type=xls${searchParams}`
    const res = handleDownloadData(url, "Users")
    return res;
  }

  useEffect(() => {
    setTotalItems(resData?.meta?.totalItems)
  }, [resData])
 
   useEffect(() => {
    if([2].includes(session?.user?.role_id) && !!projectSelectedId){
      setQueryParams((preValue: any) => {
          return { ...queryParams, ['projectId']: projectSelectedId }
      })                           
    } 
   },[projectSelectedId])

  useEffect(() => { 
    if([0,1].includes(session?.user?.role_id) ){
      refreshTableData()    
    }
    if(Object.keys(queryParams).length > 0 ){  
        refreshTableData()  
    } 
  }, [queryParams, page, rowsPerPage])
  
  const resetFilter = async() => {
    if([2].includes(session?.user?.role_id) && !!projectSelectedId){
      setQueryParams({ ['projectId']: projectSelectedId })
    }else{
      setQueryParams({})
    }
    setPage(1)
    await refreshTableData()
  } 
   
  return (
    <>
      <User 
       resetFilter={resetFilter} 
       propsData={resData} 
       handleExcelExport={handleExcelExport} 
       refreshTableData={refreshTableData} 
       isLoading={isLoading} 
       filterActiveUser={filterActiveUser} 
       searchTableData={handleSearch} 
       totalItems={totalItems} 
       handleChangePage={handleChangePage}
       handleChangeRowsPerPage={handleChangeRowsPerPage}
       page={page}
       rowsPerPage={rowsPerPage}/>
    </>
  );
};

export default withAuth(Users, [0, 1, 2]);