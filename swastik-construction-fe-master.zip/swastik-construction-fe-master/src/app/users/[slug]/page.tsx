"use client"
import { useParams } from 'next/navigation';
import React, { useEffect, useState } from 'react'
import User from '../../../components/Users/Users';
import useGet from '../../../hooks/useGet';
import withAuth from '../../../hooks/withAuth';
import { all_user_url } from '../../../constants/api-routes';

const UserList = () => {
    const params = useParams<{ tag: string; item: string }>()
    const { resData, handleGetData, isLoading } = useGet()
    const [totalItems, setTotalItems] = useState(0);
    const [page, setPage] = useState(1); 
    const [rowsPerPage, setRowsPerPage] = useState(10);
  
    const handleChangePage = (event: React.ChangeEvent<HTMLInputElement>, newPage: number) => {
      setPage(newPage + 1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
      ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
      };

    const refreshTableData = async () => { 
        const res = await handleGetData(`${all_user_url}/?page=1&limit=100&q=${params.slug}`)
            .then((data) => {
                return data;
            })
            .catch((error) => {
                return error;
            });
        return res;
    };

    const handleExcelExport = async () => {
        const res = await handleGetData(`${all_user_url}/?type=xls`)
        return res;
    }

    const filterActiveUser = async (param: any) => {
        const res = await handleGetData(`${all_user_url}/?page=1&limit=100&${param.key}=${param.value}`)
            .then((data) => {
                return data;
            }).catch((error) => {
                return error;
            });
        return res;
    }

    useEffect(() => {
        setTotalItems(resData?.meta?.totalItems)
    }, [resData])

    useEffect(() => {
        refreshTableData()
    }, [])

    return (
        <>
            <User 
              propsData={resData} 
              refreshTableData={refreshTableData} 
              handleExcelExport={handleExcelExport} 
              isLoading={isLoading} 
              filterActiveUser={filterActiveUser}
              totalItems={totalItems}
              handleChangePage={handleChangePage}
              handleChangeRowsPerPage={handleChangeRowsPerPage}
              page={page}
              rowsPerPage={rowsPerPage}/>
        </>
    )
}

export default withAuth(UserList, [0, 1, 2]);