'use client';
import { TableContainer, Wrapper } from '../styles';
import React, { useEffect, useState } from 'react';
import withAuth from '../../hooks/withAuth';
import {
    HeadingBox,
    Blankbox,
    Heading,
    TableBox,
} from '../../common/styles/Users/styles';
import dynamic from 'next/dynamic';
import { useAllowedNavigation } from '../../context/context';
import CommonDialog from '../../components/CommonDialog/CommonDialog';
import MainForm from '../../components/common-form';
import useGet from '../../hooks/useGet';
import { siteStaffColumns } from '../../constants/table-columns';
import usePatch from '../../hooks/usePatch'; 
import useDelete from '../../hooks/useDelete';
import useDownloadExcel from '../../hooks/downloadExcel';
import { projects_url, site_staff_labour_url } from '../../constants/api-routes';
import {useSelector} from 'react-redux';
import {useSession} from 'next-auth/react';
const TableMain = dynamic(() => import('../../components/Table/Table'), {
    ssr: false,
});

function createData(
    id: number,
    sNo: number,
    name: string,
    projectId: number,
    projectName: string,
    createdBy: string,
    mobileNumber: string,
    image: string,
    status: boolean,
    createdAt: string,
): any {
    return {
        id,
        sNo,
        name,
        projectId,
        projectName,
        createdBy,
        mobileNumber,
        image,
        status,
        createdAt
    };
}

const StaffManagement = () => {
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [data, setData] = useState([]);
    const [allProjects, setAllProject] = useState<any>([]);
    const { setOpen, setRenderData, setOpenDialog } = useAllowedNavigation();
    const { resData, handleGetData, isLoading: loadProjectData } = useGet();
    const { handleUpdateData } = usePatch();
    const { resData: getProjects, isLoading, handleGetData: handleGetProjectdata } = useGet();
    const { handleDeleteData } = useDelete()
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const [selectedFilterProject, setSelectedFilterProject] = useState<any>('')
    const [selectedProject, setSelectedProject] = useState<any>(null)
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet() 
    const [totalItems, setTotalItems] = useState(0);
    const projectSelected = useSelector((state: any) => state?.selectedProject)
    const {data: session} = useSession()
    let selectedProjectId = projectSelected?.selectedValue !== 'null'  ? projectSelected?.selectedValue?.id : 'null'
    let projectArray: any = []
    
    useEffect(() => {
        if([2, 4].includes(session?.user?.role_id)){
            setQueryParams((prev) => {
                return { ...queryParams, ['projectId'] : selectedProjectId }
            })
        }
    }, [selectedProjectId])

    useEffect(() => {
        setTotalItems(resData?.meta?.totalItems) 
        const projectData = resData?.items?.map((i: any, index: number) => {
            return createData(
                i?.id,
                (page - 1) * rowsPerPage + index + 1,
                i?.name,
                i?.Project?.id,
                i?.Project?.projectName,
                i?.CreatedBy?.name,
                i?.mobileNumber,
                i?.image,
                i?.status,
                i?.createdAt
            );
        });
        setRenderData(true);
        setData(projectData);
        setAllProject(getProjects?.items);
    }, [resData?.items, getProjects?.items]);

    useEffect(() => {
        if([0, 1].includes(session?.user?.role_id)){
            getAllSiteStaff()
        }
        if(([2, 4].includes(session?.user?.role_id)) && (Object.keys(queryParams)?.length)){
            getAllSiteStaff()
        }
        getProjectData() 
        getAllProjects();  
      }, [queryParams, page, rowsPerPage]) 

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage + 1); 
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };
 
    const getAllSiteStaff = async () => {
        let searchParams = "";
        Object?.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
        const details = await handleGetData(`${site_staff_labour_url}/?page=${page}&limit=${rowsPerPage}&${searchParams}`);
        // setPage(0)
        return details;
    };


    const getAllProjects = async () => { 
            const details = await handleGetProjectdata(`${projects_url}?page=1&limit=100&sales=active`);
            return details; 
    };

    const handleUpdateProps = async (
        e: { preventDefault: () => void },
        payload: any
    ) => {
        e.preventDefault();
        const res = await handleUpdateData(site_staff_labour_url, payload)
            .then((data) => {
                setRenderData(true);
            })
            .catch((error) => {
                alert(`Invalid Credentials, Try Again ${error.message}`);
            });
        getAllSiteStaff();
        setOpenDialog(false);
        return res;
    };
  
    const searchTableData = async (value: any) => {
        setQueryParams((prev) => {
            return { ...queryParams, ['q'] : value }
        })
        setPage(1)
    };

    const handleRemoveRow = async (Id: number) => {
        const { id } = Id;
        const STAFF_DELETE = `${site_staff_labour_url}/${id}`;
        const details = await handleDeleteData(STAFF_DELETE);
        return details;
    }

    const getProjectData = async () => {
    const res = await handleGetProjectData(`${projects_url}?page=1&limit=100`);
    return res;
    }
 
    resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
    return projectArray.push({ id: Item?.id, name: Item?.projectName })
    });

    useEffect(() => { 
        setSelectedProject(projectArray)
    }, [resProjectData?.items])
  
    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${site_staff_labour_url}/?type=xls${searchParams}`
        const res = handleDownloadData(url, "Staff Management")
        return res;
    }

    const filterByProject = (param:any) => {
        setQueryParams((prev) => {
            return {...queryParams, ['projectId'] : param}
        })
        setPage(1)
    }
 
    const resetFilter = async() => { 
        if([2, 4].includes(session?.user?.role_id)){
            setQueryParams((prev) => {
                return { ['projectId'] : selectedProjectId }
            })
        }else{
            setQueryParams({})
        }
        setSelectedFilterProject('')
        await getAllSiteStaff()
    }    
      
    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Site Staff </Heading>
                    </Blankbox>
                    <Blankbox>
                        { session?.user?.role_id !== 0 &&  <CommonDialog title="Add Staff">
                                <MainForm
                                    data={{
                                        name: '',
                                        mobileNumber: '',
                                        image: '',
                                        projectId: ''
                                    }}
                                    url={site_staff_labour_url}
                                    title={'Add Staff'}
                                    refreshData={getAllSiteStaff}
                                    selectItem={allProjects}
                                />
                            </CommonDialog>}
                    </Blankbox>
                </HeadingBox>

                <TableBox>
                    <TableContainer>
                        <TableMain
                            handleRemoveRow={handleRemoveRow}
                            isLoading={loadProjectData}
                            columns={siteStaffColumns}
                            handleExcelExport={handleExcelExport}
                            rows={data}
                            page={page}
                            rowsPerPage={rowsPerPage}
                            handleChangePage={handleChangePage}
                            handleChangeRowsPerPage={handleChangeRowsPerPage}
                            handleUpdateProps={handleUpdateProps}
                            refreshTableData={getAllSiteStaff}
                            selectItems={allProjects}
                            title={'Staff'}
                            editData={{
                                id: null,
                                name: '',
                            }}
                            url={site_staff_labour_url}
                            searchTableData={searchTableData}
                            resetFilter={resetFilter}
                            filterByProject={filterByProject}
                            selectedFilterProject={selectedFilterProject}
                            setSelectedFilterProject={setSelectedFilterProject}
                            projectItems={selectedProject}
                            totalItems={totalItems}
                        />
                    </TableContainer>
                </TableBox>
            </Wrapper> 
        </>
    );
};

export default withAuth(StaffManagement, [0, 1, 2, 4]); 
