/* eslint-disable react/no-children-prop */
'use client';

import React, {useEffect} from 'react';
import withAuth from '../hooks/withAuth';
import { Heading, HeadingBox } from '../common/styles/Users/styles';
import { Blankbox } from '../components/Table/styles';
import { Wrapper } from './styles';
import dynamic from 'next/dynamic';
import {useSession} from 'next-auth/react'; 
const Dashboard = dynamic(() => import('../components/Dashboard/Dashboard'),{
  ssr: false,
});

function Home() {
  const {data:session} = useSession() 

  useEffect(() => {
    if (session?.user?.accessToken) {  
          localStorage.setItem('token', session?.user?.accessToken);
    }
  }, [session])

  return (
    <>
      <Wrapper>
        <HeadingBox>
          <Blankbox>
            <Heading>Dashboard</Heading>
          </Blankbox>
        </HeadingBox>
        <Dashboard />
      </Wrapper>
    </>

  );
}
export default withAuth(Home, [0, 1, 2, 3, 4, 5]);
