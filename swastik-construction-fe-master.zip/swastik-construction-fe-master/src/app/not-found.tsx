'use client'

import React from "react"
import withAuth from "../hooks/withAuth"
import { Style } from "@mui/icons-material"

function PageNotFound() {

    return (
        <div id="notfound" className="vh-100">
            <div className="notfound vh-100" style={{ textAlign: 'center', margin: 'auto', width: '50%', paddingTop: '100px' }}>
                <div className="notfound-404" />
                <h1>404</h1>
                <h2>Oops! Page Not Be Found</h2>
                <p>
                    Sorry but the page you are looking for does not exist, have been
                    removed. name changed or is temporarily unavailable
                </p>
                <a href="/">Back to dashboard</a>
            </div>
        </div>
    )
}

export default withAuth(PageNotFound, [0, 1, 2, 3, 4, 5])
