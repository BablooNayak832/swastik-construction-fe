import { theme } from '../../src/common/styles/theme';
import styled, { css } from 'styled-components';

export const Wrapper = styled.div`
  background: #f3f2f7;
  ${({ theme }) => css``}

  .MuiButton-contained.Mui-disabled{
    color: white;
    background-color: #e6a3a4 !important;
  }
   th.MuiTableCell-root.MuiTableCell-head.MuiTableCell-sizeMedium {
    text-wrap-mode: nowrap !important;
  }
`;
export const AttendanceFilterDate = styled.div`
  .MuiFormLabel-root {
    font-size: 16px !important;
    font-weight: 400 !important;
    color: rgba(0, 0, 0, 0.6);
  }
`;

export const MarkAttendanceFormLayout = styled.div`
  .css-18lrbqr {
    line-height: 1.9;
    height: 40px;
    border-radius: 4px;
  }

  button.MuiButtonBase-root.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeSmall.MuiButton-containedSizeSmall.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeSmall.MuiButton-containedSizeSmall.css-11qr2p8-MuiButtonBase-root-MuiButton-root {
    margin: 23px auto;
    float: right;
    height: 43px;
  }
`;

export const TableContainer = styled.div`
  .css-1v8abvc-MuiInputBase-root-MuiOutlinedInput-root {
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-style: none;
    background: #0000000d;
  }
  .MuiBox-root.css-lvaj0o {
    padding: 15px;
  }
  .css-1ndpvdd-MuiTableCell-root {
    color: #000;
    font-size: 16px;
    font-style: normal;
    font-weight: 600;
    line-height: normal;
  }

  .css-2rshpx-MuiButtonBase-root-MuiIconButton-root {
    color: ${theme.colors.DarkGray};
  }
`;

export const FormContainer = styled.div`
  padding: 1px 30px;
  .css-1v8abvc-MuiInputBase-root-MuiOutlinedInput-root {
  }
  .css-1d3z3hw-MuiOutlinedInput-notchedOutline {
    border-style: none;
    background: #0000000d;
  }
  .MuiBox-root.css-lvaj0o {
    padding: 15px;
  }
  .css-1ndpvdd-MuiTableCell-root {
    color: #000;
    font-size: 16px;
    font-style: normal;
    font-weight: 600;
    line-height: normal;
  }
`;

export const GalleryItemLayout = styled.div`
  display: grid;
  padding: 10px;
  margin: 10px;
  placeitems: center;
  border: 1px solid #d3cfcf;
  text-align: left;
  justify-content: center;
  width: 250px;
`;
