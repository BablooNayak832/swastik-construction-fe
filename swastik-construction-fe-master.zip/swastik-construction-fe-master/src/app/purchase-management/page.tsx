'use client'
import React,{useEffect,useState} from 'react';
import withAuth from '../../hooks/withAuth'
import {Wrapper} from '../styles';
import {Blankbox,Heading,HeadingBox} from '../../common/styles/Users/styles';
import TableMain from '../../components/Table/Table';
import getRequestAPI from '../../services/getRequest'
import {purchaseOrderColumns} from '../../constants/table-columns'
import { Button } from '@mui/material';
import {useRouter} from 'next/navigation';
import {projects_url, purchase_order_url} from '../../constants/api-routes';
import {useSession} from 'next-auth/react';
import useDownloadExcel from '../../hooks/downloadExcel';
import _ from 'lodash';  
import {stringCapitalization} from 'src/utils/formatString';
import useGet from 'src/hooks/useGet'; 
import moment from 'moment';

function createData(
    sNo: string,
    requestId: string,
    purchaseOrderNo?: any,
    status?: any,
    projectName?: string,
    orderdItems?: any,
    image_url?: string, 
    createdAt: string
) {
    return {
        sNo,
        requestId,
        purchaseOrderNo,
        status,
        projectName,
        orderdItems,
        image_url,  
        createdAt
    }
}

function createItemsData(
    sNo: number,
    productName: string,
    productId: number,
    specification: string,
    size: string,
    unit: string,
    quantity: number,
    rate: string, 
    gst: string,
    vendorDetails?:any, 
    creditNoteDetails?:any,  
    notDeliveredQuantity?:any
) {
    return {
        sNo,
        productName,
        productId,
        specification,
        size,
        unit,
        quantity,
        rate,
        gst,
        vendorDetails,
        creditNoteDetails,
        notDeliveredQuantity 
    }
}

const PurchaseManagement=() => {
    const router=useRouter()
    const {data: session} = useSession()
    const [purchaseOrderList,setPurchaseOrderList]=useState<any>([])
    const [isLoading,setIsLoading]=useState(false)
    const [page,setPage]=useState(1);
    const [rowsPerPage,setRowsPerPage]=useState(10);
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const [totalItems, setTotalItems] = useState(0);
    const [purchaseDataList, setPurchaseDataList] = useState([])  
    const [selectedFilterProject, setSelectedFilterProject] = useState<any>('')
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet()  
    const [selectedProjects, setSelectedProject] = useState<any>(null)
     
    const handleChangePage=(event: any,newPage: number) => {
        setPage(newPage+1);
    };
    
    const handleChangeRowsPerPage=(
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };
        
    useEffect(() => {
        handleGetPurchaseOrder() 
    }, [queryParams, page, rowsPerPage])
    
    const handleGetPurchaseOrder = async () => {
       let searchParams:any = '';
        Object.entries(queryParams)?.map(([key, value]) => {
          searchParams += `${key}=${value}&`
        })
        setIsLoading(false) 
          try {
            if(searchParams !== undefined){
                const res=await getRequestAPI(`${purchase_order_url}?page=${page}&limit=${rowsPerPage}&${searchParams}`)
                if(res) { 
                    setIsLoading(true); 
                    setPurchaseOrderList(res?.data?.orderData)
                }
            }
        } catch(error) {
            return error;
        }
    }

    useEffect(() => {
        handleGetPurchaseOrder()
        getAssignedProjectData()
    },[page, rowsPerPage])

    let productName: any,
        productId: number,
        specification: any,
        size: any,
        unit: any,
        createOrderedItems: any,
        status: any,
        projectName: any,
        creditNoteDetails: any;

    useEffect(() => {
        setTotalItems(purchaseOrderList?.metaData?.totalItems)
        const res = purchaseOrderList?.items?.map((i: any,idx: any) => {
            let purchaseOrderNo;
            let orderedItems: any=[], reqId: any = [], image_url: string, vendorObj:any, notDeliveredQuantity, createdAt:string; 
            i?.items?.map((purchase: any,index: number) => {     
                purchaseOrderNo=i?.purchaseOrderNo; 
                productName=purchase?.materialDetails?.productName;
                productId = purchase?.materialDetails?.id;
                specification=purchase?.materialDetails?.specification;
                size=purchase?.materialDetails?.size;
                unit=purchase?.materialDetails?.unit;
                projectName=purchase?.projectDetails?.projectName;
                status= stringCapitalization(purchase?.status);
                notDeliveredQuantity = purchase?.notDeliveredQuantity !== null ? purchase?.notDeliveredQuantity : null,
                creditNoteDetails = purchase?.creditNotes !== null ?  { creditNoteId: purchase?.creditNotes?.creditNoteNumber,
                    description: purchase?.creditNotes?.reason , 
                    quantity : purchase?.creditNotes?.quantity} : null;
                vendorObj = {vendorId: purchase?.vendorDetails?.id, vendorName: purchase?.vendorDetails?.name}
                createOrderedItems = createItemsData(index+1,productName, productId,specification,size,unit, purchase?.quantity, purchase?.rate, purchase?.GST, vendorObj, creditNoteDetails, notDeliveredQuantity );
                image_url = purchase?.image;
                reqId.push(purchase?.requestId)
                createdAt = moment(purchase?.createdAt).format('DD-MM-YYYY') ?? '';
                if(purchaseOrderNo===i?.purchaseOrderNo) {
                    orderedItems.push(createOrderedItems);
                }
            })
            const uniqReqId = _.uniq(reqId);  
            return createData((page - 1) * rowsPerPage + idx + 1, uniqReqId?.join(', '), i?.purchaseOrderNo, status, projectName, orderedItems, image_url, createdAt)
        });
        setPurchaseDataList(res)
    }, [purchaseOrderList?.items])

     useEffect(() => { 
        let projectArray:any = []
        resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
            return projectArray.push({ id: Item?.id, name: Item?.projectName })
        });
        setSelectedProject(projectArray)
     }, [resProjectData?.items])

     const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
          searchParams += `&${key}=${value}`
        })
        let url = `${purchase_order_url}/?type=allxls${searchParams}`
        const res = handleDownloadData(url, "Purchase Order")
        return res;
     }

     const searchTableData = async (value: any) => {
         setQueryParams((prevValue: any) => {
             return { ...queryParams, ['searchTerm']: value }
            })
         setPage(1)
     }
     
    const getAssignedProjectData = async () => {
        const machinery = await handleGetProjectData(`${projects_url}?page=1&limit=1000`);
        return machinery;
    }

    const filterByProject = (param: any) => {
        setQueryParams((prev) => {
            return {...queryParams, ['projectId'] : param}
        })
        setPage(1)
    }

     const resetFilter = async() => {
        setQueryParams({})
        setSelectedFilterProject('') 
        setPage(1)
        await handleGetPurchaseOrder()
     } 
    
    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>
                            Purchase Management
                        </Heading>
                    </Blankbox>
                   {session?.user?.role_id === 3 && <Blankbox>
                        <Button variant='contained' onClick={() => router.push('/purchase-management/purchase-order')}>
                            Generate PO
                        </Button>
                    </Blankbox>}
                </HeadingBox>

                <TableMain
                    handleExcelExport={handleExcelExport}
                    title='Purchase Management'
                    isLoading={isLoading}
                    columns={purchaseOrderColumns}
                    rows={purchaseDataList}
                    page={page}
                    rowsPerPage={rowsPerPage} 
                    searchTableData={searchTableData}
                    handleChangePage={handleChangePage}
                    handleChangeRowsPerPage={handleChangeRowsPerPage}
                    refreshTableData={handleGetPurchaseOrder}
                    resetFilter={resetFilter}
                    totalItems={totalItems} 
                    selectedFilterProject={selectedFilterProject}
                    setSelectedFilterProject={setSelectedFilterProject} 
                    projectItems={selectedProjects}
                    filterByProject={filterByProject}
                /> 
            </Wrapper>
        </>
    )
}

export default withAuth(PurchaseManagement,[0,1,3])