'use client'
import React, {useEffect} from 'react'
import withAuth from '../../../../hooks/withAuth'
import {useParams, useRouter} from 'next/navigation' 
import PurchaseOrder from  '../../../../components/GeneratePurchaseOrder/PurchaseOrder' 
import useGet from '../../../../hooks/useGet'
import {Wrapper} from '../../../../app/styles'
import {Heading, HeadingBox} from '../../../../common/styles/Users/styles'
import {Blankbox} from '../../../../components/Table/styles'
import {Button} from '@mui/material'
import {ArrowLeftIcon} from '@mui/x-date-pickers'

const PurchaseOrderClose = () => {
    const params = useParams<{ tag: string; item: string }>()
    const { handleGetData , resData } = useGet() 
    const router = useRouter()

    useEffect(() => {
        getPurchaseOrderById()
    },[params]) 

    const getPurchaseOrderById = async() => {
       await handleGetData(`/purchase-head/single-purchase-order/${params?.id}`)
    }
 
    return (
        <>  
          <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>
                            Purchase Order
                        </Heading>
                    </Blankbox>
                   <Blankbox>
                       <Button variant='contained' size='medium' sx={{float: "right"}} onClick={()=> router.back()}> 
                       <ArrowLeftIcon />Go Back
                       </Button> 
                   </Blankbox>
                </HeadingBox>
               <PurchaseOrder data={resData} fetchData={getPurchaseOrderById}/>
            </Wrapper>
        </>
    )
}

export default withAuth(PurchaseOrderClose, [0,1,3])