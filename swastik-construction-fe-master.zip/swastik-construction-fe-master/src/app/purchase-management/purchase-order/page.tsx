'use client'
import React from 'react'
import withAuth from '../../../hooks/withAuth'
import GeneratePurchaseOrder from '../../../components/GeneratePurchaseOrder/index'
import {useSearchParams} from 'next/navigation'

const PurchaseOrder = () => {
    const searchParams = useSearchParams()  
    const searchParamObj:any = {}
    for (const [key, value] of searchParams.entries()) {
        searchParamObj[key] = value
    } 
    
    return (
        <>
            <GeneratePurchaseOrder searchParamObj={searchParamObj}/>
        </>
    )
}

export default withAuth(PurchaseOrder, [3])