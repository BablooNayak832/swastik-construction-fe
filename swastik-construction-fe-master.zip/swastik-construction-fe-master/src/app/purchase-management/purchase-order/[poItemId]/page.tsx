'use client'
import React, { useEffect } from 'react';
import withAuth from '../../../../hooks/withAuth';
import { useParams, useRouter } from 'next/navigation';
import { useState } from "react";
import { Grid, List, ListItem, ListItemText, styled, Typography } from "@mui/material";
import { Heading, HeadingBox } from "../../../../common/styles/Users/styles";
import { Blankbox } from "../../../../components/Table/styles";
import { Wrapper } from "../../../styles";
import { ContainerMain } from '../../../../../src/common/styles/Dashboard/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Button } from '@mui/material';
import Paper from '@mui/material/Paper';
import getRequestAPI from '../../../../services/getRequest'
import _ from 'lodash';
import { useSearchParams } from 'next/navigation'; 
import { purchase_order_detail_url } from '../../../../constants/api-routes';
import moment from 'moment';
import useDownloadPDF from 'src/hooks/useDownloadPDF'; 
import {ArrowLeftIcon} from '@mui/x-date-pickers';
import {stringCapitalization} from 'src/utils/formatString'; 
import {LoadingIcon} from '../../../../../assets/svg/LoadingIcon'

interface Data {
    purchaseOrderNo: any;
    reqId: string;
    status: string;
    orderItems: string;
    projectName: string;
    orderDate: string;
}

function createData(
    purchaseOrderNo: any,
    reqId: string,
    status: string,
    orderItems: any,
    projectName:string,
    orderDate: string,
): Data {
    return { purchaseOrderNo, reqId, status, orderItems , projectName, orderDate};
}

function createItemsData(
    sNo: number,
    poItemId: string,
    productName: string,
    productId: number,
    itemName?:string,
    specification?: string,
    size?: string,
    unit: string,
    rate?: string,
    gst?:string,
    quantity: any,
    approvedQty: number,
    brandName: string,
    vendorName: string,
    remark:string,
) {
    return {
        sNo,
        poItemId,
        productName,
        productId,
        itemName,
        specification,
        size,
        unit,
        rate,
        gst,
        quantity,
        approvedQty,
        brandName,
        vendorName,
        remark,
    }
}

const Demo = styled('div')(({ theme }) => ({
    backgroundColor: theme.palette.background.paper,
}));

const PurchaseOrderByPOItemId = () => {
    const searchParams = useSearchParams()
    const router = useRouter()
    const params = useParams<{ tag: string; item: string }>()
    const [orderDetailData, setOrderDetailData] = useState([])
    const [loading, setLoading] = useState(false)
    const purchaseOrderId = searchParams.get('purchaseOrderNo')
    const { handleDownloadPDF } = useDownloadPDF()
    const [pdfLoading, setPdfLoading] = useState(false)

    const getDetailsOfPurchaseOrder = async () => {
        const purchaseOrderId = searchParams.get('purchaseOrderNo')
        setLoading(true)
        try {
            const getDetailsOfPurchaseOrder = getRequestAPI(`${purchase_order_detail_url}/${purchaseOrderId}`)
                .then((response: any) => {
                    if (!!response?.data) {
                        setOrderDetailData(response?.data)
                        setLoading(false)
                    }
                })
            return getDetailsOfPurchaseOrder;
        } catch (error) {
            return error;
        }
    }
 
    useEffect(() => {
        getDetailsOfPurchaseOrder()
    }, [])

    const mergeQuantities = (data:any) => {
        const merged :any= {};  
        data.forEach((item:any) => {
          const { productId, quantity, approvedQty } = item; 
          if (merged[productId]) {
            merged[productId].quantity += quantity;
            merged[productId].approvedQty += approvedQty;
          } else {
            merged[productId] = { ...item };
          }
        }); 
        return Object.values(merged);
    }

    let reqId: string, status: string, orderDate: string, poItems: any, poItemId, gst, productName, productId, itemName, rate, specification, remark, size, unit, quantity, approvedQty, createOrderedItems, vendorName: string, brandName: string, projectName:string;
    const orderDetails = orderDetailData?.map((i: any, idx: any) => {
        let orderedItems: any = []; 
        i?.items?.map((order: any, index: number) => { 
            
            reqId = _.uniq(order?.vendorItems?.map((i: any) => i?.requestId)).join(', ');
            if (order?.poItemId == params?.poItemId) {
                order?.vendorItems?.map((vItem: any) => {  
                    poItemId = vItem?.poItemId;
                    productName = vItem?.materialDetails?.productName;
                    productId = vItem?.materialId
                    itemName = vItem?.materialDetails?.itemName !== null ? vItem?.materialDetails?.itemName : "_";
                    specification = vItem?.materialDetails?.specification !== null ? vItem?.materialDetails?.specification : "_";
                    size = vItem?.materialDetails?.size !== null ? vItem?.materialDetails?.size : "_";
                    unit = vItem?.materialDetails?.unit;
                    quantity = vItem?.quantity;
                    approvedQty = vItem?.materialRequestInfo?.quantity;
                    status = stringCapitalization(vItem?.status); 
                    brandName = vItem?.brandDetails?.brandName !== null ? vItem?.brandDetails?.brandName : "_";
                    vendorName = vItem?.vendorDetails?.name;
                    gst = vItem?.GST;
                    rate = vItem?.rate;
                    projectName = vItem?.projectDetails?.projectName;
                    remark = vItem?.remark;
                    createOrderedItems = createItemsData(index + 1, poItemId, productName, productId, itemName, specification, size, unit, rate ,gst, quantity, approvedQty, brandName, vendorName, remark);
                    orderedItems.push(createOrderedItems);
                    poItems = mergeQuantities(orderedItems)  
                    orderDate = moment(vItem?.createdAt).format('DD-MM-YYYY') 
                })
            }
        }) 
        return createData(purchaseOrderId, reqId, status, poItems, projectName, orderDate)
    });

    const downloadPageAsPDF = async(poNo: number | any, poItemId: string | any) => { 
        setPdfLoading(true)
        const res = await handleDownloadPDF(`/purchase-head/pdf/${poNo}?poItemId=${poItemId}`, `PO-${poItemId}`)
        setPdfLoading(false)
        return res;
    }

    return (
        <>
            <Wrapper> 
                    <HeadingBox>
                        <Blankbox>
                            <Heading>Order Details {params?.poItemId}</Heading>
                        </Blankbox>
                        <Blankbox>
                            <Button variant='contained' onClick={() => downloadPageAsPDF(purchaseOrderId, params?.poItemId)}>
                              { pdfLoading ? <LoadingIcon/> : "Download PDF"}
                            </Button>
                            <Button style={{ float: 'right', margin: '0 5px' }} onClick={() => router.back()} variant='contained'><ArrowLeftIcon />Go Back</Button>
                        </Blankbox>
                    </HeadingBox> 
                <ContainerMain>
                    <Grid item lg={12} xs={12} md={12}>
                        <div id='purchase-order-form'>
                            {loading ? <h1>Loading...</h1> :
                                orderDetails?.map((orderItem: any) => {  
                                    
                                    return (
                                        <>
                                            <Grid container spacing={2}>
                                                <Grid item lg={12} xs={12} md={12}>
                                                    <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong> Project: </strong>  {orderItem?.projectName}</span>
                                                            </div>
                                                        );
                                                        }} />
                                                    <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong>PO Item ID: </strong> {params?.poItemId ?? "_"}</span>
                                                            </div>
                                                        );
                                                        }} /> 
                                                    <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong>Request No.: </strong> {orderItem?.reqId ?? "_"}</span>
                                                            </div>
                                                        );
                                                        }} /> 
                                                    <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong>Status: </strong> {orderItem?.status ?? "_"}</span>
                                                            </div>
                                                        );
                                                        }} /> 
                                                    <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong>Vendor Name: </strong> {vendorName ?? "_"}</span>
                                                        </div>
                                                    );
                                                    }} /> 
                                                   <Typography paragraph={true} component={() => {
                                                    return (
                                                        <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                        <span><strong>Ordered Date: </strong> {orderItem?.orderDate ?? "_"}</span>
                                                        </div>
                                                    );
                                                    }} /> 
                                                </Grid>
                                                
                                                <Grid item lg={12} xs={12} md={12}>
                                                    <TableContainer component={Paper}>
                                                        <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                                                            <TableHead>
                                                                <TableRow>
                                                                    <TableCell sx={{fontWeight: 'bold'}} width={'70px'}>S No.</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Product Name</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Type / Grade</TableCell> 
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Specification</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Size</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Approved Qty</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'100px'}>Ordered Qty</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Unit</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Rate</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>GST</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Brand Name</TableCell>
                                                                    <TableCell sx={{fontWeight: 'bold'}} align="left" width={'20px'}>Remark</TableCell>
                                                                </TableRow>
                                                            </TableHead>
                                                            <TableBody> 
                                                                {orderItem?.orderItems?.filter((item) => item?.poItemId === params?.poItemId)?.map((row: any, i: number) => {      
                                                                   return (
                                                                        <>
                                                                            {row?.productName !== undefined &&
                                                                                <TableRow key={i} >
                                                                                    <TableCell>{i + 1}</TableCell>
                                                                                    <TableCell align="left" >{row?.productName}</TableCell>
                                                                                    <TableCell align="left" >{row?.itemName}</TableCell> 
                                                                                    <TableCell align="left" >{row?.specification?.length ? row?.specification : "_"}</TableCell>
                                                                                    <TableCell align="left" >{row?.size?.length ? row?.size : "_"}</TableCell>
                                                                                    <TableCell align="left" >{row?.approvedQty}</TableCell>
                                                                                    <TableCell align="left" >{row?.quantity}</TableCell>
                                                                                    <TableCell align="left" >{row?.unit}</TableCell>
                                                                                    <TableCell align="left" width={'20px'}>{!!row?.rate ? row?.rate : "_" }</TableCell>
                                                                                    <TableCell align="left" >{row?.gst}</TableCell>
                                                                                    <TableCell align="left" >{row?.brandName !== undefined ? row?.brandName : '_'}</TableCell>
                                                                                    <TableCell align="left" >{row?.remark}</TableCell> 
                                                                                </TableRow>
                                                                            }
                                                                        </>
                                                                    )
                                                                }
                                                                )}
                                                            </TableBody>
                                                        </Table>
                                                    </TableContainer>
                                                </Grid>
                                            </Grid>
                                        </>
                                    )
                                })
                            }
                        </div>
                    </Grid>
                </ContainerMain>
            </Wrapper>

        </>
    )
}

export default withAuth(PurchaseOrderByPOItemId, [0,1,3])