'use client'
import React, { useEffect } from 'react';
import withAuth from '../../../hooks/withAuth';
import { useParams, useRouter } from 'next/navigation';
import { useState } from "react";
import { Grid, IconButton, Tooltip, Typography } from "@mui/material";
import { Heading, HeadingBox } from "../../../common/styles/Users/styles";
import { Blankbox } from "../../../components/Table/styles";
import { Wrapper } from "../../styles";
import { ContainerMain } from '../../../../src/common/styles/Dashboard/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import { Button } from '@mui/material';
import Paper from '@mui/material/Paper';
import getRequestAPI from '../../../services/getRequest'
import _ from 'lodash';
import { Visibility } from '@mui/icons-material';
import { purchase_order_detail_url } from '../../../constants/api-routes';
import moment from 'moment';
import {ArrowLeftIcon} from "@mui/x-date-pickers";
import {stringCapitalization} from 'src/utils/formatString';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf'; 
import useDownloadPDF from 'src/hooks/useDownloadPDF';


interface Data {
    purchaseOrderNo: any;
    reqId: string;
    status: string;
    orderItems: string;
    orderDate: string;
}

function createData(
    purchaseOrderNo: any,
    reqId: string,
    status: string,
    orderItems: any,
    orderDate: string,
): Data {
    return { purchaseOrderNo, reqId, status, orderItems, orderDate};
}

function createItemsData(
    sNo: number,
    poItemId: string,
    vendorName?: string,
) {
    return {
        sNo,
        poItemId,
        vendorName,
    }
}

const OrderDetail = () => {
    const router = useRouter()
    const params = useParams<{ tag: string; item: string }>()
    const [orderDetailData, setOrderDetailData] = useState([])
    const [loading, setLoading] = useState(false)  
    const { handleDownloadPDF } = useDownloadPDF()

    useEffect(() => {
        getDetailsOfPurchaseOrder()
    }, [])

    const getDetailsOfPurchaseOrder = async () => {
        setLoading(true)
        try {
            const getDetailsOfPurchaseOrder = getRequestAPI(`${purchase_order_detail_url}/${params.id}`)
                .then((response: any) => {
                    if (!!response?.data) {
                        setLoading(false)
                        setOrderDetailData(response?.data)
                    }
                })
            return getDetailsOfPurchaseOrder;
        } catch (error) {
            return error;
        }
    }

    const downloadPageAsPDF = async(poNo?: number) => {  
        let param = {};
        let orderId = poNo !== undefined ? poNo : params.id;
        let searchParam = ''
        if(poNo !== undefined){
            param.poItemId = poNo
        }
       if(Object.keys(param).length){
          searchParam = `?poItemId=${param?.poItemId}`
       } 
       const res = await handleDownloadPDF(`/purchase-head/pdf/${params.id}${searchParam}`, `PO-${orderId}`)
       return res;
    }
 
    let reqId: string, status: string, poItemId, createOrderedItems, vendorName, orderDate:string;
    let purchaseOrderNo: number; 
    const orderDetails = orderDetailData?.map((i: any, idx: any) => {
        let orderedItems: any = [];
        i?.items?.map((order: any, index: number) => {
            reqId= i?.requestIds.join(',');
            status= i?.status;
            purchaseOrderNo = params?.id;
            poItemId = order?.poItemId;
            vendorName = order?.vendorName;
            createOrderedItems = createItemsData(index + 1, poItemId, vendorName);
            orderedItems.push(createOrderedItems);
            orderDate = moment( _.uniqBy(order?.vendorItems?.map(item => item?.createdAt), 'createdAt')?.join('')).format('DD-MM-YYYY')
        })
        return createData(purchaseOrderNo, reqId, status, orderedItems, orderDate)
    });  

    return (
        <>
            <Wrapper> 
                <HeadingBox>
                    <Blankbox>
                        <Heading>Order Details </Heading>
                    </Blankbox> 
                    <Blankbox>
                        <Button style={{ float: 'right', margin: '10px 0 0 5px' }} onClick={() => downloadPageAsPDF() } variant='contained'>Download PO Summary</Button>
                        <Button style={{ float: 'right', margin: '10px 0' }} onClick={() => router.back()} variant='contained'> <ArrowLeftIcon />Go Back</Button>
                    </Blankbox>  
                </HeadingBox> 
                <ContainerMain>
                    <div id='order-detail'>
                        {loading ? <h1>Loading...</h1> :
                            orderDetails?.map((orderItem: any) => {  
                                return (
                                    <>
                                        <Grid container spacing={2}>
                                            <Grid item lg={4} xs={3} md={3}> 
                                                <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong> Purchase Order No. : </strong>  {orderItem?.purchaseOrderNo}</span>
                                                            </div>
                                                        );
                                                        }} />
                                                 <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong> Ordered Date: </strong>  {orderItem?.orderDate}</span>
                                                            </div>
                                                        );
                                                        }} />
                                                 <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong> Status: </strong>  {stringCapitalization(orderItem?.status)}</span>
                                                            </div>
                                                        );
                                                        }} />
                                                 <Typography paragraph={true} component={() => {
                                                        return (
                                                            <div style={{ fontSize: '17px', lineHeight:'1.6rem', width: '100%' }}>
                                                            <span><strong> Request No.: </strong>  {orderItem?.reqId}</span>
                                                            </div>
                                                        );
                                                        }} />
                                            </Grid> 
                                            <Grid item lg={12} xs={12} md={12}>
                                                <TableContainer component={Paper}>
                                                    <Table sx={{ minWidth: 650, border: '1px solid #3333' }} aria-label="simple table">
                                                        <TableHead>
                                                            <TableRow>
                                                                <TableCell sx={{fontWeight: 'bold'}} width={'70px'}>S No.</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>PO Item Id</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'50px'}>Vendor</TableCell>
                                                                <TableCell sx={{fontWeight: 'bold'}} align="left" width={'70px'}>Action</TableCell>
                                                            </TableRow>
                                                        </TableHead>
                                                        <TableBody>
                                                            {orderItem?.orderItems?.map((row, i: number) => {
                                                                return (
                                                                    <>
                                                                        {
                                                                            <TableRow key={row?.name}>
                                                                                <TableCell >{i + 1}</TableCell>
                                                                                <TableCell align="left" >{row?.poItemId?.length ? row?.poItemId : "_"}</TableCell>
                                                                                <TableCell align="left" >{row?.vendorName}</TableCell>
                                                                                <TableCell align="left">
                                                                                    <Tooltip title="Download PDF">                                          
                                                                                        <IconButton  
                                                                                            sx={{color: 'red'}}
                                                                                            size="small" 
                                                                                            onClick={( e ) => downloadPageAsPDF(row?.poItemId)}
                                                                                        >
                                                                                          <PictureAsPdfIcon/>
                                                                                        </IconButton> 
                                                                                    </Tooltip>

                                                                                    <Tooltip title="View">  
                                                                                        <IconButton 
                                                                                            sx={{color: 'red'}}
                                                                                            size="small" 
                                                                                            onClick={( e ) => router.push(`/purchase-management/purchase-order/${row?.poItemId}?purchaseOrderNo=${orderItem?.purchaseOrderNo}`)}
                                                                                        >
                                                                                            <Visibility />
                                                                                        </IconButton> 
                                                                                    </Tooltip>
                                                                                </TableCell>
                                                                            </TableRow>
                                                                        }
                                                                    </>
                                                                )
                                                            }
                                                            )}
                                                        </TableBody>
                                                    </Table>
                                                </TableContainer>
                                            </Grid>
                                        </Grid>
                                    </>
                                )
                            })
                        }
                    </div> 
                </ContainerMain>
            </Wrapper>

        </>
    )
}

export default withAuth(OrderDetail, [0, 1, 3])