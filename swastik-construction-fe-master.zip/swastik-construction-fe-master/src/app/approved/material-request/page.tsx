'use client'
import React, { useEffect, useState } from "react";
import withAuth from "../../../hooks/withAuth";
import TableMain from '../../../components/Table/Table' 
import { Heading, HeadingBox } from "../../../common/styles/Users/styles";
import { Blankbox } from "../../../components/Table/styles";
import useGet from "../../../hooks/useGet";
import { Wrapper } from "../../styles";
import usePatch from "../../../hooks/usePatch";
import { useAllowedNavigation } from "../../../context/context";
import { approvedMaterialReqColumns } from "../../../constants/table-columns";
import { projects_url, materialRequestList, materialRequestUpdate } from "../../../constants/api-routes";
import useDownloadExcel from "../../../hooks/downloadExcel";
import {stringCapitalization} from "src/utils/formatString";

function createRequestData(
    reqId?: number,
    sNo: number,
    productName?: string,
    location?: string,
    type?: string,
    categoryName?: string,
    projectId?: number,
    projectName?: string,
    quantity?: number,
    approvedBy?: string,
    reqStatus?: string,
    approveStatus?: string,
    senderName?: string,
    items?: []
): any {
    return {
        reqId,
        sNo,
        productName,
        location,
        type,
        categoryName,
        projectId,
        projectName,
        quantity,
        approvedBy,
        reqStatus,
        approveStatus,
        senderName,
        items
    }
}

function createRequestItem(
    id: number,
    machineryOrPrductName: string,
    size: number,
    unit: string,
    quantity: number,
    remark: string,
): any {
    return {
        id,
        machineryOrPrductName,
        size,
        unit,
        quantity,
        remark,
    }
}

const Request = () => { 
    const { resData: resRequestListData, handleGetData: handleRequestListData, isLoading } = useGet()
    const { resData: resProjectData, handleGetData: handleGetProjectData } = useGet() 
    const { handleUpdateData } = usePatch(); 
    const { setOpen } = useAllowedNavigation();
    const { handleDownloadData } = useDownloadExcel() 
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [queryParams , setQueryParams] = useState({})
    const [selectedFilterProject, setSelectedFilterProject] = useState<any>('')
    const [selectedProject, setSelectedProject] = useState<any>(null)
    const [requestDataList, setRequestDataList ] = useState([])
    const [totalItems, setTotalItems] = useState(0);

    let projectArray: any = []

    useEffect(() => {
        getRequestList() 
    }, [page, rowsPerPage])

    useEffect(() => {
      getRequestList()
    },[queryParams, page, rowsPerPage])

    useEffect(() => {
        getProjectData()
    }, [])

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage+1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };
 
    useEffect(() => {
        setTotalItems(resRequestListData?.metaData?.totalItems)
        const data = resRequestListData?.items?.map((i: any, idx: any) => {
            let sNo, itemId, machineryOrPrductName, projectName, projectId, location, materialType, categoryName, quantity, approveStatus, reqStatus, approvedBy, senderName, createitems, itemSize, itemUnit;
            let items: any = []
    
            i?.items?.map((request: any) => {
                itemId = request?.id;
                sNo = (page - 1) * rowsPerPage + idx + 1;
                projectId = request.projectDetails?.id;
                projectName = request?.projectDetails?.projectName;
                location = request?.projectDetails?.location;
                materialType = request.typeId === 1 ? "Material" : "Machinery";
                categoryName = (request?.productDetails !== null) ? (request?.productDetails?.category?.categoryName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.categoryDetails?.categoryName) : 'Null';
                machineryOrPrductName = (request?.productDetails !== null) ? (request?.productDetails?.productName) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.machineryName) : 'Null';
                itemSize = (request?.productDetails !== null) ? (request?.productDetails?.size) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.size) : 'Null';
                itemUnit = (request?.productDetails !== null) ? (request?.productDetails?.unit) : (request?.machineryDetails !== null) ? (request?.machineryDetails?.unit) : 'Null';
                quantity = request?.quantity;
                approveStatus = request?.status;
                reqStatus = stringCapitalization(request?.status); 
                approvedBy = request?.acceptedby !== null ? request?.acceptedby?.name : "Not specified";
                senderName = request?.requesterDetails?.name;
                createitems = createRequestItem(itemId, machineryOrPrductName, itemSize, itemUnit, request?.quantity, request?.remark);
                items.push(createitems);
            }) 
            return createRequestData(i?.request, sNo, machineryOrPrductName, location, materialType, categoryName, projectId, projectName, quantity, approvedBy, reqStatus, approveStatus, senderName, items)
        });
        setRequestDataList(data) 
    },[resRequestListData])

    const getRequestList = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `${key}=${value}&`
        })
        const request = await handleRequestListData(`${materialRequestList}/?page=${page}&limit=${rowsPerPage}&type=1&${searchParams}`);
        return request;
    } 

    const handleUpdateRequest = async (e: any, payload: any) => {
        e.preventDefault();
        const res = await handleUpdateData(materialRequestUpdate, payload)
            .then((data: any) => {
                return data;
            })
            .catch((error: any) => {
                alert(`Invalid Credentials, Try Again ${error.message}`);
            });
        setOpen(false);
        // getRequest();
        getRequestList()
        return res;
    }

    const searchTableData = async (value: any) => {
        setQueryParams((preValue: any) => {
            return { ...queryParams, ['q']: value }
          }) 
        setPage(1)
    }

    const removeRequest = async (mId: number) => {
        // const { id } = mId;
        // const MACHINERY_DELETE = `/machinery/${id}`;
        // const details = await handleDeleteData(MACHINERY_DELETE);
        // return details;
    };

    const filterActiveUser = async (param: any) => {
        setQueryParams((value: any) => {
          return { ...queryParams, [param.key]: param.value }
        }) 
      }

    const filterMenuOption = [
        { id: 1, menuText: 'Pending', fun: () => filterActiveUser({ key: 'status', value: 'pending' }) },
        { id: 2, menuText: 'Ordered', fun: () => filterActiveUser({ key: 'status', value: 'ordered' }) },
        { id: 3, menuText: 'Partial Delivered', fun: () => filterActiveUser({ key: 'status', value: 'partialDelivered' }) },
        { id: 4, menuText: 'Approved', fun: () => filterActiveUser({ key: 'status', value: 'approved' }) }
     ]

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${materialRequestList}/?type=xls${searchParams}`
        const res = handleDownloadData(url, "Material Request")
        return res;
    }

    const getProjectData = async () => {
    const res = await handleGetProjectData(`${projects_url}?page=${page}&limit=100`);
    return res;
    }
     
    resProjectData?.items?.length && resProjectData?.items?.map((Item: any, idx: any) => {
    return projectArray.push({ id: Item?.id, name: Item?.projectName })
    });

    const filterByProject = (param:any) => {
        setQueryParams((prev) => {
            return {...queryParams, ['projectId'] : param}
        })
    }

    const resetFilter = async() => {
        setQueryParams({})
        setSelectedFilterProject('')
        await getRequestList()
    }

    useEffect(() => { 
        setSelectedProject(projectArray)
    }, [resProjectData?.items])
  
    return (
        <>
            <Wrapper> 
                    <HeadingBox>
                        <Blankbox>
                            <Heading>Material Request</Heading>
                        </Blankbox>
                    </HeadingBox>
                    <TableMain
                        isVisible={false}
                        title='Material Request'
                        isLoading={isLoading}
                        columns={approvedMaterialReqColumns}
                        rows={requestDataList}
                        page={page}
                        filterMenuOption={filterMenuOption}
                        handleExcelExport={handleExcelExport}
                        rowsPerPage={rowsPerPage}
                        handleChangePage={handleChangePage}
                        handleChangeRowsPerPage={handleChangeRowsPerPage}
                        refreshTableData={getRequestList}
                        handleRemoveRow={removeRequest}
                        handleUpdateProps={handleUpdateRequest}
                        searchTableData={searchTableData}
                        resetFilter={resetFilter}
                        filterByProject={filterByProject}
                        selectedFilterProject={selectedFilterProject}
                        setSelectedFilterProject={setSelectedFilterProject}
                        projectItems={selectedProject}
                        totalItems={totalItems}
                    /> 
            </Wrapper>
        </>
    );
}

export default withAuth(Request, [3]);