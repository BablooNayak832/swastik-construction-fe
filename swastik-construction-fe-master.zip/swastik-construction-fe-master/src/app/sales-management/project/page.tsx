
'use client';
import { TableContainer, Wrapper } from '../../styles';
import React, { useEffect, useState } from 'react';
import withAuth from '../../../hooks/withAuth';
import {
    HeadingBox,
    Blankbox,
    Heading,
    TableBox,
} from '../../../common/styles/Users/styles';
import { 
    assignProject,
    assignUserType,
} from '../../../Interfaces/ProjectsInterface';
import dynamic from 'next/dynamic';
import { useAllowedNavigation } from '../../../context/context';
import useGet from '../../../hooks/useGet';
import { projectColumnsForSales } from '../../../constants/table-columns';
import { project_update_url, projects_url, all_user_url } from '../../../constants/api-routes';
import usePatch from '../../../hooks/usePatch';
import moment from 'moment'; 
import useDownloadExcel from '../../../hooks/downloadExcel';
const TableMain = dynamic(() => import('../../../components/Table/Table'), {
    ssr: false,
});

function createData(
    id: number,
    sNo: number,
    projectName: string,
    projectId: string | number,
    location: string,
    assignproject: assignProject,
    supervisior: assignUserType,
    projectManagers: assignUserType,
    siteManagers: assignUserType,
    purchaseManager: assignUserType,
    startDate: string,
    endDate: string,
    progress?: string,
    status?: any,
    salesStatus?: string,
    description?: string,
    remark?: string
): any {
    return {
        id,
        sNo,
        projectName,
        projectId,
        location,
        assignproject,
        supervisior,
        projectManagers,
        siteManagers,
        purchaseManager,
        startDate,
        endDate,
        progress,
        status,
        salesStatus,
        description,
        remark
    };
}

const Projects = () => {
    const [page, setPage] = useState(1);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [data, setData] = useState([]);
    const [allUserData, setAllUserData] = useState<any>([]);
    const { setOpen, setRenderData } = useAllowedNavigation();
    const { handleDownloadData } = useDownloadExcel()
    const [queryParams, setQueryParams] = useState({})
    const { resData, handleGetData } = useGet();
    const { handleUpdateData: updateProjectApproval } = usePatch()
    const {
        resData: getUser,
        isLoading,
        handleGetData: handleGetUsersdata,
    } = useGet();
    const { handleUpdateData } = usePatch();
    const [totalItems, setTotalItems] = useState(0);

    useEffect(() => {
        GetAllProjectss();
        GetAllUsers();
    }, [page, rowsPerPage]);

    useEffect(() => {
        GetAllProjectss(); 
    },[queryParams, page, rowsPerPage]);

    useEffect(() => {
        setTotalItems(resData?.meta?.totalItems)
        const projectData = resData?.items?.map((i: any, index: number) => {
            const originalStartDate = moment(i?.startDate);
            const originalEndDateDate = moment(i?.endDate);
            const assignSupervisors = i?.assignProject?.filter((assign: any) => assign?.admin?.role?.key === "supervisior")
            const assignSiteManager = i?.assignProject?.filter((assign: any) => assign?.admin?.role?.key === "siteHead")
            const assignProjectManager = i?.assignProject?.filter((assign: any) => assign?.admin?.role?.key === "projectHead")
            const assignPurchaseManager = i?.assignProject?.filter((assign: any) => assign?.admin?.role?.key === "purchaseHead")
            const projectStatus = i?.status === 'upcoming' ? 'Up Coming' : i?.status === 'running' ? "In Progress" : i?.status === 'completed' ? 'Completed' : i?.status === 'onhold' ? "On Hold" : i?.status === "resume" ? "In Progress" : i?.status === "rejected" ? "Rejected" : i?.status === "notStartedYet" ? "Not Started Yet" : i?.status;
            const assignedUsers = i?.assignProject?.filter(fItem => fItem?.user !== null)?.map(item => item)
            const salesStatus = i?.salesStatus === "active" ? "Approved" : i?.salesStatus === "rejected" ? "Rejected" : i?.salesStatus === "pending" ? "Pending" : "Not Specified";
            return createData(
                i?.id,
                (page - 1) * rowsPerPage + index + 1,
                i?.projectName,
                i?.siteId,
                i?.location,
                assignedUsers,
                assignSupervisors,
                assignProjectManager,
                assignSiteManager,
                assignPurchaseManager,
                originalStartDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
                    ? originalStartDate.format('DD-MM-YYYY')
                    : 'Not specified',
                originalEndDateDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
                    ? originalEndDateDate.format('DD-MM-YYYY')
                    : 'Not specified',
                '10%',
                projectStatus,
                salesStatus,
                i?.description,
                i?.remark
            );
        });

        setRenderData(true);
        setData(projectData);
        setAllUserData(getUser?.items);
    }, [resData?.items]); 

    const handleChangePage = (event: any, newPage: number) => {
        setPage(newPage+1);
    };

    const handleChangeRowsPerPage = (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(1); 
    };

    const GetAllProjectss = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        }) 
        const details = await handleGetData(`${projects_url}/?page=${page}&limit=${rowsPerPage}&${searchParams}`);
        return details; 
    };

    const GetAllUsers = async () => {
        try {
            const details = await handleGetUsersdata(`${all_user_url}?page=1&limit=1000`);
            return details;
        } catch (err) {
            return err;
        }
    };

    const handleUpdateProps = async (
        e: { preventDefault: () => void },
        payload: any
    ) => {
        e.preventDefault();
        const res = await handleUpdateData(project_update_url, payload)
            .then((data) => {
                setRenderData(true);
            })
            .catch((error) => {
                alert(`Invalid Credentials, Try Again ${error.message}`);
            });
        setOpen(false);
        GetAllProjectss();
        return res;
    };
 
    const filterActiveUser = async (param: any) => {
        setQueryParams((value: any) => {
            return { ...queryParams, [param.key]: param.value }
        }) 
        setPage(1)
    }

    const filterMenuOption = [
        { id: 1, menuText: 'Active Projects', fun: () => filterActiveUser({ key: 'sales', value: 'active' }) },
        { id: 2, menuText: 'Rejected Projects', fun: () => filterActiveUser({ key: 'sales', value: 'rejected' }) },
        ]

    const searchTableData = async (value: any) => {
        setQueryParams((prevValue: any) => {
            return { ...queryParams, ['q']: value }
        }) 
        setPage(1)
    };

    const handleApproveProject = async (
        payload: any
    ) => {
        const res = await updateProjectApproval(project_update_url, payload) 
        setRenderData(true);
        GetAllProjectss();
        return res;
    };

    const handleExcelExport = async () => {
        let searchParams = "";
        Object.entries(queryParams)?.map(([key, value]) => {
            searchParams += `&${key}=${value}`
        })
        let url = `${projects_url}/?type=xls${searchParams}`
        const res = handleDownloadData(url, "Sales Projects")
        return res;
    } 

    const resetFilter = async() => {
        setQueryParams({})
        await GetAllProjectss() 
    } 
         
    return (
        <>
            <Wrapper>
                <HeadingBox>
                    <Blankbox>
                        <Heading>Project Overview</Heading>
                    </Blankbox>
                </HeadingBox>

                <TableBox>
                    <TableContainer>
                        <TableMain
                            searchTableData={searchTableData} 
                            filterMenuOption={filterMenuOption} 
                            isLoading={isLoading}
                            columns={projectColumnsForSales}
                            rows={data}
                            handleExcelExport={handleExcelExport}
                            page={page}
                            rowsPerPage={rowsPerPage}
                            handleChangePage={handleChangePage}
                            handleChangeRowsPerPage={handleChangeRowsPerPage}
                            handleUpdateProps={handleUpdateProps}
                            refreshTableData={GetAllProjectss}
                            selectItems={allUserData}
                            title={'Sales Projects'}
                            editData={{
                                project: {
                                    id: 1,
                                    projectName: '',
                                    location: '',
                                    startDate: '',
                                    endDate: ''
                                },
                                assignProject: {
                                    projectId: '',
                                    projectManager: [],
                                    supervisior: [],
                                    purchaseManager: [],
                                    siteManager: []
                                }
                            }}
                            url={project_update_url}
                            handleApproveProject={handleApproveProject}
                            resetFilter={resetFilter}
                            totalItems={totalItems}
                        />
                    </TableContainer>
                </TableBox>
            </Wrapper> 
        </>
    );
};

export default withAuth(Projects, [0, 1]);
