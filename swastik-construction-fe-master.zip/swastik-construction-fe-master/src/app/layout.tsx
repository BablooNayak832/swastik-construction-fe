'use client';

import StyledComponentsRegistry from './lib/registry';
import { ThemeProvider } from 'styled-components';
import { GlobalStyles } from '../common/styles/global';
import { theme } from '../common/styles/theme';
import React, { Suspense } from 'react';
import MetadataContext from '../context/context';
import SessionProviders from '../_providers/session-providers'
import Providers from '../redux/Providers';
import { Barlow, Inter, Poppins, Montserrat, Lato } from 'next/font/google';
import Head from './head'
import Loading from './loading'
 


export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <Head />
      <body>
        <StyledComponentsRegistry>
          <>
            <GlobalStyles />
            <MetadataContext>
              <ThemeProvider theme={theme}>
                <Suspense fallback={<center>Loading...</center>}>
                  <SessionProviders>
                    <Providers>
                      {children}
                    </Providers>
                  </SessionProviders>
                </Suspense>
              </ThemeProvider>
            </MetadataContext>
          </>
        </StyledComponentsRegistry>
      </body>
    </html>
  );
}
