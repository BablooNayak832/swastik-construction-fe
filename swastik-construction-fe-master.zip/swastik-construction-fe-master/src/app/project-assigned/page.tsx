'use client'
import React from "react";
import withAuth from "../../hooks/withAuth";
import dynamic from 'next/dynamic';
const ProjectAssigned = dynamic(() => import('../../components/ProjectAssigned'));

const ProjectAssignedPage = () => {
    return (<>
        <ProjectAssigned />
    </>);
}

export default withAuth(ProjectAssignedPage, [2, 4, 5]);