'use client';
import { TableContainer, Wrapper } from '../styles';
import React, { useEffect, useState } from 'react';
import withAuth from '../../hooks/withAuth';
import {
  HeadingBox,
  Blankbox,
  Heading,
  TableBox,
} from '../../common/styles/Users/styles';
import {
  Data,
  assignProject,
  assignUserType,
} from '../../Interfaces/ProjectsInterface';
import dynamic from 'next/dynamic';
import { useAllowedNavigation } from '../../context/context';
import CommonDialog from '../../components/CommonDialog/CommonDialog';
import MainForm from '../../components/common-form';
import useGet from '../../hooks/useGet';
import { projectColumns } from '../../constants/table-columns';
import { project_update_url, projects_url, all_user_url } from '../../constants/api-routes';
import usePatch from '../../hooks/usePatch';
import moment from 'moment'; 
import { useSession } from 'next-auth/react';
import useDownloadExcel from 'src/hooks/downloadExcel'; 
import { formateDate } from '../../utils/formatDate';
const  TableMain = dynamic(() => import('../../components/Table/Table'), {
  ssr: false,
});

const Projects = () => {
  const { data: session } = useSession()
  const [page, setPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [data, setData] = useState([]);
  const [allUserData, setAllUserData] = useState<any>([]);
  const { setRenderData, setOpenDialog } = useAllowedNavigation();
  const { resData, handleGetData, isLoading: loadProjectData } = useGet();
  const { handleUpdateData } = usePatch();
  const { handleUpdateData: updateProjectApproval } = usePatch()
  const { resData: getUser, handleGetData: handleGetUsersdata } = useGet();
  const { handleDownloadData } = useDownloadExcel()
  const [queryParams, setQueryParams] = useState({})
  const [selectedDateRange, setSelectedDateRange] = React.useState<any>([null, null]) 
  const [totalItems, setTotalItems] = useState(0);

  const handleChangePage = (event: any, newPage: number) => {
    setPage(newPage+1);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => { 
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(1); 
  };

  function createData(
    id: number,
    sNo: number,
    projectId: string | number,
    projectName: string,
    location: string,
    latitude: string,
    longitude: string,
    assignproject: assignProject,
    projectManagers: assignUserType,
    siteManagers: assignUserType,
    supervisior: assignUserType,
    purchaseManager: assignUserType,
    displayStartDate: string,
    displayEndDate: string,
    startDate: string,
    endDate: string,
    status: string,
    salesStatus: string,
    description?: string
  ): Data {
    return {
      id,
      sNo,
      projectId,
      projectName,
      location,
      latitude,
      longitude,
      assignproject,
      projectManagers,
      siteManagers,
      supervisior,
      purchaseManager,
      displayStartDate,
      displayEndDate,
      startDate,
      endDate,
      status,
      salesStatus,
      description
    };
  }

  const GetAllProjectss = async () => {
    let searchParams = "";
    Object?.entries(queryParams)?.map(([key, value]) => {
      searchParams += `${key}=${value}&`
    }) 
    const details = await handleGetData(`${projects_url}/?page=${page}&limit=${rowsPerPage}&sales=active&${searchParams}`);
    // setPage(1)
    return details;
  };

  const handleFilterInActiveProjects = async (id: number) => {
    let isActive = id === 0 ? true : '';
    try {
      const project = await handleGetData(`${projects_url}?page=${page}&limit=${rowsPerPage}&inActive=${isActive}`);
      return project;
    } catch (err) {
      return err;
    }
  };

  const GetAllUsers = async () => {
    try {
      const details = await handleGetUsersdata(`${all_user_url}?page=1&limit=1000`);
      return details;
    } catch (err) {
      return err;
    }
  };

  const handleUpdateProps = async (
    e: { preventDefault: () => void },
    payload: any
  ) => {
    e.preventDefault();
    const res = await handleUpdateData(project_update_url, payload)
      .then((data) => {
        setRenderData(true);
      })
      .catch((error) => {
        alert(`Invalid Credentials, Try Again ${error.message}`);
      });
    GetAllProjectss();
    setOpenDialog(false);
    return res;
  };

  useEffect(() => {
    GetAllProjectss();
    GetAllUsers();
  }, [page, rowsPerPage]);

  useEffect(() => {
    setTotalItems(resData?.meta?.totalItems)
    const projectData = resData?.items?.map((i: any, index: number) => { 
      const originalStartDate = moment(i?.startDate);
      const originalEndDateDate = moment(i?.endDate);
      const assignSupervisors = i?.assignProject?.filter((assign: any) => assign?.user?.role?.key === "supervisior")
      const assignSiteManager = i?.assignProject?.filter((assign: any) => assign?.user?.role?.key === "siteHead")
      const assignProjectManager = i?.assignProject?.filter((assign: any) => assign?.user?.role?.key === "projectHead")
      const assignPurchaseManager = i?.assignProject?.filter((assign: any) => assign?.user?.role?.key === "purchaseHead")
      const projectStatus = i?.status === 'upcoming' ? 'Upcoming' : i?.status === 'running' ? "In Progress" : i?.status === 'completed' ? 'Completed' : i?.status === 'onhold' ? "On Hold" : i?.status === "resume" ? "In Progress" :  i?.status === "notStartedYet" ? "Not Started Yet" : i?.status;
      const assignProjectsList = i?.assignProject?.filter(fItem => fItem?.user !== null)?.map((item) => item) ;
      const salesStatus = i?.salesStatus === "active" ? "Approved" : i?.salesStatus === "rejected" ? "Rejected" : i?.salesStatus === "pending" ? "Pending" : "Not Specified";
      return createData(
        i?.id,
        (page - 1) * rowsPerPage + index + 1,
        i?.siteId,
        i?.projectName,
        i?.location,
        i?.latitude,
        i?.longitude,       
        assignProjectsList,
        assignProjectManager,
        assignSiteManager,
        assignSupervisors,
        assignPurchaseManager,
        originalStartDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
          ? originalStartDate.format('DD-MM-YYYY')
          : 'Not specified',
        originalEndDateDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
        ? originalEndDateDate.format('DD-MM-YYYY')
        : 'Not specified',
        originalStartDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
          ? originalStartDate.format('YYYY-MM-DD')
          : 'Not specified',
        originalEndDateDate.format('YYYY-MM-DD HH:mm') !== 'Invalid date'
          ? originalEndDateDate.format('YYYY-MM-DD')
          : 'Not specified',
        projectStatus,
        salesStatus,
        i?.description
      );
    });

    setRenderData(true);
    setData(projectData);
    setAllUserData(getUser?.items);
  }, [resData?.items]);

  const filterActiveUser = async (param: any) => {
    setQueryParams((item: any) => {
      return { ...queryParams,
       ["status"]: param.value  
      }}) 
      setPage(1)
  }

  const filterMenuOption = [
    { id: 3, menuText: 'Upcoming', fun: () => filterActiveUser({ key: 'status', value: 'upcoming' }) },
    { id: 4, menuText: 'In Progress', fun: () => filterActiveUser({ key: 'status', value: 'running' }) },
    { id: 5, menuText: 'On hold', fun: () => filterActiveUser({ key: 'status', value: 'onhold' }) },
    { id: 6, menuText: 'Completed', fun: () => filterActiveUser({ key: 'status', value: 'completed' }) },
  ]

  const searchTableData = async (value: any) => { 
    setQueryParams((item: any) => {
      return { ...queryParams,
       ["q"]: value, 
      }}) 
      setPage(1)
  };

  const handleApproveProject = async (
    payload: any
  ) => {
    const url = project_update_url;
    const res = await updateProjectApproval(url, payload)
    setRenderData(true);
    GetAllProjectss();
    setOpenDialog(false);
    return res;
  };

  const handleExcelExport = async () => {
    let searchParams = "";
    Object.entries(queryParams)?.map(([key, value]) => {
      searchParams += `&${key}=${value}`
    })
    const res = handleDownloadData(`${projects_url}/?page=${page}&limit=${rowsPerPage}&type=xls${searchParams}`, 'Project')
    return res;
  }

  const filterOnProject = async(e:any) => {  
      if (Array.isArray(e)) {
         const startDate = formateDate(e?.[0]?.$d);
         const endDate = formateDate(e?.[1]?.$d);
        setSelectedDateRange(e) 
        if((startDate !== 'NaN-NaN-NaN') && (endDate !== 'NaN-NaN-NaN')){ 
          setQueryParams((value: any) => {
            return { ...queryParams,
             ["startDate"]: startDate,   
             ['endDate']: endDate
            }}) 
        }
       } 
      // setPage(1)
    }
  
    useEffect(() => {
      GetAllProjectss()
    }, [queryParams, page, rowsPerPage])

    const resetFilter = async() => { 
      setQueryParams({})  
      setSelectedDateRange([null, null]) 
      setPage(1)
      await GetAllProjectss()
    }  

  return (
    <>
      <Wrapper>
        <HeadingBox>
          <Blankbox>
            <Heading>Projects</Heading>
          </Blankbox>
          <Blankbox>
            {
              ((session?.user?.role_id === 1) || (session?.user?.role_id === 2)) &&
              <CommonDialog title="Add Project">
                <MainForm
                  data={{
                    projectName: '',
                    siteId: '',
                    location: '',
                    latitude: '',
                    longitude: '',
                    startDate: '',
                    endDate: "",
                    description: '',
                    projectHead: null,
                    siteHead: [],
                    supervisior: [],
                    purchaseHead: [],
                    status: ''
                  }}
                  url={project_update_url}
                  title={'Add Project'}
                  refreshData={GetAllProjectss}
                  selectItem={allUserData}
                />
              </CommonDialog>
              }
          </Blankbox>
        </HeadingBox>

        <TableBox>
          <TableContainer>
            <TableMain
              selectedDateRange={selectedDateRange}
              handleExcelExport={handleExcelExport}
              filterMenuOption={filterMenuOption}
              handleFilterInActiveProjects={handleFilterInActiveProjects}
              isLoading={loadProjectData}
              columns={projectColumns}
              rows={data}
              page={page}
              resetFilter={resetFilter}
              filterOnProject={filterOnProject}
              rowsPerPage={rowsPerPage}
              handleChangePage={handleChangePage}
              handleChangeRowsPerPage={handleChangeRowsPerPage}
              handleUpdateProps={handleUpdateProps}
              refreshTableData={GetAllProjectss}
              selectItems={allUserData}
              title={'Project'}
              editData={{
                project: {
                  id: 1,
                  projectName: '',
                  location: '',
                  startDate: '',
                  endDate: '',
                  status: ''
                },
                assignProject: {
                  projectId: null,
                  projectManager: [],
                  supervisior: [],
                  purchaseManager: [],
                  siteManager: []
                }
              }}
              url={project_update_url}
              searchTableData={searchTableData}
              handleApproveProject={handleApproveProject}
              totalItems={totalItems}
            />
          </TableContainer>
        </TableBox>
      </Wrapper>  
    </>
  );
};

export default withAuth(Projects, [0, 1, 2, 3]); 
