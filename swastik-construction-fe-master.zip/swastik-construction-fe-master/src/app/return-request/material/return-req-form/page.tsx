'use client'
import React from 'react'
import MaterialReturnRequestForm from '../../../../components/common-form/ReturnMaterialRequest' 
import withAuth from '../../../../hooks/withAuth'
import { useSelector } from 'react-redux' 
import { MainFormLayout } from '../../../../components/Modal/styles'
import { Alert, CardContent, Typography } from '@mui/material'
import { MainConteiner } from '../../../../common/styles/common-form/styles'
import { HeadingBox} from 'src/common/styles/Users/styles'
import {Blankbox} from 'src/components/Table/styles'

const MaterialReturnReqForm = () => {
    const selectedProject = useSelector((state: any) => state?.selectedProject);  
 
    return (
        <>
         <HeadingBox>
          <Blankbox> 
                <Typography sx={ {   flex: 1 } } variant="h5" component="div">
                   Create Return Request
              </Typography>  
          </Blankbox>
         </HeadingBox> 
            <MainConteiner>
                <CardContent>
                  { !!selectedProject?.selectedValue?.name ?  
                  <>
                   {
                    selectedProject?.selectedValue?.status === "completed" ? 
                        <Alert variant="standard" severity="error"> 
                          Can't create request for completed projects
                        </Alert>
                        : 
                        <MainFormLayout>
                                <MaterialReturnRequestForm
                                    data={{
                                        projectId: selectedProject?.selectedValue?.id,
                                        projectName: selectedProject?.selectedValue?.name,
                                        location: selectedProject?.selectedValue?.location,
                                        machineryOrPrductId: null,
                                        typeId: null,
                                        quantity: '',
                                        unit: '',
                                        remark: '',
                                        size: ''
                                    }}
                                    title={'Material Request'} 
                                />
                        </MainFormLayout>  
                   }
                  </>
                  : 
                      <Alert variant="standard" severity="error"> 
                         Please select any project...
                      </Alert> 
                  }
                </CardContent>
            </MainConteiner>
        </>
    )
}

export default withAuth(MaterialReturnReqForm, [2, 4, 5]) 