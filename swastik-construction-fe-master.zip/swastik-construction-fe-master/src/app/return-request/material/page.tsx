"use client"
import React from 'react'
import withAuth from '../../../hooks/withAuth'
import ReturnMaterial from '../../../components/ReturnRequest/Material/page'

const ReturnMaterialRequest = () => {
    return (
        <><ReturnMaterial /></>
    )
}

export default withAuth(ReturnMaterialRequest, [2, 3, 4, 5])