 'use client'
import React, { useEffect, useState } from 'react' 
import withAuth from '../../../../../hooks/withAuth' 
import useGet from '../../../../../hooks/useGet'
import { MainFormLayout } from '../../../../../components/Modal/styles'
import { CardContent, Typography } from '@mui/material'
import { MainConteiner } from '../../../../../common/styles/common-form/styles'
import { category_url, return_request_url } from '../../../../../constants/api-routes'
import { useParams } from 'next/navigation'
import RequestUpdate from 'src/view/material-request-update/ReturnRequestUpdate'

function createRequestData(
  sNo: any,
  reqId: string,
  productName: any,
  location: any,
  type: any,
  categoryName: any,
  projectId: any,
  projectName: any,
  quantity: any,
  approveStatus: any,
  senderName: any,
  items: any,
  requestedDate: any,
  createdById: any,
): any {
  return { 
    sNo,
    reqId,
    productName,
    location,
    type,
    categoryName,
    projectId,
    projectName,
    quantity,
    approveStatus,
    senderName,
    items,
    requestedDate,
    createdById, 
  }
}

const UpdateReturnRequest = () => {
  const params = useParams<{ tag: string; item: string }>()
  const {resData ,handleGetData} = useGet()
  const [updateData, setUpdateData] = useState({})
  const {resData: catItems, handleGetData:handleGetCatItems} = useGet()

  const getCategory = async () => {
      const category = await handleGetCatItems(`${category_url}?type=1`);
      return category;
  }
  
  const getRequestData = () => {
      const res = handleGetData(`${return_request_url}/${params?.reqId}`)
      return res;
  }

  useEffect(() => {
    getRequestData()
    getCategory()
  }, [])

  let obj :any= {}, sNo:number, productName:string, location: string, categoryName:string, projectId:number, projectName:string ,quantity: number, status:string, requesterName:string, createdAt:string, createdById:number, items:any = [];
  useEffect(() => { 
        if(!!resData?.length ){
          resData?.map((item:any, index:number) => {
            const reqId = item?.returnRequest;
            obj = item?.items?.map((sItem:any) => { 
                sNo = index + 1, 
                reqId, 
                productName = sItem?.materialDetails?.productName, 
                location = sItem?.projectDetails?.location, 
                categoryName = sItem?.materialDetails?.category?.categoryName,
                projectId = sItem?.projectId,
                projectName = sItem?.projectDetails?.projectName,
                quantity = sItem?.quantity,
                status = sItem?.status,
                requesterName = sItem?.Sender?.name,
                createdAt = sItem?.createdAt,
                createdById = sItem?.createdById,
                items.push({
                  id: sItem?.id,
                  reqId,
                  machineryOrPrductId: sItem?.materialId,
                  materialId: sItem?.materialId,
                  machineryOrPrductName: sItem?.materialDetails?.productName, 
                  itemName : (sItem?.materialDetails !== null) ? (sItem?.materialDetails?.itemName) : (sItem?.machineryDetails !== null) ? (sItem?.machineryDetails?.itemName) : 'Null',
                  specification : (sItem?.materialDetails !== null) ? (sItem?.materialDetails?.specification) : (sItem?.machineryDetails !== null) ? (sItem?.machineryDetails?.specification) : 'Null',
                  size : (sItem?.materialDetails !== null) ? (sItem?.materialDetails?.size) : (sItem?.machineryDetails !== null) ? (sItem?.machineryDetails?.size) : 'Null',
                  unit: sItem?.materialDetails?.unit,
                  quantity: sItem?.quantity,
                  remark: sItem?.remark,
                  typeId: sItem?.typeId,
                  categoryId: sItem?.materialDetails?.categoryId,
                  siteAvailableQuantity: sItem?.siteAvailableQuantity,
                  projectId : sItem?.projectId,
                })
            }) 
            obj = createRequestData(sNo, reqId, productName, location, 'Material', categoryName, projectId, projectName, quantity, status, requesterName, items, createdAt, createdById )
          })
        }
        setUpdateData(obj)
  }, [resData])   


  return (
    <>
      <MainConteiner>
        <CardContent>
        <Typography sx={ { my: 2, flex: 1 } } variant="h5" component="div">
            Material Request
          </Typography> 
          <MainFormLayout> 
            <RequestUpdate  
              updateData={updateData}  
              catItems={catItems}
              refreshTableData={getRequestData}/> 
          </MainFormLayout>
        </CardContent>
      </MainConteiner>
    </>
  )
}

export default withAuth(UpdateReturnRequest, [2, 3, 4, 5])