import axios from 'axios';
import { baseUrl } from '../constants/api-routes';
import { signOut } from 'next-auth/react';

const axiosInstance = axios.create({
  baseURL: baseUrl,
});

axiosInstance.interceptors.request.use(
  (config) => {
    const token =
      typeof window !== 'undefined' ? localStorage.getItem('token') : '';
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

const getRequestAPI = async (url: string) => {
  const result = await axiosInstance
    .get(url)
    .then((response) => {
      if (response.status == 200) {
        return response;
      }
    })
    .catch((error) => {
      if (
        error?.response?.data?.MESSAGE === 'jwt expired' ||
        error?.response?.data?.MESSAGE === 'login_again'
      ) {
        signOut({ callbackUrl: "/auth/signin" })
      }
    });
  return result;
};

export default getRequestAPI;
