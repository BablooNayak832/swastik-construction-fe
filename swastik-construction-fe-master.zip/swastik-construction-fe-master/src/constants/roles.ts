export const roles = [
  { id: 0, label: 'Super Admin' },
  { id: 1, label: 'Admin' },
  { id: 2, label: 'Project Head' },
  { id: 3, label: 'Purchase Head' },
  { id: 4, label: 'Site Head' },
  { id: 5, label: 'Supervisor' },
];
