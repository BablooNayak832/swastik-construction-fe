import { TypeColumn } from './../Interfaces/Typeinterface';
import { CategoryColumn } from '../Interfaces/CategoryInterface';
import {
  SubCategoryColumn,
  projectListDashboard,
} from '../Interfaces/SubCategoryinterface';
import { InventoryColumn } from '../Interfaces/InventoryInterface';
import {
  projectAssignedColumn,
  projectColumn,
} from '../Interfaces/ProjectsInterface';
import { RoleColumn } from '../Interfaces/Roleinterface';
import { UserColumn } from '../Interfaces/Userinterface';
import { TableColumn } from '../Interfaces/Tableinterface';
import { StoreColumn } from '../Interfaces/Storeinterface';
import { MaterialColumn } from '../Interfaces/Materialinterface';
import { BrandColumn } from '../Interfaces/BrandInterface'; 

export const storecolumns: readonly StoreColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'storeName', label: 'Store Name', minWidth: 70 },
  { id: 'storeLocation', label: 'Store Location', minWidth: 70 },
  { id: 'availableQuantity', label: 'Available Quantity', minWidth: 70 },
];

export const storeinventorycolumns: readonly StoreColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'category', label: 'Category', minWidth: 70 },
  { id: 'subCategory', label: 'Sub Category', minWidth: 70 },
  { id: 'quantity', label: 'Quantity', minWidth: 70 },
  { id: 'type', label: 'type', minWidth: 70 },
  { id: 'brand', label: 'brand', minWidth: 70 },
];

export const materialcolumns: readonly MaterialColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'name', label: 'Name', minWidth: 70 },
  { id: 'image', label: 'Image', minWidth: 70 },
];

export const typecolumns: readonly TypeColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'name', label: 'Name', minWidth: 70 },
  { id: 'image', label: 'Image', minWidth: 70 },
];

export const brandcolumns: readonly BrandColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'name', label: 'Name', minWidth: 70 },
  { id: 'image', label: 'Image', minWidth: 70 },
];
export const usercolumns: readonly UserColumn[] = [
  { id: 'sNo', label: 'S No.', minWidth: '80px' },
  { id: 'name', label: 'Name', minWidth: '150px' },
  { id: 'email', label: 'Email', minWidth: '70px' },
  { id: 'mobileNumber', label: 'Number', minWidth: '70px' },
  { id: 'role', label: 'Role', minWidth: '150px' },
  { id: 'userStatus', label: 'Status', minWidth: '70px', align: 'center' },
];

export const adminUserColumn: readonly any[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'userName', label: 'Name', minWidth: 70 },
  { id: 'createBy', label: 'Created By', minWidth: 70 },
  { id: 'userNumber', label: 'Mobile Number', minWidth: 70 },
  // { id: 'status', label: 'status', minWidth: 70 },
  { id: 'userEmail', label: 'email', minWidth: 70 },
  { id: 'createdAt', label: 'Created At', minWidth: 70 },
  { id: 'role', label: 'Role ', minWidth: 50 },
];

export const rolecolumns: readonly RoleColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'Roles', label: 'Role', minWidth: 170 },
  { id: 'Created_By', label: 'Created By', minWidth: 170 },
  { id: 'Permission', label: 'Permission', minWidth: 170 },
];
export const categorycolumns: CategoryColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 50 },
  { id: 'category', label: 'Category', minWidth: 50 },
  { id: 'images', label: 'Images', minWidth: 120 },
  { id: 'type', label: 'Type', minWidth: 120 },
  { id: 'createby', label: 'Create By', minWidth: 50 },
];
export const approvedReqColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'reqId', label: 'Request No.', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'senderName', label: 'Sender Name', minWidth: 70 },
  { id: 'reqApproveStatus', label: 'Status', minWidth: 70 }, 
];

export const subCategoryColumns: SubCategoryColumn[] = [
  { id: 'id', label: 'S No.', align: 'center' },
  { id: 'subcategory', label: 'Sub Category', align: 'right' },
  { id: 'img', label: 'img', align: 'right' },
  { id: 'category', label: 'Category', align: 'center' },
];

export const projectListDashboardColumn: projectListDashboard[] = [
  { id: 'projectName', label: 'PROJECT NAME', align: 'left', minWidth: 150 },
  { id: 'siteId', label: 'PROJECT ID', align: 'left', minWidth: 150 },
  {
    id: 'location',
    label: 'LOCATION',
    minWidth: 150,
    align: 'left',
    format: (value: number) => value.toLocaleString('en-US'),
  },
];

export const projectColumns: readonly projectColumn[] = [
  { id: 'sNo', label: 'S No.', minWidth: '80px', align: 'center' },
  { id: 'projectId', label: 'Project Id', minWidth: '150px' },
  { id: 'projectName', label: 'Project', minWidth: '150px' },
  { id: 'location', label: 'Location', minWidth: '150px' },
  { id: 'displayStartDate', label: 'Start Date', minWidth: '150px' },
  { id: 'displayEndDate', label: 'End Date', minWidth: '150px' },
  { id: 'status', label: 'Project Status', minWidth: '150px' },
  { id: 'assignproject', label: 'Assigned users', minWidth: '50px' },
  // { id: 'salesStatus', label: 'Approve Status', minWidth: '50px' },
  {
    id: 'approvedOrReject',
    label: 'Project Approval',
    minWidth: '50px',
    textAlign: 'center',
  },
];

export const siteStaffColumns: readonly any[] = [
  { id: 'sNo', label: 'S No.', minWidth: '80px', align: 'center' },
  { id: 'name', label: 'Name', minWidth: '150px' },
  { id: 'projectName', label: 'Project', minWidth: '150px' },
  { id: 'mobileNumber', label: 'Mobile Number', minWidth: '150px' },
  { id: 'image', label: 'Image', minWidth: '150px' },
];

export const projectColumnsForSales: readonly any[] = [
  { id: 'sNo', label: 'S No.', minWidth: '75px', align: 'center' },
  { id: 'projectId', label: 'Project Id', minWidth: '150px' },
  { id: 'projectName', label: 'Project', minWidth: '120px' },
  { id: 'location', label: 'Location', minWidth: '150px' },
  { id: 'assignproject', label: 'Assigned users', minWidth: '50px' },
  { id: 'startDate', label: 'Start Date', minWidth: '150px' },
  { id: 'endDate', label: 'End Date', minWidth: '150px' },
  { id: 'status', label: 'Project Status', minWidth: '100' },
  { id: 'salesStatus', label: 'Approve Status', minWidth: '50px' },
  {
    id: 'approvedOrReject',
    label: 'Project Approval',
    minWidth: '50px',
    textAlign: 'center',
  },
];

export const inventoryColumns: readonly InventoryColumn[] = [
  { id: 'id', label: 'S No.', minWidth: 50 },
  { id: 'category', label: 'Category', minWidth: 70 },
  { id: 'itemName', label: 'Name', minWidth: 70 },
  { id: 'subCategory', label: 'Sub category', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'quantity', label: 'Quantity', minWidth: 70 },
  { id: 'orderBy', label: 'Order By', minWidth: 70 },
  { id: 'deliveredDate', label: 'Delivered date', minWidth: 70 },
  { id: 'vendorName', label: 'Vendor Name', minWidth: 70 },
  { id: 'transferredBy', label: 'Transferred by', minWidth: 70 },
];
export const vendorColumns: readonly any[] = [
  { id: 'sNo', label: 'S No.', minWidth: '80px', align: 'center' },
  { id: 'name', label: 'Name', minWidth: '100px', align: 'center' },
  { id: 'address', label: 'Address', minWidth: '100px', align: 'center' },
  { id: 'contact', label: 'Contact', minWidth: '100px', align: 'center' },
  { id: 'GSTIN', label: 'GSTIN', minWidth: '250px', align: 'center' },
  { id: 'category', label: 'Category', minWidth:  '200px', align: 'center' },
  {
    id: 'verifiedByAdmin',
    label: 'Status',
    minWidth: '100px',
    align: 'center',
  },
];

export const attendanceListColumns: readonly any[] = [
  { id: 'sNo', label: 'S No.', minWidth: '80px', align: 'center' },
  { id: 'user', label: 'Name', minWidth: '150px', align: 'center' },
  {
    id: 'checkInAddress',
    label: 'Clock In Address',
    minWidth: '150px',
    align: 'center',
  },
  {
    id: 'checkInDate',
    label: 'Date', 
    minWidth: '150px',
    align: 'center',
  },
  {
    id: 'checkInTime',
    label: 'Clock In Time',
    minWidth: '150px',
    align: 'center',
  },
  {
    id: 'checkoutAddress',
    label: 'Clock Out Address',
    minWidth: '150px',
    align: 'center',
  },
  {
    id: 'checkOutTime',
    label: 'Clock Out Time',
    minWidth: '150px',
    align: 'center',
  },
  { id: 'userRole', label: 'Role', minWidth: '100px', align: 'center' },
  {
    id: 'attendanceMarkedBy',
    label: 'Attendance Marked by',
    minWidth: '100px',
    align: 'center',
  },
  {
    id: 'attandanceStatus',
    label: 'Attendance Status',
    minWidth: '100px',
    align: 'center',
  }, 
];

export const headers: TableColumn[] = [
  {
    id: 'action',
    label: 'Action',
    minWidth: 150,
    align: 'center',
  },
];

export const projectAssignedColumns: readonly projectAssignedColumn[] = [
  { id: 'sNo', label: 'S No.', minWidth: '80px', align: 'center' },
  { id: 'projectName', label: 'Project', minWidth: '150px', align: 'center' },
  { id: 'uniqueid', label: 'Project Id', minWidth: '100px', align: 'center' },
  { id: 'location', label: 'Location', minWidth: '250px', align: 'center' },
  { id: 'status', label: 'Status', minWidth: '150px', align: 'center' },
  { id: 'startDateFormat', label: 'Start Date', minWidth: '150px', align: 'center' },
  { id: 'endDateFormat', label: 'End Date', minWidth: '150px', align: 'center' },
];

export const purchaseOrderColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: '80px', align: 'center' },
  {
    id: 'purchaseOrderNo',
    label: 'Purchase Order No',
    minWidth: '170px',
    align: 'center',
    width: '180px',
  },
  {
    id: 'requestId',
    label: 'Request Id',
    minWidth: '150px',
    align: 'center',
    width: '180px',
  },
  { id: 'projectName', label: 'Project', minWidth: '70px', align: 'center' },
   { id: 'createdAt', label: 'Date', minWidth: '120px', align: 'center'},
  { id: 'status', label: 'Status', minWidth: '70px', align: 'center' },
];
 
export const poDashboardColumn: any = [
  { id: 'sNo', label: 'S No.', minWidth: '50px', align: 'center' },
  {
    id: 'poNo',
    label: 'PO No.',
    minWidth: '80px',
    align: 'center',
    width: '180px',
  },
  // {
  //   id: 'requestId',
  //   label: 'Req. Id',
  //   minWidth: '150px',
  //   align: 'center',
  //   width: '180px',
  // },
  { id: 'projectName', label: 'Project', minWidth: '70px', align: 'center' },
  { id: 'poStatus', label: 'Status', minWidth: '70px', align: 'center' },
];

export const machineryRequestColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'reqId', label: 'Request No.', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'senderName', label: 'Sender Name', minWidth: 70 },
  { id: 'approveStatus', label: 'Status', minWidth: 70 },
];

export const materialRequestColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 100 },
  { id: 'reqId', label: 'Request No.', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'location', label: 'Location', minWidth: 70 },
  { id: 'senderName', label: 'Sender Name', minWidth: 70 },
  { id: 'requestedDate', label: 'Requested Date', minWidth: 70 },
  { id: 'reqApproveStatus', label: 'Status', minWidth: 70 },
];

export const approvedMaterialReqColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'reqId', label: 'Request No.', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'senderName', label: 'Sender Name', minWidth: 70 },
  { id: 'approvedBy', label: 'Approved By', minWidth: 70 },
  { id: 'reqStatus', label: 'Status', minWidth: 70 },
];

export const materialReturnReqColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'reqId', label: 'Request No.', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'projectLocation', label: 'Location', minWidth: 70 },
  { id: 'senderName', label: 'Sender Name', minWidth: 70 },
  { id: 'approveStatus', label: 'Status', minWidth: 70 },
];

export const materialReportColumns: any = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'materialName', label: 'Material Name', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'startDate', label: 'Start Date', minWidth: 70 },
  { id: 'machineryName', label: 'Machinery ', minWidth: 70 },
  { id: 'productName', label: 'Product ', minWidth: 70 },
  { id: 'approvedMaterial', label: 'Approved Material', minWidth: 70 },
  { id: 'assigedUsers', label: 'Assiged Users', minWidth: 70 },
];

export const projectReportColumns: any = [
  { id: 'id', label: 'S No.', minWidth: 70 },
  { id: 'projectName', label: 'Project Name', minWidth: 70 },
  { id: 'startDate', label: 'Start Date', minWidth: 70 },
  { id: 'machineryOrPrductId', label: 'Machinery / Prduct', minWidth: 70 },
  { id: 'approvedMaterial', label: 'Approved Material', minWidth: 70 },
  { id: 'assigedUsers', label: 'Assiged Users', minWidth: 70 },
];

export const invetoryCategoryColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 50 },
  { id: 'categoryName', label: 'Name', minWidth: 70 },
  { id: 'type', label: 'Type', minwidth: 100 },
];

export const inventoryMachineryColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'machineryName', label: 'Name', minWidth: 70 },
  { id: 'categoryName', label: 'Category', minWidth: 70 },
  { id: 'size', label: 'Size', minWidth: 70 },
  { id: 'unit', label: 'Unit', minWidth: 70 },
];

export const inventoryMaterialColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 100 },
  { id: 'image', label: 'Image', minWidth: 120 },
  { id: 'categoryName', label: 'Category', minWidth: 170 },
  { id: 'productName', label: 'Name', minWidth: 170 },
  { id: 'brandItems', label: 'Brands', minWidth: 170 },
  { id: 'itemName', label: 'Type / Grade', minWidth: 170 },
  { id: 'specification', label: 'Specification', minWidth: 70 },
  { id: 'size', label: 'Size', minWidth: 100 },
  { id: 'unit', label: 'Unit', minWidth: 100 },
];

export const siteInventoryColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'projectName', label: 'Project', minWidth: 180 },
  { id: 'productName', label: 'Product Name', minWidth: 70 },
  { id: 'category', label: 'Category', minWidth: 70 },
  { id: 'itemName', label: 'Type / Grade', minWidth: 70 },
  { id: 'specification', label: 'Specification', minWidth: 70 },
  { id: 'size', label: 'Size', minWidth: 70 },
  { id: 'unit', label: 'Unit', minWidth: 70 },
  { id: 'availableQuantity', label: 'Available Quantity', minWidth: 70 },
];

export const CentralMaterialInventoryColumns: any = [
  { id: 'sNo', label: 'S No.', minWidth: 70 },
  { id: 'materialName', label: 'Item', minWidth: 70 },
  { id: 'type', label: 'Type', minWidth: 70 },
  { id: 'category', label: 'Category', minWidth: 70 },
  { id: 'itemName', label: 'Type / Grade', minWidth: 70 },
  { id: 'specification', label: 'Specification', minWidth: 70 },
  { id: 'size', label: 'Size', minWidth: 70 },
  { id: 'unit', label: 'Unit', minWidth: 70 },
  { id: 'availableQuantity', label: 'Available Quantity', minWidth: 70 },
];

export const inventoryTablecolumns: readonly any[] = [
  { id: 'id', label: 'S No.', minWidth: 50 },
  {
    id: 'itemName',
    label: 'Name',
    minWidth: 50,
    align: 'center',
  },
  { id: 'category', label: 'Category', minWidth: 50 },
  {
    id: 'subCategory',
    label: 'Sub Category',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'projectName',
    label: 'Project Name',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'quantity',
    label: 'Total Quantity',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'availableQuantity',
    label: 'Available Quantity',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'totalTransferQuantity',
    label: 'Total Transfered Quantity',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'orderBy',
    label: 'Order By',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'deliveredDate',
    label: 'Delivered Date',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'vendorName',
    label: 'Vendor Name',
    minWidth: 50,
    align: 'center',
  },
  {
    id: 'transferredBy',
    label: 'Transferred By',
    minWidth: 70,
    align: 'center',
  },
];

const ITEM_HEIGHT = 50;
const ITEM_PADDING_TOP = 8;
export const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 'auto',
    },
    sx: {
      boxShadow: '1px 2px 10px #0c0c0c !important', 
    '.MuiMenu-list': {
      paddingTop: 0,
      paddingBottom: 0, 
     }
    }
  },
};
