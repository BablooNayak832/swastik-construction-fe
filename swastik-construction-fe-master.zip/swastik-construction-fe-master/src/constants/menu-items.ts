import { UserRoleEnum } from '../components/Enum/rolesEnum';
import dashboardIcons from '../../assets/svg/DashboardIcons';
import { ProjectIcon } from '../../assets/svg/ProjectIcon';
import { StoreIcon } from '../../assets/svg/StoreIcon';
import { StockInventoryIcon } from '../../assets/svg/StockInventoryIcon';
import { ReportIcon } from '../../assets/svg/ReportIcon';
import { BrandIcon } from '../../assets/svg/BrandIcon';
import { UserIcon } from '../../assets/svg/UserIcon'; 

type MenuOption = {
  id: number;
  name: string;
  isExpanded?: boolean;
  icon?: any;
  url?: string;
  subItems?: MenuOption[];
  role?: UserRoleEnum[];
};

const MENU_OPTIONS: MenuOption[] = [
  {
    id: 1,
    name: 'Dashboard',
    isExpanded: false,
    icon: dashboardIcons,
    url: '/',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.ProjectHead,
      UserRoleEnum.PurchaseManager,
      UserRoleEnum.SiteManager,
      UserRoleEnum.SuperVisior,
      UserRoleEnum.SalesRepresentative,
    ],
  },
  {
    id: 2,
    name: 'User Management',
    isExpanded: false,
    icon: UserIcon,
    url: '/users',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.ProjectHead,
    ],
  },
  {
    id: 3,
    name: 'Project Management',
    isExpanded: false,
    icon: ProjectIcon,
    url: '/projects',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.PurchaseManager,
    ],
  },
  {
    id: 4,
    name: 'Project Management',
    isExpanded: false,
    icon: ProjectIcon,
    url: '/project-assigned',
    role: [
      UserRoleEnum.SuperVisior,
      UserRoleEnum.SiteManager,
      UserRoleEnum.SalesRepresentative,
      UserRoleEnum.ProjectHead,
    ],
  },
  {
    id: 5,
    name: 'Inventory',
    isExpanded: false,
    icon: StockInventoryIcon,
    role: [UserRoleEnum.SuperAdmin, UserRoleEnum.Admin, UserRoleEnum.PurchaseManager],
    subItems: [
      {
        id: 1,
        name: 'Category',
        icon: () => null,
        url: '/stock-inventory/category',
        role: [UserRoleEnum.SuperAdmin, UserRoleEnum.Admin, UserRoleEnum.PurchaseManager],
      },
      {
        id: 1,
        name: 'Brand',
        icon: () => null,
        url: '/stock-inventory/brand',
        role: [UserRoleEnum.SuperAdmin, UserRoleEnum.Admin, UserRoleEnum.PurchaseManager],
      },
      {
        id: 1,
        name: 'Material',
        icon: () => null,
        url: '/stock-inventory/product',
        role: [UserRoleEnum.SuperAdmin, UserRoleEnum.Admin, UserRoleEnum.PurchaseManager],
      },
    ],
  },
  {
    id: 6,
    name: 'Central Inventory',
    isExpanded: false,
    icon: StoreIcon,
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.PurchaseManager,
      UserRoleEnum.ProjectHead,
    ],
    subItems: [
      {
        id: 1,
        name: 'Material',
        icon: () => null,
        url: '/central-inventory/material-inventory',
        role: [
          UserRoleEnum.SuperAdmin,
          UserRoleEnum.Admin,
          UserRoleEnum.PurchaseManager,
          UserRoleEnum.ProjectHead,
        ],
      }, 
    ],
  },
  {
    id: 8,
    name: 'Sales Management',
    isExpanded: false,
    icon: StoreIcon,
    url: '/sales-management/project',
    role: [UserRoleEnum.SuperAdmin, UserRoleEnum.Admin],
  },
  {
    id: 9,
    name: 'Request Management',
    isExpanded: false,
    icon: BrandIcon,
    url: '/request-management',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.SiteManager,
      UserRoleEnum.SuperVisior,
      UserRoleEnum.ProjectHead,
    ],
    subItems: [
      {
        id: 1,
        name: 'Material',
        icon: () => null,
        url: '/request-management/material-request',
        role: [
          UserRoleEnum.SuperAdmin,
          UserRoleEnum.Admin,
          UserRoleEnum.SiteManager,
          UserRoleEnum.SuperVisior,
          UserRoleEnum.SuperAdmin,
          UserRoleEnum.ProjectHead,
        ],
      }, 
      {
        id: 3,
        name: 'Verification',
        icon: () => null,
        url: '/request-management/request-verification',
        role: [
          UserRoleEnum.SiteManager,
          UserRoleEnum.SuperVisior,
          UserRoleEnum.SuperAdmin,
          UserRoleEnum.Admin,
          UserRoleEnum.ProjectHead
        ],
      },
    ],
  },
  {
    id: 10,
    name: 'Request Management',
    isExpanded: false,
    icon: BrandIcon,
    url: '/request-management',
    role: [UserRoleEnum.PurchaseManager],
    subItems: [
      {
        id: 3,
        name: 'Material',
        icon: () => null,
        url: '/approved/material-request',
        role: [UserRoleEnum.PurchaseManager],
      }, 
    ],
  },
  {
    id: 16,
    name: 'Return Request',
    isExpanded: false,
    icon: BrandIcon,
    role: [
      UserRoleEnum.SiteManager,
      UserRoleEnum.ProjectHead,
      UserRoleEnum.SuperVisior,
    ],
    subItems: [
      {
        id: 16.1,
        name: 'Material',
        icon: () => null,
        url: '/return-request/material',
        role: [
          UserRoleEnum.SiteManager,
          UserRoleEnum.ProjectHead,
          UserRoleEnum.SuperVisior,
        ],
      }, 
    ],
  },
  {
    id: 11,
    name: 'Vendor Management',
    isExpanded: false,
    icon: StoreIcon,
    url: '/vendor',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.PurchaseManager,
    ],
  },
  {
    id: 12,
    name: 'Staff Management',
    isExpanded: false,
    icon: ProjectIcon,
    url: '/staff-management',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.ProjectHead,
      UserRoleEnum.SiteManager
    ],
  },
  {
    id: 13,
    name: 'Attendance Management',
    isExpanded: false,
    icon: ProjectIcon,
    url: '/attendance-management',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.ProjectHead,
    ],
  },
  {
    id: 14,
    name: 'Purchase Management',
    isExpanded: false,
    icon: ProjectIcon,
    url: '/purchase-management',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.PurchaseManager,
    ],
  },
  {
    id: 15,
    name: 'Site Inventory',
    isExpanded: false,
    icon: BrandIcon,
    role: [
      UserRoleEnum?.SuperAdmin,
      UserRoleEnum?.Admin,
      UserRoleEnum.ProjectHead,
      UserRoleEnum.SiteManager,
      UserRoleEnum?.PurchaseManager 
    ],
    subItems: [
      {
        id: 15.1,
        name: 'Material',
        icon: () => null,
        url: '/site-inventory/material',
        role: [
          UserRoleEnum?.SuperAdmin,
          UserRoleEnum?.Admin,
          UserRoleEnum.ProjectHead,
          UserRoleEnum.SiteManager,
          UserRoleEnum?.PurchaseManager 
        ],
      }, 
    ],
  },
  {
    id: 16,
    name: 'DPR',
    isExpanded: false,
    icon: StoreIcon,
    url: '/dpr-management',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.ProjectHead,
      UserRoleEnum.SiteManager,
      UserRoleEnum.SuperVisior,
    ],
  },
  {
    id: 17,
    name: 'Reporting',
    isExpanded: false,
    icon: ReportIcon,
    url: '/reports',
    role: [
      UserRoleEnum.SuperAdmin,
      UserRoleEnum.Admin,
      UserRoleEnum.ProjectHead,
      UserRoleEnum.SiteManager,
      UserRoleEnum.SuperVisior,
    ],
    subItems: [
      {
        id: 1,
        name: 'DPR',
        icon: () => null,
        url: '/reports/daily-progress-report',
        role: [
          UserRoleEnum.SuperAdmin,
          UserRoleEnum.Admin,
          UserRoleEnum.ProjectHead,
          UserRoleEnum.SiteManager,
          UserRoleEnum.SuperVisior,
        ],
      },
      {
        id: 1,
        name: 'Site Inventory',
        icon: () => null,
        url: '/reports/site-inventory',
        role: [
          UserRoleEnum.SuperAdmin,
          UserRoleEnum.Admin,
          UserRoleEnum.ProjectHead,
          UserRoleEnum.SiteManager,
          UserRoleEnum.SuperVisior,
        ],
      }, 
    ],
  },
  {
    id: 18,
    name: 'Settings',
    isExpanded: false,
    icon: StoreIcon,
    url: '/settings',
    role: [],
  },
];

export type MenuItem = {
  name: string;
  isExpanded: boolean;
  icon: React.ComponentType;
  url: string;
  id: string;
  depth: number;
  subItems?: MenuItem[];
  role?: any;
};

function makeMenuLevel(options: MenuOption[], depth = 0): MenuItem[] {
  return options?.map((option, idx) => ({
    ...option,
    id: depth === 0 ? idx.toString() : `${depth}.${idx}`,
    depth,
    subItems:
      option?.subItems && option?.subItems?.length > 0
        ? makeMenuLevel(option?.subItems, depth + 1)
        : undefined,
  }));
}

export const MENU_ITEMS: any = makeMenuLevel(MENU_OPTIONS);
