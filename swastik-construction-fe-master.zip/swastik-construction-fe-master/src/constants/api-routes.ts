// updated api url
export const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
export const baseImgUrl = process.env.NEXT_PUBLIC_BASE_IMG_URL;
export const login = process.env.NEXT_PUBLIC_LOGIN || '';
export const get_roles_url: string =
  process.env.NEXT_PUBLIC_GET_ROLES_URL || '';
export const user_url = process.env.NEXT_PUBLIC_USER_URL || '';
export const all_user_url: string = process.env.NEXT_PUBLIC_ALL_USER_URL || '';

export const user_get_count: string =
  process.env.NEXT_PUBLIC_USER_GET_COUNT || '';

export const particular_user: string =
  process.env.NEXT_PUBLIC_PARTICULAR_USER || '';

export const user_assigned_projects: string =
  process.env.NEXT_PUBLIC_USER_ASSIGNED_PROJECTS || '';

export const projects_url: string = process.env.NEXT_PUBLIC_PROJECT_URL || '';
export const category_url: string = process.env.NEXT_PUBLIC_CATEGORY_URL || '';
export const material_url: string = process.env.NEXT_PUBLIC_MATERIAL_URL || '';

export const machinery_url: string =
  process.env.NEXT_PUBLIC_MACHINERY_URL || '';

export const material_request_url: string =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_URL || '';

export const is_checkin_attendance_url =
  process.env.NEXT_PUBLIC_IS_CHECKIN_ATTENDANCE_URL || '';

export const attendance_url = process.env.NEXT_PUBLIC_ATTENDANCE_URL || '';

export const project_update_url =
  process.env.NEXT_PUBLIC_PROJECT_UPDATE_URL || '';

export const purchase_order_url =
  process.env.NEXT_PUBLIC_PURCHASE_ORDER_URL || '';

export const purchase_order_detail_url =
  process.env.NEXT_PUBLIC_PURCHASE_ORDER_DETAIL_URL || '';

export const material_request_data =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_DATA || '';

export const material_request_add_item =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_ADD_ITEM || '';

export const material_request_item_delete_url: string =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_ITEM_DELETE || '';

export const return_request: string =
  process.env.NEXT_PUBLIC_RETURN_REQUEST || '';

export const return_request_url: string =
  process.env.NEXT_PUBLIC_RETURN_REQUEST_URL || '';

export const site_inventory_url: string =
  process.env.NEXT_PUBLIC_SITE_INVENTORY_URL || '';

export const site_staff_labour_url: string =
  process.env.NEXT_PUBLIC_SITE_STAFF_LABOUR_URL || '';

export const vendor_url: string = process.env.NEXT_PUBLIC_VENDOR || '';

export const user_update_password =
  process.env.NEXT_PUBLIC_USER_UPDATE_PASSWORD || '';

export const central_inventory_url =
  process.env.NEXT_PUBLIC_CENTRAL_INVENTORY_URL || '';

export const notification_url: string =
  process.env.NEXT_PUBLIC_NOTIFICATION_URL || '';

export const notification_pending_requests: string =
  process.env.NEXT_PUBLIC_NOTIFICATION_PENDING_REQUEST_URL || '';

export const materialRequestGetNotification =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_GET_NOTIFICATION || '';

export const type_list = process.env.NEXT_PUBLIC_TYPE_LIST || '';
export const type_url = process.env.NEXT_PUBLIC_TYPE_URL || '';

export const inventory_graph_data =
  process.env.NEXT_PUBLIC_INVENTORY_GRAPH_DATA || '';

export const project_count = process.env.NEXT_PUBLIC_PROJECT_COUNT || '';

export const brand_url = process.env.NEXT_PUBLIC_BRAND_URL || '';

export const materialRequestList: string =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_URL || '';

export const materialRequestUpdate: string =
  process.env.NEXT_PUBLIC_MATERIAL_REQUEST_UPDATE || '';

export const verifyMaterial: string =
  process.env.NEXT_PUBLIC_VERIFY_MATERIAL_URL || '';

export const brandExcel: string =
  process.env.NEXT_PUBLIC_BRAND_EXCEL_URL || ''; 
  
export const categoryExcel: string =
  process.env.NEXT_PUBLIC_CATEGORY_EXCEL_URL || '';

export const materialExcel: string =
  process.env.NEXT_PUBLIC_MATERIAL_EXCEL_URL || '';
