import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export const downloadComponentAsPDF = (componentId: any, filename: any) => {
  const pdfWidth = 595.28;
  const pdfHeight = 700;

  const input = document.getElementById(componentId);
  html2canvas(input).then((canvas) => {
    const imgData = canvas.toDataURL('image/png');

    // Get original canvas width and height
    const imgWidth = canvas.width;
    const imgHeight = canvas.height;

    // Calculate aspect ratio
    const ratio = imgWidth / imgHeight;

    // Calculate the new dimensions based on desired PDF width
    const pdfImgWidth = pdfWidth;
    const pdfImgHeight = pdfWidth / ratio;

    const pdf = new jsPDF({
      orientation: pdfWidth > pdfHeight ? 'landscape' : 'portrait',
      unit: 'pt',
      format: [pdfWidth, pdfHeight],
    });

    // Add the image with new dimensions
    pdf.addImage(imgData, 'PNG', 0, 0, pdfImgWidth, pdfImgHeight);
    pdf.save(`${filename}.pdf`);
  });
};
