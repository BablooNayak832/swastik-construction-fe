'use client';
import { useEffect, useState } from "react";
import { onMessage, MessagePayload } from "firebase/messaging";
import { messaging } from "../firebase/index";
import { toast } from "react-toastify";
import useFCMToken from "./useFCMToken";

const useFCM = () => {
  const fcmToken = useFCMToken();
  const [messages, setMessages] = useState<MessagePayload[]>([]);

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      const fcmmessaging = messaging();
      const unsubscribe = onMessage(fcmmessaging,(payload) => {
        console.log("Foreground message received:", payload);
        toast(`${payload.notification?.title}: ${payload.notification?.body}`);
        setMessages((prevMessages) => [...prevMessages, payload]);
      });
      return () => unsubscribe();
    }
  }, [fcmToken])

  return { fcmToken, messages };
};

export default useFCM;