'use client';
import { useEffect, useState } from "react";
import { getMessaging, getToken, isSupported } from "firebase/messaging";
import useNotificationPermissionStatus from "./useNotificationPermission";

const useFCMToken = () => {
  const permission = useNotificationPermissionStatus();
  const [fcmToken, setFcmToken] = useState<string | null>(null);

  useEffect(() => {
    const fetchToken = async () => {
      if (permission === "granted") {
        const isFcmSupported = await isSupported();
        if (!isFcmSupported) return;
        navigator.serviceWorker.register("/firebase-messaging-sw.js").then(async (registration) => {
          const messaging = getMessaging();
          const token = await getToken(messaging, {
            vapidKey:'BCBTWg1_DxJjURyw93injrQo1HXepO-j1s6y09TSNdDtT_O5_5uMdfmCFeN4FvmwAd_Z-eY-pWbyEd9N6afmOvY',
            serviceWorkerRegistration: registration,
          });
          if (token) {
            setFcmToken(token);
            localStorage.setItem("fcmToken", token);
          } else {
            console.warn("No FCM registration token available.");
          }
        }).catch((err) => {
          console.error("Service Worker registration failed:", err);
        });
      }
    };
    fetchToken();
  }, [permission]);

  return fcmToken;
};

export default useFCMToken;