'use client';
import { useEffect, useState } from "react";

const useNotificationPermissionStatus = () => {
  const [permission, setPermission] = useState<NotificationPermission>("default");

  useEffect(() => {
    const updatePermission = () => setPermission(Notification.permission);

    Notification.requestPermission().then(updatePermission);
    navigator.permissions.query({ name: "notifications" }).then((result) => {
      result.onchange = updatePermission;
    });
  }, []);

  return permission;
};

export default useNotificationPermissionStatus;