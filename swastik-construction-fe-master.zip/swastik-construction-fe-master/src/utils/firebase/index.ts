import { FirebaseOptions, initializeApp } from "firebase/app";  
import { getMessaging } from "firebase/messaging"
 
const firebaseConfig : FirebaseOptions = {
   apiKey : process.env.NEXT_PUBLIC_FIREBASE_API_KEY,  
   authDomain : "swastik-73b7d.firebaseapp.com",
   projectId : "swastik-73b7d",
   storageBucket : "swastik-73b7d.firebasestorage.app",
   messagingSenderId : "832372446744",
   appId : process.env.NEXT_PUBLIC_FIREBASE_APPID 
};

// Initialize Firebase
const app = initializeApp(firebaseConfig); 
export const messaging = () => getMessaging(app);
export default app;