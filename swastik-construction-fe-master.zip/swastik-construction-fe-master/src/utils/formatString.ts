export function formatString(str: any) {
  if (!str) return str;
  // Check if the string contains uppercase letters indicating camelCase
  if (/[A-Z]/.test(str)) {
    // Convert camelCase to spaced words and capitalize the first letter
    return str.toLowerCase().replace(/\s+/g, ' ').trim().split(' ').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' '); 
    // return str
    //   .replace(/([A-Z])/g, ' $1')
    //   .replace(/^./, (str: string) => str.toUpperCase());
  } else {
    // Capitalize the first letter for lowercase words
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}

export function stringCapitalization(str: any) {
  if (!str) return str;
  // Check if the string contains uppercase letters indicating camelCase
  if (/[A-Z]/.test(str)) {
    // Convert camelCase to spaced words and capitalize the first letter
    return str
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str: string) => str.toUpperCase());
  } else {
    // Capitalize the first letter for lowercase words
    return str.charAt(0).toUpperCase() + str.slice(1);
  }
}