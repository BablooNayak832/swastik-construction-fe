export const formateDate = (date: any) => {
  if (date === null) {
    return;
  }
  const newDate = new Date(date);
  const year = newDate.getFullYear();
  const month = String(newDate?.getMonth() + 1).padStart(2, '0'); // getMonth() returns 0-based month
  const day = String(newDate?.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`; //`${day}-${month}-${year}`;
};
