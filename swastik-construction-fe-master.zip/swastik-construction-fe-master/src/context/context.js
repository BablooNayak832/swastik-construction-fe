/* eslint-disable react/jsx-filename-extension */
'use client';
import { createContext, useState, useContext } from 'react';
export const ThemeContext = createContext();
function MetadataContext({ children }) {
  const [allowedNavigation, setAllowedNavigation] = useState([]);
  const [user, setUser] = useState('');
  const [open, setOpen] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [data, setData] = useState([]); 
  const [allOptions, setOption] = useState([]);
  const [openEndModal, setOpenEndModal] = useState(false);
  const [isRenderData, setRenderData] = useState(false);
  const [errors, setErrors] = useState({});
  const [noficationAccepted, setNotificationAccepted] = useState(false);
  const [loaded, setLoaded] = useState(true);
  const [ isResLoading, setResLoading ]=useState(false) 
  return (
    <ThemeContext.Provider
      value={{
        data,
        setData,
        user,
        setUser,
        allowedNavigation,
        setAllowedNavigation,
        open,
        setOpen, 
        allOptions,
        setOption,
        openDialog,
        setOpenDialog,
        openEndModal,
        setOpenEndModal,
        isRenderData,
        setRenderData,
        errors,
        setErrors,
        setNotificationAccepted,
        noficationAccepted,
        loaded,
        setLoaded,
        isResLoading,
        setResLoading
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}
export const useAllowedNavigation = () => useContext(ThemeContext);
export default MetadataContext;
