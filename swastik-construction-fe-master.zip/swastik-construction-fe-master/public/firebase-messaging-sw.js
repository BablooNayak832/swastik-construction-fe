importScripts("https://www.gstatic.com/firebasejs/9.0.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging-compat.js");

fetch("/firebase-config.json")
  .then((response) => response.json())
  .then((config) => {
    firebase.initializeApp(config.firebaseConfig);
    const messaging = firebase.messaging();
    messaging.onBackgroundMessage((payload) => {
      console.log("Background message received:", payload);
      const { title, body, icon } = payload.notification || {};
      if (title && body) {
        self.registration.showNotification(title, { body, icon });
      }
    });
  })
  .catch((error) => {
    console.error("Error initializing Firebase in service worker:", error);
  });