import React from 'react'

function ArrowIcons() {
    return (
        <div>

            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="5" viewBox="0 0 10 5" fill="none">
                <path d="M8.99988 4.49997C8.99988 4.49997 6.05392 0.500009 4.99985 0.5C3.94577 0.499991 0.999878 4.5 0.999878 4.5" stroke="black" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}

export default ArrowIcons