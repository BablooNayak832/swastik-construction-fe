import React from 'react'

export const ReportIcon = () => {
    return (
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                <path d="M17.0833 14.6071V8.83332C17.0833 5.69063 17.0833 4.11928 16.107 3.14297C15.1307 2.16666 13.5593 2.16666 10.4166 2.16666H9.58329C6.4406 2.16666 4.86925 2.16666 3.89294 3.14297C2.91663 4.11928 2.91663 5.69063 2.91663 8.83332V16.75" stroke="black" strokeOpacity="0.8" strokeLinecap="round" />
                <path d="M17.0833 14.6667H4.99996C3.84937 14.6667 2.91663 15.5994 2.91663 16.75C2.91663 17.9006 3.84937 18.8333 4.99996 18.8333H17.0833" stroke="black" strokeOpacity="0.8" strokeLinecap="round" />
                <path d="M17.0833 18.8333C15.9327 18.8333 15 17.9006 15 16.75C15 15.5994 15.9327 14.6667 17.0833 14.6667" stroke="black" strokeOpacity="0.8" strokeLinecap="round" />
                <path d="M12.5 6.33333L7.5 6.33333" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M10 9.66666L7.5 9.66666" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}
