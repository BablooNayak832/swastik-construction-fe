import React from 'react'

export const CreditNoteIcon = () => {
    return (
        <>
        <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 2048 2048" width="30" height="30">
         <path transform="translate(372,257)" d="m0 0h1302l18 3 16 5 17 8 12 8 10 8 14 14 11 15 8 15 6 16 4 18 1 8v1298l-4 22-7 19-9 17-9 12-9 10-7 7-17 12-15 8-21 7-15 3-10 1h-1290l-16-2-18-5-16-7-14-8-14-11-11-11-10-13-10-17-6-15-4-14-2-13-1-20v-1270l2-19 4-17 6-16 8-15 10-14 4-5h2l2-4 12-11 17-11 16-8 16-5zm8 86-13 4-8 6-5 5-6 8-4 10-1 6v1285l4 13 7 10 9 8 11 5 8 2h1282l13-3 12-7 7-7 5-9 3-8 1-10v-1278l-3-13-6-10-5-6-11-7-12-4z"/>
         <path transform="translate(1024,426)" d="m0 0h84l2 1v84h84l2 2-1 84-3 1h-204l-16 3-12 5-11 8-6 10-2 5-1 6v10l4 13 6 10 7 6 12 6 11 2h22l89-1h76l17 3 16 5 17 8 12 8 10 8 14 14 12 17 10 21 5 17 3 21v14l-3 21-5 16-7 16-10 15-9 11-8 7-14 11-18 10-22 8-23 5-18 2-35 1-1 83-1 1h-85l-1-1v-84h-169v-86l286-1 16-2 13-4 13-7 7-7 5-10 1-5v-14l-3-10-6-10-4-5-10-6-7-3-5-1h-39l-79 1h-68l-21-3-17-5-19-9-14-10-10-9-11-11-10-14-9-17-5-14-4-16-2-18 1-18 4-20 7-19 8-14 10-13 7-8 8-7 14-10 16-9 18-7 21-5 15-2 37-1 5 1v-83z"/>
         <path transform="translate(597,1109)" d="m0 0h853l1 1v83l-3 2h-850l-1-1z"/>
         <path transform="translate(597,1365)" d="m0 0h853l1 1v83l-3 2h-850l-1-1z"/>
        </svg>
           {/* <svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 2048 2048" width="2rem" height="2rem">
             <path transform="translate(342,129)" d="m0 0h1364v1787h-1249l2-2 16-5 21-9 16-8 19-11 17-12 16-13 15-14 4-4 1045 1v-1632h-1208v1140l-4 1-15-2-59-1z" fill="#5969CD"/>
             <path transform="translate(363,1362)" d="m0 0h42l25 3 27 6 21 7 19 8 25 13 18 12 13 10 14 12 17 17 9 11 8 10 12 18 12 21 10 23 9 27 5 24 3 22 1 26-1 23-4 27-4 19-9 27-8 18-12 23-12 18-10 13-12 14-17 17-11 9-13 10-15 10-22 12-20 9-27 9-23 5-20 3-11 1h-38l-25-3-24-5-19-6-21-8-16-8-20-11-14-10-14-11-12-11-19-19-11-14-10-14-12-20-13-27-11-33-5-25-3-25v-38l4-31 6-25 9-26 7-16 11-20 14-21 11-14 11-12 9-10 11-10 14-11 14-10 15-9 21-11 23-9 19-6 24-5zm1 65-25 4-24 7-21 9-18 10-17 12-14 12-14 14-11 14-9 13-9 16-8 17-7 21-5 23-2 19v26l3 24 4 17 7 21 12 25 10 16 11 14 12 13 9 9 14 11 13 9 16 9 17 8 24 8 19 4 18 2h31l22-3 20-5 20-7 19-9 16-10 11-8 11-9 14-13 9-11 10-13 10-16 8-16 8-21 6-22 3-20v-41l-4-24-6-21-8-20-11-21-11-16-9-11-14-15-14-12-17-12-18-10-15-7-24-8-25-5-8-1z" fill="#5969CD"/>
             <path transform="translate(567,927)" d="m0 0h909v42h-910v-41z" fill="#5969CD"/>
             <path transform="translate(570,798)" d="m0 0h908l1 1v41h-910v-41z" fill="#5969CD"/>
             <path transform="translate(569,1065)" d="m0 0h910v41l-47 1h-862l-1-1z" fill="#5969CD"/>
             <path transform="translate(573,507)" d="m0 0h313l4 2 1 3v196l-2 3-48 1h-160l-110-1-2-3-1-26v-128l1-45zm35 39-1 8v118l1 1h244v-127z" fill="#5969CD"/>
             <path transform="translate(566,1339)" d="m0 0h377l1 1v41h-378z" fill="#5969CD"/>
             <path transform="translate(569,1202)" d="m0 0h378v41l-1 1h-377z" fill="#5969CD"/>
             <path transform="translate(1101,1712)" d="m0 0h378v41l-2 1h-375l-1-1z" fill="#5969CD"/>
             <path transform="translate(1101,653)" d="m0 0h378v41l-9 1h-368l-1-1z" fill="#5969CD"/>
             <path transform="translate(617,1476)" d="m0 0h329l1 1v41l-306 1-4-4-11-22-9-15z" fill="#5969CD"/>
             <path transform="translate(285,1610)" d="m0 0h200l7 6v42l-3 1-2 4h-204l-5-6v-40z" fill="#5969CD"/>
             <path transform="translate(1236,1339)" d="m0 0h242l1 1v41h-243l-1-21v-16z" fill="#5969CD"/>
             <path transform="translate(1236,1202)" d="m0 0h243v41l-1 1h-242l-1-23v-14z" fill="#5969CD"/>
             <path transform="translate(1236,1476)" d="m0 0h242l1 1v41h-243l-1-21v-16z" fill="#5969CD"/>
             <path transform="translate(1132,271)" d="m0 0h23l5 8 19 39 11 23 5 12v-63l1-18 1-1h21l2 2v130l-2 1h-23l-5-9-8-16-20-41-7-16v81l-2 1h-21l-2-4v-126z" fill="#5A6ACE"/>
             <path transform="translate(628,271)" d="m0 0h47l14 3 9 5 7 7 5 11 1 5v20l-4 12-6 8-7 6-2 1 1 5 21 42 1 7-2 1h-24l-3-4-11-23-10-21-1-1-12-1v49l-2 1h-22l-1-1v-131zm24 24v36h14l10-2 6-4 3-5 1-5v-8l-4-8-5-3-5-1z" fill="#5969CD"/>
             <path transform="translate(1285,269)" d="m0 0h16l9 2 11 6 9 8 7 11 5 13 3 15v25l-3 16-4 11-6 11-4 5h-2l-1 3-11 7-13 4h-17l-10-3-10-6-6-5-7-10-5-11-4-14-1-7v-26l3-15 5-13 6-9 7-8 10-6 7-3zm3 25-9 5-6 8-4 9-2 11v21l4 16 5 8 5 5 8 4h8l9-4 6-7 5-12 2-11v-21l-4-16-6-9-5-4-7-3z" fill="#5A6ACD"/>
             <path transform="translate(832,271)" d="m0 0h37l12 2 12 5 8 6 8 9 6 12 3 10 2 17v11l-3 20-5 13-7 11-10 9-11 5-14 3h-40l-1-2v-128zm24 23-1 1v85l2 1 15-2 8-4 8-9 4-12 2-14-1-15-3-12-6-10-7-5-11-3z" fill="#5969CD"/>
             <path transform="translate(1462,271)" d="m0 0h70l1 1v23l-47 1v27h39l1 1v22l-1 1h-39v32l49 1v23l-1 1h-73l-1-3v-127z" fill="#5969CD"/>
             <path transform="translate(734,271)" d="m0 0h71l1 1v23l-46 1-1 27h39l1 1v22l-1 1h-39l1 32h30l17 1 1 1v22l-1 1h-73l-1-3v-128z" fill="#5969CD"/>
             <path transform="translate(1603,206)" d="m0 0h26l2 17v16l-1 2 2 1v10l-1 3 1 9v1513l1 3-1 5v14l-1 2 2 1-1 13-1 6-1 14-2 4v-1632h-25z" fill="#6172DF"/>
             <path transform="translate(564,269)" d="m0 0h16l10 3 9 6 8 7 1 3-10 13-3 4-4-2-9-6-5-2h-9l-9 4-7 8-5 11-2 11v18l3 14 6 11 6 5 7 3h10l9-4 9-8 5 3 10 13-2 4-7 8-11 7-10 3h-18l-12-4-11-7-8-9-7-12-4-13-2-11v-24l4-18 8-16 7-9 10-8 12-5z" fill="#5969CD"/>
             <path transform="translate(984,271)" d="m0 0h87l2 1 1 5v17l-1 1-31 1-1 107-1 1h-23l-2-6v-103l-24 1-7-1-1-1v-20z" fill="#5C6CCE"/>
             <path transform="translate(1354,271)" d="m0 0h87l2 1v23l-31 1-1 107-1 1h-23l-2-3v-106l-26 1-6-2v-21z" fill="#5969CE"/>
             <path transform="translate(941,271)" d="m0 0h23l2 1v131l-2 1h-22l-1-1-1-33v-60z" fill="#5C6BCE"/>
             <path transform="translate(342,129)" d="m0 0 4 1 1 5-2 4 1 9 1 3-1 3v9l1 13-1 7 1 7-1 5 1 2-2 7 2 1-1 3v23l1 4-1 3v15l1 2-1 13v1026l-1 17-2 2z" fill="#6071DE"/>
             <path transform="translate(570,508)" d="m0 0h3l1 5-1 6v52l-1 3v99l1 8-1 2v15l-1 2h2l1 11-4-1-1-2-1-26v-128l1-45z" fill="#5F70DA"/>
             <path transform="translate(1101,1712)" d="m0 0 4 1 1 5h-2v5l1 5v17l2 7 369 1v-36l-2-1 3-4h2v41l-2 1h-375l-1-1z" fill="#6172DF"/>
             <path transform="translate(1101,653)" d="m0 0 4 1 1 5h-2v5l1 5v14l2 10 362 1v1h-367l-1-1z" fill="#6172DF"/>
             <path transform="translate(1236,1476)" d="m0 0h226v1l-223 1v23l1 9 1 6 3 1-8 1-1-21v-16z" fill="#6071DE"/>
             <path transform="translate(852,548)" d="m0 0h1l2 22v80l-1 15-2 3z" fill="#6172DF"/>
             <path transform="translate(1460,274)" d="m0 0 2 1 1 121 2 5 4 3h-8l-1-3z" fill="#6273DF"/>
             <path transform="translate(1101,1712)" d="m0 0 4 1 1 5h-2v5l1 5v17l2 7h17l3 2h-25l-1-1z" fill="#5F70DB"/>
             <path transform="translate(1101,653)" d="m0 0 4 1 1 5h-2v5l1 5v14l2 10h15l1 2h-21l-1-1z" fill="#5F70DB"/>
             <path transform="translate(1704,129)" d="m0 0h2l-1 97h-1l-1-61-1-8 1-10v-7l-2-6v-2l-28-1v-1z" fill="#6172DF"/>
             <path transform="translate(1236,1203)" d="m0 0 4 1-2 6v2l1 8v12l2 10h12v2h-17l-1-23v-14z" fill="#5E6FD9"/>
             <path transform="translate(567,927)" d="m0 0h52v1h-50v7l-1 5 2 1v17l1 9 2 1h-6z" fill="#6071DE"/>
             <path transform="translate(1236,1340)" d="m0 0h3v6l-3 2h2l1 10v11l2 8v2l4 1-9 1-1-21v-16z" fill="#6172DF"/>
             <path transform="translate(1477,1202)" d="m0 0h2v41l-1 1h-45v-1l14-1h29l1-10v-21l-2-6z" fill="#6172DF"/>
             <path transform="translate(945,1202)" d="m0 0h2v41l-1 1h-46v-1l16-1 28 1 1-7v-26l-1-7z" fill="#6071DD"/>
             <path transform="translate(1463,1339)" d="m0 0h15l1 1v41l-4-1 2-11-1-24v-4l-13-1z" fill="#6172DF"/>
             <path transform="translate(945,1476)" d="m0 0 2 1v41l-5-1 2-1-1-4 1-1 1-29-3-1z" fill="#6172DD"/>
             <path transform="translate(1477,653)" d="m0 0h2v41l-3-1 1-33h-2l-1-3z" fill="#5C6CD4"/>
             <path transform="translate(1477,1476)" d="m0 0 2 1v41l-3-1-1-5h2v-30h-2z" fill="#6172DF"/>
             <path transform="translate(570,1211)" d="m0 0 2 4v17l2 10h10l1 2h-16z" fill="#6071DE"/>
             <path transform="translate(1477,1712)" d="m0 0h2v41l-2-4-1-32-2-1z" fill="#5C6CD4"/>
             <path transform="translate(570,1066)" d="m0 0 3 1-1 10v17l2 7v4l-4 2-1-5z" fill="#6172DF"/>
             <path transform="translate(1534,389)" d="m0 0h1v14l-1 1h-64v-1l62-1z" fill="#6273DF"/>
             <path transform="translate(886,508)" d="m0 0 4 1 1 3v25l-2 1-1-11 1-14-3-1v-3z" fill="#6172DF"/>
             <path transform="translate(570,807)" d="m0 0 2 4v12l1 10 1 4v2l-5 1z" fill="#6071DE"/>
             <path transform="translate(1237,1232)" d="m0 0h2l2 10h12v2h-17v-9z" fill="#6172DF"/>
             <path transform="translate(943,1361)" d="m0 0h1v20h-12v-1l9-1 1-10v-7z" fill="#6071DD"/>
             <path transform="translate(342,129)" d="m0 0 4 1 1 5-3 4-1 9h-1z" fill="#5E6ED8"/>
             <path transform="translate(1477,653)" d="m0 0h2l-1 28h-1v-21h-2l-1-3z" fill="#6172DF"/>
             <path transform="translate(462,1913)" d="m0 0 4 1 18 1v1h-27l2-2z" fill="#6373DB"/>
             <path transform="translate(570,1095)" d="m0 0 3 1 1 9-4 2-1-5z" fill="#6071DE"/>
             <path transform="translate(1477,1712)" d="m0 0h2l-1 25h-1l-1-20-2-1z" fill="#6172DF"/>
             <path transform="translate(1236,1340)" d="m0 0h3v6l-3 2h2l-1 5h-2v-9z" fill="#5F70DC"/>
             <path transform="translate(1704,149)" d="m0 0h1v17l-2-1-1-8 1-7z" fill="#6071DE"/>
             <path transform="translate(1236,1203)" d="m0 0 4 1-2 6v2l1 4-4 1v-10z" fill="#6071DD"/>
             <path transform="translate(929,1339)" d="m0 0h14l1 2-1 7-1-3-3-1 1-3-11-1z" fill="#6172DF"/>
             <path transform="translate(983,274)" d="m0 0h1l1 17 3 3-4 1-1-1z" fill="#6172DF"/>
           </svg> */}
        </>
    )
}