import React from 'react'

export const StockInventoryIcon = () => {
    return (
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                <path d="M17.5 18H8.33333C5.58347 18 4.20854 18 3.35427 17.1457C2.5 16.2915 2.5 14.9165 2.5 12.1667V3" stroke="black" strokeOpacity="0.8" strokeLinecap="round" />
                <path d="M14.754 8.27779L12.3592 12.1538C12.0102 12.7186 11.614 13.5717 10.8957 13.4453C10.0509 13.2967 9.64514 12.0374 8.91882 11.6205C8.32733 11.2809 7.89972 11.6901 7.55392 12.1667M17.5 3.83334L15.9553 6.33334M4.16663 17.1667L6.27189 14.0556" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}
