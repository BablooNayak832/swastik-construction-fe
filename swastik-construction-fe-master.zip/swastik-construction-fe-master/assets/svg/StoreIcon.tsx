import React from 'react'

export const StoreIcon = () => {
    return (
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
                <path d="M14 1.16667V2.83334M4 1.16667V2.83334" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M7.33333 13.6667L7.33332 10.6227C7.33332 10.4629 7.21938 10.3333 7.07882 10.3333H6.5M10.358 13.6667L11.4868 10.6243C11.5396 10.4821 11.4274 10.3333 11.2672 10.3333H9.83333" stroke="black" strokeOpacity="0.8" strokeLinecap="round" />
                <path d="M1.08337 9.7027C1.08337 6.07161 1.08337 4.25607 2.12681 3.12803C3.17024 2 4.84962 2 8.20837 2H9.79171C13.1505 2 14.8298 2 15.8733 3.12803C16.9167 4.25607 16.9167 6.07161 16.9167 9.7027V10.1306C16.9167 13.7617 16.9167 15.5773 15.8733 16.7053C14.8298 17.8333 13.1505 17.8333 9.79171 17.8333H8.20837C4.84962 17.8333 3.17024 17.8333 2.12681 16.7053C1.08337 15.5773 1.08337 13.7617 1.08337 10.1306V9.7027Z" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M4 6.16667H14" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}
