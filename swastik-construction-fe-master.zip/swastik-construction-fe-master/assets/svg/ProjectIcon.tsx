import React from 'react'

export const ProjectIcon = () => {
    return (
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none">
                <path d="M3.31668 11.247C2.2687 11.8613 -0.47903 13.1155 1.19452 14.685C2.01204 15.4517 2.92255 16 4.06727 16H10.5993C11.744 16 12.6545 15.4517 13.4721 14.685C15.1456 13.1155 12.3979 11.8613 11.3499 11.247C8.89241 9.80658 5.77417 9.80658 3.31668 11.247Z" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M10.6667 4.33333C10.6667 6.17428 9.17428 7.66667 7.33333 7.66667C5.49238 7.66667 4 6.17428 4 4.33333C4 2.49238 5.49238 1 7.33333 1C9.17428 1 10.6667 2.49238 10.6667 4.33333Z" stroke="black" strokeOpacity="0.8" />
                <path d="M15.25 1.83331V5.99998M17.3333 3.91665L13.1666 3.91665" stroke="black" strokeOpacity="0.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}
