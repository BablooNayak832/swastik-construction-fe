/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    domains: ['localhost', 'portal.swastikhabitates.com'],
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  env: {
    NEXTAUTH_SECRET: "mQ46qpFwfE1BHuqMC+qlm19qBAD9fVPgh28werwe3ASFlAfnKjM=",
    NEXTAUTH_URL: process.env.NEXT_PUBLIC_CURRENT_URL,
  },
  distDir: "build",
};

module.exports = nextConfig;
