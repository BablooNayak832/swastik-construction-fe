# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2025-02-21
Fix the UI issue

## [1.1.0] - 2025-02-25
## Remove
.env.save
.env.save.1
.env.save.2

## Added
add confirmation dialog on delete material from generate PO and delete contractor in DPR 

## Change
change image in profile page
fix issue on download PO pdf summary
fix issue on PO generate for remaining qty and credit qty 
DPR : fix validation on contractor section
Bill upload dialog ui change 
fix ui on varification


## [1.1.0] - 2025-03-04
## Change
Fix issue on delete material in request approval page
fix update material on request approval 
validate email on update user 


## 2025-03-24
fixed PO quantity 
fixed approved material request list serial number 
remove edit access from approved material request list for purchase head

## 2025-05-26
remove machinery page from stock inventory
Add date column in PO listing page
Add category while creating brand
Replace machinery count to material count in dashboard

## 2025-06-16
If no email is given when creating a user, set the default value to null